# Example Usage in a GitHub Action
The following YML is an example usage of this action. This setup uses GitHub Action [permissions](https://docs.github.com/en/actions/using-jobs/assigning-permissions-to-jobs) to establish an OIDC token with Azure. Documentation for establishing that 
connectivity can be found [here](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-azure).

## Configuration Settings
In the example below, there are several secrets and variables in use. Those settings are:
* `secrets.ARM_CLIENT_ID` - the client ID of an Azure service principal or application that has at least `List` and `Get` permissions on the keyvault(s) you intend to monitor, and `Update` permissions on the secrets in the keyvault.
* `secrets.ARM_SUBSCRIPTION_ID` - the Azure Subscription ID of above client
* `secrets.ARM_TENANT_ID` - the Azure Tenant ID of the above client
* `secrets.KT_INTERAL_REPO_KEY` - this is a secret provisioned at the krogertechnology organization level, and gives access to use this action in your workflow
* `vars.KEYVAULT_NAME` - the name (not ID) of the Azure keyvault to monitor.
* `vars.KEYVAULT_MONITOR_INFORMATION_URL` - this is ideally a confluence page or some other informational page having details about the keyvault(s) you are monitoring. This URL will be included in the notification, and should give some context about what the secrets are used for, how to refresh them, etc.
* `vars.KEYVAULT_MONITOR_TEAMS_NOTIFICATION_WEBHOOK_URL` - this action currently only supports notiications via a Teams channel, so this should be the webhook URL for that teams channel. See [this documentation](https://learn.microsoft.com/en-us/microsoftteams/platform/webhooks-and-connectors/how-to/add-incoming-webhook?tabs=dotnet#create-incoming-webhooks-1) for details on how to configure that.

## Example
```yml
name: Monitor Azure Keyvault Secrets

on: 
  workflow_dispatch:
  schedule:
    # Run this every Monday at 9am
    - cron: '00 9 * * 1'

env:
  ARM_CLIENT_ID: '${{ secrets.ARM_CLIENT_ID }}'
  ARM_SUBSCRIPTION_ID: '${{ secrets.ARM_SUBSCRIPTION_ID }}'
  ARM_TENANT_ID: '${{ secrets.ARM_TENANT_ID }}'

permissions:
  id-token: write
  contents: read

jobs:
  monitor-keyvault:
    name: Monitor Azure Keyvault Secrets - ${{ vars.KEYVAULT_NAME }}
    runs-on:
      - self-hosted
      - aks
    environment: dev
    steps:
      # Kroger self-hosted runners don't have azure CLI, which is needed by the azure login action
      - name: Install Azure CLI
        run: |
          curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

      - name: Azure Login
        id: az-login
        uses: azure/login@v1
        with:
          client-id: ${{ env.ARM_CLIENT_ID }}
          tenant-id: ${{ env.ARM_TENANT_ID }}
          subscription-id: ${{ env.ARM_SUBSCRIPTION_ID }}

      - name: Checkout
        uses: actions/checkout@v4

      # This allows the workflow to be able to access the monitor action from the krogertechnology org
      - name: Generate Token
        uses: krogertechnology/grant-internal-repo-access@v1.2.6
        with:
          # The incorect speling of KT_INTERAL_REPO_KEY is not a typo. It is mis-spelt in the GitHub organizashun sekrets.
          kt-internal-repo-key: ${{ secrets.KT_INTERAL_REPO_KEY }}
          export-environment-variable: true
          override-git-config: true

      - name: Check Expiring Secrets - ${{ vars.KEYVAULT_NAME }}
        uses: krogertechnology/azciam-monitor-keyvault-secrets@v1.0.0
        with:
            dry-run: false
            key-vault-name: ${{ vars.KEYVAULT_NAME }}
            secret-pattern: '.*'
            expiration-window-days: 30
            information-url: ${{ vars.KEYVAULT_MONITOR_INFORMATION_URL }}
            notifier-type: 'teams'
            notifier-config: |
              { 
                "themeColor": "0072C6",
                "webhookUrl": "${{ vars.KEYVAULT_MONITOR_TEAMS_NOTIFICATION_WEBHOOK_URL }}"
              }
```