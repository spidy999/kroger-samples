import { TokenCredential } from '@azure/identity'
import { SecretClient, SecretProperties } from '@azure/keyvault-secrets'
import { addDays, addYears, formatISO, isBefore, parseISO } from 'date-fns'

export class KeyVault {
  readonly secretClient: SecretClient

  constructor(name: string, credential: TokenCredential) {
    this.secretClient = new SecretClient(
      `https://${name}.vault.azure.net/`,
      credential
    )
  }

  async listSecrets(secretNamePattern = /.*/): Promise<AzureKeyVaultSecret[]> {
    const secrets = Array<AzureKeyVaultSecret>()
    for await (const secretProperties of this.secretClient.listPropertiesOfSecrets()) {
      if (secretNamePattern.test(secretProperties.name)) {
        secrets.push(AzureKeyVaultSecret.fromSecretProperties(secretProperties))
      }
    }
    return secrets
  }

  async listExpiringSecrets(
    numberOfDays = 30,
    secretNamePattern = /.*/
  ): Promise<AzureKeyVaultSecret[]> {
    if (numberOfDays < 0) {
      throw new Error(
        `Cannot look for expired secrets in the past (numberOfDays = ${numberOfDays})`
      )
    }

    const secrets = await this.listSecrets(secretNamePattern)

    const expirationBoundary = addDays(new Date(), numberOfDays)

    return secrets.filter(secret => {
      return (
        secret.expiresOn !== undefined &&
        isBefore(secret.expiresOn, expirationBoundary)
      )
    })
  }

  async updateSecretTags(
    secret: AzureKeyVaultSecret
  ): Promise<AzureKeyVaultSecret> {
    const currentSecret = await this.secretClient.getSecret(secret.name)
    if (!currentSecret.properties.version) {
      throw new Error(
        `Secret "${secret.name}" needs a version in order to update tags`
      )
    }

    const response = await this.secretClient.updateSecretProperties(
      secret.name,
      currentSecret.properties.version,
      {
        tags: secret.tags
      }
    )
    return AzureKeyVaultSecret.fromSecretProperties(response)
  }
}

export class AzureKeyVaultSecret implements SecretProperties {
  vaultUrl: string
  version?: string | undefined
  name: string
  id?: string | undefined
  contentType?: string | undefined
  enabled?: boolean | undefined
  notBefore?: Date | undefined
  expiresOn?: Date | undefined
  tags?: { [propertyName: string]: string } | undefined
  keyId?: undefined
  certificateKeyId?: string | undefined
  managed?: boolean | undefined
  createdOn?: Date | undefined
  updatedOn?: Date | undefined
  recoveryLevel?: string | undefined
  recoverableDays?: number | undefined

  private constructor(vaultUrl: string, name: string) {
    this.vaultUrl = vaultUrl
    this.name = name
  }

  static fromSecretProperties(
    secretProperties: SecretProperties
  ): AzureKeyVaultSecret {
    const secret = new AzureKeyVaultSecret(
      secretProperties.vaultUrl,
      secretProperties.name
    )
    Object.assign(secret, secretProperties)
    return secret
  }

  toSecretProperties(): SecretProperties {
    const secretProperties = {} as SecretProperties
    Object.assign(secretProperties, this)
    return secretProperties
  }

  get isAlerted(): boolean {
    return (
      this.tags !== undefined &&
      this.tags['ExpirationAlertSentDate'] !== undefined
    )
  }

  /**
   * The expiration date of this secret - if none is set, this will return a date far in the future (100 years).
   */
  get expirationDate(): Date {
    return this.expiresOn || addYears(new Date(), 100)
  }

  get expirationAlertSentDate(): Date | null {
    if (
      this.tags === undefined ||
      this.tags['ExpirationAlertSentDate'] === undefined
    ) {
      return null
    }

    return parseISO(this.tags['ExpirationAlertSentDate'])
  }

  set expirationAlertSentDate(value: Date) {
    this.tags = this.tags === undefined ? {} : this.tags
    this.tags['ExpirationAlertSentDate'] = formatISO(value)
  }
}
