import axios from 'axios'
import { NotifierConfig } from '../monitor-action'

export enum NotificationPriority {
  HIGH = 1,
  MEDIUM = 2,
  LOW = 3
}

export enum NotifierType {
  TEAMS = 'teams'
}

export interface Notifier {
  sendNotification(
    title: string,
    message: string,
    priority: NotificationPriority
  ): Promise<void>
}

export class TeamsNotifier implements Notifier {
  readonly axiosClient = axios
  constructor(readonly config: TeamsNotifierConfig) {}

  async sendNotification(
    title: string,
    message: string,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    priority: NotificationPriority
  ): Promise<void> {
    const messagePayload = {
      '@type': 'MessageCard',
      '@context': 'http://schema.org/extensions',
      themeColor: this.config.themeColor,
      title,
      text: message
    }

    await this.axiosClient.post(this.config.webhookUrl, messagePayload)
  }
}

export class TeamsNotifierConfig implements NotifierConfig {
  readonly type = NotifierType.TEAMS
  themeColor = '0072C6'

  constructor(readonly webhookUrl: string) {}
}
