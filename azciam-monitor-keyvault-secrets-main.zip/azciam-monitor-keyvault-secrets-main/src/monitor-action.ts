import { DefaultAzureCredential, TokenCredential } from '@azure/identity'
import { AzureKeyVaultSecret, KeyVault } from './services/keyvault'
import {
  NotificationPriority,
  Notifier,
  NotifierType,
  TeamsNotifier,
  TeamsNotifierConfig
} from './services/notifier'
import { format } from 'date-fns'

export class MonitorAction {
  readonly keyVault: KeyVault
  readonly notifier: Notifier
  constructor(
    readonly config: MonitorActionConfig,
    readonly azureCredentials: TokenCredential = new DefaultAzureCredential()
  ) {
    this.keyVault = new KeyVault(config.keyVaultName, azureCredentials)
    switch (config.notifierConfig.type) {
      case NotifierType.TEAMS:
        this.notifier = new TeamsNotifier(
          config.notifierConfig as TeamsNotifierConfig
        )
        break
      default:
        throw Error(
          `Invalid notifier type ${
            config.notifierConfig.type
          }. Only ${NotifierType.TEAMS.toString()} is supported.`
        )
    }
  }

  async process(): Promise<ExpiringSecretResult[]> {
    const expiringSecrets = (
      await this.keyVault.listExpiringSecrets(
        this.config.expirationWindowDays ?? 30,
        this.config.secretPattern ?? /.*/
      )
    ).filter(secret => !secret.isAlerted)

    const results = new Array<ExpiringSecretResult>()

    for (const secret of expiringSecrets) {
      secret.expirationAlertSentDate = new Date()
      const result = {
        secret
      } as ExpiringSecretResult
      try {
        if (!this.config.dryRun) {
          await this.notifier.sendNotification(
            `Azure Keyvault ${this.config.keyVaultName} secret ${secret.name} expiring soon!`,
            `The secret **\`${secret.name}\`** in keyvault **\`${
              this.config.keyVaultName
            }\`** is expiring soon, expiration date is **${format(
              secret.expirationDate,
              'MMMM dd, yyyy'
            )}**.\n\nPlease update this secret as soon as possible, to avoid issues. See [this page](${
              this.config.informationUrl
            }) for more information.`,
            NotificationPriority.LOW
          )
        }
      } catch (e) {
        result.notificationError = e
      }

      if (result.notificationError === undefined && !this.config.dryRun) {
        try {
          await this.keyVault.updateSecretTags(secret)
        } catch (e) {
          result.updateError = e
        }
      }
      results.push(result)
    }

    return results
  }
}

export interface ExpiringSecretResult {
  secret: AzureKeyVaultSecret
  notificationError: unknown | undefined
  updateError: unknown | undefined
}

export interface MonitorActionConfig {
  keyVaultName: string
  secretPattern: RegExp | null
  expirationWindowDays: number | null
  notifierConfig: NotifierConfig
  dryRun: boolean
  informationUrl: string
}

export interface NotifierConfig {
  type: NotifierType
}
