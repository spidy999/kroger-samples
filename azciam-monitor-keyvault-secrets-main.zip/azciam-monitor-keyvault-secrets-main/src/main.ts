import {
  getInput as ghaGetInput,
  getBooleanInput as ghaGetBooleanInput,
  setFailed as ghaSetFailed,
  info as ghaInfo,
  error as ghaError,
  debug as ghaDebug,
  warning as ghaWarning,
  setOutput as ghaSetOutput
} from '@actions/core'
import { MonitorAction, MonitorActionConfig } from './monitor-action'
import { DefaultAzureCredential } from '@azure/identity'
import { format } from 'date-fns'

export async function run(): Promise<void> {
  try {
    const keyVaultNameInput: string = ghaGetInput('key-vault-name', {
      required: true
    })
    const informationUrlInput: string = ghaGetInput('information-url', {
      required: true
    })
    const notifierTypeInput: string = ghaGetInput('notifier-type', {
      required: true
    })
    const notifierConfigInput: string = ghaGetInput('notifier-config', {
      required: true
    })

    const expirationWindowDaysInput: string =
      ghaGetInput('expiration-window-days') || '30'
    const secretPatternInput: string = ghaGetInput('secret-pattern') || '.*'
    const dryRunInput: boolean = ghaGetBooleanInput('dry-run')

    try {
      new RegExp(secretPatternInput)
    } catch (e) {
      throw new Error(
        `secret-pattern ${secretPatternInput} is not a valid regular expression`,
        { cause: e }
      )
    }

    try {
      const exp = parseInt(expirationWindowDaysInput)
      if (exp < 0) {
        throw new Error(
          `expiration-window-days ${exp} must be a positive number`
        )
      }
    } catch (e) {
      throw new Error(
        `expiration-window-days ${expirationWindowDaysInput} is not a valid number`,
        { cause: e }
      )
    }

    try {
      JSON.parse(notifierConfigInput)
    } catch (e) {
      throw new Error(`notification-config must be a valid JSON string`, {
        cause: e
      })
    }

    const config = {
      keyVaultName: keyVaultNameInput.trim(),
      secretPattern: new RegExp(secretPatternInput),
      expirationWindowDays: parseInt(expirationWindowDaysInput),
      dryRun: dryRunInput,
      informationUrl: informationUrlInput.trim(),
      notifierConfig: {
        type: notifierTypeInput,
        ...JSON.parse(notifierConfigInput)
      }
    } as MonitorActionConfig

    ghaInfo(
      `Beginning to process expiring secrets for key vault ${config.keyVaultName}`
    )
    ghaDebug(`Configuration: ${JSON.stringify(config, null, '  ')}`)

    const monitorAction = new MonitorAction(
      config,
      new DefaultAzureCredential()
    )
    const results = await monitorAction.process()
    ghaInfo(
      `Finished processing expiring secrets for key vault ${config.keyVaultName}. ${results.length} secrets were expiring.`
    )
    ghaDebug(`Expiring secrets: ${JSON.stringify(results, null, '  ')}`)

    let isError = false
    for (const r of results) {
      if (r.notificationError !== undefined) {
        isError = true
        ghaError(
          `Could not send notification regarding expiring secret: ${
            config.keyVaultName
          } -> ${r.secret.name} (${format(
            r.secret.expirationDate,
            'MMMM dd, yyyy'
          )})`
        )
        ghaError(JSON.stringify(r.notificationError))
      }
      if (r.updateError !== undefined) {
        ghaWarning(
          `Error updating notification date on expiring secret: ${
            config.keyVaultName
          } -> ${r.secret.name} (${format(
            r.secret.expirationDate,
            'MMMM dd, yyyy'
          )})`
        )
        ghaWarning(JSON.stringify(r.updateError))
      }
    }

    if (isError) {
      ghaSetFailed(`Could not notify for one or more expiring secrets.`)
    }

    ghaSetOutput('expiring-secrets', JSON.stringify(results, null, '  '))
  } catch (error) {
    if (error instanceof Error) {
      ghaSetFailed(error)
    } else {
      ghaSetFailed(JSON.stringify(error))
    }
  }
}
