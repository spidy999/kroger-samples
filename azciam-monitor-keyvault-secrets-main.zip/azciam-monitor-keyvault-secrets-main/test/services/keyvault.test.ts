import { DefaultAzureCredential } from '@azure/identity'
import { AzureKeyVaultSecret, KeyVault } from '../../src/services/keyvault'
import {
  PagedAsyncIterableIterator,
  SecretProperties
} from '@azure/keyvault-secrets'
import { mock } from 'ts-jest-mocker'
import { addDays } from 'date-fns'

describe('KeyVault', () => {
  let fixture: KeyVault

  const curDate = new Date()

  const expiringSecret = {
    name: 'expiring_secret',
    vaultUrl: 'https://vault.url',
    expiresOn: addDays(curDate, 5),
    version: '12345'
  }
  const expiredSecret = {
    name: 'expired_secret',
    vaultUrl: 'https://vault.url',
    expiresOn: addDays(new Date(), -1),
    version: '12345'
  }
  const notExpiredSecret = {
    name: 'not_expired_secret',
    vaultUrl: 'https://vault.url',
    expiresOn: addDays(new Date(), 31),
    version: '12345'
  }
  const expiredSecretButNoRegexMatch = {
    name: 'old_secret_but_no_regex_match',
    vaultUrl: 'https://vault.url',
    expiresOn: addDays(new Date(), -1),
    version: '12345'
  }

  const vaultSecrets: SecretProperties[] = [
    {
      name: 'first_secret',
      vaultUrl: 'https://vault.url',
      version: '12345'
    },
    {
      name: 'second_secret',
      vaultUrl: 'https://vault.url',
      version: '12345'
    },
    expiringSecret,
    expiredSecret,
    notExpiredSecret,
    expiredSecretButNoRegexMatch
  ]

  beforeEach(() => {
    jest.clearAllMocks()

    const creds = mock<DefaultAzureCredential>()
    fixture = new KeyVault('azciam-artifactory', creds)

    const listSecretsSpy = jest.spyOn(
      fixture.secretClient,
      'listPropertiesOfSecrets'
    )
    const returnedSecrets = [...vaultSecrets]

    const results = mock<PagedAsyncIterableIterator<SecretProperties>>()
    results.next.mockImplementation(async () => {
      const secret = returnedSecrets.shift()

      return Promise.resolve({
        value: secret,
        done: secret === undefined
      } as IteratorResult<SecretProperties>)
    })
    results[Symbol.asyncIterator].mockReturnValue(results)
    listSecretsSpy.mockImplementation(() => {
      return results
    })
  })

  it('listSecrets() returns all secrets when no regex is specified', async () => {
    const secrets = await fixture.listSecrets()
    expect(secrets).toHaveLength(vaultSecrets.length)
  })

  it('listSecrets() returns selected secrets when a regex is specified', async () => {
    const secrets = await fixture.listSecrets(/^second.*$/)
    expect(secrets).toHaveLength(1)
    expect(secrets[0].name).toBe(vaultSecrets[1].name)
  })

  it('listExpiringSecrets() returns all expiring secrets when no regex is specified', async () => {
    const secrets = await fixture.listExpiringSecrets(30)
    expect(secrets).toHaveLength(3)
    expect(secrets).toContainEqual(
      AzureKeyVaultSecret.fromSecretProperties(expiredSecret)
    )
    expect(secrets).toContainEqual(
      AzureKeyVaultSecret.fromSecretProperties(expiringSecret)
    )
    expect(secrets).toContainEqual(
      AzureKeyVaultSecret.fromSecretProperties(expiredSecretButNoRegexMatch)
    )
  })

  it('listExpiringSecrets() returns expiring secrets matching the specified regex', async () => {
    const secrets = await fixture.listExpiringSecrets(30, /expir/)
    expect(secrets).toHaveLength(2)
    expect(secrets).toContainEqual(
      AzureKeyVaultSecret.fromSecretProperties(expiredSecret)
    )
    expect(secrets).toContainEqual(
      AzureKeyVaultSecret.fromSecretProperties(expiringSecret)
    )
  })
})
