import axios from 'axios'
import {
  NotificationPriority,
  TeamsNotifier,
  TeamsNotifierConfig
} from '../../src/services/notifier'

jest.mock('axios', () => ({
  post: jest.fn()
}))

describe('TeamsNotifier', () => {
  const config = new TeamsNotifierConfig('https://webhook.url')
  let fixture: TeamsNotifier

  beforeEach(() => {
    jest.clearAllMocks()
    fixture = new TeamsNotifier(config)
  })

  it('sendNotification() should post to the webhook URL', async () => {
    const title = 'this is the title'
    const message = 'this is the message'
    await fixture.sendNotification(title, message, NotificationPriority.HIGH)
    // eslint-disable-next-line @typescript-eslint/unbound-method
    expect(axios.post).toHaveBeenCalledWith(config.webhookUrl, {
      '@type': 'MessageCard',
      '@context': 'http://schema.org/extensions',
      themeColor: config.themeColor,
      title,
      text: message
    })
  })

  it('sendNotification() should rethrow if an axios error is thrown', async () => {
    const error = new Error('this is an error')

    ;(axios.post as jest.Mock).mockImplementation(() => {
      throw error
    })
    try {
      await fixture.sendNotification(
        'title',
        'message',
        NotificationPriority.HIGH
      )
    } catch (e) {
      // eslint-disable-next-line jest/no-conditional-expect
      expect(e).toEqual(error)
    }
  })
})
