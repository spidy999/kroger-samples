import { DefaultAzureCredential } from '@azure/identity'
import { KeyVault } from '../../../src/services/keyvault'
import { formatISO, parseISO } from 'date-fns'

describe('KeyVault', () => {
  let fixture: KeyVault

  beforeEach(() => {
    const creds = new DefaultAzureCredential()
    fixture = new KeyVault('azciam-artifactory', creds)
  })

  it('listExpiringSecrets() returns the expiring secrets matching the specified regex', async () => {
    const secrets = await fixture.listExpiringSecrets(30, /DCPSERV-66043/)
    console.log(JSON.stringify(secrets[0], null, '  '))
    expect(secrets).toHaveLength(1)
  }, 20000)

  it('updateSecretTags() properly updates tag on expiring secret', async () => {
    const secrets = await fixture.listExpiringSecrets(30, /DCPSERV-66043/)
    expect(secrets).toHaveLength(1)

    const secret = secrets[0]
    const alertDate = new Date()
    const alertDateStored = parseISO(formatISO(alertDate))
    secret.expirationAlertSentDate = alertDate
    const updatedSecret = await fixture.updateSecretTags(secret)
    expect(updatedSecret.expirationAlertSentDate).toEqual(alertDateStored)
  }, 20000)
})
