import { DefaultAzureCredential } from '@azure/identity'
import { MonitorAction, MonitorActionConfig } from '../../src/monitor-action'

describe('MonitorAction', () => {
  // const webhookUrl =
  //   'https://kproductivity.webhook.office.com/webhookb2/1480444a-2e84-4b6e-a5bc-eda00641ff31@8331e14a-9134-4288-bf5a-5e2c8412f074/IncomingWebhook/96f15c2bf6a94ef6ad6d21ac4cad2c56/6f13c701-bb91-43ef-82f1-986baad8d8ce'

  const webhookUrl =
    'https://kproductivity.webhook.office.com/webhookb2/1480444a-2e84-4b6e-a5bc-eda00641ff31@8331e14a-9134-4288-bf5a-5e2c8412f074/IncomingWebhook/b6aff0fbea7e45d6987973e51f25ec9d/6f13c701-bb91-43ef-82f1-986baad8d8ce'
  let fixture: MonitorAction
  let config: MonitorActionConfig

  beforeEach(() => {
    jest.clearAllMocks()

    config = {
      keyVaultName: 'azciam-artifactory',
      expirationWindowDays: 30,
      secretPattern: /.*/,
      notifierConfig: {
        type: 'teams',
        webhookUrl
      },
      dryRun: false,
      informationUrl:
        'https://teams.microsoft.com/l/message/19:a343fa7b1dee4f31bd4a4bf44f577e60@thread.tacv2/1704924602201?tenantId=8331e14a-9134-4288-bf5a-5e2c8412f074&groupId=1480444a-2e84-4b6e-a5bc-eda00641ff31&parentMessageId=1704924602201&teamName=CIAM%20(SHIELD)&channelName=SHIELD%20-%20Support%20alerts&createdTime=1704924602201'
    } as MonitorActionConfig
    fixture = new MonitorAction(config, new DefaultAzureCredential())
  })

  it('should alert for expiring secret', async () => {
    const secrets = await fixture.process()
    expect(secrets).toHaveLength(1)
    expect(secrets[0].notificationError).toBeUndefined()
    expect(secrets[0].updateError).toBeUndefined()
  }, 20000)
})
