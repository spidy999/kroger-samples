## Providers

| Name        | Version   |
| ----------- | --------- |
| azurerm     | >=2.96.0  |

## Inputs

| Name                          | Description   | Type  | Required      |   
| ---------------------------   |:--------------------------| -----| ------------- | 
| resource_name                 | Name of the resource that private endpoints will be created for  |  `string` | `true`  | 
| resource_group_name           | Name of the resource group that the resource is in  |  `string` | `true`  |  
| private_dns_zone_name         | Name of the private dns zone name  |  `list(string)` | `true`  |
| private_endpoint_locations         | What locations the private endpoints will be created in. 1-4 unique locations - "prod_eastus2" "prod_centralus" "nonprod_eastus2" "nonprod_centralus". Default is set to all locations.  |  `list(string)` | `false`  |
| private_endpoint_connection   | Defined Below  |  `object` | `true`  |  

#### A private_endpoint_connection Block Supports the Following
| Name          | Description   | Type  | Required      |   
| ------------- |:--------------------------| -----| ------------- |
| is_manual_connection           | Does the Private Endpoint require Manual Approval from the remote resource owner? False is reccomended.  |  `bool` | `true`  | 
| private_connection_resource_id | Id of resource private endpoints will be created for  |  `string` | `true`  |  
| subresource_names              | Subresource name which the Private Endpoint is able to connect to. Find correct value [here](https://confluence.kroger.com/confluence/display/CLOUDSERVICES/Azure+Private+Endpoints#AzurePrivateEndpoints-PrivateEndpointResourceTypes)  |  `list(string)` | `true`  |  


## Outputs

| Name                           | Description                                  |
| -----------------              | -------------------------------------------- |
| prod_eastus2_endpoint_name     | Name of prod eastus2 private endpoint        |
| nonprod_eastus2_endpoint_name  | Name of nonprod eastus2 private endpoint     |
| prod_centralus_endpoint_name   | Name of prod centralus private endpoint      |
| nonprod_centralus_endpoint_name| Name of nonprod centralus private endpoint   |
| prod_eastus2_endpoint_id       | Id of prod eastus2 private endpoint          |
| nonprod_eastus2_endpoint_id    | Id of nonprod eastus2 private endpoint       |
| prod_centralus_endpoint_id     | Id of prod centralus private endpoint        |
| nonprod_centralus_endpoint_id  | Id of nonprod centralus private endpoint     |

# Example - Storage Account Blob with Endpoints in Each Location

```terraform
module "private_endpoints_storage" {
  source = "https://krogertechnology.jfrog.io/artifactory/kroger-cloud-security/tf-modules/terraform-azurerm-cis-private-endpoint.v2.1.0.tar.gz"
  resource_name = azurerm_storage_account.sa.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = ["privatelink.blob.core.windows.net"]
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_storage_account.sa.id
    subresource_names              = ["blob"]
  }
}
```

# Example - Storage Account Blob with Endpoints in Specified Locations

```terraform
module "private_endpoints_storage" {
  source = "https://krogertechnology.jfrog.io/artifactory/kroger-cloud-security/tf-modules/terraform-azurerm-cis-private-endpoint.v2.1.0.tar.gz"
  resource_name = azurerm_storage_account.sa.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = ["privatelink.blob.core.windows.net"]
  private_endpoint_locations = ["prod_eastus2", "nonprod_eastus2"] // Will create private endpoints for prod/np eastus2
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_storage_account.sa.id
    subresource_names              = ["blob"]
  }
}
```

# Example - SQL Server with Endpoints in Each Location

```terraform
module "private_endpoints_sql" {
  source = "https://krogertechnology.jfrog.io/artifactory/kroger-cloud-security/tf-modules/terraform-azurerm-cis-private-endpoint.v2.1.0.tar.gz"
  resource_name = azurerm_mssql_server.sql_server.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = ["privatelink.database.windows.net"]
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_mssql_server.sql_server.id
    subresource_names              = ["sqlServer"]
  }
}
```

# Example - SQL Server with Endpoints in Specified Locations

```terraform
module "private_endpoints_sql" {
  source = "https://krogertechnology.jfrog.io/artifactory/kroger-cloud-security/tf-modules/terraform-azurerm-cis-private-endpoint.v2.1.0.tar.gz"
  resource_name = azurerm_mssql_server.sql_server.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = ["privatelink.database.windows.net"]
  private_endpoint_locations = ["prod_eastus2", "nonprod_eastus2"] // Will create private endpoints for prod/np eastus2
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_mssql_server.sql_server.id
    subresource_names              = ["sqlServer"]
  }
}
```
