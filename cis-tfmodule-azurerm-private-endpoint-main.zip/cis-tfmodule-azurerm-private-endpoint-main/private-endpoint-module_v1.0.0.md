## Providers

| Name        | Version   |
| ----------- | --------- |
| azurerm     | ~> 2.0.0  |

## Inputs

| Name                          | Description   | Type  | Required      |   
| ---------------------------   |:--------------------------| -----| ------------- | 
| resource_name                 | Name of the resource that private endpoints will be created for  |  `string` | `true`  | 
| resource_group_name           | Name of the resource group that the resource is in  |  `string` | `true`  |  
| private_dns_zone_name         | Name of the private dns zone name  |  `string` | `true`  |
| private_endpoint_connection   | Defined Below  |  `object` | `true`  |  

#### A private_endpoint_connection Block Supports the Following
| Name          | Description   | Type  | Required      |   
| ------------- |:--------------------------| -----| ------------- |
| is_manual_connection           | Does the Private Endpoint require Manual Approval from the remote resource owner? False is reccomended.  |  `bool` | `true`  | 
| private_connection_resource_id | Id of resource private endpoints will be created for  |  `string` | `true`  |  
| subresource_names              | Subresource name which the Private Endpoint is able to connect to. Find correct value [here](https://confluence.kroger.com/confluence/display/CLOUDSERVICES/Azure+Private+Endpoints#AzurePrivateEndpoints-PrivateEndpointResourceTypes)  |  `list(string)` | `true`  |  


## Outputs

| Name              | Description                                        |
| ----------------- | -------------------------------------------------- |
| private_endpoint  | Names of private endpoints that were created       |

# Example - Storage Account Blob

```terraform
module "private_endpoints_storage" {
  source = "http://artifactory.kroger.com/artifactory/tf-modules/azurerm/terraform-azurerm-cis-private-endpoint.v1.0.0.tar.gz"
  resource_name = azurerm_storage_account.sa.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = "privatelink.blob.core.windows.net"
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_storage_account.sa.id
    subresource_names              = ["blob"]
  }
}

output "blob_private_endpoint_names" {
    value = "${module.private_endpoints_storage.private_endpoint}"
}
```

# Example - SQL Server

```terraform
module "private_endpoints_storage_sql" {
  source = "http://artifactory.kroger.com/artifactory/tf-modules/azurerm/terraform-azurerm-cis-private-endpoint.v1.0.0.tar.gz"
  resource_name = azurerm_mssql_server.sql_server.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = "privatelink.database.windows.net"
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_mssql_server.sql_server.id
    subresource_names              = ["sqlServer"]
  }
}

output "sql_private_endpoint_names" {
    value = "${module.private_endpoints_storage_sql.private_endpoint}"
}
```
