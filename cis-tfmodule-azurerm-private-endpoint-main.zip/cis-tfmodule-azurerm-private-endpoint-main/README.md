## Private Endpoint Module

This module creates private endpoints for any resources that support it. Before executing these modules, make sure your service principal has the appropriate permissions. Information on how to do this can be found here. It also contains the values you should input for the 'private_dns_zone_name' and 'subresource_names' variables - [Private Endpoints Confluence](https://confluence.kroger.com/confluence/display/NOE/Azure+Private+Endpoint+Documentation#AzurePrivateEndpointDocumentation-CreatePrivateEndpointviaTerraform)
- Note: The kroger VPN range is included in the "prod_eastus2" region. If you are specifying specific locations for your private endpoints, you must inlclude "prod_eastus2" if you need to access the resources from our VPN range.
  
## Requirements

* Terraform Version: >=1.0.0
* Azurerm provider >=2.96.0

## Full Documentation
* [v2.4.0 Documentation](private-endpoint-module_v2.4.0.md)
* [v2.3.0 Documentation](private-endpoint-module_v2.3.0.md)
* [v2.1.0 Documentation](private-endpoint-module_v2.1.0.md)
* [v2.0.0 Documentation](private-endpoint-module_v2.0.0.md)

## Example Usage

### Storage Account Blob with Endpoints in Each Location

```terraform
module "private_endpoints_storage" {
  source = "git::https://github.com/krogertechnology/cis-tfmodule-azurerm-private-endpoint.git?ref=v2.4.1"
  resource_name = azurerm_storage_account.sa.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = ["privatelink.blob.core.windows.net"]
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_storage_account.sa.id
    subresource_names              = ["blob"]
  }
  tags = {
    application-name = "test-app"
    owner = "cis@kroger.com"
  }
}

output "prod_eastus2_id" {
  value = module.private_endpoints_storage.prod_eastus2_endpoint_id
}

output "nonprod_eastus2_id" {
  value = module.private_endpoints_storage.nonprod_eastus2_endpoint_id
}

output "prod_centralus_id" {
  value = module.private_endpoints_storage.prod_centralus_endpoint_id
}

output "nonprod_centralus_id" {
  value = module.private_endpoints_storage.nonprod_centralus_endpoint_id
}

```

### Storage Account Blob with Endpoints in Specified Locations

```terraform
module "private_endpoints_storage" {
  source = "git::https://github.com/krogertechnology/cis-tfmodule-azurerm-private-endpoint.git?ref=v2.4.1"
  resource_name = azurerm_storage_account.sa.name
  resource_group_name = data.azurerm_resource_group.rg.name
  private_dns_zone_name = ["privatelink.blob.core.windows.net"]
  private_endpoint_locations = ["prod-eastus2", "nonprod-eastus2"] // Will create private endpoints for prod/np eastus2
  private_endpoint_connection = {
    is_manual_connection           = false
    private_connection_resource_id = azurerm_storage_account.sa.id
    subresource_names              = ["blob"]
  }
  tags = {
    application-name = "test-app"
    owner = "cis@kroger.com"
  }
}

output "prod_eastus2_id" {
  value = module.private_endpoints_storage.prod_eastus2_endpoint_id
}

output "nonprod_eastus2_id" {
  value = module.private_endpoints_storage.nonprod_eastus2_endpoint_id
}
```
