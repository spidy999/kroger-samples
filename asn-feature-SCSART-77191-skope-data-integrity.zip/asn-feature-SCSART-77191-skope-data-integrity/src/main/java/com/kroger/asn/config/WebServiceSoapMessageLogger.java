package com.kroger.asn.config;

import org.slf4j.Logger;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.ByteArrayOutputStream;
import java.util.Set;

public class WebServiceSoapMessageLogger implements SOAPHandler<SOAPMessageContext> {

    private final Logger logger;

    public WebServiceSoapMessageLogger(Logger logger) {
        this.logger = logger;
    }

    public Set<QName> getHeaders() {
        return null;
    }

    public void close(MessageContext messageContext) {
    }

    public boolean handleFault(SOAPMessageContext soapMessageContext) {

        try {
            SOAPMessage message = soapMessageContext.getMessage();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write("\n============================================\n".getBytes());
            message.writeTo(out);
            out.write("\n============================================\n".getBytes());
            logger.info("Soap Fault Log:"+out.toString());
        } catch (Exception e) {
            logger.info("Exception logging soap message", e);
        }
        return true;
    }

    public boolean handleMessage(SOAPMessageContext soapMessageContext) {

        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            SOAPMessage message = soapMessageContext.getMessage();
            boolean isOutboundMessage = (Boolean) soapMessageContext
                    .get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
            out.write("\n============================================\n".getBytes());
            if (isOutboundMessage) {
                out.write("OUTBOUND MESSAGE\n".getBytes());
            } else {
                out.write("INBOUND MESSAGE\n".getBytes());
            }
            message.writeTo(out);
            out.write("\n============================================\n".getBytes());
            logger.info("Soap Messages: "+out.toString());

        } catch (Exception e) {
            logger.info("Soap Message Exception Logging", e);
        }
        return true;
    }

}
