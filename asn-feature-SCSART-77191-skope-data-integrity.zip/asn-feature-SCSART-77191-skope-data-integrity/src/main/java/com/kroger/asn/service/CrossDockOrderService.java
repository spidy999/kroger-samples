package com.kroger.asn.service;

import com.kroger.schema.canonical.xdoc._3_0.AcknowledgeCrossDockOrderType;
import com.kroger.schema.canonical.xdoc._3_0.SyncCrossDockOrderType;


public interface CrossDockOrderService {
	AcknowledgeCrossDockOrderType syncCrossDockOrder(SyncCrossDockOrderType type);
}
