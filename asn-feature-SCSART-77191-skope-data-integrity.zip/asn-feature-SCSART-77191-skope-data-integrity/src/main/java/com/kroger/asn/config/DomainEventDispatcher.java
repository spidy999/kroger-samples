package com.kroger.asn.config;

import com.kroger.asn.service.ConsumerService;
import org.apache.avro.specific.SpecificRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.Dictionary;
import java.util.Hashtable;
import java.util.function.Consumer;

/**
 * @author AB36672
 * Created on: 3/19/2020 3:17 PM
 */

public class DomainEventDispatcher {

    private Logger logger = LoggerFactory.getLogger(DomainEventDispatcher.class);
    Dictionary<String, Consumer<SpecificRecord>> consumers = new Hashtable();

    public DomainEventDispatcher() {
    }

    public void register(Class cls, Consumer<SpecificRecord> eventHandler) {
        this.consumers.put(cls.getName(), eventHandler);
    }

    public void dispatch(SpecificRecord event) throws RuntimeException {
        try {
            Consumer<SpecificRecord> item = (Consumer) this.consumers.get(event.getClass().getName());
            if (item != null) {
                item.accept(event);
            }
        } catch (DataIntegrityViolationException dataEx) {
            logger.error("DataIntegrityViolation caught. Acknowledging message since this error is " +
                    "unlikely to be resolved on retry.");
        }
    }
}
