package com.kroger.asn.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "CROSSDOCK_MAP_RELEASE")
@IdClass(CrossdockMapReleaseEntityPK.class)
public class CrossdockMapReleaseEntity {

    private int crossdockMapId;
    private int processDayNo;
    private Timestamp skopeOrderRequestTs;
    private Timestamp orderReleaseToWinTs;

    @Id
    @Column(name = "CROSSDOCK_MAP_ID", nullable = false)
    public int getCrossdockMapId() {
        return crossdockMapId;
    }

    public void setCrossdockMapId(int crossdockMapId) {
        this.crossdockMapId = crossdockMapId;
    }

    @Id
    @Column(name = "PROCESS_DAY_NO", nullable = false)
    public int getProcessDayNo() {
        return processDayNo;
    }

    public void setProcessDayNo(int processDayNo) {
        this.processDayNo = processDayNo;
    }


    @Column(name = "SKOPE_ORDER_REQUEST_TS")
    public Timestamp getSkopeOrderRequestTs() {
        return skopeOrderRequestTs;
    }

    public void setSkopeOrderRequestTs(Timestamp skopeOrderRequestTs) {
        this.skopeOrderRequestTs = skopeOrderRequestTs;
    }


    @Column(name = "ORDER_RELEASE_TO_WIN_TS")
    public Timestamp getOrderReleaseToWinTs() {
        return orderReleaseToWinTs;
    }

    public void setOrderReleaseToWinTs(Timestamp orderReleaseToWinTs) {
        this.orderReleaseToWinTs = orderReleaseToWinTs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockMapReleaseEntity that = (CrossdockMapReleaseEntity) o;

        if (crossdockMapId != that.crossdockMapId) return false;
        if (processDayNo != that.processDayNo) return false;
        if (skopeOrderRequestTs != null ? !skopeOrderRequestTs.equals(that.skopeOrderRequestTs) : that.skopeOrderRequestTs != null)
            return false;
        if (orderReleaseToWinTs != null ? !orderReleaseToWinTs.equals(that.orderReleaseToWinTs) : that.orderReleaseToWinTs != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockMapId;
        result = 31 * result + processDayNo;
        result = 31 * result + (skopeOrderRequestTs != null ? skopeOrderRequestTs.hashCode() : 0);
        result = 31 * result + (orderReleaseToWinTs != null ? orderReleaseToWinTs.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CrossdockMapReleaseEntity{" +
                "crossdockMapId=" + crossdockMapId +
                ", processDayNo=" + processDayNo +
                ", skopeOrderRequestTs=" + skopeOrderRequestTs +
                ", orderReleaseToWinTs=" + orderReleaseToWinTs +
                '}';
    }
}
