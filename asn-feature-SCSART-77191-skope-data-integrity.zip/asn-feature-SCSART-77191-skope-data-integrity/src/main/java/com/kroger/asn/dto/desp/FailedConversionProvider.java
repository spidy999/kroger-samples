package com.kroger.asn.dto.desp;

import org.apache.avro.specific.SpecificRecord;
import org.apache.kafka.common.header.Headers;
import org.springframework.kafka.support.serializer.FailedDeserializationInfo;

import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * @author AB36672
 * Created on: 12/16/2019 2:17 PM
 */

public class FailedConversionProvider implements Function<FailedDeserializationInfo, SpecificRecord> {

    @Override
    public SpecificRecord apply(FailedDeserializationInfo info) {
        return new BadSpecificRecord(info);
    }
}
