package com.kroger.asn.entities;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "SOURCING_FACILITY")
public class SourcingFacilityEntity {

    private int sourcingFacilityId;
    private String sourcingFacilityNo;
    private String sourcingFacilityNme;
    private String sourcingFacilityTypeCd;
    private String sourcingFacilityTimezoneCd;
    private Integer lastLoadId;
    private int lastOrderNo;
    private Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByOriginSourcingFacilityId;
    private Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByCrossdockSourcingFacilityId;
    private Collection<CrossdockContainerEntity> crossdockContainersBySourcingFacilityId;
    private Collection<CrossdockLoadEntity> crossdockLoadsBySourcingFacilityId;
    private Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByOriginSourcingFacilityId;
    private Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByCrossdockSourcingFacilityId;
    private Collection<SkopeOrderEntity> skopeOrdersBySourcingFacilityId;

    @Override
    public String toString() {
        return "SourcingFacilityEntity{" +
                "sourcingFacilityId=" + sourcingFacilityId +
                ", sourcingFacilityNo='" + sourcingFacilityNo + '\'' +
                ", sourcingFacilityNme='" + sourcingFacilityNme + '\'' +
                ", sourcingFacilityTypeCd='" + sourcingFacilityTypeCd + '\'' +
                ", sourcingFacilityTimezoneCd='" + sourcingFacilityTimezoneCd + '\'' +
                ", lastLoadId=" + lastLoadId +
                ", lastOrderNo=" + lastOrderNo +
                '}';
    }

    @Id
    @Column(name = "SOURCING_FACILITY_ID", nullable = false)
    public int getSourcingFacilityId() {
        return sourcingFacilityId;
    }

    public void setSourcingFacilityId(int sourcingFacilityId) {
        this.sourcingFacilityId = sourcingFacilityId;
    }


    @Column(name = "SOURCING_FACILITY_NO", nullable = false, length = 3)
    public String getSourcingFacilityNo() {
        return sourcingFacilityNo;
    }

    public void setSourcingFacilityNo(String sourcingFacilityNo) {
        this.sourcingFacilityNo = sourcingFacilityNo;
    }


    @Column(name = "SOURCING_FACILITY_NME", nullable = false, length = 30)
    public String getSourcingFacilityNme() {
        return sourcingFacilityNme;
    }

    public void setSourcingFacilityNme(String sourcingFacilityNme) {
        this.sourcingFacilityNme = sourcingFacilityNme;
    }


    @Column(name = "SOURCING_FACILITY_TYPE_CD", nullable = false, length = 2)
    public String getSourcingFacilityTypeCd() {
        return sourcingFacilityTypeCd;
    }

    public void setSourcingFacilityTypeCd(String sourcingFacilityTypeCd) {
        this.sourcingFacilityTypeCd = sourcingFacilityTypeCd;
    }


    @Column(name = "SOURCING_FACILITY_TIMEZONE_CD", length = 3)
    public String getSourcingFacilityTimezoneCd() {
        return sourcingFacilityTimezoneCd;
    }

    public void setSourcingFacilityTimezoneCd(String sourcingFacilityTimezoneCd) {
        this.sourcingFacilityTimezoneCd = sourcingFacilityTimezoneCd;
    }


    @Column(name = "LAST_LOAD_ID")
    public Integer getLastLoadId() {
        return lastLoadId;
    }

    public void setLastLoadId(Integer lastLoadId) {
        this.lastLoadId = lastLoadId;
    }


    @Column(name = "LAST_ORDER_NO", nullable = false)
    public int getLastOrderNo() {
        return lastOrderNo;
    }

    public void setLastOrderNo(int lastOrderNo) {
        this.lastOrderNo = lastOrderNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SourcingFacilityEntity that = (SourcingFacilityEntity) o;

        if (sourcingFacilityId != that.sourcingFacilityId) return false;
        if (lastOrderNo != that.lastOrderNo) return false;
        if (sourcingFacilityNo != null ? !sourcingFacilityNo.equals(that.sourcingFacilityNo) : that.sourcingFacilityNo != null)
            return false;
        if (sourcingFacilityNme != null ? !sourcingFacilityNme.equals(that.sourcingFacilityNme) : that.sourcingFacilityNme != null)
            return false;
        if (sourcingFacilityTypeCd != null ? !sourcingFacilityTypeCd.equals(that.sourcingFacilityTypeCd) : that.sourcingFacilityTypeCd != null)
            return false;
        if (sourcingFacilityTimezoneCd != null ? !sourcingFacilityTimezoneCd.equals(that.sourcingFacilityTimezoneCd) : that.sourcingFacilityTimezoneCd != null)
            return false;
        if (lastLoadId != null ? !lastLoadId.equals(that.lastLoadId) : that.lastLoadId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = sourcingFacilityId;
        result = 31 * result + (sourcingFacilityNo != null ? sourcingFacilityNo.hashCode() : 0);
        result = 31 * result + (sourcingFacilityNme != null ? sourcingFacilityNme.hashCode() : 0);
        result = 31 * result + (sourcingFacilityTypeCd != null ? sourcingFacilityTypeCd.hashCode() : 0);
        result = 31 * result + (sourcingFacilityTimezoneCd != null ? sourcingFacilityTimezoneCd.hashCode() : 0);
        result = 31 * result + (lastLoadId != null ? lastLoadId.hashCode() : 0);
        result = 31 * result + lastOrderNo;
        return result;
    }

    @OneToMany(mappedBy = "sourcingFacilityByOriginSourcingFacilityId")
    public Collection<CrossdockCatalogGroupMapEntity> getCrossdockCatalogGroupMapsByOriginSourcingFacilityId() {
        return crossdockCatalogGroupMapsByOriginSourcingFacilityId;
    }

    public void setCrossdockCatalogGroupMapsByOriginSourcingFacilityId(Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByOriginSourcingFacilityId) {
        this.crossdockCatalogGroupMapsByOriginSourcingFacilityId = crossdockCatalogGroupMapsByOriginSourcingFacilityId;
    }

    @OneToMany(mappedBy = "sourcingFacilityByCrossdockSourcingFacilityId")
    public Collection<CrossdockCatalogGroupMapEntity> getCrossdockCatalogGroupMapsByCrossdockSourcingFacilityId() {
        return crossdockCatalogGroupMapsByCrossdockSourcingFacilityId;
    }

    public void setCrossdockCatalogGroupMapsByCrossdockSourcingFacilityId(Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByCrossdockSourcingFacilityId) {
        this.crossdockCatalogGroupMapsByCrossdockSourcingFacilityId = crossdockCatalogGroupMapsByCrossdockSourcingFacilityId;
    }

    @OneToMany(mappedBy = "sourcingFacilityByOriginSourcingFacilityId")
    public Collection<CrossdockContainerEntity> getCrossdockContainersBySourcingFacilityId() {
        return crossdockContainersBySourcingFacilityId;
    }

    public void setCrossdockContainersBySourcingFacilityId(Collection<CrossdockContainerEntity> crossdockContainersBySourcingFacilityId) {
        this.crossdockContainersBySourcingFacilityId = crossdockContainersBySourcingFacilityId;
    }

    @OneToMany(mappedBy = "sourcingFacilityByOriginSourcingFacilityId")
    public Collection<CrossdockLoadEntity> getCrossdockLoadsBySourcingFacilityId() {
        return crossdockLoadsBySourcingFacilityId;
    }

    public void setCrossdockLoadsBySourcingFacilityId(Collection<CrossdockLoadEntity> crossdockLoadsBySourcingFacilityId) {
        this.crossdockLoadsBySourcingFacilityId = crossdockLoadsBySourcingFacilityId;
    }

    @OneToMany(mappedBy = "sourcingFacilityByOriginSourcingFacilityId")
    public Collection<CrossdockOrderHeaderEntity> getCrossdockOrderHeadersByOriginSourcingFacilityId() {
        return crossdockOrderHeadersByOriginSourcingFacilityId;
    }

    public void setCrossdockOrderHeadersByOriginSourcingFacilityId(Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByOriginSourcingFacilityId) {
        this.crossdockOrderHeadersByOriginSourcingFacilityId = crossdockOrderHeadersByOriginSourcingFacilityId;
    }

    @OneToMany(mappedBy = "sourcingFacilityByCrossdockSourcingFacilityId")
    public Collection<CrossdockOrderHeaderEntity> getCrossdockOrderHeadersByCrossdockSourcingFacilityId() {
        return crossdockOrderHeadersByCrossdockSourcingFacilityId;
    }

    public void setCrossdockOrderHeadersByCrossdockSourcingFacilityId(Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByCrossdockSourcingFacilityId) {
        this.crossdockOrderHeadersByCrossdockSourcingFacilityId = crossdockOrderHeadersByCrossdockSourcingFacilityId;
    }

    @OneToMany(mappedBy = "sourcingFacilityBySourcingFacilityId")
    public Collection<SkopeOrderEntity> getSkopeOrdersBySourcingFacilityId() {
        return skopeOrdersBySourcingFacilityId;
    }

    public void setSkopeOrdersBySourcingFacilityId(Collection<SkopeOrderEntity> skopeOrdersBySourcingFacilityId) {
        this.skopeOrdersBySourcingFacilityId = skopeOrdersBySourcingFacilityId;
    }

}
