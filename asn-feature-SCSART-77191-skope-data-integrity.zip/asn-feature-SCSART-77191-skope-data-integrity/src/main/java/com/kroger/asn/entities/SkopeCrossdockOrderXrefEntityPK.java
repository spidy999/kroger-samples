package com.kroger.asn.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

public class SkopeCrossdockOrderXrefEntityPK implements Serializable {

    private int crossdockOrderId;
    private int skopeOrderId;


    @Id
    @Column(name = "CROSSDOCK_ORDER_ID", nullable = false)
    public int getCrossdockOrderId() {
        return crossdockOrderId;
    }

    public void setCrossdockOrderId(int crossdockOrderId) {
        this.crossdockOrderId = crossdockOrderId;
    }


    @Id
    @Column(name = "SKOPE_ORDER_ID", nullable = false)
    public int getSkopeOrderId() {
        return skopeOrderId;
    }

    public void setSkopeOrderId(int skopeOrderId) {
        this.skopeOrderId = skopeOrderId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SkopeCrossdockOrderXrefEntityPK that = (SkopeCrossdockOrderXrefEntityPK) o;

        if (crossdockOrderId != that.crossdockOrderId) return false;
        if (skopeOrderId != that.skopeOrderId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockOrderId;
        result = 31 * result + skopeOrderId;
        return result;
    }

    @Override
    public String toString() {
        return "SkopeCrossdockOrderXrefEntityPK{" +
                "crossdockOrderId=" + crossdockOrderId +
                ", skopeOrderId=" + skopeOrderId +
                '}';
    }
}
