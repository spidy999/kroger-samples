package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockLoadEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CrossdockLoadRepo extends JpaRepository<CrossdockLoadEntity,Integer>
{
    CrossdockLoadEntity findByLoadNo(String loadNumber);
}
