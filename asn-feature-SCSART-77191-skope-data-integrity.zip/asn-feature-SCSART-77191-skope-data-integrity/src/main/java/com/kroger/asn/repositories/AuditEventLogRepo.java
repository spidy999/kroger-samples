package com.kroger.asn.repositories;

import com.kroger.asn.entities.AuditEventLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditEventLogRepo extends JpaRepository<AuditEventLogEntity,Integer> {
}
