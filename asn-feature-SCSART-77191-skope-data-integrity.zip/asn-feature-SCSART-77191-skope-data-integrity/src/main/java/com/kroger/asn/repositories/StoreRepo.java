package com.kroger.asn.repositories;

import com.kroger.asn.entities.StoreEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface StoreRepo extends JpaRepository<StoreEntity,Integer>
{
    StoreEntity findByOrderManagementDivisionIdAndStoreNo(int orderManagementDivisionId, String storeNumber);
}
