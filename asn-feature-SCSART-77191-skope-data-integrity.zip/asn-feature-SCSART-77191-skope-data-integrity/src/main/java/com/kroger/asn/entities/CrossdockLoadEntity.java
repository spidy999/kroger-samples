package com.kroger.asn.entities;

import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Pallet;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "CROSSDOCK_LOAD")
public class CrossdockLoadEntity {

    private int crossdockLoadId;
    private String loadNo;
    private BigDecimal grossCubeAmt;
    private String grossCubeUomVlu;
    private BigDecimal netWeightAmt;
    private String netWeightUomVlu;
    private int loadCaseQty;
    private Timestamp originShipmentTs;
    private Timestamp crossdockShipmentTs;
    private Timestamp crossdockLoadCancelTs;
    private String positionCd;
    private String topLoadedFlg;
    private String hazmatCd;
    private Integer loadUnitQty;
    private SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId;
    private CrossdockOrderHeaderEntity crossdockOrderHeaderByCrossdockOrderId;

    public CrossdockLoadEntity() {
    }

    public CrossdockLoadEntity(Pallet pallet, CrossdockOrderHeaderEntity crossdockOrderHeader) {
        this.loadNo = pallet.getId().toUpperCase();
        this.grossCubeAmt = BigDecimal.valueOf(pallet.getCube());
        this.netWeightAmt = BigDecimal.valueOf(pallet.getWeight());
        this.loadCaseQty = pallet.getCases();
        this.loadUnitQty = pallet.getCases();
        this.sourcingFacilityByOriginSourcingFacilityId = crossdockOrderHeader.getSourcingFacilityByOriginSourcingFacilityId();
        this.crossdockOrderHeaderByCrossdockOrderId = crossdockOrderHeader;
        this.originShipmentTs = crossdockOrderHeader.getOriginOrderCompleteTs();
    }


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CROSSDOCK_LOAD_ID", nullable = false)
    public int getCrossdockLoadId() {
        return crossdockLoadId;
    }

    public void setCrossdockLoadId(int crossdockLoadId) {
        this.crossdockLoadId = crossdockLoadId;
    }


    @Column(name = "LOAD_NO", nullable = false, length = 20)
    public String getLoadNo() {
        return loadNo;
    }

    public void setLoadNo(String loadNo) {
        this.loadNo = loadNo;
    }


    @Column(name = "GROSS_CUBE_AMT", nullable = false, precision = 2)
    public BigDecimal getGrossCubeAmt() {
        return grossCubeAmt;
    }

    public void setGrossCubeAmt(BigDecimal grossCubeAmt) {
        this.grossCubeAmt = grossCubeAmt;
    }


    @Column(name = "GROSS_CUBE_UOM_VLU", length = 30)
    public String getGrossCubeUomVlu() {
        return grossCubeUomVlu;
    }

    public void setGrossCubeUomVlu(String grossCubeUomVlu) {
        this.grossCubeUomVlu = grossCubeUomVlu;
    }


    @Column(name = "NET_WEIGHT_AMT", nullable = false, precision = 2)
    public BigDecimal getNetWeightAmt() {
        return netWeightAmt;
    }

    public void setNetWeightAmt(BigDecimal netWeightAmt) {
        this.netWeightAmt = netWeightAmt;
    }


    @Column(name = "NET_WEIGHT_UOM_VLU", length = 30)
    public String getNetWeightUomVlu() {
        return netWeightUomVlu;
    }

    public void setNetWeightUomVlu(String netWeightUomVlu) {
        this.netWeightUomVlu = netWeightUomVlu;
    }


    @Column(name = "LOAD_CASE_QTY", nullable = false)
    public int getLoadCaseQty() {
        return loadCaseQty;
    }

    public void setLoadCaseQty(int loadCaseQty) {
        this.loadCaseQty = loadCaseQty;
    }


    @Column(name = "ORIGIN_SHIPMENT_TS")
    public Timestamp getOriginShipmentTs() {
        return originShipmentTs;
    }

    public void setOriginShipmentTs(Timestamp originShipmentTs) {
        this.originShipmentTs = originShipmentTs;
    }


    @Column(name = "CROSSDOCK_SHIPMENT_TS")
    public Timestamp getCrossdockShipmentTs() {
        return crossdockShipmentTs;
    }

    public void setCrossdockShipmentTs(Timestamp crossdockShipmentTs) {
        this.crossdockShipmentTs = crossdockShipmentTs;
    }


    @Column(name = "CROSSDOCK_LOAD_CANCEL_TS")
    public Timestamp getCrossdockLoadCancelTs() {
        return crossdockLoadCancelTs;
    }

    public void setCrossdockLoadCancelTs(Timestamp crossdockLoadCancelTs) {
        this.crossdockLoadCancelTs = crossdockLoadCancelTs;
    }


    @Column(name = "POSITION_CD", length = 3)
    public String getPositionCd() {
        return positionCd;
    }

    public void setPositionCd(String positionCd) {
        this.positionCd = positionCd;
    }


    @Column(name = "TOP_LOADED_FLG",length = 1)
    public String getTopLoadedFlg() {
        return topLoadedFlg;
    }

    public void setTopLoadedFlg(String topLoadedFlg) {
        this.topLoadedFlg = topLoadedFlg;
    }


    @Column(name = "HAZMAT_CD", length = 3)
    public String getHazmatCd() {
        return hazmatCd;
    }

    public void setHazmatCd(String hazmatCd) {
        this.hazmatCd = hazmatCd;
    }


    @Column(name = "LOAD_UNIT_QTY")
    public Integer getLoadUnitQty() {
        return loadUnitQty;
    }

    public void setLoadUnitQty(Integer loadUnitQty) {
        this.loadUnitQty = loadUnitQty;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockLoadEntity that = (CrossdockLoadEntity) o;

        if (crossdockLoadId != that.crossdockLoadId) return false;
        if (loadCaseQty != that.loadCaseQty) return false;
        if (loadNo != null ? !loadNo.equals(that.loadNo) : that.loadNo != null) return false;
        if (grossCubeAmt != null ? !grossCubeAmt.equals(that.grossCubeAmt) : that.grossCubeAmt != null) return false;
        if (grossCubeUomVlu != null ? !grossCubeUomVlu.equals(that.grossCubeUomVlu) : that.grossCubeUomVlu != null)
            return false;
        if (netWeightAmt != null ? !netWeightAmt.equals(that.netWeightAmt) : that.netWeightAmt != null) return false;
        if (netWeightUomVlu != null ? !netWeightUomVlu.equals(that.netWeightUomVlu) : that.netWeightUomVlu != null)
            return false;
        if (originShipmentTs != null ? !originShipmentTs.equals(that.originShipmentTs) : that.originShipmentTs != null)
            return false;
        if (crossdockShipmentTs != null ? !crossdockShipmentTs.equals(that.crossdockShipmentTs) : that.crossdockShipmentTs != null)
            return false;
        if (crossdockLoadCancelTs != null ? !crossdockLoadCancelTs.equals(that.crossdockLoadCancelTs) : that.crossdockLoadCancelTs != null)
            return false;
        if (positionCd != null ? !positionCd.equals(that.positionCd) : that.positionCd != null) return false;
        if (topLoadedFlg != null ? !topLoadedFlg.equals(that.topLoadedFlg) : that.topLoadedFlg != null) return false;
        if (hazmatCd != null ? !hazmatCd.equals(that.hazmatCd) : that.hazmatCd != null) return false;
        if (loadUnitQty != null ? !loadUnitQty.equals(that.loadUnitQty) : that.loadUnitQty != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockLoadId;
        result = 31 * result + (loadNo != null ? loadNo.hashCode() : 0);
        result = 31 * result + (grossCubeAmt != null ? grossCubeAmt.hashCode() : 0);
        result = 31 * result + (grossCubeUomVlu != null ? grossCubeUomVlu.hashCode() : 0);
        result = 31 * result + (netWeightAmt != null ? netWeightAmt.hashCode() : 0);
        result = 31 * result + (netWeightUomVlu != null ? netWeightUomVlu.hashCode() : 0);
        result = 31 * result + loadCaseQty;
        result = 31 * result + (originShipmentTs != null ? originShipmentTs.hashCode() : 0);
        result = 31 * result + (crossdockShipmentTs != null ? crossdockShipmentTs.hashCode() : 0);
        result = 31 * result + (crossdockLoadCancelTs != null ? crossdockLoadCancelTs.hashCode() : 0);
        result = 31 * result + (positionCd != null ? positionCd.hashCode() : 0);
        result = 31 * result + (topLoadedFlg != null ? topLoadedFlg.hashCode() : 0);
        result = 31 * result + (hazmatCd != null ? hazmatCd.hashCode() : 0);
        result = 31 * result + (loadUnitQty != null ? loadUnitQty.hashCode() : 0);
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "ORIGIN_SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID")
    public SourcingFacilityEntity getSourcingFacilityByOriginSourcingFacilityId() {
        return sourcingFacilityByOriginSourcingFacilityId;
    }

    public void setSourcingFacilityByOriginSourcingFacilityId(SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId) {
        this.sourcingFacilityByOriginSourcingFacilityId = sourcingFacilityByOriginSourcingFacilityId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_ORDER_ID", referencedColumnName = "CROSSDOCK_ORDER_ID", nullable = false)
    public CrossdockOrderHeaderEntity getCrossdockOrderHeaderByCrossdockOrderId() {
        return crossdockOrderHeaderByCrossdockOrderId;
    }

    public void setCrossdockOrderHeaderByCrossdockOrderId(CrossdockOrderHeaderEntity crossdockOrderHeaderByCrossdockOrderId) {
        this.crossdockOrderHeaderByCrossdockOrderId = crossdockOrderHeaderByCrossdockOrderId;
    }

    @Override
    public String toString() {
        return "CrossdockLoadEntity{" +
                "crossdockLoadId=" + crossdockLoadId +
                ", loadNo='" + loadNo + '\'' +
                ", grossCubeAmt=" + grossCubeAmt +
                ", grossCubeUomVlu='" + grossCubeUomVlu + '\'' +
                ", netWeightAmt=" + netWeightAmt +
                ", netWeightUomVlu='" + netWeightUomVlu + '\'' +
                ", loadCaseQty=" + loadCaseQty +
                ", originShipmentTs=" + originShipmentTs +
                ", crossdockShipmentTs=" + crossdockShipmentTs +
                ", crossdockLoadCancelTs=" + crossdockLoadCancelTs +
                ", positionCd='" + positionCd + '\'' +
                ", topLoadedFlg='" + topLoadedFlg + '\'' +
                ", hazmatCd='" + hazmatCd + '\'' +
                ", loadUnitQty=" + loadUnitQty +
                '}';
    }
}
