package com.kroger.asn.entities;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "CROSSDOCK_CATALOG_GROUP")
public class CrossdockCatalogGroupEntity {

    private String crossdockCatalogGroupNo;
    private Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByCrossdockCatalogGroupNo;
    private Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByCrossdockCatalogGroupNo;

    @Id
    @Column(name = "CROSSDOCK_CATALOG_GROUP_NO", nullable = false, length = 3)
    public String getCrossdockCatalogGroupNo() {
        return crossdockCatalogGroupNo;
    }

    public void setCrossdockCatalogGroupNo(String crossdockCatalogGroupNo) {
        this.crossdockCatalogGroupNo = crossdockCatalogGroupNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockCatalogGroupEntity that = (CrossdockCatalogGroupEntity) o;

        if (crossdockCatalogGroupNo != null ? !crossdockCatalogGroupNo.equals(that.crossdockCatalogGroupNo) : that.crossdockCatalogGroupNo != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return crossdockCatalogGroupNo != null ? crossdockCatalogGroupNo.hashCode() : 0;
    }

    @OneToMany(mappedBy = "crossdockCatalogGroupByCrossdockCatalogGroupNo")
    public Collection<CrossdockCatalogGroupMapEntity> getCrossdockCatalogGroupMapsByCrossdockCatalogGroupNo() {
        return crossdockCatalogGroupMapsByCrossdockCatalogGroupNo;
    }

    public void setCrossdockCatalogGroupMapsByCrossdockCatalogGroupNo(Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByCrossdockCatalogGroupNo) {
        this.crossdockCatalogGroupMapsByCrossdockCatalogGroupNo = crossdockCatalogGroupMapsByCrossdockCatalogGroupNo;
    }

    @OneToMany(mappedBy = "crossdockCatalogGroupByCrossdockCatalogGroupNo")
    public Collection<CrossdockOrderHeaderEntity> getCrossdockOrderHeadersByCrossdockCatalogGroupNo() {
        return crossdockOrderHeadersByCrossdockCatalogGroupNo;
    }

    public void setCrossdockOrderHeadersByCrossdockCatalogGroupNo(Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByCrossdockCatalogGroupNo) {
        this.crossdockOrderHeadersByCrossdockCatalogGroupNo = crossdockOrderHeadersByCrossdockCatalogGroupNo;
    }

    @Override
    public String toString() {
        return "CrossdockCatalogGroupEntity{" +
                "crossdockCatalogGroupNo='" + crossdockCatalogGroupNo + '\'' +
                '}';
    }
}
