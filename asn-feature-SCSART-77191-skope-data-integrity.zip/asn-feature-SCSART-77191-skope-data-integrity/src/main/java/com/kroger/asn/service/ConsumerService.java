package com.kroger.asn.service;

import com.kroger.asn.config.DomainEventDispatcher;
import com.kroger.asn.dto.desp.FailedConversionProvider;
import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNOrderSummaryEvent;
import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNShipmentEvent;
import com.kroger.streaming.configuration.DespKafkaProperties;
import io.confluent.kafka.streams.serdes.avro.SpecificAvroDeserializer;
import org.apache.avro.specific.SpecificRecord;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer2;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;

import java.util.Map;

/**
 * @author AB36672
 * Created on: 12/16/2019 2:14 PM
 */

@Configuration
@EnableKafka
@EnableConfigurationProperties(DespKafkaProperties.class)
public class ConsumerService {

    private Logger logger = LoggerFactory.getLogger(ConsumerService.class);

    @Autowired
    private DespKafkaProperties despKafkaProperties;

    @Autowired
    AsnRouteCloseService asnRouteCloseService;


    private void handleAsnShipmentEvent(SpecificRecord record) throws Exception {
        ASNShipmentEvent asnShipmentEvent = (ASNShipmentEvent) record;

        MDC.clear();
        MDC.put("Sourcing-Facility-Number", asnShipmentEvent.getAsnShipment().getSender().getShipFromFacility().getNumber());
        MDC.put("Sourcing-Facility-Name", asnShipmentEvent.getAsnShipment().getSender().getShipFromFacility().getName());
        MDC.put("Reference-Id", asnShipmentEvent.getAsnShipment().getSender().getReferenceId());
        MDC.put("Sender-Create-Time", asnShipmentEvent.getAsnShipment().getSender().getCreationDateTime().getValue());
        MDC.put("Route-Name", asnShipmentEvent.getAsnShipment().getShipmentData().getRouteName());
        MDC.put("Event-Header-Time", String.valueOf(asnShipmentEvent.getEventHeader().getTime()));
        MDC.put("Event-JSON", asnShipmentEvent.toString());
        logger.info("Handling ASN Shipment Event, ID # {}", asnShipmentEvent.getEventHeader().getId());

        asnRouteCloseService.processAsnRouteCloseEvent(asnShipmentEvent.getAsnShipment());
    }

    private void handleAsnOrderSummaryEvent(SpecificRecord record) throws Exception {
            ASNOrderSummaryEvent asnOrderSummaryEvent = (ASNOrderSummaryEvent) record;
//            Commenting out MDC lines as that fixed our logging issue in Stage environment - ABengel 1/20/21
//            MDC.clear();
//            MDC.put("Sourcing-Facility-Number", asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber());
//            MDC.put("Sourcing-Facility-Name", asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getName());
//            MDC.put("Reference-Id", asnOrderSummaryEvent.getSenderInfo().getReferenceId());
//            MDC.put("Sender-Create-Time", asnOrderSummaryEvent.getSenderInfo().getCreationDateTime().getValue());
//            MDC.put("Event-JSON", asnOrderSummaryEvent.toString());
//            MDC.put("Route-Name", asnOrderSummaryEvent.getRouteName());
//            logger.info("Handling ASN Order Summary Event, ID # {}", asnOrderSummaryEvent.getEventHeader().getId());

            asnRouteCloseService.processAsnOrderSummaryEvent(asnOrderSummaryEvent);
    }


    @Bean
    DomainEventDispatcher eventDispatcher() {
        DomainEventDispatcher eventDispatcher = new DomainEventDispatcher();
        eventDispatcher.register(ASNShipmentEvent.class, record -> {
            try {
                handleAsnShipmentEvent(record);
            } catch (DataIntegrityViolationException dataEx) {
                throw new DataIntegrityViolationException("Error saving ASN Shipment Event: " + dataEx.getMessage());
            }
            catch (Exception e) {
                throw new RuntimeException("Error handling ASN Shipment Event: " + e.getMessage());
            }
        });
        eventDispatcher.register(ASNOrderSummaryEvent.class, record -> {
            try {
                handleAsnOrderSummaryEvent(record);
            } catch (DataIntegrityViolationException dataEx) {
                throw new DataIntegrityViolationException("Error saving ASN Order Summary Event: " + dataEx.getMessage());
            }
            catch (Exception e) {
                throw new RuntimeException("Error handling ASN Order Summary Event: " + e.getMessage());
            }
        });
        return eventDispatcher;
    }

    @Autowired
    private DomainEventDispatcher domainEventDispatcher;

    @Bean("consumerFactory")
    public ConsumerFactory<String, SpecificRecord> consumerFactory() {
        // build base consumer props from application.yml
        Map<String, Object> props = despKafkaProperties.buildConsumerProperties();

        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer2.class);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer2.class);
        props.put(ErrorHandlingDeserializer2.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
        props.put(ErrorHandlingDeserializer2.VALUE_DESERIALIZER_CLASS, SpecificAvroDeserializer.class.getName());
        props.put(ErrorHandlingDeserializer2.VALUE_FUNCTION, FailedConversionProvider.class);
        props.put("isolation.level", "read_committed");

        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean("kafkaListenerContainerFactory")
    @ConditionalOnMissingBean(name = "kafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, SpecificRecord> listenerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, SpecificRecord> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
//        ExponentialBackOff backOff = new ExponentialBackOff(100L, 2.0);
//        backOff.setMaxInterval(290000L);
        factory.setErrorHandler(new SeekToCurrentErrorHandler());
        return factory;
    }

    @KafkaListener(topics = "${topics.warehouse-operations}", containerFactory = "kafkaListenerContainerFactory")
    public void topicListener(ConsumerRecord<String, SpecificRecord> record, Acknowledgment acknowledgment, @Headers MessageHeaders messageHeaders) {
        if (messageHeaders.containsKey("desp_replicated")) {
            acknowledgment.acknowledge();
        } else {
            logger.info("Consumed from partition {} with offset {}, record type is: {}", record.partition(), record.offset(), record.value().getClass().getTypeName());
            domainEventDispatcher.dispatch(record.value());
            acknowledgment.acknowledge();
        }
    }
}
