package com.kroger.asn;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.FileCopyUtils;

@SpringBootApplication
public class AdvancedShipmentNoticeApplication
{
    @SuppressWarnings("resource")
    public static void main(String[] args) throws FileNotFoundException, IOException
    {
        FileCopyUtils.copy(
                new ClassPathResource("kafka.client.truststore.jks").getInputStream(),
                new FileOutputStream("/tmp/kafka.client.truststore.jks"));
        SpringApplication.run(AdvancedShipmentNoticeApplication.class, args);
    }
}