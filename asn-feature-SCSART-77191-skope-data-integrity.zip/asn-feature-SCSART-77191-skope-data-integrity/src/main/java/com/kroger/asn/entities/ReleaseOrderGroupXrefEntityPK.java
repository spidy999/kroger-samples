package com.kroger.asn.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

public class ReleaseOrderGroupXrefEntityPK implements Serializable {

    private int releaseOrderGroupId;
    private int crossdockOrderId;

    @Column(name = "RELEASE_ORDER_GROUP_ID", nullable = false)
    @Id
    public int getReleaseOrderGroupId() {
        return releaseOrderGroupId;
    }

    public void setReleaseOrderGroupId(int releaseOrderGroupId) {
        this.releaseOrderGroupId = releaseOrderGroupId;
    }

    @Column(name = "CROSSDOCK_ORDER_ID", nullable = false)
    @Id
    public int getCrossdockOrderId() {
        return crossdockOrderId;
    }

    public void setCrossdockOrderId(int crossdockOrderId) {
        this.crossdockOrderId = crossdockOrderId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReleaseOrderGroupXrefEntityPK that = (ReleaseOrderGroupXrefEntityPK) o;

        if (releaseOrderGroupId != that.releaseOrderGroupId) return false;
        if (crossdockOrderId != that.crossdockOrderId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = releaseOrderGroupId;
        result = 31 * result + crossdockOrderId;
        return result;
    }
}
