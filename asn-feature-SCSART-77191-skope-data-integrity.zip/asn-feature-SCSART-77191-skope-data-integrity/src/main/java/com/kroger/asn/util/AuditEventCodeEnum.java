package com.kroger.asn.util;

public enum AuditEventCodeEnum {

    AllEntries("All", "All"),
    CreateCatalogGroupMap("A", "Create Catalog Group Map"),
    DeleteCatalogGroupMap("B", "Delete Catalog Group Map"),
    CreateCrossDockMap("C", "Create Cross Dock Map"),
    DeleteCrossDockMap("D", "Delete Create Cross Dock Map"),
    UpdateCrossDockMap("E", "Update Cross Dock Map"),
    CancelSkopeOrder("F", "Cancel SKOPE Order"),
    ReleaseCrossDockOrderHeader("G", "Release Cross Dock Order"),
    UpdateCrossDockOrder("H", "Update Cross Dock Order"),
    RequestOrders("I", "Request Orders"),
    RouteClose("J", "Route Close"),
    ProcessMessage("K", "Process Message"),
    CreateCrossDockContainer("L", "Create Cross Dock Container"),
    UpdateCrossDockContainer("M", "Update Cross Dock Container"),
    DeleteCrossDockContainer("N", "Delete Cross Dock Container"),
    CancelCrossDockOrder("O", "Cancel Cross Dock Order"),
    CreateCrossDockRoute("P", "Create Cross Dock Route"),
    UpdateCrossDockRoute("Q", "Update Cross Dock Route"),
    CloseCrossDockRoute("R", "Close Cross Dock Route"),
    PrintLabelRoute("S", "Print Label Route"),
    SendLabelRoute("Z", "Send Label Route"),
    CreatePrintLabel("T", "Create Print Label"),
    DeletePrintLabel("U", "Delete Print Label"),
    BatchPurge("V", "Purge Process"),
    ManualOrderEntrySave("W", "Manual Order Entry Save"),
    ManualOrderEntryImport("X", "Manual Order Entry Import"),
    ReleaseDeleteOrders("Y", "Release Delete Orders"),
    AsnRouteClose("AA", "ASN Route close"),
    AsnReleaseCrossDockOrderHeaders("AB", "ASN Release Cross Dock Order"),
    AsnOrderSummary("AC", "ASN Order Summary");

    private final String auditEventCodeColumnValue;
    private final String auditEventCodeDescription;

    private AuditEventCodeEnum(String theColumnValue, String theDescription)
    {
        this.auditEventCodeColumnValue = theColumnValue;
        this.auditEventCodeDescription = theDescription;
    }

    public String getAuditEventCodeColumnValue()
    {
        return auditEventCodeColumnValue;
    }

    public String getAuditEventCodeDescription()
    {
        return auditEventCodeDescription;
    }


}
