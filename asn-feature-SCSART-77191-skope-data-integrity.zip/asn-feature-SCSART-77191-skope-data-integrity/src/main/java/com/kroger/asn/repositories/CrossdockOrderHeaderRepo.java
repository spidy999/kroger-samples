package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockOrderHeaderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;


import java.sql.Date;
import java.util.List;
import java.util.Optional;


@Repository
public interface CrossdockOrderHeaderRepo extends JpaRepository<CrossdockOrderHeaderEntity,Integer>
{
    @Query(value = "SELECT coh.* FROM CROSSDOCK_ORDER_HEADER as coh " +
            "JOIN SKOPE_CROSSDOCK_ORDER_XREF as scox ON coh.crossdock_order_id = scox.crossdock_order_id " +
            "WHERE scox.skope_order_id = :skopeOrderId AND CROSSDOCK_ORDER_CANCEL_TS IS NULL", nativeQuery = true)
    List<CrossdockOrderHeaderEntity> findBySkopeCrossdockOrderXrefBySkopeOrderId(@Param("skopeOrderId") int skopeOrderId);

    @Query(value = "SELECT cr.* FROM   crossdock_order_header cr, store st, order_management_division or, sourcing_facility origin, sourcing_facility crossdock "
            + "WHERE  cr.store_id = st.store_id AND cr.order_management_division_id = or.order_management_division_id AND cr.origin_sourcing_facility_id = origin.sourcing_facility_id "
            + "AND cr.crossdock_sourcing_facility_id = crossdock.sourcing_facility_id AND cr.origin_sourcing_facility_id = :originFacilityId AND cr.crossdock_sourcing_facility_id = :crossdockFacilityId "
            + "AND cr.crossdock_catalog_group_no = :crossdockCatalogGroupNumber AND cr.origin_order_complete_ts IS NULL AND cr.crossdock_order_cancel_ts IS NULL AND cr.order_management_division_id = :orderManagementDivisionId "
            + "AND cr.store_id = :storeId AND cr.crossdock_order_delivery_dt = :adjustedDeliveryDate", nativeQuery = true)
    Optional<List<CrossdockOrderHeaderEntity>> findAvailableCrossDockOrderHeaders(@Param("originFacilityId") int originFacilityId, @Param("crossdockFacilityId") int crossdockFacilityId,
                                                                                  @Param("crossdockCatalogGroupNumber") String crossdockCatalogGroupNumber, @Param("orderManagementDivisionId") Long orderManagementDivisionId,
                                                                                  @Param("storeId") Long storeId, @Param("adjustedDeliveryDate") Date adjustedDeliveryDate);


    @Query(value = "SELECT coh.* FROM CROSSDOCK_ORDER_HEADER as coh " +
            "JOIN SKOPE_CROSSDOCK_ORDER_XREF as scox ON coh.crossdock_order_id = scox.crossdock_order_id " +
            "WHERE scox.skope_order_id = :skopeOrderId AND ORIGIN_ORDER_COMPLETE_TS IS NULL FETCH FIRST ROW ONLY ", nativeQuery = true)
    CrossdockOrderHeaderEntity findFirstOpenCrossdockOrderHeaderBySkopeOrderId(@Param("skopeOrderId") int skopeOrderId);

    CrossdockOrderHeaderEntity findByCrossdockOrderId(int crossdockOrderId);
}
