package com.kroger.asn.repositories;

import com.kroger.asn.entities.SkopeOrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface SkopeOrderRepo extends JpaRepository<SkopeOrderEntity,Integer>
{
    @Query(value = "SELECT skope_order.* FROM skope_order, sourcing_facility " +
            "WHERE skope_order.sourcing_facility_id = sourcing_facility.sourcing_facility_id and skope_order.order_billing_division_no = :billingDivisionNumber " +
            "and skope_order.skope_order_no = :skopeOrderNumber and sourcing_facility.sourcing_facility_no = :sourcingFacilityNumber " +
            "and skope_order.store_id = :storeId and skope_order.catalog_group_id = :catGroupId " +
            "FETCH FIRST 1 ROWS ONLY", nativeQuery = true)
    SkopeOrderEntity findExistingSkopeOrder(@Param("billingDivisionNumber") String billingDivisionNumber,
                                            @Param("skopeOrderNumber") String skopeOrderNumber, @Param("sourcingFacilityNumber")  String sourcingFacilityNumber,
                                            @Param("storeId")  int storeId, @Param("catGroupId")  int catGroupId);
    SkopeOrderEntity findBySkopeOrderNo(String skopeOrderNo);
}