package com.kroger.asn.entities;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "CATALOG_GROUP")
public class CatalogGroupEntity {

    private int catalogGroupId;
    private String catalogGroupNo;
    private int sourcingFacilityId;
    private Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByCatalogGroupId;
    private Collection<CrossdockContainerEntity> crossdockContainersByCatalogGroupId;
    private Collection<SkopeOrderEntity> skopeOrdersByCatalogGroupId;

    @Id
    @Column(name = "CATALOG_GROUP_ID", nullable = false)
    public int getCatalogGroupId() {
        return catalogGroupId;
    }

    public void setCatalogGroupId(int catalogGroupId) {
        this.catalogGroupId = catalogGroupId;
    }


    @Column(name = "CATALOG_GROUP_NO", nullable = false, length = 3)
    public String getCatalogGroupNo() {
        return catalogGroupNo;
    }

    public void setCatalogGroupNo(String catalogGroupNo) {
        this.catalogGroupNo = catalogGroupNo;
    }

    @Column(name = "SOURCING_FACILITY_ID", nullable = false)
    public int getSourcingFacilityId() {
        return sourcingFacilityId;
    }

    public void setSourcingFacilityId(int sourcingFacilityId) {
        this.sourcingFacilityId = sourcingFacilityId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CatalogGroupEntity that = (CatalogGroupEntity) o;

        if (catalogGroupId != that.catalogGroupId) return false;
        if (catalogGroupNo != null ? !catalogGroupNo.equals(that.catalogGroupNo) : that.catalogGroupNo != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = catalogGroupId;
        result = 31 * result + (catalogGroupNo != null ? catalogGroupNo.hashCode() : 0);
        return result;
    }

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "catalogGroupByOriginCatalogGroupId")
    public Collection<CrossdockCatalogGroupMapEntity> getCrossdockCatalogGroupMapsByCatalogGroupId() {
        return crossdockCatalogGroupMapsByCatalogGroupId;
    }

    public void setCrossdockCatalogGroupMapsByCatalogGroupId(Collection<CrossdockCatalogGroupMapEntity> crossdockCatalogGroupMapsByCatalogGroupId) {
        this.crossdockCatalogGroupMapsByCatalogGroupId = crossdockCatalogGroupMapsByCatalogGroupId;
    }

    @OneToMany(mappedBy = "catalogGroupByOriginCatalogGroupId")
    public Collection<CrossdockContainerEntity> getCrossdockContainersByCatalogGroupId() {
        return crossdockContainersByCatalogGroupId;
    }

    public void setCrossdockContainersByCatalogGroupId(Collection<CrossdockContainerEntity> crossdockContainersByCatalogGroupId) {
        this.crossdockContainersByCatalogGroupId = crossdockContainersByCatalogGroupId;
    }

    @OneToMany(mappedBy = "catalogGroupByCatalogGroupId")
    public Collection<SkopeOrderEntity> getSkopeOrdersByCatalogGroupId() {
        return skopeOrdersByCatalogGroupId;
    }

    public void setSkopeOrdersByCatalogGroupId(Collection<SkopeOrderEntity> skopeOrdersByCatalogGroupId) {
        this.skopeOrdersByCatalogGroupId = skopeOrdersByCatalogGroupId;
    }

    @Override
    public String toString() {
        return "CatalogGroupEntity{" +
                "catalogGroupId=" + catalogGroupId +
                ", catalogGroupNo='" + catalogGroupNo + '\'' +
                '}';
    }
}
