package com.kroger.asn.util.errors;

/**
 * @author ab36672
 * Created on: 1/10/2020 10:32 AM
 */

public class SkopeOrderValidationException extends Exception {

    public SkopeOrderValidationException() {
    }

    public SkopeOrderValidationException(String message) {
        super(message);
    }

    public SkopeOrderValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public SkopeOrderValidationException(Throwable cause) {
        super(cause);
    }

    public SkopeOrderValidationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
