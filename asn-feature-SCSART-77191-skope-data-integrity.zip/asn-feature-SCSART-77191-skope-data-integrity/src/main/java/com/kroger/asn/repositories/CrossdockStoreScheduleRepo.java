package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockStoreScheduleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CrossdockStoreScheduleRepo extends JpaRepository<CrossdockStoreScheduleEntity,Integer>
{
    CrossdockStoreScheduleEntity findByCrossdockStoreMapIdAndScheduleDayNo(int crossdockStoreMapId, short dayOfWeekNumber);
}
