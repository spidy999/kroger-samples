package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockCatalogGroupMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CrossdockCatalogGroupMapRepo extends JpaRepository<CrossdockCatalogGroupMapEntity,Integer>
{
    List<CrossdockCatalogGroupMapEntity> findBySourcingFacilityByOriginSourcingFacilityIdAndCatalogGroupByOriginCatalogGroupId(int originFacilityId, int originCatGroupId);
}
