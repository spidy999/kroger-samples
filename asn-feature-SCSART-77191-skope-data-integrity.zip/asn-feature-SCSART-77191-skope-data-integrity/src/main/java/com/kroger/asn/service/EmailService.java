package com.kroger.asn.service;

import com.kroger.asn.dto.asnshipmentdata.SkopeOrder;
import com.kroger.commons.mail.EmailFactory;
import com.kroger.commons.mail.MailingListEmail;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Pallet;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.mail.Address;
import javax.mail.SendFailedException;
import javax.mail.internet.AddressException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EmailService {
    @Value("${asn.email.toEmail}")
    List<String> toEmailAddresses = new ArrayList<>();

    @Value("${asn.email.ccEmail}")
    List<String> ccEmailAddresses = new ArrayList<>();

    private Logger logger = LoggerFactory.getLogger(EmailService.class);
    private static final String TABLE_ROW_OPEN = "   <td>";
    private static final String TABLE_ROW_CLOSE = "</td>\n";

    /**
     * This method will send an email to the Nashville Routing Center with a list of unmapped SKOPE orders, as well as
     * load IDs that will not scan.
     * @param skopeOrderMap                 A list of SKOPE orders with no store map in XDock
     * @param palletsOnRouteClose           A list of pallets on this route close message
     */
    void sendNoStoreMapFoundEmail(Map<String, SkopeOrder> skopeOrderMap, List<Pallet> palletsOnRouteClose) {
        //Set email as a priority
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("X-Priority", "1");

        List<String> invalidLoadIdsToLog = new ArrayList<>();
        StringBuilder message = new StringBuilder();
        Email noStoreMapEmail = EmailFactory.getHtmlEmailInstance();
        MailingListEmail mailingListEmail = new MailingListEmail(noStoreMapEmail);
        Address[] invalidAddresses = null;
        //If we find an orderIDRef that is still valid, that load ID will still scan, so don't log it as invalid
        for (Pallet pallet : palletsOnRouteClose) {
            boolean validSkopeOrderFound = false;
            for (String orderIdReference : pallet.getOrderIdReferences()) {
                SkopeOrder skopeOrder = new SkopeOrder(orderIdReference);
                if (!skopeOrderMap.containsKey(skopeOrder.getSkopeOrderNo())) {
                    validSkopeOrderFound = true;
                }
            }
            if (!validSkopeOrderFound) {
                invalidLoadIdsToLog.add(pallet.getId());
            }
        }
        try {
            //Setting to/from values. Modify as needed for testing so as to not flood inboxes
            mailingListEmail.setSubject("CROSS DOCK ALERT - Store Map(s) Not Found");
            mailingListEmail.setHeaders(headerMap);
            for (String toEmailAddress: toEmailAddresses) {
                noStoreMapEmail.addTo(toEmailAddress);
            }
            for (String ccEmailAddress: ccEmailAddresses) {
                noStoreMapEmail.addCc(ccEmailAddress);
            }
            mailingListEmail.setFrom("noreply@kroger.com");

            //Set formatting of table in email
            message.append("<html>\n" +
                    "<head>\n" +
                    "<style>\n" +
                    "table {\n" +
                    "  font-family: arial, sans-serif;\n" +
                    "  border-collapse: collapse;\n" +
                    "  width: 50%;\n" +
                    "}\n" +
                    "\n" +
                    "td, th {\n" +
                    "  border: 1px solid #dddddd;\n" +
                    "  text-align: left;\n" +
                    "  padding: 8px;\n" +
                    "}\n" +
                    "\n" +
                    "tr:nth-child(even) {\n" +
                    "  background-color: #dddddd;\n" +
                    "}\n" +
                    "</style>\n" +
                    "</head>\n" +
                    "<body>");
            message.append("No Cross Dock store map found or delivery day not checked for the following SKOPE order(s) for Source Facility " +
                    skopeOrderMap.get(skopeOrderMap.keySet().stream().findFirst().get()).getFacilityNo() +
                    "<br>\n" +
                    "<br>\n");

            //Build table for skope order data
            message.append("<table>\n" +
                    " <tr>\n" +
                    "    <th>SKOPE Order Number</th>\n" +
                    "    <th>Division</th>\n" +
                    "    <th>Store</th>\n" +
                    " </tr>\n");
            for (Map.Entry<String,SkopeOrder> entry : skopeOrderMap.entrySet()) {
                message.append(
                        "<tr>\n" +
                        TABLE_ROW_OPEN + entry.getKey() + TABLE_ROW_CLOSE +
                        TABLE_ROW_OPEN + entry.getValue().getOrderManagementDivisionNo() + TABLE_ROW_CLOSE +
                        TABLE_ROW_OPEN + entry.getValue().getStoreNo() + TABLE_ROW_CLOSE +
                        "</tr>\n");
            }
            message.append("</table>\n");
            message.append("<br>");
            message.append("<br>");

            //Build mini table for invalid load IDs
            message.append("<table style=width:25%>\n" +
                    " <tr>\n" +
                    "    <th>Invalid Load IDs</th>\n" +
                    " </tr>\n");
            for (String loadId : invalidLoadIdsToLog) {
                message.append(
                        "<tr>\n" +
                           TABLE_ROW_OPEN + loadId + TABLE_ROW_CLOSE +
                        "</tr>\n");
            }
            message.append("</table>\n" +
                    "</body>\n" +
                    "</html>");
            mailingListEmail.setMsg(message.toString());
            mailingListEmail.send();
        } catch (EmailException emailException) {
            Throwable resendException = emailException.getCause();
            Throwable rootException = resendException != null
                    ? resendException.getCause() : null;
            if (rootException instanceof SendFailedException)
            {
                SendFailedException sendFailedException = (SendFailedException) rootException;
                invalidAddresses = sendFailedException.getInvalidAddresses();
            }
            else if (resendException instanceof SendFailedException)
            {
                SendFailedException sendFailedException = (SendFailedException) resendException;
                invalidAddresses = sendFailedException.getInvalidAddresses();
            }
            else if (resendException instanceof AddressException)
            {
                AddressException sendFailedException = (AddressException) resendException;
                logger.error("There was an error parsing an email address: {}", sendFailedException.getRef());
            }
            else if (rootException instanceof AddressException)
            {
                AddressException sendFailedException = (AddressException) rootException;
                logger.error("There was an error parsing an email address: {}", sendFailedException.getRef());
            }
            else {
                logger.error("An error occurred sending an email: {}", emailException.getMessage());
            }

        }
        if (invalidAddresses != null)
        {
            for (Address invalidAddress : invalidAddresses)
            {
                logger.error("Invalid email address: {}", invalidAddress.toString());
            }
        }
    }
}
