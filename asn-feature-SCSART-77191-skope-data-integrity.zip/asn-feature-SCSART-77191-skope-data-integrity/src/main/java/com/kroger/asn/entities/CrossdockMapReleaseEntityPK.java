package com.kroger.asn.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

public class CrossdockMapReleaseEntityPK implements Serializable {
    private int crossdockMapId;
    private int processDayNo;

    @Column(name = "CROSSDOCK_MAP_ID", nullable = false)
    @Id
    public int getCrossdockMapId() {
        return crossdockMapId;
    }

    public void setCrossdockMapId(int crossdockMapId) {
        this.crossdockMapId = crossdockMapId;
    }

    @Column(name = "PROCESS_DAY_NO", nullable = false)
    @Id
    public int getProcessDayNo() {
        return processDayNo;
    }

    public void setProcessDayNo(int processDayNo) {
        this.processDayNo = processDayNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockMapReleaseEntityPK that = (CrossdockMapReleaseEntityPK) o;

        if (crossdockMapId != that.crossdockMapId) return false;
        if (processDayNo != that.processDayNo) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockMapId;
        result = 31 * result + processDayNo;
        return result;
    }

    @Override
    public String toString() {
        return "CrossdockMapReleaseEntityPK{" +
                "crossdockMapId=" + crossdockMapId +
                ", processDayNo=" + processDayNo +
                '}';
    }
}
