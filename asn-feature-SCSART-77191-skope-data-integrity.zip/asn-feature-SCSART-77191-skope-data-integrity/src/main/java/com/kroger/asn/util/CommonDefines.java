package com.kroger.asn.util;

public enum CommonDefines {
    NO("N"),
    ASN_ID_PREFIX("ASN-");

    private String value;

    CommonDefines(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return this.value;
    }
}
