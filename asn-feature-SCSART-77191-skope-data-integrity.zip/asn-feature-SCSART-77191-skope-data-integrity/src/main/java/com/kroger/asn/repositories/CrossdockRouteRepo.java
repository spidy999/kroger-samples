package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockRouteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Date;

@Repository
public interface CrossdockRouteRepo extends JpaRepository<CrossdockRouteEntity, Integer>
{
    CrossdockRouteEntity findBySourcingFacilityIdAndRouteNmeAndDispatchDt(Integer sourcingFacilityId, String routeNme, Date dispatchDt);
    CrossdockRouteEntity findByRouteId(Integer RouteId);
}
