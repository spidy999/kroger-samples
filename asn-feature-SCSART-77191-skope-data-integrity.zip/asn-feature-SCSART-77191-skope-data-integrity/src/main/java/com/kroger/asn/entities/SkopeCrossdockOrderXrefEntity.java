package com.kroger.asn.entities;

import javax.persistence.*;

@Entity
@Table(name = "SKOPE_CROSSDOCK_ORDER_XREF")
@IdClass(SkopeCrossdockOrderXrefEntityPK.class)
public class SkopeCrossdockOrderXrefEntity {
    private int crossdockOrderId;
    private int skopeOrderId;
    private CrossdockOrderHeaderEntity crossdockOrderHeaderByCrossdockOrderId;
    private SkopeOrderEntity skopeOrderBySkopeOrderId;

    public SkopeCrossdockOrderXrefEntity() {
    }

    public SkopeCrossdockOrderXrefEntity(int crossdockOrderId, int skopeOrderId) {
        this.crossdockOrderId = crossdockOrderId;
        this.skopeOrderId = skopeOrderId;
    }

    @Id
    @Column(name = "CROSSDOCK_ORDER_ID", nullable = false)
    public int getCrossdockOrderId() {
        return crossdockOrderId;
    }

    public void setCrossdockOrderId(int crossdockOrderId) {
        this.crossdockOrderId = crossdockOrderId;
    }

    @Id
    @Column(name = "SKOPE_ORDER_ID", nullable = false)
    public int getSkopeOrderId() {
        return skopeOrderId;
    }

    public void setSkopeOrderId(int skopeOrderId) {
        this.skopeOrderId = skopeOrderId;
    }

    @Override
    public String toString() {
        return "SkopeCrossdockOrderXrefEntity{" +
                "crossdockOrderId=" + crossdockOrderId +
                ", skopeOrderId=" + skopeOrderId +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SkopeCrossdockOrderXrefEntity that = (SkopeCrossdockOrderXrefEntity) o;

        if (crossdockOrderId != that.crossdockOrderId) return false;
        if (skopeOrderId != that.skopeOrderId) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockOrderId;
        result = 31 * result + skopeOrderId;
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_ORDER_ID", referencedColumnName = "CROSSDOCK_ORDER_ID", nullable = false,insertable = false, updatable = false)
    public CrossdockOrderHeaderEntity getCrossdockOrderHeaderByCrossdockOrderId() {
        return crossdockOrderHeaderByCrossdockOrderId;
    }

    public void setCrossdockOrderHeaderByCrossdockOrderId(CrossdockOrderHeaderEntity crossdockOrderHeaderByCrossdockOrderId) {
        this.crossdockOrderHeaderByCrossdockOrderId = crossdockOrderHeaderByCrossdockOrderId;
    }

    @ManyToOne
    @JoinColumn(name = "SKOPE_ORDER_ID", referencedColumnName = "SKOPE_ORDER_ID", nullable = false,insertable = false, updatable = false)
    public SkopeOrderEntity getSkopeOrderBySkopeOrderId() {
        return skopeOrderBySkopeOrderId;
    }

    public void setSkopeOrderBySkopeOrderId(SkopeOrderEntity skopeOrderBySkopeOrderId) {
        this.skopeOrderBySkopeOrderId = skopeOrderBySkopeOrderId;
    }

}
