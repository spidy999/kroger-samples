package com.kroger.asn.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.kroger.commons.error.AbstractGlobalExceptionHandler;
import com.kroger.commons.error.EnableMissingWebRouteSupport;

import brave.Tracer;

@RestControllerAdvice
@EnableMissingWebRouteSupport
public class GlobalExceptionHandler extends AbstractGlobalExceptionHandler
{
    public GlobalExceptionHandler(@Autowired(required = false)Tracer tracer)
    {
        super(tracer);
    }


}