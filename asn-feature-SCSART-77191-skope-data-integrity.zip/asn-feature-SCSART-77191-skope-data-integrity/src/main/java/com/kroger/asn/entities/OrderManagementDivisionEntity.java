package com.kroger.asn.entities;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "ORDER_MANAGEMENT_DIVISION")
public class OrderManagementDivisionEntity {
    private int orderManagementDivisionId;
    private String orderManagementDivisionNo;
    private String orderManagementDivisionNme;
    private Collection<CrossdockMapEntity> crossdockMapsByOrderManagementDivisionId;
    private Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByOrderManagementDivisionId;
    private Collection<SkopeOrderEntity> skopeOrdersByOrderManagementDivisionId;

    @Id
    @Column(name = "ORDER_MANAGEMENT_DIVISION_ID", nullable = false)
    public int getOrderManagementDivisionId() {
        return orderManagementDivisionId;
    }

    public void setOrderManagementDivisionId(int orderManagementDivisionId) {
        this.orderManagementDivisionId = orderManagementDivisionId;
    }


    @Column(name = "ORDER_MANAGEMENT_DIVISION_NO", nullable = false, length = 3)
    public String getOrderManagementDivisionNo() {
        return orderManagementDivisionNo;
    }

    public void setOrderManagementDivisionNo(String orderManagementDivisionNo) {
        this.orderManagementDivisionNo = orderManagementDivisionNo;
    }


    @Column(name = "ORDER_MANAGEMENT_DIVISION_NME", nullable = false, length = 30)
    public String getOrderManagementDivisionNme() {
        return orderManagementDivisionNme;
    }

    public void setOrderManagementDivisionNme(String orderManagementDivisionNme) {
        this.orderManagementDivisionNme = orderManagementDivisionNme;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderManagementDivisionEntity that = (OrderManagementDivisionEntity) o;

        if (orderManagementDivisionId != that.orderManagementDivisionId) return false;
        if (orderManagementDivisionNo != null ? !orderManagementDivisionNo.equals(that.orderManagementDivisionNo) : that.orderManagementDivisionNo != null)
            return false;
        if (orderManagementDivisionNme != null ? !orderManagementDivisionNme.equals(that.orderManagementDivisionNme) : that.orderManagementDivisionNme != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = orderManagementDivisionId;
        result = 31 * result + (orderManagementDivisionNo != null ? orderManagementDivisionNo.hashCode() : 0);
        result = 31 * result + (orderManagementDivisionNme != null ? orderManagementDivisionNme.hashCode() : 0);
        return result;
    }

    @OneToMany(mappedBy = "orderManagementDivisionByOrderManagementDivisionId")
    public Collection<CrossdockMapEntity> getCrossdockMapsByOrderManagementDivisionId() {
        return crossdockMapsByOrderManagementDivisionId;
    }

    public void setCrossdockMapsByOrderManagementDivisionId(Collection<CrossdockMapEntity> crossdockMapsByOrderManagementDivisionId) {
        this.crossdockMapsByOrderManagementDivisionId = crossdockMapsByOrderManagementDivisionId;
    }

    @OneToMany(mappedBy = "orderManagementDivisionByOrderManagementDivisionId")
    public Collection<CrossdockOrderHeaderEntity> getCrossdockOrderHeadersByOrderManagementDivisionId() {
        return crossdockOrderHeadersByOrderManagementDivisionId;
    }

    public void setCrossdockOrderHeadersByOrderManagementDivisionId(Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByOrderManagementDivisionId) {
        this.crossdockOrderHeadersByOrderManagementDivisionId = crossdockOrderHeadersByOrderManagementDivisionId;
    }

    @OneToMany(mappedBy = "orderManagementDivisionByOrderManagementDivisionId")
    public Collection<SkopeOrderEntity> getSkopeOrdersByOrderManagementDivisionId() {
        return skopeOrdersByOrderManagementDivisionId;
    }

    public void setSkopeOrdersByOrderManagementDivisionId(Collection<SkopeOrderEntity> skopeOrdersByOrderManagementDivisionId) {
        this.skopeOrdersByOrderManagementDivisionId = skopeOrdersByOrderManagementDivisionId;
    }

    @Override
    public String toString() {
        return "OrderManagementDivisionEntity{" +
                "orderManagementDivisionId=" + orderManagementDivisionId +
                ", orderManagementDivisionNo='" + orderManagementDivisionNo + '\'' +
                ", orderManagementDivisionNme='" + orderManagementDivisionNme + '\'' +
                '}';
    }
}
