package com.kroger.asn.service;

import com.kroger.schema.canonical.xdoc._3_0.AcknowledgeCrossDockOrderType;
import com.kroger.schema.canonical.xdoc._3_0.SyncCrossDockOrderType;
import com.kroger.xdock.webservices.orderservice.ws.CrossDockOrderInterface;
import org.springframework.stereotype.Service;


@Service
public class CrossDockOrderServiceImpl implements CrossDockOrderService {
	
	private CrossDockOrderInterface crossDockOrderInterface;

	public void setCrossDockOrderClient(CrossDockOrderInterface crossDockOrderInterface) {
		this.crossDockOrderInterface = crossDockOrderInterface;
	}

	@Override
	public AcknowledgeCrossDockOrderType syncCrossDockOrder(SyncCrossDockOrderType type) {
		return crossDockOrderInterface.syncCrossDockOrder(type);
	}

}
