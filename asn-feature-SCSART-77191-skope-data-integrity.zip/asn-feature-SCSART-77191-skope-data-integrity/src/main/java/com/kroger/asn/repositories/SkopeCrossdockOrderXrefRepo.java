package com.kroger.asn.repositories;

import com.kroger.asn.entities.SkopeCrossdockOrderXrefEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface SkopeCrossdockOrderXrefRepo extends JpaRepository<SkopeCrossdockOrderXrefEntity,Integer>
{
    Optional<List<SkopeCrossdockOrderXrefEntity> > findAllBySkopeOrderId(int skopeOrderId);

    Optional<SkopeCrossdockOrderXrefEntity> findFirstByCrossdockOrderIdAndAndSkopeOrderId(int crossdockOrderId, int skopeOrderId);

}
