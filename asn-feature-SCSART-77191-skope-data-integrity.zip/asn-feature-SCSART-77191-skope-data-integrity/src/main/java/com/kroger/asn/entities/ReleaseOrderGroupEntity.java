package com.kroger.asn.entities;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "RELEASE_ORDER_GROUP")
public class ReleaseOrderGroupEntity {
    private int releaseOrderGroupId;
    private String releaseTypeCd;
    private String releaseUserId;
    private Timestamp releaseTs;
    private Collection<ReleaseOrderGroupXrefEntity> releaseOrderGroupXrefsByReleaseOrderGroupId;

    @Id
    @Column(name = "RELEASE_ORDER_GROUP_ID", nullable = false)
    public int getReleaseOrderGroupId() {
        return releaseOrderGroupId;
    }

    public void setReleaseOrderGroupId(int releaseOrderGroupId) {
        this.releaseOrderGroupId = releaseOrderGroupId;
    }


    @Column(name = "RELEASE_TYPE_CD",length = 1)
    public String getReleaseTypeCd() {
        return releaseTypeCd;
    }

    public void setReleaseTypeCd(String releaseTypeCd) {
        this.releaseTypeCd = releaseTypeCd;
    }

    @Override
    public String toString() {
        return "ReleaseOrderGroupEntity{" +
                "releaseOrderGroupId=" + releaseOrderGroupId +
                ", releaseTypeCd='" + releaseTypeCd + '\'' +
                ", releaseUserId='" + releaseUserId + '\'' +
                ", releaseTs=" + releaseTs +
                '}';
    }

    @Column(name = "RELEASE_USER_ID", length = 8)
    public String getReleaseUserId() {
        return releaseUserId;
    }

    public void setReleaseUserId(String releaseUserId) {
        this.releaseUserId = releaseUserId;
    }


    @Column(name = "RELEASE_TS")
    public Timestamp getReleaseTs() {
        return releaseTs;
    }

    public void setReleaseTs(Timestamp releaseTs) {
        this.releaseTs = releaseTs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReleaseOrderGroupEntity that = (ReleaseOrderGroupEntity) o;

        if (releaseOrderGroupId != that.releaseOrderGroupId) return false;
        if (releaseTypeCd != null ? !releaseTypeCd.equals(that.releaseTypeCd) : that.releaseTypeCd != null)
            return false;
        if (releaseUserId != null ? !releaseUserId.equals(that.releaseUserId) : that.releaseUserId != null)
            return false;
        if (releaseTs != null ? !releaseTs.equals(that.releaseTs) : that.releaseTs != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = releaseOrderGroupId;
        result = 31 * result + (releaseTypeCd != null ? releaseTypeCd.hashCode() : 0);
        result = 31 * result + (releaseUserId != null ? releaseUserId.hashCode() : 0);
        result = 31 * result + (releaseTs != null ? releaseTs.hashCode() : 0);
        return result;
    }

    @OneToMany(mappedBy = "releaseOrderGroupByReleaseOrderGroupId")
    public Collection<ReleaseOrderGroupXrefEntity> getReleaseOrderGroupXrefsByReleaseOrderGroupId() {
        return releaseOrderGroupXrefsByReleaseOrderGroupId;
    }

    public void setReleaseOrderGroupXrefsByReleaseOrderGroupId(Collection<ReleaseOrderGroupXrefEntity> releaseOrderGroupXrefsByReleaseOrderGroupId) {
        this.releaseOrderGroupXrefsByReleaseOrderGroupId = releaseOrderGroupXrefsByReleaseOrderGroupId;
    }

}
