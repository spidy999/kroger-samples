package com.kroger.asn.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author ab36672
 * Created on: 3/6/2020 2:44 PM
 */

public class AuditEventLogEntityPK implements Serializable {

    private String auditEventCd;
    private Timestamp auditTs;

    @Id
    @Column(name = "AUDIT_EVENT_CD", nullable = true, length = 2)
    public String getAuditEventCd() {
        return auditEventCd;
    }

    public void setAuditEventCd(String auditEventCd) {
        this.auditEventCd = auditEventCd;
    }

    @Id
    @Column(name = "AUDIT_TS", nullable = false)
    public Timestamp getAuditTs() {
        return auditTs;
    }

    public void setAuditTs(Timestamp auditTs) {
        this.auditTs = auditTs;
    }


    @Override
    public String toString() {
        return "AuditEventLogEntityPK{" +
                "auditEventCd='" + auditEventCd + '\'' +
                ", auditTs=" + auditTs +
                '}';
    }
}
