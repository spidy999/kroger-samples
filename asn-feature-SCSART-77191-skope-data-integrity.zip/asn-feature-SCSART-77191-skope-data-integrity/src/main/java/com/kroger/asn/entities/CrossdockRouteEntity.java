package com.kroger.asn.entities;

import com.kroger.asn.util.CommonDefines;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.ShipmentData;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;

@Entity
@Table(name = "CROSSDOCK_ROUTE")
public class CrossdockRouteEntity {

    private int routeId;
    private Integer sourcingFacilityId; //in
    private String routeNme; //in
    private Date dispatchDt; //in
    private String crossdockTrailerNo; // change
    private String crossdockCarrierCd;
    private String crossdockTrailerTypeCd;
    private Timestamp routeCloseTs;
    private Timestamp rowCreateTs;
    private Timestamp rowUpdateTs;
    private String rowCreateId;
    private String rowUpdateId;


    public CrossdockRouteEntity() {
    }

    public CrossdockRouteEntity(ShipmentData shipmentData, SourcingFacilityEntity originFacility, Timestamp originFacilityShipmentTs) {
        this.crossdockCarrierCd = shipmentData.getCarrierCode().toUpperCase();
        this.routeNme = shipmentData.getRouteName().toUpperCase();
        this.sourcingFacilityId = originFacility.getSourcingFacilityId();
        this.crossdockTrailerNo = shipmentData.getTrailerNumber().toUpperCase();
        //Hard code trailer type code until issue with external api dropping the field is fixed
        this.crossdockTrailerTypeCd = shipmentData.getTrailerType().toUpperCase();
        this.routeCloseTs = originFacilityShipmentTs;
        this.dispatchDt = Date.valueOf(this.routeCloseTs.toLocalDateTime().toLocalDate());
        this.rowCreateTs = new Timestamp(System.currentTimeMillis());
        this.rowCreateId = CommonDefines.ASN_ID_PREFIX + originFacility.getSourcingFacilityNo();
        this.rowUpdateTs = new Timestamp(System.currentTimeMillis());
        this.rowUpdateId = CommonDefines.ASN_ID_PREFIX + originFacility.getSourcingFacilityNo();
    }

    //this constructor is for ASNOrderSummary Events
    public CrossdockRouteEntity(SourcingFacilityEntity originFacility, String routeNme) {
        this.sourcingFacilityId = originFacility.getSourcingFacilityId();
        this.routeNme = routeNme;
        this.rowCreateTs = new Timestamp(System.currentTimeMillis());
        this.rowCreateId = CommonDefines.ASN_ID_PREFIX + originFacility.getSourcingFacilityNo();
        this.rowUpdateTs = new Timestamp(System.currentTimeMillis());
        this.rowUpdateId = CommonDefines.ASN_ID_PREFIX + originFacility.getSourcingFacilityNo();
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ROUTE_ID", nullable = false)
    public int getRouteId() {
        return routeId;
    }

    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }


    @Column(name = "SOURCING_FACILITY_ID")
    public Integer getSourcingFacilityId() {
        return sourcingFacilityId;
    }

    public void setSourcingFacilityId(Integer sourcingFacilityId) {
        this.sourcingFacilityId = sourcingFacilityId;
    }


    @Column(name = "ROUTE_NME",length = 6)
    public String getRouteNme() {
        return routeNme;
    }

    public void setRouteNme(String routeNme) {
        this.routeNme = routeNme;
    }


    @Column(name = "DISPATCH_DT")
    public Date getDispatchDt() {
        return dispatchDt;
    }

    public void setDispatchDt(Date dispatchDt) {
        this.dispatchDt = dispatchDt;
    }


    @Column(name = "CROSSDOCK_TRAILER_NO", length = 12)
    public String getCrossdockTrailerNo() {
        return crossdockTrailerNo;
    }

    public void setCrossdockTrailerNo(String crossdockTrailerNo) {
        this.crossdockTrailerNo = crossdockTrailerNo;
    }


    @Column(name = "CROSSDOCK_CARRIER_CD", length = 4)
    public String getCrossdockCarrierCd() {
        return crossdockCarrierCd;
    }

    public void setCrossdockCarrierCd(String crossdockCarrierCd) {
        this.crossdockCarrierCd = crossdockCarrierCd;
    }


    @Column(name = "CROSSDOCK_TRAILER_TYPE_CD", length = 12)
    public String getCrossdockTrailerTypeCd() {
        return crossdockTrailerTypeCd;
    }

    public void setCrossdockTrailerTypeCd(String crossdockTrailerTypeCd) {
        this.crossdockTrailerTypeCd = crossdockTrailerTypeCd;
    }


    @Column(name = "ROUTE_CLOSE_TS")
    public Timestamp getRouteCloseTs() {
        return routeCloseTs;
    }

    public void setRouteCloseTs(Timestamp routeCloseTs) {
        this.routeCloseTs = routeCloseTs;
    }


    @Column(name = "ROW_CREATE_TS", nullable = false)
    public Timestamp getRowCreateTs() {
        return rowCreateTs;
    }

    public void setRowCreateTs(Timestamp rowCreateTs) {
        this.rowCreateTs = rowCreateTs;
    }


    @Column(name = "ROW_UPDATE_TS", nullable = false)
    public Timestamp getRowUpdateTs() {
        return rowUpdateTs;
    }

    public void setRowUpdateTs(Timestamp rowUpdateTs) {
        this.rowUpdateTs = rowUpdateTs;
    }


    @Column(name = "ROW_CREATE_ID", length = 8)
    public String getRowCreateId() {
        return rowCreateId;
    }

    public void setRowCreateId(String rowCreateId) {
        this.rowCreateId = rowCreateId;
    }


    @Column(name = "ROW_UPDATE_ID", length = 8)
    public String getRowUpdateId() {
        return rowUpdateId;
    }

    public void setRowUpdateId(String rowUpdateId) {
        this.rowUpdateId = rowUpdateId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockRouteEntity that = (CrossdockRouteEntity) o;

        if (routeId != that.routeId) return false;
        if (sourcingFacilityId != null ? !sourcingFacilityId.equals(that.sourcingFacilityId) : that.sourcingFacilityId != null)
            return false;
        if (routeNme != null ? !routeNme.equals(that.routeNme) : that.routeNme != null) return false;
        if (dispatchDt != null ? !dispatchDt.equals(that.dispatchDt) : that.dispatchDt != null) return false;
        if (crossdockTrailerNo != null ? !crossdockTrailerNo.equals(that.crossdockTrailerNo) : that.crossdockTrailerNo != null)
            return false;
        if (crossdockCarrierCd != null ? !crossdockCarrierCd.equals(that.crossdockCarrierCd) : that.crossdockCarrierCd != null)
            return false;
        if (crossdockTrailerTypeCd != null ? !crossdockTrailerTypeCd.equals(that.crossdockTrailerTypeCd) : that.crossdockTrailerTypeCd != null)
            return false;
        if (routeCloseTs != null ? !routeCloseTs.equals(that.routeCloseTs) : that.routeCloseTs != null) return false;
        if (rowCreateTs != null ? !rowCreateTs.equals(that.rowCreateTs) : that.rowCreateTs != null) return false;
        if (rowUpdateTs != null ? !rowUpdateTs.equals(that.rowUpdateTs) : that.rowUpdateTs != null) return false;
        if (rowCreateId != null ? !rowCreateId.equals(that.rowCreateId) : that.rowCreateId != null) return false;
        if (rowUpdateId != null ? !rowUpdateId.equals(that.rowUpdateId) : that.rowUpdateId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = routeId;
        result = 31 * result + (sourcingFacilityId != null ? sourcingFacilityId.hashCode() : 0);
        result = 31 * result + (routeNme != null ? routeNme.hashCode() : 0);
        result = 31 * result + (dispatchDt != null ? dispatchDt.hashCode() : 0);
        result = 31 * result + (crossdockTrailerNo != null ? crossdockTrailerNo.hashCode() : 0);
        result = 31 * result + (crossdockCarrierCd != null ? crossdockCarrierCd.hashCode() : 0);
        result = 31 * result + (crossdockTrailerTypeCd != null ? crossdockTrailerTypeCd.hashCode() : 0);
        result = 31 * result + (routeCloseTs != null ? routeCloseTs.hashCode() : 0);
        result = 31 * result + (rowCreateTs != null ? rowCreateTs.hashCode() : 0);
        result = 31 * result + (rowUpdateTs != null ? rowUpdateTs.hashCode() : 0);
        result = 31 * result + (rowCreateId != null ? rowCreateId.hashCode() : 0);
        result = 31 * result + (rowUpdateId != null ? rowUpdateId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CrossdockRouteEntity{" +
                "routeId=" + routeId +
                ", sourcingFacilityId=" + sourcingFacilityId +
                ", routeNme='" + routeNme + '\'' +
                ", dispatchDt=" + dispatchDt +
                ", crossdockTrailerNo='" + crossdockTrailerNo + '\'' +
                ", crossdockCarrierCd='" + crossdockCarrierCd + '\'' +
                ", crossdockTrailerTypeCd='" + crossdockTrailerTypeCd + '\'' +
                ", routeCloseTs=" + routeCloseTs +
                ", rowCreateTs=" + rowCreateTs +
                ", rowUpdateTs=" + rowUpdateTs +
                ", rowCreateId='" + rowCreateId + '\'' +
                ", rowUpdateId='" + rowUpdateId + '\'' +
                '}';
    }
}
