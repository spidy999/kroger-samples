package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CrossdockMapRepo extends JpaRepository<CrossdockMapEntity,Integer>
{
    CrossdockMapEntity findByCrossdockMapId(int crossdockMapId);
}
