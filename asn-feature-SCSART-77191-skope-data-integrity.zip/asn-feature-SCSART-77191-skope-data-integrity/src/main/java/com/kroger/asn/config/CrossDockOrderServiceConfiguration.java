package com.kroger.asn.config;

import com.kroger.asn.service.AsnRouteCloseService;
import com.kroger.asn.service.CrossDockOrderService;
import com.kroger.asn.service.CrossDockOrderServiceImpl;
import com.kroger.xdock.webservices.orderservice.ws.CrossDockOrderInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.namespace.QName;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import java.net.URL;
import java.util.List;
import java.util.Map;

@Configuration
public class CrossDockOrderServiceConfiguration {
    protected static Logger LOG = LoggerFactory.getLogger(CrossDockOrderServiceConfiguration.class);

    @Value("${kroger.webmethods.win.serverName}")
    String serverName;

    @Value("${kroger.webmethods.win.portNumber}")
    String portNumber;

    @Value("${kroger.webmethods.win.username}")
    String userName;

    @Value("${kroger.webmethods.win.password}")
    String password;


    @Bean
    public CrossDockOrderService crossDockOrderClient()
    {

        URL wsdlLocation = AsnRouteCloseService.class.getResource("/com/kroger/xdock/webservices/CrossDockOrderService.wsdl");
        com.kroger.xdock.webservices.orderservice.ws.CrossDockOrderService crossDockOrderService = new com.kroger.xdock.webservices.orderservice.ws.CrossDockOrderService(
                wsdlLocation, new QName("http://www.webservices.kroger.com/ws/xdoc/CrossDockOrder", "CrossDockOrderService"));

        CrossDockOrderInterface crossDockOrderInterface = crossDockOrderService.getCrossDockOrderBinding();
        configureCrossDockOrderInterface(crossDockOrderInterface);

        CrossDockOrderServiceImpl crossDockOrderSoaWebService = new CrossDockOrderServiceImpl();

        configureCrossDockOrderService(crossDockOrderSoaWebService, crossDockOrderInterface);

        return crossDockOrderSoaWebService;
    }

    protected void configureCrossDockOrderInterface(CrossDockOrderInterface crossDockOrderInterface)
    {

        BindingProvider bindingProvider = ((BindingProvider) crossDockOrderInterface);

        Binding binding = bindingProvider.getBinding();
        List<Handler> handlerChain = binding.getHandlerChain();

        WebServiceSoapMessageLogger webServiceSoapMessageLogger = new WebServiceSoapMessageLogger(LOG);

        handlerChain.add(webServiceSoapMessageLogger);
        binding.setHandlerChain(handlerChain);

        Map<String, Object> requestContext = bindingProvider.getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://"+serverName+":"+portNumber+"/crossdock/CrossDockOrderService");
        requestContext.put(BindingProvider.USERNAME_PROPERTY, userName);
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, password);
    }

    protected void configureCrossDockOrderService( CrossDockOrderServiceImpl crossDockOrderSoaWebService,
                                                   CrossDockOrderInterface crossDockOrderInterface)
    {
        crossDockOrderSoaWebService.setCrossDockOrderClient(crossDockOrderInterface);
    }
}
