package com.kroger.asn.util;

import com.kroger.commons.calendar.KrogerFiscalCalendar;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author ab36672
 * Created on: 1/3/2020 12:09 PM
 */

public class DateParser {

    //This class should not be instantiated as it is a util class
    protected DateParser() {
        throw new IllegalStateException("DateParser is utility class and should not be instantiated.");
    }

    public static KrogerFiscalCalendar dateToKrogerFiscalCalendar(Date baseDate)
    {
        GregorianCalendar date = (GregorianCalendar) Calendar.getInstance();
        date.setTime(baseDate);
        return new KrogerFiscalCalendar(date);
    }

    public static int dayOfTheWeek(Date baseDate)
    {
        GregorianCalendar date = (GregorianCalendar) Calendar.getInstance();
        date.setTime(baseDate);
        return date.get(Calendar.DAY_OF_WEEK);
    }
}
