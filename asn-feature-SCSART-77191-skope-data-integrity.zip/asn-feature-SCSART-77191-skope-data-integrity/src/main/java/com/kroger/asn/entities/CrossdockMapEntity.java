package com.kroger.asn.entities;

import com.kroger.asn.util.DateParser;
import com.kroger.commons.calendar.KrogerFiscalCalendar;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "CROSSDOCK_MAP")
public class CrossdockMapEntity {
    private static final String CALENDAR_14_DAY = "B";

    private int crossdockMapId;
    private Timestamp crossdockMapStartTs;
    private Timestamp crossdockMapEndTs;
    private String crossdockMapNme;
    private String crossdockScheduleCalendarCd;
    private String releaseCd;
    private Timestamp rowCreateTs;
    private Timestamp rowUpdateTs;
    private String rowCreateId;
    private String rowUpdateId;
    private CrossdockCatalogGroupMapEntity crossdockCatalogGroupMapByCrossdockCatalogGroupMapId;
    private OrderManagementDivisionEntity orderManagementDivisionByOrderManagementDivisionId;
    private Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByCrossdockMapId;
    private Collection<CrossdockStoreMapEntity> crossdockStoreMapsByCrossdockMapId;


    @Id
    @Column(name = "CROSSDOCK_MAP_ID", nullable = false)
    public int getCrossdockMapId() {
        return crossdockMapId;
    }

    public void setCrossdockMapId(int crossdockMapId) {
        this.crossdockMapId = crossdockMapId;
    }


    @Column(name = "CROSSDOCK_MAP_START_TS", nullable = false)
    public Timestamp getCrossdockMapStartTs() {
        return crossdockMapStartTs;
    }

    public void setCrossdockMapStartTs(Timestamp crossdockMapStartTs) {
        this.crossdockMapStartTs = crossdockMapStartTs;
    }


    @Column(name = "CROSSDOCK_MAP_END_TS")
    public Timestamp getCrossdockMapEndTs() {
        return crossdockMapEndTs;
    }

    public void setCrossdockMapEndTs(Timestamp crossdockMapEndTs) {
        this.crossdockMapEndTs = crossdockMapEndTs;
    }


    @Column(name = "CROSSDOCK_MAP_NME", length = 50)
    public String getCrossdockMapNme() {
        return crossdockMapNme;
    }

    public void setCrossdockMapNme(String crossdockMapNme) {
        this.crossdockMapNme = crossdockMapNme;
    }


    @Column(name = "CROSSDOCK_SCHEDULE_CALENDAR_CD", nullable = false, length = 1)
    public String getCrossdockScheduleCalendarCd() {
        return crossdockScheduleCalendarCd;
    }

    public void setCrossdockScheduleCalendarCd(String crossdockScheduleCalendarCd) {
        this.crossdockScheduleCalendarCd = crossdockScheduleCalendarCd;
    }


    @Column(name = "RELEASE_CD", length = 1)
    public String getReleaseCd() {
        return releaseCd;
    }

    public void setReleaseCd(String releaseCd) {
        this.releaseCd = releaseCd;
    }


    @Column(name = "ROW_CREATE_TS", nullable = false)
    public Timestamp getRowCreateTs() {
        return rowCreateTs;
    }

    public void setRowCreateTs(Timestamp rowCreateTs) {
        this.rowCreateTs = rowCreateTs;
    }


    @Column(name = "ROW_UPDATE_TS", nullable = false)
    public Timestamp getRowUpdateTs() {
        return rowUpdateTs;
    }

    public void setRowUpdateTs(Timestamp rowUpdateTs) {
        this.rowUpdateTs = rowUpdateTs;
    }


    @Column(name = "ROW_CREATE_ID", length = 8)
    public String getRowCreateId() {
        return rowCreateId;
    }

    public void setRowCreateId(String rowCreateId) {
        this.rowCreateId = rowCreateId;
    }


    @Column(name = "ROW_UPDATE_ID", length = 8)
    public String getRowUpdateId() {
        return rowUpdateId;
    }

    public void setRowUpdateId(String rowUpdateId) {
        this.rowUpdateId = rowUpdateId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockMapEntity that = (CrossdockMapEntity) o;

        if (crossdockMapId != that.crossdockMapId) return false;
        if (crossdockMapStartTs != null ? !crossdockMapStartTs.equals(that.crossdockMapStartTs) : that.crossdockMapStartTs != null)
            return false;
        if (crossdockMapEndTs != null ? !crossdockMapEndTs.equals(that.crossdockMapEndTs) : that.crossdockMapEndTs != null)
            return false;
        if (crossdockMapNme != null ? !crossdockMapNme.equals(that.crossdockMapNme) : that.crossdockMapNme != null)
            return false;
        if (crossdockScheduleCalendarCd != null ? !crossdockScheduleCalendarCd.equals(that.crossdockScheduleCalendarCd) : that.crossdockScheduleCalendarCd != null)
            return false;
        if (releaseCd != null ? !releaseCd.equals(that.releaseCd) : that.releaseCd != null) return false;
        if (rowCreateTs != null ? !rowCreateTs.equals(that.rowCreateTs) : that.rowCreateTs != null) return false;
        if (rowUpdateTs != null ? !rowUpdateTs.equals(that.rowUpdateTs) : that.rowUpdateTs != null) return false;
        if (rowCreateId != null ? !rowCreateId.equals(that.rowCreateId) : that.rowCreateId != null) return false;
        if (rowUpdateId != null ? !rowUpdateId.equals(that.rowUpdateId) : that.rowUpdateId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockMapId;
        result = 31 * result + (crossdockMapStartTs != null ? crossdockMapStartTs.hashCode() : 0);
        result = 31 * result + (crossdockMapEndTs != null ? crossdockMapEndTs.hashCode() : 0);
        result = 31 * result + (crossdockMapNme != null ? crossdockMapNme.hashCode() : 0);
        result = 31 * result + (crossdockScheduleCalendarCd != null ? crossdockScheduleCalendarCd.hashCode() : 0);
        result = 31 * result + (releaseCd != null ? releaseCd.hashCode() : 0);
        result = 31 * result + (rowCreateTs != null ? rowCreateTs.hashCode() : 0);
        result = 31 * result + (rowUpdateTs != null ? rowUpdateTs.hashCode() : 0);
        result = 31 * result + (rowCreateId != null ? rowCreateId.hashCode() : 0);
        result = 31 * result + (rowUpdateId != null ? rowUpdateId.hashCode() : 0);
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_CATALOG_GROUP_MAP_ID", referencedColumnName = "CROSSDOCK_CATALOG_GROUP_MAP_ID", nullable = false)
    public CrossdockCatalogGroupMapEntity getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId() {
        return crossdockCatalogGroupMapByCrossdockCatalogGroupMapId;
    }

    public void setCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId(CrossdockCatalogGroupMapEntity crossdockCatalogGroupMapByCrossdockCatalogGroupMapId) {
        this.crossdockCatalogGroupMapByCrossdockCatalogGroupMapId = crossdockCatalogGroupMapByCrossdockCatalogGroupMapId;
    }

    @ManyToOne
    @JoinColumn(name = "ORDER_MANAGEMENT_DIVISION_ID", referencedColumnName = "ORDER_MANAGEMENT_DIVISION_ID", nullable = false)
    public OrderManagementDivisionEntity getOrderManagementDivisionByOrderManagementDivisionId() {
        return orderManagementDivisionByOrderManagementDivisionId;
    }

    public void setOrderManagementDivisionByOrderManagementDivisionId(OrderManagementDivisionEntity orderManagementDivisionByOrderManagementDivisionId) {
        this.orderManagementDivisionByOrderManagementDivisionId = orderManagementDivisionByOrderManagementDivisionId;
    }

    @OneToMany(mappedBy = "crossdockMapByCrossdockMapId")
    public Collection<CrossdockOrderHeaderEntity> getCrossdockOrderHeadersByCrossdockMapId() {
        return crossdockOrderHeadersByCrossdockMapId;
    }

    public void setCrossdockOrderHeadersByCrossdockMapId(Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByCrossdockMapId) {
        this.crossdockOrderHeadersByCrossdockMapId = crossdockOrderHeadersByCrossdockMapId;
    }

    @OneToMany(mappedBy = "crossdockMapByCrossdockMapId")
    public Collection<CrossdockStoreMapEntity> getCrossdockStoreMapsByCrossdockMapId() {
        return crossdockStoreMapsByCrossdockMapId;
    }

    public void setCrossdockStoreMapsByCrossdockMapId(Collection<CrossdockStoreMapEntity> crossdockStoreMapsByCrossdockMapId) {
        this.crossdockStoreMapsByCrossdockMapId = crossdockStoreMapsByCrossdockMapId;
    }

    /*
    * Below are custom methods to help determine if a valid map exists
    * */

    public int findDayOfWeek(Date inputDate) {
        int dayOfWeek = DateParser.dayOfTheWeek(inputDate);

        if (this.determineIfCrossDockScheduleCalendarCD14Day())
        {
            KrogerFiscalCalendar krogerCalendar = DateParser.dateToKrogerFiscalCalendar(inputDate);

            int krogerWeek = krogerCalendar.get(KrogerFiscalCalendar.FISCAL_WEEK);

            //Zero all the bits but leave the least significant bit unchanged and check if the result is 1
            // if least significant bit is 1, it indicates odd number..if least significant bit is 0, it indicates even number
            if ((krogerWeek & 1) == 1) {
                // this is an odd week so use day 8 through 14
                dayOfWeek += 7;
            }
        }
        return dayOfWeek;
    }

    public boolean determineIfCrossDockScheduleCalendarCD14Day() {
        return this.crossdockScheduleCalendarCd.equals(CALENDAR_14_DAY);
    }

    @Transient
    public boolean isAutoRelease(){ return this.releaseCd.equalsIgnoreCase("A");}

    @Override
    public String toString() {
        return "CrossdockMapEntity{" +
                "crossdockMapId=" + crossdockMapId +
                ", crossdockMapStartTs=" + crossdockMapStartTs +
                ", crossdockMapEndTs=" + crossdockMapEndTs +
                ", crossdockMapNme='" + crossdockMapNme + '\'' +
                ", crossdockScheduleCalendarCd='" + crossdockScheduleCalendarCd + '\'' +
                ", releaseCd='" + releaseCd + '\'' +
                ", rowCreateTs=" + rowCreateTs +
                ", rowUpdateTs=" + rowUpdateTs +
                ", rowCreateId='" + rowCreateId + '\'' +
                ", rowUpdateId='" + rowUpdateId + '\'' +
                '}';
    }
}
