package com.kroger.asn.entities;

import javax.persistence.*;

@Entity
@Table(name = "CROSSDOCK_CONTAINER")
public class CrossdockContainerEntity {
    @Override
    public String toString() {
        return "CrossdockContainerEntity{" +
                "containerId=" + containerId +
                ", cubeAmt=" + cubeAmt +
                ", labelFormatCd='" + labelFormatCd + '\'' +
                ", labelQty=" + labelQty +
                '}';
    }

    private int containerId;
    private Double cubeAmt;
    private String labelFormatCd;
    private Integer labelQty;
    private SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId;
    private CatalogGroupEntity catalogGroupByOriginCatalogGroupId;

    @Id
    @Column(name = "CONTAINER_ID", nullable = false)
    public int getContainerId() {
        return containerId;
    }

    public void setContainerId(int containerId) {
        this.containerId = containerId;
    }


    @Column(name = "CUBE_AMT", precision = 0)
    public Double getCubeAmt() {
        return cubeAmt;
    }

    public void setCubeAmt(Double cubeAmt) {
        this.cubeAmt = cubeAmt;
    }


    @Column(name = "LABEL_FORMAT_CD", length = 1)
    public String getLabelFormatCd() {
        return labelFormatCd;
    }

    public void setLabelFormatCd(String labelFormatCd) {
        this.labelFormatCd = labelFormatCd;
    }


    @Column(name = "LABEL_QTY")
    public Integer getLabelQty() {
        return labelQty;
    }

    public void setLabelQty(Integer labelQty) {
        this.labelQty = labelQty;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockContainerEntity that = (CrossdockContainerEntity) o;

        if (containerId != that.containerId) return false;
        if (cubeAmt != null ? !cubeAmt.equals(that.cubeAmt) : that.cubeAmt != null) return false;
        if (labelFormatCd != null ? !labelFormatCd.equals(that.labelFormatCd) : that.labelFormatCd != null)
            return false;
        if (labelQty != null ? !labelQty.equals(that.labelQty) : that.labelQty != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = containerId;
        result = 31 * result + (cubeAmt != null ? cubeAmt.hashCode() : 0);
        result = 31 * result + (labelFormatCd != null ? labelFormatCd.hashCode() : 0);
        result = 31 * result + (labelQty != null ? labelQty.hashCode() : 0);
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "ORIGIN_SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID")
    public SourcingFacilityEntity getSourcingFacilityByOriginSourcingFacilityId() {
        return sourcingFacilityByOriginSourcingFacilityId;
    }

    public void setSourcingFacilityByOriginSourcingFacilityId(SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId) {
        this.sourcingFacilityByOriginSourcingFacilityId = sourcingFacilityByOriginSourcingFacilityId;
    }

    @ManyToOne
    @JoinColumn(name = "ORIGIN_CATALOG_GROUP_ID", referencedColumnName = "CATALOG_GROUP_ID")
    public CatalogGroupEntity getCatalogGroupByOriginCatalogGroupId() {
        return catalogGroupByOriginCatalogGroupId;
    }

    public void setCatalogGroupByOriginCatalogGroupId(CatalogGroupEntity catalogGroupByOriginCatalogGroupId) {
        this.catalogGroupByOriginCatalogGroupId = catalogGroupByOriginCatalogGroupId;
    }

}
