package com.kroger.asn.repositories;

import com.kroger.asn.entities.CatalogGroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface CatalogGroupRepo extends JpaRepository<CatalogGroupEntity,Integer>
{
    CatalogGroupEntity findBySourcingFacilityIdAndCatalogGroupNo(int sourceFacilityId, String catalogGroupNumber);
}
