package com.kroger.asn.entities;

import com.kroger.asn.dto.asnshipmentdata.SkopeOrder;
import com.kroger.asn.util.CommonDefines;
import com.kroger.asn.util.DateParser;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "SKOPE_ORDER")
public class SkopeOrderEntity {

    private static final String NORMAL = "N";

    private int skopeOrderId;
    private String orderBillingDivisionNo;
    private String skopeOrderNo;
    private BigDecimal skopeGrossCubeAmt;
    private String skopeGrossCubeUomVlu;
    private BigDecimal skopeNetWeightAmt;
    private String skopeNetWeightUomVlu;
    private int skopeOrderQty;
    private String routeNo;
    private String stopNo;
    private Date skopeOrderDeliveryDt;
    private Timestamp skopeOrderProcessTs;
    private Timestamp sourceFacilityOrderCmplTs;
    private Timestamp skopeOrderCancelTs;
    private Timestamp rowCreateTs;
    private Timestamp rowUpdateTs;
    private String rowCreateId;
    private String rowUpdateId;
    private Integer labelsQty;
    private String pickSequenceNo;
    private String processDayCd;
    private String orderMethodCreateCd;
    private Collection<SkopeCrossdockOrderXrefEntity> skopeCrossdockOrderXrefsBySkopeOrderId;
    private OrderManagementDivisionEntity orderManagementDivisionByOrderManagementDivisionId;
    private Long orderManagementDivisionId;
    private StoreEntity storeByStoreId;
    private Long storeId;
    private CatalogGroupEntity catalogGroupByCatalogGroupId;
    private Long catalogGroupId;
    private SourcingFacilityEntity sourcingFacilityBySourcingFacilityId;
    private int sourcingFacilityId;
    private CrossdockStoreMapEntity crossdockStoreMap;
    private int crossdockFacilityId;
    private String crossdockCatalogGroupNumber;
    private CrossdockCatalogGroupMapEntity crossdockCatalogGroupMapEntity;

    public SkopeOrderEntity() {
    }

    public SkopeOrderEntity(SkopeOrder skopeOrder) {
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        this.storeId = skopeOrder.getStoreId();
        this.catalogGroupId = skopeOrder.getCatalogGroupId();
        this.orderManagementDivisionId = skopeOrder.getOrderManagementDivisionId();
        this.orderBillingDivisionNo = skopeOrder.getOrderBillingDivisionNo();
        this.skopeOrderNo = skopeOrder.getSkopeOrderNo();
        this.skopeOrderDeliveryDt = new Date(skopeOrder.getOrderDeliveryDate().getTime());
        this.sourceFacilityOrderCmplTs = new Timestamp(skopeOrder.getOriginFacilityOrderCompleteTime().getTime());
        this.sourcingFacilityId =  skopeOrder.getFacilityId().intValue();
        this.skopeOrderProcessTs = currentTime;
        this.processDayCd = String.valueOf(DateParser.dayOfTheWeek(new java.util.Date()));
        this.skopeGrossCubeAmt = BigDecimal.valueOf(skopeOrder.getGrossCubeAmt());
        this.skopeNetWeightAmt = BigDecimal.valueOf(skopeOrder.getNetWeightAmt());
        this.skopeOrderQty = skopeOrder.getOrderQty();
        this.orderMethodCreateCd = NORMAL;
        this.routeNo = skopeOrder.getRoute();
        this.rowCreateTs = currentTime;
        this.rowUpdateTs = currentTime;
    }

    public SkopeOrderEntity(SkopeOrder skopeOrder, SourcingFacilityEntity sourcingFacilityEntity, CatalogGroupEntity originCatalogGroup,
                            OrderManagementDivisionEntity orderManagementDivisionEntity, StoreEntity storeEntity, CrossdockStoreMapEntity crossdockStoreMapEntity) {
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        this.orderBillingDivisionNo = skopeOrder.getOrderBillingDivisionNo().toUpperCase();
        this.skopeOrderNo = skopeOrder.getSkopeOrderNo().toUpperCase();
        this.skopeOrderDeliveryDt = new Date(skopeOrder.getOrderDeliveryDate().getTime());
        //need null check as ASN Order Summary will not have originFacilityOrderCompleteTime
        if(skopeOrder.getOriginFacilityOrderCompleteTime() != null) {
            this.sourceFacilityOrderCmplTs = new Timestamp(skopeOrder.getOriginFacilityOrderCompleteTime().getTime());
        }
        this.skopeOrderProcessTs = currentTime;
        this.processDayCd = String.valueOf(DateParser.dayOfTheWeek(new java.util.Date())).toUpperCase();
        this.skopeGrossCubeAmt = BigDecimal.valueOf(skopeOrder.getGrossCubeAmt());
        this.skopeNetWeightAmt = BigDecimal.valueOf(skopeOrder.getNetWeightAmt());
        this.skopeOrderQty = skopeOrder.getOrderQty();
        this.orderMethodCreateCd = NORMAL;
        //need null check as ASN Order Summary will not have route
        if(skopeOrder.getRoute() != null){
            this.routeNo = skopeOrder.getRoute().toUpperCase();
        }
        this.rowCreateTs = currentTime;
        this.rowUpdateTs = currentTime;

        //set update user in db to ASN-originFacilityNumber (ex. ASN-096). Can help when debugging prod issues
        this.rowCreateId = (CommonDefines.ASN_ID_PREFIX + sourcingFacilityEntity.getSourcingFacilityNo()).toUpperCase();
        this.rowUpdateId = (CommonDefines.ASN_ID_PREFIX + sourcingFacilityEntity.getSourcingFacilityNo()).toUpperCase();

        //FK relationships
        this.sourcingFacilityBySourcingFacilityId = sourcingFacilityEntity;
        this.sourcingFacilityId =  skopeOrder.getFacilityId().intValue();
        this.catalogGroupByCatalogGroupId = originCatalogGroup;
        this.catalogGroupId = skopeOrder.getCatalogGroupId();
        this.orderManagementDivisionByOrderManagementDivisionId = orderManagementDivisionEntity;
        this.orderManagementDivisionId = skopeOrder.getOrderManagementDivisionId();
        this.storeByStoreId = storeEntity;
        this.storeId = skopeOrder.getStoreId();
        this.crossdockStoreMap = crossdockStoreMapEntity;
        this.crossdockCatalogGroupMapEntity = crossdockStoreMapEntity.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId();
        this.crossdockCatalogGroupNumber = this.crossdockCatalogGroupMapEntity.getCrossdockCatalogGroupByCrossdockCatalogGroupNo().getCrossdockCatalogGroupNo();
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SKOPE_ORDER_ID")
    public int getSkopeOrderId() {
        return skopeOrderId;
    }

    public void setSkopeOrderId(int skopeOrderId) {
        this.skopeOrderId = skopeOrderId;
    }


    @Column(name = "ORDER_BILLING_DIVISION_NO", nullable = false, length = 3)
    public String getOrderBillingDivisionNo() {
        return orderBillingDivisionNo;
    }

    public void setOrderBillingDivisionNo(String orderBillingDivisionNo) {
        this.orderBillingDivisionNo = orderBillingDivisionNo;
    }


    @Column(name = "SKOPE_ORDER_NO", nullable = false, length = 5)
    public String getSkopeOrderNo() {
        return skopeOrderNo;
    }

    public void setSkopeOrderNo(String skopeOrderNo) {
        this.skopeOrderNo = skopeOrderNo;
    }


    @Column(name = "SKOPE_GROSS_CUBE_AMT", nullable = false, precision = 2)
    public BigDecimal getSkopeGrossCubeAmt() {
        return skopeGrossCubeAmt;
    }

    public void setSkopeGrossCubeAmt(BigDecimal skopeGrossCubeAmt) {
        this.skopeGrossCubeAmt = skopeGrossCubeAmt;
    }

    @Column(name = "SKOPE_GROSS_CUBE_UOM_VLU",length = 30)
    public String getSkopeGrossCubeUomVlu() {
        return skopeGrossCubeUomVlu;
    }

    public void setSkopeGrossCubeUomVlu(String skopeGrossCubeUomVlu) {
        this.skopeGrossCubeUomVlu = skopeGrossCubeUomVlu;
    }


    @Column(name = "SKOPE_NET_WEIGHT_AMT", nullable = false, precision = 2)
    public BigDecimal getSkopeNetWeightAmt() {
        return skopeNetWeightAmt;
    }

    public void setSkopeNetWeightAmt(BigDecimal skopeNetWeightAmt) {
        this.skopeNetWeightAmt = skopeNetWeightAmt;
    }


    @Column(name = "SKOPE_NET_WEIGHT_UOM_VLU", length = 30)
    public String getSkopeNetWeightUomVlu() {
        return skopeNetWeightUomVlu;
    }

    public void setSkopeNetWeightUomVlu(String skopeNetWeightUomVlu) {
        this.skopeNetWeightUomVlu = skopeNetWeightUomVlu;
    }


    @Column(name = "SKOPE_ORDER_QTY", nullable = false)
    public int getSkopeOrderQty() {
        return skopeOrderQty;
    }

    public void setSkopeOrderQty(int skopeOrderQty) {
        this.skopeOrderQty = skopeOrderQty;
    }


    @Column(name = "ROUTE_NO", length = 6)
    public String getRouteNo() {
        return routeNo;
    }

    public void setRouteNo(String routeNo) {
        this.routeNo = routeNo;
    }


    @Column(name = "STOP_NO", length = 2)
    public String getStopNo() {
        return stopNo;
    }

    public void setStopNo(String stopNo) {
        this.stopNo = stopNo;
    }


    @Column(name = "SKOPE_ORDER_DELIVERY_DT")
    public Date getSkopeOrderDeliveryDt() {
        return skopeOrderDeliveryDt;
    }

    public void setSkopeOrderDeliveryDt(Date skopeOrderDeliveryDt) {
        this.skopeOrderDeliveryDt = skopeOrderDeliveryDt;
    }


    @Column(name = "SKOPE_ORDER_PROCESS_TS")
    public Timestamp getSkopeOrderProcessTs() {
        return skopeOrderProcessTs;
    }

    public void setSkopeOrderProcessTs(Timestamp skopeOrderProcessTs) {
        this.skopeOrderProcessTs = skopeOrderProcessTs;
    }


    @Column(name = "SOURCE_FACILITY_ORDER_CMPL_TS")
    public Timestamp getSourceFacilityOrderCmplTs() {
        return sourceFacilityOrderCmplTs;
    }

    public void setSourceFacilityOrderCmplTs(Timestamp sourceFacilityOrderCmplTs) {
        this.sourceFacilityOrderCmplTs = sourceFacilityOrderCmplTs;
    }


    @Column(name = "SKOPE_ORDER_CANCEL_TS")
    public Timestamp getSkopeOrderCancelTs() {
        return skopeOrderCancelTs;
    }

    public void setSkopeOrderCancelTs(Timestamp skopeOrderCancelTs) {
        this.skopeOrderCancelTs = skopeOrderCancelTs;
    }


    @Column(name = "ROW_CREATE_TS", nullable = false)
    public Timestamp getRowCreateTs() {
        return rowCreateTs;
    }

    public void setRowCreateTs(Timestamp rowCreateTs) {
        this.rowCreateTs = rowCreateTs;
    }


    @Column(name = "ROW_UPDATE_TS", nullable = false)
    public Timestamp getRowUpdateTs() {
        return rowUpdateTs;
    }

    public void setRowUpdateTs(Timestamp rowUpdateTs) {
        this.rowUpdateTs = rowUpdateTs;
    }


    @Column(name = "ROW_CREATE_ID", length = 8)
    public String getRowCreateId() {
        return rowCreateId;
    }

    public void setRowCreateId(String rowCreateId) {
        this.rowCreateId = rowCreateId;
    }


    @Column(name = "ROW_UPDATE_ID", length = 8)
    public String getRowUpdateId() {
        return rowUpdateId;
    }

    public void setRowUpdateId(String rowUpdateId) {
        this.rowUpdateId = rowUpdateId;
    }


    @Column(name = "LABELS_QTY")
    public Integer getLabelsQty() {
        return labelsQty;
    }

    public void setLabelsQty(Integer labelsQty) {
        this.labelsQty = labelsQty;
    }


    @Column(name = "PICK_SEQUENCE_NO", length = 5)
    public String getPickSequenceNo() {
        return pickSequenceNo;
    }

    public void setPickSequenceNo(String pickSequenceNo) {
        this.pickSequenceNo = pickSequenceNo;
    }


    @Column(name = "PROCESS_DAY_CD", length = 1)
    public String getProcessDayCd() {
        return processDayCd;
    }

    public void setProcessDayCd(String processDayCd) {
        this.processDayCd = processDayCd;
    }


    @Column(name = "ORDER_METHOD_CREATE_CD",length = 1)
    public String getOrderMethodCreateCd() {
        return orderMethodCreateCd;
    }

    public void setOrderMethodCreateCd(String orderMethodCreateCd) {
        this.orderMethodCreateCd = orderMethodCreateCd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SkopeOrderEntity that = (SkopeOrderEntity) o;

        if (skopeOrderId != that.skopeOrderId) return false;
        if (skopeOrderQty != that.skopeOrderQty) return false;
        if (orderBillingDivisionNo != null ? !orderBillingDivisionNo.equals(that.orderBillingDivisionNo) : that.orderBillingDivisionNo != null)
            return false;
        if (skopeOrderNo != null ? !skopeOrderNo.equals(that.skopeOrderNo) : that.skopeOrderNo != null) return false;
        if (skopeGrossCubeAmt != null ? !skopeGrossCubeAmt.equals(that.skopeGrossCubeAmt) : that.skopeGrossCubeAmt != null)
            return false;
        if (skopeGrossCubeUomVlu != null ? !skopeGrossCubeUomVlu.equals(that.skopeGrossCubeUomVlu) : that.skopeGrossCubeUomVlu != null)
            return false;
        if (skopeNetWeightAmt != null ? !skopeNetWeightAmt.equals(that.skopeNetWeightAmt) : that.skopeNetWeightAmt != null)
            return false;
        if (skopeNetWeightUomVlu != null ? !skopeNetWeightUomVlu.equals(that.skopeNetWeightUomVlu) : that.skopeNetWeightUomVlu != null)
            return false;
        if (routeNo != null ? !routeNo.equals(that.routeNo) : that.routeNo != null) return false;
        if (stopNo != null ? !stopNo.equals(that.stopNo) : that.stopNo != null) return false;
        if (skopeOrderDeliveryDt != null ? !skopeOrderDeliveryDt.equals(that.skopeOrderDeliveryDt) : that.skopeOrderDeliveryDt != null)
            return false;
        if (skopeOrderProcessTs != null ? !skopeOrderProcessTs.equals(that.skopeOrderProcessTs) : that.skopeOrderProcessTs != null)
            return false;
        if (sourceFacilityOrderCmplTs != null ? !sourceFacilityOrderCmplTs.equals(that.sourceFacilityOrderCmplTs) : that.sourceFacilityOrderCmplTs != null)
            return false;
        if (skopeOrderCancelTs != null ? !skopeOrderCancelTs.equals(that.skopeOrderCancelTs) : that.skopeOrderCancelTs != null)
            return false;
        if (rowCreateTs != null ? !rowCreateTs.equals(that.rowCreateTs) : that.rowCreateTs != null) return false;
        if (rowUpdateTs != null ? !rowUpdateTs.equals(that.rowUpdateTs) : that.rowUpdateTs != null) return false;
        if (rowCreateId != null ? !rowCreateId.equals(that.rowCreateId) : that.rowCreateId != null) return false;
        if (rowUpdateId != null ? !rowUpdateId.equals(that.rowUpdateId) : that.rowUpdateId != null) return false;
        if (labelsQty != null ? !labelsQty.equals(that.labelsQty) : that.labelsQty != null) return false;
        if (pickSequenceNo != null ? !pickSequenceNo.equals(that.pickSequenceNo) : that.pickSequenceNo != null)
            return false;
        if (processDayCd != null ? !processDayCd.equals(that.processDayCd) : that.processDayCd != null) return false;
        if (orderMethodCreateCd != null ? !orderMethodCreateCd.equals(that.orderMethodCreateCd) : that.orderMethodCreateCd != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = skopeOrderId;
        result = 31 * result + (orderBillingDivisionNo != null ? orderBillingDivisionNo.hashCode() : 0);
        result = 31 * result + (skopeOrderNo != null ? skopeOrderNo.hashCode() : 0);
        result = 31 * result + (skopeGrossCubeAmt != null ? skopeGrossCubeAmt.hashCode() : 0);
        result = 31 * result + (skopeGrossCubeUomVlu != null ? skopeGrossCubeUomVlu.hashCode() : 0);
        result = 31 * result + (skopeNetWeightAmt != null ? skopeNetWeightAmt.hashCode() : 0);
        result = 31 * result + (skopeNetWeightUomVlu != null ? skopeNetWeightUomVlu.hashCode() : 0);
        result = 31 * result + skopeOrderQty;
        result = 31 * result + (routeNo != null ? routeNo.hashCode() : 0);
        result = 31 * result + (stopNo != null ? stopNo.hashCode() : 0);
        result = 31 * result + (skopeOrderDeliveryDt != null ? skopeOrderDeliveryDt.hashCode() : 0);
        result = 31 * result + (skopeOrderProcessTs != null ? skopeOrderProcessTs.hashCode() : 0);
        result = 31 * result + (sourceFacilityOrderCmplTs != null ? sourceFacilityOrderCmplTs.hashCode() : 0);
        result = 31 * result + (skopeOrderCancelTs != null ? skopeOrderCancelTs.hashCode() : 0);
        result = 31 * result + (rowCreateTs != null ? rowCreateTs.hashCode() : 0);
        result = 31 * result + (rowUpdateTs != null ? rowUpdateTs.hashCode() : 0);
        result = 31 * result + (rowCreateId != null ? rowCreateId.hashCode() : 0);
        result = 31 * result + (rowUpdateId != null ? rowUpdateId.hashCode() : 0);
        result = 31 * result + (labelsQty != null ? labelsQty.hashCode() : 0);
        result = 31 * result + (pickSequenceNo != null ? pickSequenceNo.hashCode() : 0);
        result = 31 * result + (processDayCd != null ? processDayCd.hashCode() : 0);
        result = 31 * result + (orderMethodCreateCd != null ? orderMethodCreateCd.hashCode() : 0);
        return result;
    }

    @OneToMany(mappedBy = "skopeOrderBySkopeOrderId")
    public Collection<SkopeCrossdockOrderXrefEntity> getSkopeCrossdockOrderXrefsBySkopeOrderId() {
        return skopeCrossdockOrderXrefsBySkopeOrderId;
    }

    public void setSkopeCrossdockOrderXrefsBySkopeOrderId(Collection<SkopeCrossdockOrderXrefEntity> skopeCrossdockOrderXrefsBySkopeOrderId) {
        this.skopeCrossdockOrderXrefsBySkopeOrderId = skopeCrossdockOrderXrefsBySkopeOrderId;
    }

    @ManyToOne
    @JoinColumn(name = "ORDER_MANAGEMENT_DIVISION_ID", referencedColumnName = "ORDER_MANAGEMENT_DIVISION_ID")
    public OrderManagementDivisionEntity getOrderManagementDivisionByOrderManagementDivisionId() {
        return orderManagementDivisionByOrderManagementDivisionId;
    }

    public void setOrderManagementDivisionByOrderManagementDivisionId(OrderManagementDivisionEntity orderManagementDivisionByOrderManagementDivisionId) {
        this.orderManagementDivisionByOrderManagementDivisionId = orderManagementDivisionByOrderManagementDivisionId;
    }

    @Column(name = "ORDER_MANAGEMENT_DIVISION_ID", insertable = false, updatable = false)
    public Long getOrderManagementDivisionId() {
        return orderManagementDivisionId;
    }

    public void setOrderManagementDivisionId(Long orderManagementDivisionId) {
        this.orderManagementDivisionId = orderManagementDivisionId;
    }

    @ManyToOne
    @JoinColumn(name = "STORE_ID", referencedColumnName = "STORE_ID")
    public StoreEntity getStoreByStoreId() {
        return storeByStoreId;
    }

    public void setStoreByStoreId(StoreEntity storeByStoreId) {
        this.storeByStoreId = storeByStoreId;
    }

    @Column(name = "STORE_ID", insertable = false, updatable = false)
    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    @ManyToOne
    @JoinColumn(name = "CATALOG_GROUP_ID", referencedColumnName = "CATALOG_GROUP_ID")
    public CatalogGroupEntity getCatalogGroupByCatalogGroupId() {
        return catalogGroupByCatalogGroupId;
    }

    public void setCatalogGroupByCatalogGroupId(CatalogGroupEntity catalogGroupByCatalogGroupId) {
        this.catalogGroupByCatalogGroupId = catalogGroupByCatalogGroupId;
    }

    @Column(name = "CATALOG_GROUP_ID", insertable = false, updatable = false)
    public Long getCatalogGroupId() {
        return catalogGroupId;
    }

    public void setCatalogGroupId(Long catalogGroupId) {
        this.catalogGroupId = catalogGroupId;
    }

    @Override
    public String toString() {
        return "SkopeOrderEntity{" +
                "skopeOrderId=" + skopeOrderId +
                ", orderBillingDivisionNo='" + orderBillingDivisionNo + '\'' +
                ", skopeOrderNo='" + skopeOrderNo + '\'' +
                ", skopeGrossCubeAmt=" + skopeGrossCubeAmt +
                ", skopeGrossCubeUomVlu='" + skopeGrossCubeUomVlu + '\'' +
                ", skopeNetWeightAmt=" + skopeNetWeightAmt +
                ", skopeNetWeightUomVlu='" + skopeNetWeightUomVlu + '\'' +
                ", skopeOrderQty=" + skopeOrderQty +
                ", routeNo='" + routeNo + '\'' +
                ", stopNo='" + stopNo + '\'' +
                ", skopeOrderDeliveryDt=" + skopeOrderDeliveryDt +
                ", skopeOrderProcessTs=" + skopeOrderProcessTs +
                ", sourceFacilityOrderCmplTs=" + sourceFacilityOrderCmplTs +
                ", skopeOrderCancelTs=" + skopeOrderCancelTs +
                ", rowCreateTs=" + rowCreateTs +
                ", rowUpdateTs=" + rowUpdateTs +
                ", rowCreateId='" + rowCreateId + '\'' +
                ", rowUpdateId='" + rowUpdateId + '\'' +
                ", labelsQty=" + labelsQty +
                ", pickSequenceNo='" + pickSequenceNo + '\'' +
                ", processDayCd='" + processDayCd + '\'' +
                ", orderMethodCreateCd='" + orderMethodCreateCd + '\'' +
                ", orderManagementDivisionId=" + orderManagementDivisionId +
                ", storeId=" + storeId +
                ", catalogGroupId=" + catalogGroupId +
                ", sourcingFacilityId=" + sourcingFacilityId +
                ", crossdockFacilityId=" + crossdockFacilityId +
                ", crossdockCatalogGroupNumber='" + crossdockCatalogGroupNumber + '\'' +
                '}';
    }

    @ManyToOne
    @JoinColumn(name = "SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID")
    public SourcingFacilityEntity getSourcingFacilityBySourcingFacilityId() {
        return sourcingFacilityBySourcingFacilityId;
    }

    public void setSourcingFacilityBySourcingFacilityId(SourcingFacilityEntity sourcingFacilityBySourcingFacilityId) {
        this.sourcingFacilityBySourcingFacilityId = sourcingFacilityBySourcingFacilityId;
    }

    @Column(name = "SOURCING_FACILITY_ID", insertable = false, updatable = false)
    public int getSourcingFacilityId() {
        return sourcingFacilityId;
    }

    public void setSourcingFacilityId(int sourcingFacilityId) {
        this.sourcingFacilityId = sourcingFacilityId;
    }

    @Transient
    public CrossdockStoreMapEntity getCrossdockStoreMap() {
        return crossdockStoreMap;
    }

    public void setCrossdockStoreMap(CrossdockStoreMapEntity crossdockStoreMap) {
        this.crossdockStoreMap = crossdockStoreMap;
        this.crossdockCatalogGroupNumber = crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCrossdockCatalogGroupByCrossdockCatalogGroupNo().getCrossdockCatalogGroupNo();
        this.crossdockFacilityId = crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId()
                .getSourcingFacilityByCrossdockSourcingFacilityId().getSourcingFacilityId();
    }

    @Transient
    public int getCrossdockFacilityId() {
        return crossdockFacilityId;
    }

    public void setCrossdockFacilityId(int crossdockFacilityId) {
        this.crossdockFacilityId = crossdockFacilityId;
    }

    @Transient
    public String getCrossdockCatalogGroupNumber() {
        return crossdockCatalogGroupNumber;
    }

    public void setCrossdockCatalogGroupNumber(String crossdockCatalogGroupNumber) {
        this.crossdockCatalogGroupNumber = crossdockCatalogGroupNumber;
    }

    @Transient
    public CrossdockCatalogGroupMapEntity getCrossdockCatalogGroupMapEntity() {
        return crossdockCatalogGroupMapEntity;
    }

    public void setCrossdockCatalogGroupMapEntity(CrossdockCatalogGroupMapEntity crossdockCatalogGroupMapEntity) {
        this.crossdockCatalogGroupMapEntity = crossdockCatalogGroupMapEntity;
    }
}
