package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockStoreMapEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CrossdockStoreMapRepo extends JpaRepository<CrossdockStoreMapEntity,Integer>
{
    @Query(value  = "SELECT csm.* FROM CROSSDOCK_STORE_MAP as csm " +
            "JOIN CROSSDOCK_MAP as cm ON csm.crossdock_map_id = cm.crossdock_map_id " +
            "JOIN CROSSDOCK_CATALOG_GROUP_MAP as ccgm on ccgm.crossdock_catalog_group_map_id = cm.crossdock_catalog_group_map_id " +
            "WHERE ccgm.origin_sourcing_facility_id = :originFacilityId AND ccgm.origin_catalog_group_id = :originCatGroupId " +
            "AND csm.store_id = :storeId  AND current_timestamp BETWEEN cm.crossdock_map_start_ts AND cm.crossdock_map_end_ts " +
            "ORDER BY cm.crossdock_map_start_ts DESC FETCH FIRST 1 ROWS ONLY", nativeQuery = true)
    CrossdockStoreMapEntity findCrossdockStoreMapByOriginCatGroupIdAndOriginFacilityAndStoreId(@Param("originCatGroupId") int originCatGroupId,
                                                                                          @Param("originFacilityId") int originFacilityId, @Param("storeId") int storeId);

    CrossdockStoreMapEntity findByCrossdockStoreMapId(int storeMapId);
}
