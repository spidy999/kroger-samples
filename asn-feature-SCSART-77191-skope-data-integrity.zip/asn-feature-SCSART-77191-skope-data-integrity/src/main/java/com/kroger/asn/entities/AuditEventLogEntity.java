package com.kroger.asn.entities;

import com.kroger.asn.util.AuditEventCodeEnum;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@IdClass(AuditEventLogEntityPK.class)
@Table(name = "AUDIT_EVENT_LOG")
public class AuditEventLogEntity {

    private String auditUserId;
    private Timestamp auditTs;
    private String auditMessage;
    private Integer crossdockMapId;
    private Integer crossdockOrderId;
    private Integer skopeOrderId;
    private String auditEventCd;
    private Integer crossdockRouteId;
    private Integer orderManagementDivisionId;
    private Integer crossdockFacilityId;
    private String crossdockCatalogGroupNo;
    private Integer originFacilityId;

    public AuditEventLogEntity() {
        this.auditTs = new Timestamp(System.currentTimeMillis());
    }

    public AuditEventLogEntity(CrossdockRouteEntity crossdockRoute, AuditEventCodeEnum auditEventCodeEnum) {
        this.auditTs = new Timestamp(System.currentTimeMillis());
        this.auditUserId = crossdockRoute.getRowUpdateId();
        this.auditEventCd = auditEventCodeEnum.getAuditEventCodeColumnValue();
        this.originFacilityId = crossdockRoute.getSourcingFacilityId();
        this.auditMessage = String.format("%s [%s] id [%s]. Sourcing Facility Id [%s] Dispatch date [%s] trailer [%s].", auditEventCodeEnum.getAuditEventCodeDescription(),
                crossdockRoute.getRouteNme(), crossdockRoute.getRouteId(), this.originFacilityId, crossdockRoute.getDispatchDt(), crossdockRoute.getCrossdockTrailerNo());
    }

    public AuditEventLogEntity(CrossdockOrderHeaderEntity crossdockOrderHeaderEntity) {
        this.crossdockOrderId = crossdockOrderHeaderEntity.getCrossdockOrderId();
        this.auditTs = new Timestamp(System.currentTimeMillis());
        this.auditUserId = crossdockOrderHeaderEntity.getRowUpdateId();
        this.auditEventCd = AuditEventCodeEnum.UpdateCrossDockOrder.getAuditEventCodeColumnValue();
        this.orderManagementDivisionId = crossdockOrderHeaderEntity.getOrderManagementDivisionByOrderManagementDivisionId().getOrderManagementDivisionId();
        this.crossdockFacilityId = crossdockOrderHeaderEntity.getSourcingFacilityByCrossdockSourcingFacilityId().getSourcingFacilityId();
        this.crossdockCatalogGroupNo = crossdockOrderHeaderEntity.getCrossdockCatalogGroupByCrossdockCatalogGroupNo().getCrossdockCatalogGroupNo();
        this.originFacilityId = crossdockOrderHeaderEntity.getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityId();
        this.auditMessage = String.format("%s. id [%s]. Cross Dock Order  Number [%s]. Delivery type is [%s].  Gross Cube is [%s].  Gross Cube Flg [%s].  Net Weight is [%s].  Net Weight Flg is [%s].",
                AuditEventCodeEnum.UpdateCrossDockOrder.getAuditEventCodeDescription(), crossdockOrderHeaderEntity.getCrossdockOrderId(), crossdockOrderHeaderEntity.getCrossdockOrderNo(), crossdockOrderHeaderEntity.getDeliveryTypeCd(), crossdockOrderHeaderEntity.getGrossCubeAmt(),
                crossdockOrderHeaderEntity.getGrossCubeAmtChangedFlg(), crossdockOrderHeaderEntity.getNetWeightAmt(), crossdockOrderHeaderEntity.getNetWeightAmtChangedFlg());
    }

    public AuditEventLogEntity(List<CrossdockOrderHeaderEntity> crossdockOrderHeaderEntityList) {
        CrossdockOrderHeaderEntity crossdockOrderHeaderBaseDetails = crossdockOrderHeaderEntityList.get(0);
        this.auditTs = new Timestamp(System.currentTimeMillis());
        this.auditUserId = crossdockOrderHeaderBaseDetails.getRowUpdateId();
        this.crossdockOrderId = crossdockOrderHeaderBaseDetails.getCrossdockOrderId();
        this.auditEventCd = AuditEventCodeEnum.AsnReleaseCrossDockOrderHeaders.getAuditEventCodeColumnValue();
        this.orderManagementDivisionId = crossdockOrderHeaderBaseDetails.getOrderManagementDivisionByOrderManagementDivisionId().getOrderManagementDivisionId();
        this.crossdockFacilityId = crossdockOrderHeaderBaseDetails.getSourcingFacilityByCrossdockSourcingFacilityId().getSourcingFacilityId();
        this.crossdockCatalogGroupNo = crossdockOrderHeaderBaseDetails.getCrossdockCatalogGroupByCrossdockCatalogGroupNo().getCrossdockCatalogGroupNo();
        this.originFacilityId = crossdockOrderHeaderBaseDetails.getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityId();

        StringBuilder crossdockOrderHeaderStringBuilder = new StringBuilder();
        crossdockOrderHeaderStringBuilder.append(AuditEventCodeEnum.AsnReleaseCrossDockOrderHeaders.getAuditEventCodeDescription()).append(". Ids: ");

        for (CrossdockOrderHeaderEntity crossdockOrderHeader : crossdockOrderHeaderEntityList) {
            crossdockOrderHeaderStringBuilder.append(String.format("[%s] ", crossdockOrderHeader.getCrossdockOrderId()));
        }

        this.auditMessage = String.format("%s", crossdockOrderHeaderStringBuilder.toString());
    }

    @Column(name = "AUDIT_USER_ID", nullable = false, length = 7)
    public String getAuditUserId() {
        return auditUserId;
    }
    public void setAuditUserId(String auditUserId) {
        this.auditUserId = auditUserId;
    }

    @Id
    @Column(name = "AUDIT_TS", nullable = false)
    public Timestamp getAuditTs() {
        return auditTs;
    }
    public void setAuditTs(Timestamp auditTs) {
        this.auditTs = auditTs;
    }

    @Column(name = "MESSAGE_VLU", nullable = true, length = 1000)
    public String getAuditMessage() {
        return auditMessage;
    }
    public void setAuditMessage(String messageVlu) {
        this.auditMessage = messageVlu;
    }

    @Column(name = "CROSSDOCK_MAP_ID", nullable = true)
    public Integer getCrossdockMapId() {
        return crossdockMapId;
    }
    public void setCrossdockMapId(Integer crossdockMapId) {
        this.crossdockMapId = crossdockMapId;
    }

    @Column(name = "CROSSDOCK_ORDER_ID", nullable = true)
    public Integer getCrossdockOrderId() {
        return crossdockOrderId;
    }
    public void setCrossdockOrderId(Integer crossdockOrderId) {
        this.crossdockOrderId = crossdockOrderId;
    }

    @Column(name = "SKOPE_ORDER_ID", nullable = true)
    public Integer getSkopeOrderId() {
        return skopeOrderId;
    }
    public void setSkopeOrderId(Integer skopeOrderId) {
        this.skopeOrderId = skopeOrderId;
    }

    @Id
    @Column(name = "AUDIT_EVENT_CD", nullable = true, length = 2)
    public String getAuditEventCd() {
        return auditEventCd;
    }
    public void setAuditEventCd(String auditEventCd) {
        this.auditEventCd = auditEventCd;
    }

    @Column(name = "CROSSDOCK_ROUTE_ID", nullable = true)
    public Integer getCrossdockRouteId() {
        return crossdockRouteId;
    }
    public void setCrossdockRouteId(Integer crossdockRouteId) {
        this.crossdockRouteId = crossdockRouteId;
    }

    @Column(name = "ORDER_MANAGEMENT_DIVISION_ID", nullable = true)
    public Integer getOrderManagementDivisionId() {
        return orderManagementDivisionId;
    }
    public void setOrderManagementDivisionId(Integer orderManagementDivisionId) {
        this.orderManagementDivisionId = orderManagementDivisionId;
    }

    @Column(name = "CROSSDOCK_FACILITY_ID", nullable = true)
    public Integer getCrossdockFacilityId() {
        return crossdockFacilityId;
    }
    public void setCrossdockFacilityId(Integer crossdockFacilityId) {
        this.crossdockFacilityId = crossdockFacilityId;
    }

    @Column(name = "CROSSDOCK_CATALOG_GROUP_NO", nullable = true, length = 3)
    public String getCrossdockCatalogGroupNo() {
        return crossdockCatalogGroupNo;
    }
    public void setCrossdockCatalogGroupNo(String crossdockCatalogGroupNo) {
        this.crossdockCatalogGroupNo = crossdockCatalogGroupNo;
    }

    @Column(name = "ORIGIN_FACILITY_ID", nullable = true)
    public Integer getOriginFacilityId() {
        return originFacilityId;
    }
    public void setOriginFacilityId(Integer originFacilityId) {
        this.originFacilityId = originFacilityId;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuditEventLogEntity that = (AuditEventLogEntity) o;
        if (auditUserId != null ? !auditUserId.equals(that.auditUserId) : that.auditUserId != null) return false;
        if (auditTs != null ? !auditTs.equals(that.auditTs) : that.auditTs != null) return false;
        if (auditMessage != null ? !auditMessage.equals(that.auditMessage) : that.auditMessage != null) return false;
        if (crossdockMapId != null ? !crossdockMapId.equals(that.crossdockMapId) : that.crossdockMapId != null)
            return false;
        if (crossdockOrderId != null ? !crossdockOrderId.equals(that.crossdockOrderId) : that.crossdockOrderId != null)
            return false;
        if (skopeOrderId != null ? !skopeOrderId.equals(that.skopeOrderId) : that.skopeOrderId != null) return false;
        if (auditEventCd != null ? !auditEventCd.equals(that.auditEventCd) : that.auditEventCd != null) return false;
        if (crossdockRouteId != null ? !crossdockRouteId.equals(that.crossdockRouteId) : that.crossdockRouteId != null)
            return false;
        if (orderManagementDivisionId != null ? !orderManagementDivisionId.equals(that.orderManagementDivisionId) : that.orderManagementDivisionId != null)
            return false;
        if (crossdockFacilityId != null ? !crossdockFacilityId.equals(that.crossdockFacilityId) : that.crossdockFacilityId != null)
            return false;
        if (crossdockCatalogGroupNo != null ? !crossdockCatalogGroupNo.equals(that.crossdockCatalogGroupNo) : that.crossdockCatalogGroupNo != null)
            return false;
        if (originFacilityId != null ? !originFacilityId.equals(that.originFacilityId) : that.originFacilityId != null)
            return false;
        return true;
    }
    @Override
    public int hashCode() {
        int result = auditUserId != null ? auditUserId.hashCode() : 0;
        result = 31 * result + (auditTs != null ? auditTs.hashCode() : 0);
        result = 31 * result + (auditMessage != null ? auditMessage.hashCode() : 0);
        result = 31 * result + (crossdockMapId != null ? crossdockMapId.hashCode() : 0);
        result = 31 * result + (crossdockOrderId != null ? crossdockOrderId.hashCode() : 0);
        result = 31 * result + (skopeOrderId != null ? skopeOrderId.hashCode() : 0);
        result = 31 * result + (auditEventCd != null ? auditEventCd.hashCode() : 0);
        result = 31 * result + (crossdockRouteId != null ? crossdockRouteId.hashCode() : 0);
        result = 31 * result + (orderManagementDivisionId != null ? orderManagementDivisionId.hashCode() : 0);
        result = 31 * result + (crossdockFacilityId != null ? crossdockFacilityId.hashCode() : 0);
        result = 31 * result + (crossdockCatalogGroupNo != null ? crossdockCatalogGroupNo.hashCode() : 0);
        result = 31 * result + (originFacilityId != null ? originFacilityId.hashCode() : 0);
        return result;
    }
}