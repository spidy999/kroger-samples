package com.kroger.asn.repositories;

import com.kroger.asn.entities.ReleaseOrderGroupEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ReleaseOrderGroupRepo extends JpaRepository<ReleaseOrderGroupEntity,Integer>
{
}
