package com.kroger.asn.service;

import com.kroger.asn.dto.asnshipmentdata.SkopeOrder;
import com.kroger.asn.entities.*;
import com.kroger.asn.repositories.*;
import com.kroger.asn.util.AuditEventCodeEnum;
import com.kroger.asn.util.CommonDefines;
import com.kroger.asn.util.DateParser;
import com.kroger.asn.util.errors.SkopeOrderValidationException;
import com.kroger.commons.calendar.KrogerFiscalCalendar;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.ASNShipment;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Order;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Pallet;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Sender;
import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNOrderSummaryEvent;
import com.kroger.schema.canonical.core._3_0.*;
import com.kroger.schema.canonical.xdoc._3_0.*;
import org.apache.commons.lang.mutable.MutableBoolean;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 */
@Service
@Transactional(isolation = Isolation.READ_UNCOMMITTED)
public class AsnRouteCloseService {

    @Autowired
    CrossdockRouteRepo crossdockRouteRepo;

    @Autowired
    SourcingFacilityRepo sourcingFacilityRepo;

    @Autowired
    OrderManagementDivisionRepo orderManagementDivisionRepo;

    @Autowired
    StoreRepo storeRepo;

    @Autowired
    CatalogGroupRepo catalogGroupRepo;

    @Autowired
    CrossdockMapRepo crossdockMapRepo;

    @Autowired
    CrossdockStoreScheduleRepo crossdockStoreScheduleRepo;

    @Autowired
    CrossdockStoreMapRepo crossdockStoreMapRepo;

    @Autowired
    SkopeOrderRepo skopeOrderRepo;

    @Autowired
    CrossdockOrderHeaderRepo crossdockOrderHeaderRepo;

    @Autowired
    CrossdockLoadRepo crossdockLoadRepo;

    @Autowired
    SkopeCrossdockOrderXrefRepo skopeCrossdockOrderXrefRepo;

    @Autowired
    AuditEventLogRepo auditEventLogRepo;

    @Autowired
    EmailService emailService;

    @Autowired
    @Qualifier("crossDockOrderClient")
    CrossDockOrderService crossDockOrderClient;

    @Value("${kroger.webmethods.win.systemEnvironmentCode}")
    String systemEnvironmentCode;

    private Logger logger = LoggerFactory.getLogger(AsnRouteCloseService.class);

    private static final String SKOPE_ORDER_HAS_ERRORS = "SKOPE ORDER %s contains errors and is invalid.";

    private static final String SKOPE_ORDER = "SKOPE-Order";

    @Transactional(rollbackFor = {Exception.class, EntityNotFoundException.class})
    public void processAsnOrderSummaryEvent(ASNOrderSummaryEvent asnOrderSummaryEvent) throws Exception{
        logger.info("processAsnOrderSummaryEvent: Facility:[{}]. RefId: [{}]", asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber(), asnOrderSummaryEvent.getSenderInfo().getReferenceId());
        String userId = CommonDefines.ASN_ID_PREFIX + asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber();
        AuditEventLogEntity auditEventLogEntity = new AuditEventLogEntity();
        auditEventLogEntity.setAuditUserId(userId);
        String baseProcessMessageAuditMessage = String.format("reference id [%s]. Create Date [%s]. SourceFacility [%s].",
                asnOrderSummaryEvent.getSenderInfo().getReferenceId(), asnOrderSummaryEvent.getSenderInfo().getCreationDateTime(),
                asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber());
        auditEventLogEntity.setAuditEventCd(AuditEventCodeEnum.AsnOrderSummary.getAuditEventCodeColumnValue());
        auditEventLogEntity.setAuditMessage(String.format("Receive ASN Order Summary message with %s", baseProcessMessageAuditMessage));
        auditEventLogRepo.save(auditEventLogEntity);

        try {
            validateAsnData(asnOrderSummaryEvent.getOrders(), null, asnOrderSummaryEvent.getSenderInfo(), null);

            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo(asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber())
                    .orElseThrow(() -> new EntityNotFoundException(String.format("Unable to find origin facility with facility number: %s.", asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber())));

            TreeMap<String, List<String>> validationErrorsByOrderTreeMap = new TreeMap<>();
            //validate asn shipment record, determine if order should be cross docked and create SKOPE order
            List<SkopeOrder> validSkopeOrders = validateSkopeRecords(asnOrderSummaryEvent.getOrders(), originFacility, validationErrorsByOrderTreeMap, null, null);

            if(!validationErrorsByOrderTreeMap.isEmpty()) {
                logInvalidData(validationErrorsByOrderTreeMap, asnOrderSummaryEvent.getSenderInfo(), null);
            }

            // Add or Update SKOPE orders if they were mapped to be cross docked
            Map<String, SkopeOrderEntity> mappedSkopeOrders = processSkopeOrders(validSkopeOrders, null);

            if (!mappedSkopeOrders.isEmpty() ) {
                //create new crossdock route
                //Create Route
                CrossdockRouteEntity crossdockRoute = new CrossdockRouteEntity(originFacility, asnOrderSummaryEvent.getRouteName());
                crossdockRoute = saveRoute(crossdockRoute);
                logger.info("Cross dock route successfully created! Id: [{} No[{}]", crossdockRoute.getRouteId(), crossdockRoute.getRouteNme());

                //get headers for mappedSkopeOrders and put in map
                Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap = processCrossDockHeaders(mappedSkopeOrders, crossdockRoute);
            }

        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            MDC.clear();
            throw ex;
        } finally {
            logger.info("Complete processing of ASN Order Summary Event. Sender: [{}]", asnOrderSummaryEvent.getSenderInfo().getShipFromFacility().getNumber());
            MDC.clear();
        }
    }

    /**
     * When we receive a route close message, we need to process it.
     * <ol>
     *     <li>Verify the vendor is a valid sourcing vendor in the database</li>
     *     <li>validate that the skope records on the route close valid and get a list of the valid ones. if there are any errors with skope orders that they sent us, <b>do not</b> process <b>ANY</b> of the orders on the route close</li>
     *     <li>Process the skope orders and get a map of all of the ones that have mappings and can be cross docked</li>
     *     <li>Create a new origin route</li>
     *     <li>Find/create cross dock order headers and attach the Skope orders to them. At this time, also assign the header to the origin route</li>
     *     <li>Process the pallets on the route close</li>
     *     <li>Send the headers down to WIN</li>
     * </ol>
     *
     * @param asnShipment a route close message that we need to process. This will contain skope orders, pallets, and info about the vendor.
     */
    @Transactional(rollbackFor = {Exception.class, EntityNotFoundException.class})
    public void processAsnRouteCloseEvent(ASNShipment asnShipment)  throws Exception {
        logger.info("processAsnRouteCloseEvent: Route: [{}]. Facility:[{}]. RefId: [{}]", asnShipment.getShipmentData().getRouteName(),asnShipment.getSender().getShipFromFacility().getNumber(),asnShipment.getSender().getReferenceId() );
        String userId = CommonDefines.ASN_ID_PREFIX + asnShipment.getSender().getShipFromFacility().getNumber();
        AuditEventLogEntity auditEventLogEntity = new AuditEventLogEntity();
        auditEventLogEntity.setAuditUserId(userId);
        String baseProcessMessageAuditMessage = String.format("reference id [%s]. Create Date [%s]. Route Num [%s]. SourceFacility [%s]. Route Close Timestamp [%s]",
                asnShipment.getSender().getReferenceId(), asnShipment.getSender().getCreationDateTime(), asnShipment.getShipmentData().getRouteName(),
                asnShipment.getSender().getShipFromFacility().getNumber(), asnShipment.getShipmentData().getShipmentTimestamp());
        auditEventLogEntity.setAuditEventCd(AuditEventCodeEnum.AsnRouteClose.getAuditEventCodeColumnValue());
        auditEventLogEntity.setAuditMessage(String.format("Receive route close message with %s", baseProcessMessageAuditMessage));
        auditEventLogRepo.save(auditEventLogEntity);


        MutableBoolean toBeReleasedToWin = new MutableBoolean();
        toBeReleasedToWin.setValue(false);
        Timestamp originFacilityShipmentTs = new Timestamp(System.currentTimeMillis());
        try {

            TimeZone tz = TimeZone.getTimeZone(asnShipment.getShipmentData().getShipmentTimestamp().getTimezone());
            TimeZone.setDefault(tz);
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
            Date shipmentTimeAsDate = df.parse(asnShipment.getShipmentData().getShipmentTimestamp().getValue());
            originFacilityShipmentTs = new Timestamp(shipmentTimeAsDate.getTime());
        } catch (ParseException e) {
            logger.error("Unable to parse shipment timestamp, use current date and time");
        }

        List<CrossdockOrderHeaderEntity> crossdockOrderHeadersToSendToWin = new ArrayList<>();
        CrossdockRouteEntity crossdockRoute = null;
        try {
            //Validate the json we received is filled in correctly and meets our requirements
            validateAsnData(asnShipment.getShipmentData().getOrders(), asnShipment.getShipmentData().getPallets(), asnShipment.getSender(), asnShipment.getShipmentData().getRouteName());

            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo(asnShipment.getSender().getShipFromFacility().getNumber())
                    .orElseThrow(() -> new EntityNotFoundException(String.format("Unable to find origin facility with facility number: %s.", asnShipment.getSender().getShipFromFacility().getNumber())));

            TreeMap<String, List<String>> validationErrorsByOrderTreeMap = new TreeMap<>();
            //validate asn shipment record, determine if order should be cross docked and create SKOPE order
            List<SkopeOrder> validSkopeOrders = validateSkopeRecords(asnShipment.getShipmentData().getOrders(), originFacility, validationErrorsByOrderTreeMap, originFacilityShipmentTs, asnShipment.getShipmentData().getRouteName());

            if(!validationErrorsByOrderTreeMap.isEmpty()) {
                logInvalidData(validationErrorsByOrderTreeMap, asnShipment.getSender(), asnShipment.getShipmentData().getRouteName());
            }

            // Add or Update SKOPE orders if they were mapped to be cross docked
                Map<String, SkopeOrderEntity> mappedSkopeOrders = processSkopeOrders(validSkopeOrders, asnShipment.getShipmentData().getPallets());

            if (!mappedSkopeOrders.isEmpty() ) {
                //create new crossdock route
                //Create Route
                crossdockRoute = new CrossdockRouteEntity(asnShipment.getShipmentData(), originFacility, originFacilityShipmentTs);
                crossdockRoute = saveRoute(crossdockRoute);
                logger.info("Cross dock route successfully created! Id: [{} No[{}]", crossdockRoute.getRouteId(),crossdockRoute.getRouteNme());

                //get headers for mappedSkopeOrders and put in map
                Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap = processCrossDockHeaders(mappedSkopeOrders, crossdockRoute);

                //process pallets on route close
                crossdockOrderHeadersToSendToWin = processAsnPallets(crossdockOrderHeaderBySkopeOrderMap, asnShipment.getShipmentData().getPallets(), toBeReleasedToWin);

                //send route close to WIN {Release orders to WIN)
                //Build list of order types
                if (!crossdockOrderHeadersToSendToWin.isEmpty()) {

                    finalizeCrossDockOrderHeaders(crossdockOrderHeadersToSendToWin, toBeReleasedToWin);


                    if(toBeReleasedToWin.isTrue()) {
                        List<CrossDockOrderType> crossDockOrderTypeList = buildCrossDockOrderTypeList(crossdockOrderHeadersToSendToWin,
                                asnShipment, crossdockRoute);

                        //Will be empty if one record is dsd or all are dsd.. else continue..
                        if(crossDockOrderTypeList.isEmpty()){
                            logger.info("Crossdock Order Type List is Empty - not processed");
                            return;
                        }
                        // Setup goo needed for web service
                        String referenceId = asnShipment.getSender().getReferenceId();
                        SyncCrossDockOrderType syncCrossDockOrder = applicationAreaSetup(
                                crossDockOrderTypeList, referenceId);
                        //Make the web service call
                        AcknowledgeCrossDockOrderType acknowledgement = (crossDockOrderClient).syncCrossDockOrder(syncCrossDockOrder);
                        String resultCode = acknowledgement.getDataArea().getAcknowledge().getResponseCriteria().get(0)
                                .getChangeStatus().getCode();
                        if (!resultCode.trim().equals("200")) {
                            String errorMessage = acknowledgement.getDataArea().getAcknowledge().getResponseCriteria().get(0)
                                    .getChangeStatus().getDescription().getValue();
                            logger.error("Cross dock order publish error. Result code: [{}] Message: [{}]", resultCode, errorMessage);
                            logger.error("Cross dock orders need to be re-released in order to get to WIN!");
                            auditEventLogEntity.setAuditMessage(String.format("Throwable raised in processing of route close messsage with %s", baseProcessMessageAuditMessage));
                        } else {
                            AuditEventLogEntity auditEventLogReleaseHeaders = new AuditEventLogEntity(crossdockOrderHeadersToSendToWin);
                            auditEventLogRepo.save(auditEventLogReleaseHeaders);

                            logger.info("Sent {} headers to WIN", crossdockOrderHeadersToSendToWin.size());
                        }
                        auditEventLogEntity.setAuditTs(new Timestamp(System.currentTimeMillis()));
                        auditEventLogRepo.save(auditEventLogEntity);
                    }

                    auditEventLogEntity.setAuditMessage(String.format("Successful completion of route close message with %s", baseProcessMessageAuditMessage));
                    auditEventLogEntity.setAuditTs(new Timestamp(System.currentTimeMillis()));
                    auditEventLogRepo.save(auditEventLogEntity);
                } else {
                    //TODO Rollback changes because there were no loads that were added.
                    logger.info("There were no valid pallets thus no headers that were valid.  Need to rollback SKOPE and Header Orders");
                }

            } else {
                //TODO: make an echo alert to send info to nashville so we can have vendor resend the info
                setAsnShipmentMDCs(asnShipment.getSender());
                MDC.put("SKOPE-ORDERS", validSkopeOrders.stream().map(SkopeOrder::getSkopeOrderNo).collect(Collectors.joining(", ")));
                logger.error("None of the SKOPE Orders on Route [{}] have store maps", asnShipment.getShipmentData().getRouteName());

                           }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
            MDC.clear();
            throw ex;
        } finally {
            logger.info("Complete processing of ASN Route Message. Route [{}].", asnShipment.getShipmentData().getRouteName() );
            MDC.clear();
        }
    }

    /**
     * Loop through all of the skope orders on a ASN Shipment <i>(route close message)</i> and ensure the orders are valid to be processed.
     * If there is an issue with an order, add the order and the list of the issues with the order to the map which will eventually be used for logging
     *
     * @param orders                    the route close message sent from a vendor
     * @param originFacility                 the facility in our database that represents the vendor who sent the route close
     * @param validationErrorsByOrderTreeMap a sorted list of errors that belong to a skope order on the route close message. Key is the skope order number and value is a list of error messages
     * @param originFacilityShipmentTs       the timestamp of the route close on the route close message
     * @return a list of valid SKOPE orders sent on a route close that need to be processed
     */
    public List<SkopeOrder> validateSkopeRecords(List<Order> orders, SourcingFacilityEntity originFacility, SortedMap<String, List<String>> validationErrorsByOrderTreeMap, Timestamp originFacilityShipmentTs, String routeName) {
        List<SkopeOrder> validSkopeOrders = new ArrayList<>();


        for (Order asnSkopeOrder : orders) {
            MDC.put(SKOPE_ORDER, asnSkopeOrder.getId());
            List<String> skopeOrderValidationErrors = new ArrayList<>();

            try {
                //validate fields on the SKOPE ORDER
                SkopeOrder skopeOrder = validateSkopeOrder(asnSkopeOrder, originFacility, skopeOrderValidationErrors,
                        routeName, originFacilityShipmentTs);

                // print out the skope order that we are adding to the valid list
                logger.info("Valid Skope Order Details: [{}]", skopeOrder.toStringDebug());

                //use tree map to group all errors that exist from a single event into a single echo log message
                validSkopeOrders.add(skopeOrder);
            } catch (EntityNotFoundException | SkopeOrderValidationException ex) {
                validationErrorsByOrderTreeMap.put(asnSkopeOrder.getId(), skopeOrderValidationErrors);
            }
        }
        MDC.remove(SKOPE_ORDER);
        return validSkopeOrders;
    }


    /** Verifies that the JSON meets requirements that all required fields are filled in and not blank quotes (""). If there are any errors, capture
     * them so that we can eventually log them to echo and not process any of the data. <br/><br/>
     * This will also include special logic to remove a pallet if all the order ID references were not sent as part of the list of SKOPE Orders in the JSON.
     * @param orders the ASN Route Close data. This should not yet be manipulated via code and the exact copy of what the vendor sent
     * @param pallets
     * @param sender
     * @param routeName
     */
    public void validateAsnData(List<Order> orders, List<Pallet> pallets, Sender sender, String routeName) {
        TreeMap<String, List<String>> invalidData = new TreeMap<>();
        Set<String> uniqueSkopeOrders = new HashSet<>();
        Set<String> uniqueSkopeOrdersOnPallets = new HashSet<>();

        // for each skope order in the list of skope orders on the asn shipment, verify all fields are filled in and if
        // the order is valid, add it to a unique set
        //Basic validations to ensure the data passed from vendors is filled in
        validateShipmentOrders(orders, uniqueSkopeOrders, invalidData);


        /* for each pallet, verify all data is filled in. Also verify that at least one order id reference is in the list
         of skope orders on the bottom of the ASN Shipment JSON. If none are in the list, log a special message which will
         be monitored in ECHO as we have to remove this pallet as there will not be a cross dock order header generated*/
        if(pallets != null && !pallets.isEmpty()) {
            Iterator<Pallet> palletsIt = pallets.iterator();
            while (palletsIt.hasNext()) {
                Pallet pallet = palletsIt.next();
                List<String> validationErrors = new ArrayList<>();
                validateJsonFieldsNotNull(pallet, validationErrors);

                if (validationErrors.isEmpty()) {
                    //check both order ids on pallets to verify they exist in list of skope orders on asn shipment json
                    boolean atLeastOneIdReferenceInSkopeOrderList = false;
                    for (String palletSkopeOrder : pallet.getOrderIdReferences()) {
                        if (uniqueSkopeOrders.contains(palletSkopeOrder)) {
                            atLeastOneIdReferenceInSkopeOrderList = true;
                            break;
                        }
                    }

                    if (!atLeastOneIdReferenceInSkopeOrderList) {
                        logger.error("Pallet: {} did not have any SKOPE Orders that were sent in the list of SKOPE Orders on the ASN Shipment JSON. Removing pallet from list of pallets.", pallet.getId());
                        palletsIt.remove();
                    } else {
                        uniqueSkopeOrdersOnPallets.addAll(pallet.getOrderIdReferences());
                    }
                } else {
                    invalidData.put("Pallet: " + pallet.getId(), validationErrors);
                    palletsIt.remove();
                }
            }
//        shipmentData.setPallets(pallets);

            verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrders(uniqueSkopeOrders, uniqueSkopeOrdersOnPallets);
        }

        //log out the errors that we had on this, but do not prevent valid orders from being processed
        if (!invalidData.isEmpty()) {
            logInvalidData(invalidData, sender, routeName);
        }

    }

    public void verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrders(Set<String> uniqueSkopeOrders, Set<String> uniqueSkopeOrdersOnPallets) {
        for (String skopeOrder : uniqueSkopeOrders) {
            if (!uniqueSkopeOrdersOnPallets.contains(skopeOrder)) {
                logger.warn("SKOPE Order ID: {} was not found on any pallets", skopeOrder);
            }
        }

        for (String palletSkopeOrder : uniqueSkopeOrdersOnPallets) {
            if (!uniqueSkopeOrders.contains(palletSkopeOrder)) {
                logger.warn("Skope Order ID: {} is on a pallet, however it was not provided in the list of SKOPE Orders on the ASN Shipment JSON." +
                        "We do not have enough info to build a valid SKOPE order to assign to a Cross Dock Order Header for this pallet.", palletSkopeOrder);
            }
        }
    }

    public void validateShipmentOrders(List<Order> orders, Set<String> uniqueSkopeOrders, SortedMap<String, List<String>> invalidData) {
        Iterator<Order> ordersIt = orders.iterator();
        while (ordersIt.hasNext()) {
            Order order = ordersIt.next();

            List<String> validationErrors = new ArrayList<>();
            validateJsonFieldsNotNull(order, validationErrors);
            order.setCatalogGroupNumber(order.getCatalogGroupNumber().toUpperCase());

            if (validationErrors.isEmpty()) {
                uniqueSkopeOrders.add(order.getId());
            } else {
                invalidData.put("SKOPE Order: " + order.getId(), validationErrors);
                ordersIt.remove();
            }
        }
    }


    /** This loops through all of the fields of an object and verify it is filled in and not blank. If it does not meet the requirements, add
     * an error message to the list to be logged to echo at some point.
     * @param parentObjectToValidate This should be the object that has the properties you want to verify are not null (ie. Order or Pallet)
     * @param validationErrors an empty list that will hold any errors if a required field is not filled in
     */
    public void validateJsonFieldsNotNull(Object parentObjectToValidate, List<String> validationErrors) {
        Field[] objectFields = parentObjectToValidate.getClass().getDeclaredFields();
        for (Field field : objectFields) {
            if (!field.toString().toLowerCase().contains("static")) {
                try {
                    String invalidFieldMessage = "Invalid " + generatePrettyName(field);
                    Object fieldValue = field.get(parentObjectToValidate);

                    validateByFieldType(fieldValue, invalidFieldMessage, validationErrors);
                } catch (IllegalAccessException e) {
                    logger.error("Unable to access field to validate that it is filled in", e);
                }
            }
        }
    }

    public void validateByFieldType(Object fieldValue, String invalidFieldMessage, List<String> validationErrors) {
        if(fieldValue instanceof String) {
            if (fieldValue.toString().trim().equals("")) {
                validationErrors.add(invalidFieldMessage);
            }
        } else if (fieldValue instanceof List) {
            if (((List) fieldValue).isEmpty()) {
                validationErrors.add(invalidFieldMessage);
            }
        } else {
            if (fieldValue == null) {
                validationErrors.add(invalidFieldMessage);
            }
        }
    }

    /** This will take a object property name and make it in a more human readable format.
     * ie. if catalogGroupNumber was the field on Order that you are processing, the pretty name would become
     * "Catalog Group Number"
     * @param field this is the property that you want to get the pretty name for
     * @return a string value in a human readable format
     */
    public String generatePrettyName(Field field) {
        String prettyName = Arrays.toString(field.getName().split("(?=\\p{Upper})"))
                .replace(",","").replace("[", "").replace("]", "");
        return prettyName.substring(0,1).toUpperCase() + prettyName.substring(1);
    }

    /**
     * Validates a single skope order from a ASN route close message. Verify that all fields are filled in and in the correct format,
     * that an order management division, catalog group, and store are all set up in the database for the order. If all those pass,
     * then create a skope order DTO. If any errors, then add them to the validation errors list.
     *
     * @param asnSkopeOrder            a individual skope order on the route close message
     * @param originFacility           the facility that sent the route close message
     * @param validationErrors         an empty list which we can add as many errors to for logging purposes
     * @param routeName                the route name from the route close message
     * @param originFacilityShipmentTs the shipment timestamp from the route close message
     * @return SkopeOrderDTO which is based off the data the vendor sent on the route close message for this order
     * @throws SkopeOrderValidationException this is thrown if we are missing key information needed to make SQL calls and would cause runtime errors
     */
    public SkopeOrder validateSkopeOrder(Order asnSkopeOrder, SourcingFacilityEntity originFacility, List<String> validationErrors,
                                         String routeName, Timestamp originFacilityShipmentTs) throws SkopeOrderValidationException {
        logger.debug("validateSkopeOrder: validating SKOPE Order: [{}]",asnSkopeOrder.getId());


        // SKOPE is sending the billing division number instead of the management division number on the EDI file to the vendors.
        // Normally they are same except for Memphis orders so it was decided to hard code this for this one situation since SKOPE will go away in a few years.
        // 023 is Memphis but the stores belong to Nashville Management Division (025)
        String managementDivisionNumber = asnSkopeOrder.getOrderManagementDivisionNumber();
        if (asnSkopeOrder.getOrderManagementDivisionNumber().equalsIgnoreCase("023")) {
           managementDivisionNumber = "025";
        }

        OrderManagementDivisionEntity orderManagementDivision = orderManagementDivisionRepo.findFirstByOrderManagementDivisionNo(managementDivisionNumber);
        CatalogGroupEntity catalogGroupEntity = catalogGroupRepo.findBySourcingFacilityIdAndCatalogGroupNo(originFacility.getSourcingFacilityId(), asnSkopeOrder.getCatalogGroupNumber());

        //return validation errors as store repo had dependency on orderManagementDivision
        if (orderManagementDivision == null || catalogGroupEntity == null) {
            if (orderManagementDivision == null) {
                validationErrors.add(String.format("Order management division number %s not found in table", managementDivisionNumber));
            }
            if (catalogGroupEntity == null) {
                validationErrors.add(String.format("Catalog group %s for facility %s was not found in the catalog group table",
                        asnSkopeOrder.getCatalogGroupNumber(), originFacility.getSourcingFacilityNo()));
            }
            throw new EntityNotFoundException("Unable to find Entity for OrderManagementDivision or CatalogGroup when validating SKOPE Order");
        }

        StoreEntity storeEntity = storeRepo.findByOrderManagementDivisionIdAndStoreNo(orderManagementDivision.getOrderManagementDivisionId(), asnSkopeOrder.getStoreNumber());

        if (storeEntity == null) {
            validationErrors.add(String.format("Store not found in store table. Order Management Division: %s, Store Number: %s",
                    orderManagementDivision.getOrderManagementDivisionNo(), asnSkopeOrder.getStoreNumber()));
            throw new EntityNotFoundException("Unable to find Entity for Store when validating SKOPE Order");

        }

        SkopeOrder skopeOrder = null;
        try {
            skopeOrder = new SkopeOrder(asnSkopeOrder, routeName);
            skopeOrder.setOrderManagementDivisionId((long) orderManagementDivision.getOrderManagementDivisionId());
            skopeOrder.setOrderManagementDivisionNo(orderManagementDivision.getOrderManagementDivisionNo());
            skopeOrder.setStoreId((long) storeEntity.getStoreId());
            skopeOrder.setStoreNo(storeEntity.getStoreNo());
            skopeOrder.setCatalogGroupNo(catalogGroupEntity.getCatalogGroupNo());
            skopeOrder.setCatalogGroupId((long) catalogGroupEntity.getCatalogGroupId());
            skopeOrder.setRoute(routeName);
            skopeOrder.setFacilityId((long) originFacility.getSourcingFacilityId());
            skopeOrder.setFacilityNo(originFacility.getSourcingFacilityNo());
            //We only set Order Complete Timestamp on ASN Shipment Event, shipmentTs is only used for ASN Shipment Events, not Order Summary
            if (originFacilityShipmentTs != null) {
                skopeOrder.setOriginFacilityOrderCompleteTime(originFacilityShipmentTs);
            }
            Date currentDate = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
            if (skopeOrder.getOrderDeliveryDate().before(currentDate)) {
                validationErrors.add("SKOPE Order delivery date must be in the future");
                throw new SkopeOrderValidationException(String.format(SKOPE_ORDER_HAS_ERRORS, asnSkopeOrder.getId()));
            }
        } catch (ParseException e) {
            validationErrors.add(String.format("Unable to parse delivery date: %s", e.toString()));
            throw new SkopeOrderValidationException(String.format(SKOPE_ORDER_HAS_ERRORS, asnSkopeOrder.getId()));
        }
        if (!validationErrors.isEmpty()) {
            throw new SkopeOrderValidationException(String.format(SKOPE_ORDER_HAS_ERRORS, asnSkopeOrder.getId()));
        }
        return skopeOrder;
    }

    /**
     * Takes a list of skope orders from the route close and determines if the skope order has a valid cross dock store map
     * which means it needs to be cross docked. If it needs to be cross docked, then check to see if the skope order already exists
     * in the database. If it exists, then update the cube, weight, quantity, source facility timestamp, and store map linkage.
     * If it doesn't exist, then create add to a list so we can create all missing skope orders in one DB call.
     * Lastly, add skope orders that need cross docked to the map to be returned.
     *
     * @param skopeOrders a list of skope orders sent on the route close that were filled in and had no errors with the primary data
     * @return a map of skope orders that were found in our database or created. The key is the skope order number and the value is the skope order entity
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public Map<String, SkopeOrderEntity> processSkopeOrders(List<SkopeOrder> skopeOrders, List<Pallet> pallets) throws Exception {
        HashMap<String, SkopeOrderEntity> mappedSkopeOrders = new HashMap<>();
        List<SkopeOrderEntity> skopeOrdersToAddOrUpdate = new ArrayList<>();
        Map<String, SkopeOrder> unmappedSkopeOrderHashMap = new HashMap<>();
        HashMap<String, CrossdockStoreMapEntity> mappedStoreMapsBySkopeOrder = new HashMap<>();
        logger.debug("processSkopeOrders: Begin Processing valid SKOPE Orders");
        for (SkopeOrder skopeOrder : skopeOrders) {
            MDC.put(SKOPE_ORDER, skopeOrder.getSkopeOrderNo());
            logger.debug("Processing valid SKOPE Order: [{}]",skopeOrder.getSkopeOrderNo());
            CrossdockStoreMapEntity crossdockStoreMap = findCrossDockMapForSkopeOrder(skopeOrder);

            if (crossdockStoreMap == null) {
                // no maps for this order go to next order on the route close record
                unmappedSkopeOrderHashMap.put(skopeOrder.getSkopeOrderNo(), skopeOrder);
                continue;
            }

            //find skope order in cross dock skope order table
            String originFacilityNumber = crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId()
                    .getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityNo();
            int storeId = crossdockStoreMap.getStoreByStoreId().getStoreId();
            int catGroupId = crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCatalogGroupByOriginCatalogGroupId().getCatalogGroupId();

            SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findExistingSkopeOrder(skopeOrder.getOrderBillingDivisionNo(), skopeOrder.getSkopeOrderNo(), originFacilityNumber, storeId, catGroupId);

            if (skopeOrderEntity == null) {
                logger.info("processSkopeOrders: SKOPE Order not found on the DB table. Billing Division: [{}]. Facility: [{}].",
                        skopeOrder.getOrderBillingDivisionNo(), originFacilityNumber);

                skopeOrderEntity = createSkopeOrder(skopeOrder, crossdockStoreMap);
                if (skopeOrderEntity != null) {
                    skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMap);
                    mappedStoreMapsBySkopeOrder.put(skopeOrderEntity.getSkopeOrderNo(), crossdockStoreMap);
                    skopeOrdersToAddOrUpdate.add(skopeOrderEntity);
                    logger.debug("Need to create SKOPE Order : [{}]", skopeOrderEntity.getSkopeOrderNo());
                    //TODO: Log to audit table
                }

            } else if (skopeOrderEntity.getSourceFacilityOrderCmplTs() != null) {
                //complete flag already sent for skope order
                logger.info("SKOPE Order [{}] ID [{}] already sent on Route Close (complete timestamp is not null) and was rejected.", skopeOrderEntity.getSkopeOrderNo(), skopeOrderEntity.getSkopeOrderId());
            } else if (skopeOrderEntity.getSkopeOrderCancelTs() != null) {
                //skope order cancelled...do not update
                logger.info("SKOPE Order has been marked as cancelled. SKOPE Order rejected.");
            } else {
                logger.info("SKOPE Order has been found on the SKOPE table. Id: [{}] and will be used.", skopeOrderEntity.getSkopeOrderId());
                skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMap);
                skopeOrderEntity.setSkopeGrossCubeAmt(BigDecimal.valueOf(skopeOrder.getGrossCubeAmt()));
                skopeOrderEntity.setSkopeNetWeightAmt(BigDecimal.valueOf(skopeOrder.getNetWeightAmt()));
                skopeOrderEntity.setSkopeOrderQty(skopeOrder.getOrderQty());
                if ((skopeOrder.getOriginFacilityOrderCompleteTime()) == null) {
                    skopeOrderEntity.setSourceFacilityOrderCmplTs(null);
                } else {
                    skopeOrderEntity.setSourceFacilityOrderCmplTs(new Timestamp(skopeOrder.getOriginFacilityOrderCompleteTime().getTime()));
                }
                skopeOrderEntity.setRowUpdateId(CommonDefines.ASN_ID_PREFIX + skopeOrderEntity.getSourcingFacilityBySourcingFacilityId().getSourcingFacilityNo());
                skopeOrderEntity.setRowUpdateTs(new Timestamp(System.currentTimeMillis()));
                skopeOrderEntity.setRouteNo(skopeOrder.getRoute());
                skopeOrderEntity.setCrossdockCatalogGroupMapEntity(crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());
                mappedStoreMapsBySkopeOrder.put(skopeOrderEntity.getSkopeOrderNo(), crossdockStoreMap);
                skopeOrdersToAddOrUpdate.add(skopeOrderEntity);
            }
        }

        MDC.remove(SKOPE_ORDER);

        if (!skopeOrdersToAddOrUpdate.isEmpty()) {
            try {
                //saving all skope orders that need to be added or updated into DB at once for performance
                List<SkopeOrderEntity> savedSkopeOrders = null;
                savedSkopeOrders = skopeOrderRepo.saveAll(skopeOrdersToAddOrUpdate);

                StringBuilder createdSkopeOrdersSb = new StringBuilder();
                savedSkopeOrders.forEach(order -> {
                    order.setCrossdockStoreMap(mappedStoreMapsBySkopeOrder.get(order.getSkopeOrderNo()));
                    mappedSkopeOrders.put(order.getSkopeOrderNo(), order);
                    createdSkopeOrdersSb.append("[ Id: ").append(order.getSkopeOrderId()).append(", Number: ").append(order.getSkopeOrderNo()).append("],\n");
                });

                logger.info("SKOPE Orders created:\n{}", createdSkopeOrdersSb);
            } catch (DataIntegrityViolationException dive) {
                logger.warn("Data Constraint Violation when saving all SKOPE Orders. Start process to save orders individually");
                try {
                    skopeOrdersToAddOrUpdate.forEach(skopeOrderEntity -> {
                        MDC.put(SKOPE_ORDER, skopeOrderEntity.getSkopeOrderNo());
                        skopeOrderEntity = skopeOrderRepo.save(skopeOrderEntity);
                        mappedSkopeOrders.put(skopeOrderEntity.getSkopeOrderNo(), skopeOrderEntity);
                        logger.info("SKOPE Order Created: [ Id: {}, Number: {}]\n", skopeOrderEntity.getSkopeOrderId(), skopeOrderEntity.getSkopeOrderNo());
                    });
                } catch (DataIntegrityViolationException nestedDive) {
                    logger.error("Unable to save SKOPE Order due to data integrity violation");
                }
            }

        }
        //checking if pallets are null because they are only used on ASN Shipment Events not ASN Order Summary Events
        if (!unmappedSkopeOrderHashMap.isEmpty() && pallets != null) {
            logger.info("Cross dock store map(s) not found. Email notification sent to Nashville routing.");
            emailService.sendNoStoreMapFoundEmail(unmappedSkopeOrderHashMap,
                    pallets);
        }
        MDC.remove(SKOPE_ORDER);
        return mappedSkopeOrders;
    }

    /**
     * Create a skope order in the database based on the skope order data sent to us from the ASN route close message
     * and the store map that should be used for the order which shows it is a valid skope order
     *
     * @param skopeOrder        the skope order DTO that was not found in our database
     * @param crossdockStoreMap the cross dock store map to use for this skope order
     * @return a new skope order entity that was just inserted into the skope order table of the database
     */
    public SkopeOrderEntity createSkopeOrder(SkopeOrder skopeOrder, CrossdockStoreMapEntity crossdockStoreMap) {
        //taking the entities of the foreign keys needed for insert from the crossdock store map and saving into individual objects for readability
        StoreEntity store = crossdockStoreMap.getStoreByStoreId();
        SourcingFacilityEntity sourcingFacility = crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getSourcingFacilityByOriginSourcingFacilityId();
        CatalogGroupEntity originCatalogGroup = crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCatalogGroupByOriginCatalogGroupId();
        OrderManagementDivisionEntity orderManagementDivision = orderManagementDivisionRepo.findById(skopeOrder.getOrderManagementDivisionId().intValue())
                .orElseThrow(() -> new EntityNotFoundException(String.format("Unable to find OrderManagementDivision with id %s", skopeOrder.getOrderManagementDivisionId().toString())));

            /*create the skope order entity to insert via hibernate
            currently we must attach the entities of the FK relationships. May be able to switch to just ids to avoid
             OrderManagementDivision database call above as that id is set on the skope order*/
        return new SkopeOrderEntity(skopeOrder, sourcingFacility, originCatalogGroup, orderManagementDivision, store, crossdockStoreMap);
    }

    /**
     * This method will determine if the SKOPE order should be cross docked.
     * It will determine if a map exist for the origin/catalog going to the management division/store for the specified SKOPE order
     *
     * @param skopeOrder the skope order DTO that we need to find a map for
     * @return will return the existing cross dock store map for this skope order if it exists. <b>It is possible to return null.</b>
     */
    public CrossdockStoreMapEntity findCrossDockMapForSkopeOrder(SkopeOrder skopeOrder) {
        logger.info("findCrossDockMapForSkopeOrder: Find Map for origin facility [{}] w/ID [{}]. Origin catalog group [{}] w/ID [{}]. Store [{}] w/ID [{}]. Management division [{}] w/ID [{}]. Delivery Date [{}]. Processing Time [{}].",
                skopeOrder.getFacilityNo(), skopeOrder.getFacilityId(),
                skopeOrder.getCatalogGroupNo(), skopeOrder.getCatalogGroupId(),
                skopeOrder.getStoreNo(), skopeOrder.getStoreId(),
                skopeOrder.getOrderBillingDivisionNo(), skopeOrder.getOrderManagementDivisionId(),
                skopeOrder.getOrderDeliveryDate(), new Date());

        CrossdockStoreMapEntity crossdockStoreMap = crossdockStoreMapRepo.findCrossdockStoreMapByOriginCatGroupIdAndOriginFacilityAndStoreId(skopeOrder.getCatalogGroupId().intValue(),
                skopeOrder.getFacilityId().intValue(), skopeOrder.getStoreId().intValue());

        //if we don't have a valid map, log out reason and return null
        if (crossdockStoreMap == null || crossdockStoreMap.getCrossdockMapByCrossdockMapId() == null) {
            logger.warn("Unable to find a valid cross dock map for combination of origin cat group[{}], origin facility[{}], and store[{}]",
                    skopeOrder.getCatalogGroupId(), skopeOrder.getFacilityId(), skopeOrder.getStoreId());
            return null;
        }

        //map found
        //see if a store schedule exist for the map that matches the delivery date
        logger.info("Best map: [{}], Map Id: [{}]. Checking the delivery day to see if it is marked for cross dock.", crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(),
                crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapId());
        int dayOfWeek = crossdockStoreMap.getCrossdockMapByCrossdockMapId().findDayOfWeek(skopeOrder.getOrderDeliveryDate());

        if (crossdockStoreMap.getCrossdockMapByCrossdockMapId().determineIfCrossDockScheduleCalendarCD14Day()) {

            KrogerFiscalCalendar krogerCalendar = DateParser.dateToKrogerFiscalCalendar(skopeOrder.getOrderDeliveryDate());
            int krogerWeek = krogerCalendar.get(KrogerFiscalCalendar.FISCAL_WEEK);

            logger.debug("Map has a 14 day schedule. Day of week is [{}]. Kroger week is [{}].", dayOfWeek, krogerWeek);
        } else {
            logger.debug("Map has a 7 day schedule. Day of week is [{}].", dayOfWeek);
        }

        CrossdockStoreScheduleEntity crossdockStoreSchedule = crossdockStoreScheduleRepo.findByCrossdockStoreMapIdAndScheduleDayNo(crossdockStoreMap.getCrossdockStoreMapId(), (short) dayOfWeek);

        if (crossdockStoreSchedule == null) {
            logger.info("Origin facility [{}] Origin cat group [{}] Delivery Date [{}]. Mgt Div [{}] Store [{}] does NOT have day [{}] checked for Cross Dock Map [{}]. Store Map Id: [{}]",
                    skopeOrder.getFacilityNo(), skopeOrder.getCatalogGroupNo(), skopeOrder.getOrderDeliveryDate(), skopeOrder.getOrderBillingDivisionNo(), crossdockStoreMap.getStoreByStoreId().getStoreNo(),
                    dayOfWeek, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(), crossdockStoreMap.getCrossdockStoreMapId());
            return null;
        } else if (crossdockStoreSchedule.getScheduleFlag().equalsIgnoreCase("t")) {
            //TODO: When system testing with TEST data (not H2) do we need to adjust code to add check crossdock cat group map on cross dock map does not contain nulls
            logger.info("Origin facility [{}] Origin cat group [{}] Delivery Date [{}] Mgt Div [{}] Store [{}]. Store Map Name: [{}] Id: [{}] is valid store map for SKOPE Order on day [{}]",
                    skopeOrder.getFacilityNo(), skopeOrder.getCatalogGroupNo(), skopeOrder.getOrderDeliveryDate(), skopeOrder.getOrderBillingDivisionNo(), crossdockStoreMap.getStoreByStoreId().getStoreNo(),
                    crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(), crossdockStoreMap.getCrossdockStoreMapId(), dayOfWeek);
        } else {
            logger.info("Origin facility [{}] Origin cat group [{}] Delivery Date [{}]. Mgt Div [{}] Store [{}] does NOT have day [{}] checked for Cross Dock Map [{}]. Store Map Id: [{}]",
                    skopeOrder.getFacilityNo(), skopeOrder.getCatalogGroupNo(), skopeOrder.getOrderDeliveryDate(), skopeOrder.getOrderBillingDivisionNo(), crossdockStoreMap.getStoreByStoreId().getStoreNo(),
                    dayOfWeek, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(), crossdockStoreMap.getCrossdockStoreMapId());
            return null;
        }

        return crossdockStoreMap;
    }

    public CrossdockStoreMapEntity findCrossDockMapForSkopeOrder(SkopeOrderEntity skopeOrder) {
        logger.info("Proccessing getting maps for origin facility [{}]. Origin catalog group [{}]. Store [{}]. Management division [{}]. Delivery Date [{}]. Processing Time [{}].",
                skopeOrder.getSourcingFacilityId(), skopeOrder.getCatalogGroupId(), skopeOrder.getStoreId(), skopeOrder.getOrderManagementDivisionId(),
                skopeOrder.getSkopeOrderDeliveryDt(), new Date());

        CrossdockStoreMapEntity crossdockStoreMap = crossdockStoreMapRepo.findCrossdockStoreMapByOriginCatGroupIdAndOriginFacilityAndStoreId(skopeOrder.getCatalogGroupId().intValue(),
                skopeOrder.getSourcingFacilityId(), skopeOrder.getStoreId().intValue());

        //if we don't have a valid map, log out reason and return null
        if (crossdockStoreMap == null || crossdockStoreMap.getCrossdockMapByCrossdockMapId() == null) {
            logger.warn("Unable to find a valid cross dock map for combination of origin cat group[{}], origin facility[{}], and store[{}]",
                    skopeOrder.getCatalogGroupId(), skopeOrder.getSourcingFacilityId(), skopeOrder.getStoreId());
            return null;
        }

        //map found
        //see if a store schedule exist for the map that matches the delivery date
        logger.debug("Best map: [{}], Map Id: [{}]. Checking the day to see if it is marked for cross dock.", crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(),
                crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapId());
        int dayOfWeek = crossdockStoreMap.getCrossdockMapByCrossdockMapId().findDayOfWeek(skopeOrder.getSkopeOrderDeliveryDt());

        if (crossdockStoreMap.getCrossdockMapByCrossdockMapId().determineIfCrossDockScheduleCalendarCD14Day()) {

            KrogerFiscalCalendar krogerCalendar = DateParser.dateToKrogerFiscalCalendar(skopeOrder.getSkopeOrderDeliveryDt());
            int krogerWeek = krogerCalendar.get(KrogerFiscalCalendar.FISCAL_WEEK);

            logger.debug("Map has a 14 day schedule. Day of week is [{}]. Kroger week is [{}].", dayOfWeek, krogerWeek);
        } else {
            logger.debug("Map has a 7 day schedule. Day of week is [{}].", dayOfWeek);
        }

        CrossdockStoreScheduleEntity crossdockStoreSchedule = crossdockStoreScheduleRepo.findByCrossdockStoreMapIdAndScheduleDayNo(crossdockStoreMap.getCrossdockStoreMapId(), (short) dayOfWeek);

        if (crossdockStoreSchedule == null) {
            logger.info("Store [{}] does not have day [{}] checked. Map [{}] Id: [{}] is discarded because the day is not checked.", crossdockStoreMap.getStoreByStoreId().getStoreNo(),
                    dayOfWeek, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(), crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapId());
            return null;
        } else if (crossdockStoreSchedule.getScheduleFlag().equalsIgnoreCase("t")) {
            //TODO: When system testing with TEST data (not H2) do we need to adjust code to add check crossdock cat group map on cross dock map does not contain nulls
            logger.info("Map: [{}] Id: [{}] is valid map for SKOPE Order on day [{}]", crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(),
                    crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapId(), dayOfWeek);
        } else {
            logger.info("Store [{}] does not have day [{}] checked. Map: [{}] Id: [{}] is discarded because the day is not checked",
                    crossdockStoreMap.getStoreByStoreId().getStoreNo(), dayOfWeek, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapNme(),
                    crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapId());
            return null;
        }

        return crossdockStoreMap;
    }

    /**
     * Check if the crossdock route already exists and update it if so. Otherwise, create a new crossdock route.
     *
     * @param crossdockRoute a cross dock route entity that was constructed and need to verify if it already exists
     * @return the saved cross dock route including the ID
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public CrossdockRouteEntity saveRoute(CrossdockRouteEntity crossdockRoute) throws Exception {
        CrossdockRouteEntity crossdockRouteFromDb = crossdockRouteRepo.findBySourcingFacilityIdAndRouteNmeAndDispatchDt(crossdockRoute.getSourcingFacilityId(), crossdockRoute.getRouteNme(), crossdockRoute.getDispatchDt());
        AuditEventLogEntity auditEventLogEntity;
        if (crossdockRouteFromDb != null) {
            crossdockRoute.setRouteId(crossdockRouteFromDb.getRouteId());
            auditEventLogEntity = new AuditEventLogEntity(crossdockRoute, AuditEventCodeEnum.UpdateCrossDockRoute);
        } else {
            auditEventLogEntity = new AuditEventLogEntity(crossdockRoute, AuditEventCodeEnum.CreateCrossDockRoute);
        }
        crossdockRoute = crossdockRouteRepo.save(crossdockRoute);
        auditEventLogRepo.save(auditEventLogEntity);

        return crossdockRoute;
    }

    /**
     * This method takes a map of valid skope orders that had a valid cross dock map that need to be assigned to cross dock order headers
     *
     * @param mappedSkopeOrders a map of all of the valid skope orders. The key is the skope order number and the value is a skope order entity
     * @param originRoute       the route that all of these skope orders need to be assigned to. In order to assign to this route, when we find the header, the header needs to be updated to point at this route
     * @return this will return a map where the key is the skope order number and the value is the crossdock order header entity
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public Map<String, CrossdockOrderHeaderEntity> processCrossDockHeaders(Map<String, SkopeOrderEntity> mappedSkopeOrders, CrossdockRouteEntity originRoute) throws Exception {

        HashMap<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeNumberMap = new HashMap<>();

        for (SkopeOrderEntity skopeOrder : mappedSkopeOrders.values()) {

            // check to see what cross dock header is currently attached to the SKOPE order.
            // IF HEADER is cancelled
            // THEN do NOT process this skope order

            //TODO: Update query to not pull back in-transit headers (origin complete not null) and do order by

            boolean foundExistingXrefHeader = false;

            /*Grab the first Cross Dock Order Header that was on the XRef table and the header is not origin complete
            * This will allow us to find the first open order that may already exist and to potentially use*/
            CrossdockOrderHeaderEntity existingHeader = crossdockOrderHeaderRepo.findFirstOpenCrossdockOrderHeaderBySkopeOrderId(skopeOrder.getSkopeOrderId());

            if (existingHeader != null && existingHeader.isCancelled()) {
                logger.info("Cross Dock order attached to the skope order is cancelled - do not use cross dock order. Continue to next skope order.");
                continue;
            } else if (existingHeader != null) {
                foundExistingXrefHeader = true;
            }

            // no cross dock order header found attached to this skope order that is considered open
            // check for database to see if there is a cross dock orders that is relevant
            if (existingHeader == null) {
                existingHeader = findAvailableCrossDockOrderHeaders(skopeOrder);
            }

            //there is not a relevant cross dock order header so we need to create one
            if (existingHeader == null || (existingHeader.isDsdOrderType() && !foundExistingXrefHeader)) {
                logger.debug("Create cross dock order for skope order.");

                //TODO add try catch. if unable to create order then rollback route close message.
                existingHeader = createCrossdockOrderHeader(skopeOrder, originRoute);
            }

            if (existingHeader == null) {
                logger.info("A cross dock order header could not be created for skope order.");
            } else {
                if (existingHeader.getCrossdockLoadsByCrossdockOrderId() == null) {
                    existingHeader.setCrossdockLoadsByCrossdockOrderId(new ArrayList<>());
                }

                logger.info("Use Cross Dock Order No: [{}] ID: [{}] for SKOPE Order No: [{}] ID: [{}].", existingHeader.getCrossdockOrderNo(), existingHeader.getCrossdockOrderId(), skopeOrder.getSkopeOrderNo(),  skopeOrder.getSkopeOrderId());

                updateCrossdockOrderHeaderWithSkopeDetails(foundExistingXrefHeader, existingHeader, skopeOrder, originRoute);
                crossdockOrderHeaderBySkopeNumberMap.put(skopeOrder.getSkopeOrderNo(), existingHeader);
            }

        }
        return crossdockOrderHeaderBySkopeNumberMap;
    }

    public void updateCrossdockOrderHeaderWithSkopeDetails(Boolean foundExistingXrefHeader, CrossdockOrderHeaderEntity existingHeader, SkopeOrderEntity skopeOrder, CrossdockRouteEntity originRoute) throws Exception {
        if(Boolean.FALSE.equals(foundExistingXrefHeader)) {
            //since we just created a mapping for this header and a skope order, we need to tie SKOPE Order to existing header
            SkopeCrossdockOrderXrefEntity skopeCrossdockOrderXref = createSkopeCrossdockOrderXref(skopeOrder, existingHeader);
            if (existingHeader.getSkopeCrossdockOrderXrefsByCrossdockOrderId() == null) {
                existingHeader.setSkopeCrossdockOrderXrefsByCrossdockOrderId(new ArrayList<>());
            }
            existingHeader.getSkopeCrossdockOrderXrefsByCrossdockOrderId().add(skopeCrossdockOrderXref);
        }
        existingHeader.setGrossCubeAmt(existingHeader.getGrossCubeAmt().add(skopeOrder.getSkopeGrossCubeAmt()));
        existingHeader.setNetWeightAmt(existingHeader.getNetWeightAmt().add(skopeOrder.getSkopeNetWeightAmt()));
        existingHeader.setCrossdockOrderQty(existingHeader.getCrossdockOrderQty() +  skopeOrder.getSkopeOrderQty());
        existingHeader.setOriginOrderCompleteTs(originRoute.getRouteCloseTs());
        existingHeader.setOriginRouteId(originRoute.getRouteId());
        existingHeader.setRowUpdateId(CommonDefines.ASN_ID_PREFIX + existingHeader.getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityNo());
        existingHeader.setRowUpdateTs(new Timestamp(System.currentTimeMillis()));
        AuditEventLogEntity auditEventLogEntity = new AuditEventLogEntity(existingHeader);
        crossdockOrderHeaderRepo.save(existingHeader);
        auditEventLogRepo.save(auditEventLogEntity);
    }

    /**
     * This will update the cross reference table to create a new row linking the skope order to the cross dock order header
     *
     * @param skopeOrder           the skope order needed to link to the cross dock order header
     * @param crossdockOrderHeader the header needed to link to the skope order
     * @return the record that was inserted into the cross reference table to link the skope and cross dock order together
     */
    public SkopeCrossdockOrderXrefEntity createSkopeCrossdockOrderXref(SkopeOrderEntity skopeOrder, CrossdockOrderHeaderEntity crossdockOrderHeader) throws Exception {
        SkopeCrossdockOrderXrefEntity skopeCrossdockOrderXref = skopeCrossdockOrderXrefRepo
                .findFirstByCrossdockOrderIdAndAndSkopeOrderId(crossdockOrderHeader.getCrossdockOrderId(), skopeOrder.getSkopeOrderId()).orElse(new SkopeCrossdockOrderXrefEntity());
        skopeCrossdockOrderXref.setCrossdockOrderHeaderByCrossdockOrderId(crossdockOrderHeader);
        skopeCrossdockOrderXref.setCrossdockOrderId(crossdockOrderHeader.getCrossdockOrderId());
        skopeCrossdockOrderXref.setSkopeOrderBySkopeOrderId(skopeOrder);
        skopeCrossdockOrderXref.setSkopeOrderId(skopeOrder.getSkopeOrderId());

        return skopeCrossdockOrderXrefRepo.save(skopeCrossdockOrderXref);
    }

    /**
     * This method is used if we are unable to find a cross dock order header based on the skope order cross dock order cross reference table.
     * We will see if there is an existing order header if we look by sourcing facility, cross dock facility, cat group number, order management division number,
     * store id, and the skope order delivery date.<br><br>
     * The query will return a list and based on the data, loop through to find the best header to use
     *
     * @param skopeOrder this is a valid skope order from the route close that we are trying to find a header for
     * @return this returns the best possible existing cross dock order header to use. <b>It is possible to return null.</b>
     */
    public CrossdockOrderHeaderEntity findAvailableCrossDockOrderHeaders(SkopeOrderEntity skopeOrder) {

        CrossdockOrderHeaderEntity crossdockOrderHeader = null;

        // ok still no cross dock order header
        // check for database to see if there is a cross dock orders that is relevant
        logger.debug("Find an existing cross dock order for skope order id [{}] with map id [{}]. CrossdockCatalogGroupID [{}]",
                skopeOrder.getSkopeOrderId(), skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().getCrossdockMapId(),
                skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCrossdockCatalogGroupMapId());

        List<CrossdockOrderHeaderEntity> crossdockOrderHeaderList = null;
        if (skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId() != null) {
            crossdockOrderHeaderList = crossdockOrderHeaderRepo.findAvailableCrossDockOrderHeaders(skopeOrder.getSourcingFacilityId(), skopeOrder.getCrossdockFacilityId(), skopeOrder.getCrossdockCatalogGroupNumber(),
                    skopeOrder.getOrderManagementDivisionId(), skopeOrder.getStoreId(), skopeOrder.getSkopeOrderDeliveryDt()).orElse(new ArrayList<>());

            //find the best order header
            for (CrossdockOrderHeaderEntity crossdockOrderHeaderFromList : crossdockOrderHeaderList) {
                logger.debug("Found an existing cross dock order for skope order id [{}] with map id [{}]. CrossdockCatalogGroupID [{}]",
                        skopeOrder.getSkopeOrderId(), skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().getCrossdockMapId(),
                        skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCrossdockCatalogGroupMapId());

                if (crossdockOrderHeader == null) {
                    logger.debug("Take this cross dock order [{}] because there is no other", crossdockOrderHeaderFromList.getCrossdockOrderNo());
                    crossdockOrderHeader = crossdockOrderHeaderFromList;
                } else if (crossdockOrderHeaderFromList.isCrossDockOrderType() && crossdockOrderHeader.isDsdOrderType()) {
                    logger.debug("Take this cross dock order [{}] because this is not a dsd order and the best one is a dsd order.", crossdockOrderHeaderFromList.getCrossdockOrderNo());
                    crossdockOrderHeader = crossdockOrderHeaderFromList;
                }
                //TODO: If we grab one that's already released, do we send an update for the cube and weight to WIN?
                // Answer: seems to be yes. But does WIN accept the updates if the headers in WIN are not in "OPEN" status
                else if (crossdockOrderHeaderFromList.getCrossdockOrderReleaseTs() != null && crossdockOrderHeader.getCrossdockOrderReleaseTs() == null) {
                    logger.debug("Take this Cross Dock order [{}] because it is released.", crossdockOrderHeaderFromList.getCrossdockOrderNo());
                    crossdockOrderHeader = crossdockOrderHeaderFromList;
                } else {
                    logger.debug("Skip cross dock order [{}]", crossdockOrderHeaderFromList.getCrossdockOrderNo());
                }
            }

        }
        return crossdockOrderHeader;
    }

    /**
     * Creates a cross dock order header for a skope order and attaches the cross dock order header to a route
     *
     * @param skopeOrder  the valid skope order that did not have an existing cross dock order header to be tied to
     * @param originRoute the origin route created for this route close message
     * @return the cross dock order header that was inserted into the database
     */
    public CrossdockOrderHeaderEntity createCrossdockOrderHeader(SkopeOrderEntity skopeOrder, CrossdockRouteEntity originRoute) throws Exception {
        CrossdockOrderHeaderEntity crossdockOrderHeader = new CrossdockOrderHeaderEntity(skopeOrder, originRoute);
        crossdockOrderHeader = crossdockOrderHeaderRepo.save(crossdockOrderHeader);

        //Must generate the crossdock order number and save the header again...save will update by id
        crossdockOrderHeader.setCrossdockOrderNo(generateCrossdockOrderNumber(String.valueOf(crossdockOrderHeader.getCrossdockOrderId())));
        return crossdockOrderHeaderRepo.save(crossdockOrderHeader);
    }

    /**
     * This method will take the order id of a crossdock order header and return what the crossdock order number should be.
     * The reason we have this is because the crossdock order number uses part or all of the uniquely generated database ID<br><br>
     * <h1>This must be run if you {@link #createCrossdockOrderHeader(SkopeOrderEntity, CrossdockRouteEntity) create a cross dock order header!}</h1>
     *
     * @param crossdockOrderHeaderId this is the crossdock order header ID of the crossdock order header that was just created
     * @return returns the string value of the crossdock order number which will be used to update the crossdock order header with this value
     * @see #createCrossdockOrderHeader(SkopeOrderEntity, CrossdockRouteEntity)
     */
    public String generateCrossdockOrderNumber(String crossdockOrderHeaderId) {
        final int LENGTH_OF_CROSSDOCK_ORDER_NUMBER_COLUMN = 5;
        int crossdockOrderHeaderIdLength = crossdockOrderHeaderId.length();

        // < 5 digits: pad to left with zeroes: 1 -> "00001", 1234 -> "01234"
        if (crossdockOrderHeaderIdLength < LENGTH_OF_CROSSDOCK_ORDER_NUMBER_COLUMN) {
            return "00000".substring(0, (LENGTH_OF_CROSSDOCK_ORDER_NUMBER_COLUMN - crossdockOrderHeaderIdLength)) + crossdockOrderHeaderId;
        }
        // 5 digits: as is: 12345 -> "12345"
        else if (crossdockOrderHeaderIdLength == LENGTH_OF_CROSSDOCK_ORDER_NUMBER_COLUMN) {
            return crossdockOrderHeaderId;
        }
        // > 5 digits: drop high order digits: 123456 -> "23456"
        else {
            return crossdockOrderHeaderId.substring(crossdockOrderHeaderIdLength - LENGTH_OF_CROSSDOCK_ORDER_NUMBER_COLUMN);
        }
    }

    /**
     * This method will take the list of headers that are going to be used for the route close from the vendors and ensure that all of the skope orders are completed.
     * If a skope order that is <b>not completed</b> is attached to a header, then we need to create a new header for that skope order and reassign it to that order.
     * This also means that we need to create the link between the skope order and the new head in the xref table
     *
     * @param crossdockOrderHeadersToBeSentToWin this is a list of unique crossdock order headers that we know our skope orders from our route close are attached to
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public void finalizeCrossDockOrderHeaders(List<CrossdockOrderHeaderEntity> crossdockOrderHeadersToBeSentToWin, MutableBoolean toBeReleasedToWin) throws Exception {
        List<CrossdockOrderHeaderEntity> newCrossdockOrderHeaders = new ArrayList<>();
        for (int i = 0; i < crossdockOrderHeadersToBeSentToWin.size(); i++) {
            CrossdockOrderHeaderEntity crossdockOrderHeader = crossdockOrderHeadersToBeSentToWin.get(i);

            //Once we find one order set to auto release, we do not need to check that code again
            Iterator xrefIterator = crossdockOrderHeader.getSkopeCrossdockOrderXrefsByCrossdockOrderId().iterator();
            CrossdockOrderHeaderEntity newCrossdockHeaderForSkopeOrder = null;
            List<SkopeCrossdockOrderXrefEntity> skopeOrdersToAddToNewHeader = new ArrayList<>();
            while (xrefIterator.hasNext()) {
                SkopeCrossdockOrderXrefEntity skopeOrderXrefOnCrossdockHeader = (SkopeCrossdockOrderXrefEntity) xrefIterator.next();
                SkopeOrderEntity skopeOrder = skopeOrderXrefOnCrossdockHeader.getSkopeOrderBySkopeOrderId();
                MDC.put(SKOPE_ORDER, skopeOrder.getSkopeOrderNo());

                // if the SKOPE order is not marked as completed, we need to move it to a new crossdock order header and adjust the xref
                if (skopeOrder.getSourceFacilityOrderCmplTs() == null) {
                    if (newCrossdockHeaderForSkopeOrder == null) {
                        newCrossdockHeaderForSkopeOrder  = new CrossdockOrderHeaderEntity(crossdockOrderHeader);
                        newCrossdockHeaderForSkopeOrder = crossdockOrderHeaderRepo.save(newCrossdockHeaderForSkopeOrder);

                        newCrossdockHeaderForSkopeOrder.setCrossdockOrderNo(generateCrossdockOrderNumber(String.valueOf(newCrossdockHeaderForSkopeOrder.getCrossdockOrderId())));
                        newCrossdockHeaderForSkopeOrder = crossdockOrderHeaderRepo.save(newCrossdockHeaderForSkopeOrder);
                        logger.debug("Create new cross dock order header [{}] as there is at least one SKOPE Order on the current order header [{}] that is not completed yet.",
                                newCrossdockHeaderForSkopeOrder.getCrossdockOrderNo(), crossdockOrderHeader.getCrossdockOrderNo());
                    }

                    logger.debug("SKOPE order [{}] is not marked as complete. Assign it to the new cross dock order header [{}]", skopeOrder.getSkopeOrderNo(), newCrossdockHeaderForSkopeOrder.getCrossdockOrderNo());
                    skopeCrossdockOrderXrefRepo.delete(skopeOrderXrefOnCrossdockHeader);
                    skopeOrdersToAddToNewHeader.add(new SkopeCrossdockOrderXrefEntity(newCrossdockHeaderForSkopeOrder.getCrossdockOrderId(), skopeOrder.getSkopeOrderId()));

                    //Ensure that we have a running total added for the cube, weight, and qty from when we move non complete skope orders to the new header
                    newCrossdockHeaderForSkopeOrder.setCrossdockOrderQty(newCrossdockHeaderForSkopeOrder.getCrossdockOrderQty() + skopeOrder.getSkopeOrderQty());
                    newCrossdockHeaderForSkopeOrder.setGrossCubeAmt(newCrossdockHeaderForSkopeOrder.getGrossCubeAmt().add(skopeOrder.getSkopeGrossCubeAmt()));
                    newCrossdockHeaderForSkopeOrder.setNetWeightAmt(newCrossdockHeaderForSkopeOrder.getNetWeightAmt().add(skopeOrder.getSkopeNetWeightAmt()));

                    xrefIterator.remove();
                    continue;
                }

                if (toBeReleasedToWin.isFalse()) {
                    if (skopeOrder.getCrossdockStoreMap() == null) {
                        logger.info("Cross dock store map on SKOPE ORDER: [{}]. Look up map to check to see if skope order is set to auto release.", skopeOrder.getSkopeOrderNo());
                        skopeOrder.setCrossdockStoreMap(findCrossDockMapForSkopeOrder(skopeOrder));
                    }
                    toBeReleasedToWin.setValue(skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().isAutoRelease());
                }
            }

            //if we had SKOPE orders that had to be moved to a brand new Cross Dock Order Header, we need to save the new xref entries.
            if (newCrossdockHeaderForSkopeOrder != null) {
                skopeCrossdockOrderXrefRepo.saveAll(skopeOrdersToAddToNewHeader);
                logger.info("Save All new xRefs between new cross dock order header [{}] and SKOPE orders moved to the header", newCrossdockHeaderForSkopeOrder.getCrossdockOrderNo());
                newCrossdockHeaderForSkopeOrder.getSkopeCrossdockOrderXrefsByCrossdockOrderId().addAll(skopeOrdersToAddToNewHeader);
                crossdockOrderHeaderRepo.save(newCrossdockHeaderForSkopeOrder);
                newCrossdockOrderHeaders.add(newCrossdockHeaderForSkopeOrder);
            }

            //Need to go back out and read DB because after deleting the xref we cannot save the header as the XREF PKs are cached
            //and the order header looks for a link to the one we deleted
            crossdockOrderHeader = crossdockOrderHeaderRepo.findByCrossdockOrderId(crossdockOrderHeader.getCrossdockOrderId());
            calculateHeaderCubeWeightAndQty(crossdockOrderHeader);
            crossdockOrderHeaderRepo.save(crossdockOrderHeader);

            AuditEventLogEntity auditEventLogEntity = new AuditEventLogEntity(crossdockOrderHeader);
            auditEventLogRepo.save(auditEventLogEntity);
            crossdockOrderHeadersToBeSentToWin.set(i, crossdockOrderHeader);
        }

        crossdockOrderHeadersToBeSentToWin.addAll(newCrossdockOrderHeaders);

        MDC.remove(SKOPE_ORDER);

        //If one cross dock order header was already released, or if one cross dock order is set to auto release, then send all cross dock order headers
        //Otherwise, send none of the headers
        if(toBeReleasedToWin.isTrue()) {
            for (CrossdockOrderHeaderEntity crossdockOrderHeaderEntity : crossdockOrderHeadersToBeSentToWin) {
                crossdockOrderHeaderEntity.setCrossdockOrderReleaseTs(new Timestamp(System.currentTimeMillis()));
                crossdockOrderHeaderRepo.save(crossdockOrderHeaderEntity);
            }
        }
    }


    public void calculateHeaderCubeWeightAndQty(CrossdockOrderHeaderEntity crossdockOrderHeader) throws Exception {
        // Get a running total of the cube, weight, and qty that are on the loads for the header we are sending to WIN and
        // set those on the header
        BigDecimal palletsCube = BigDecimal.valueOf(0);
        BigDecimal palletsWeight = BigDecimal.valueOf(0);
        Integer palletsQty = 0;
        for (CrossdockLoadEntity pallet : crossdockOrderHeader.getCrossdockLoadsByCrossdockOrderId()) {
            pallet.setGrossCubeAmt(pallet.getGrossCubeAmt().compareTo(BigDecimal.valueOf(1)) < 0 ? BigDecimal.valueOf(1) : pallet.getGrossCubeAmt());
            pallet = crossdockLoadRepo.save(pallet);
            palletsCube = palletsCube.add(pallet.getGrossCubeAmt());
            palletsWeight = palletsWeight.add(pallet.getNetWeightAmt());
            palletsQty += pallet.getLoadCaseQty();
        }

        crossdockOrderHeader.setNetWeightAmt(palletsWeight);
        crossdockOrderHeader.setCrossdockOrderQty(palletsQty);
        crossdockOrderHeader.setGrossCubeAmt(palletsCube);
    }

    /**
     * Takes the event that had the bad data and logs out the errors pertaining to the JSON or bad skope orders and what was wrong with them to ECHO as a single message
     *
     * @param asnValidationErrors a map of the errors associated to the json or a skope order that was on a asnShipment (route close)
     * @param sender         the data that the vendors sent us that needed to be processed but had errors
     * @param routeName
     */
    public void logInvalidData(SortedMap<String, List<String>> asnValidationErrors, Sender sender, String routeName) {
        setAsnShipmentMDCs(sender);
        ObjectMapper objectMapper = new ObjectMapper();
        String invalidDataJson;
        try {
            invalidDataJson = objectMapper.writeValueAsString(asnValidationErrors);
        } catch (IOException e) {
            logger.error("Unable to use object mapper for invalid data. Create JSON string manually.");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("{");
            for (Map.Entry<String, List<String>> pair : asnValidationErrors.entrySet()) {
                String skopeOrder = pair.getKey();
                List<String> errors = pair.getValue();
                stringBuilder.append("\"").append(skopeOrder).append("\":[");
                for (String error : errors) {
                    stringBuilder.append("\"").append(error).append("\",");
                }
                stringBuilder.append("],");
            }
            stringBuilder.append("}");
            invalidDataJson = stringBuilder.toString();
        }
        MDC.put("Invalid-Data", invalidDataJson);
        logger.error("Invalid data on ASN Event from vendor!: " + invalidDataJson);
        MDC.clear();
    }

    /**
     * When setting the MDC, this will allow for message details under the MDC names to show up in echo for us to better logging
     *
     * @param sender the route close data that will allow us to properly update the MDC for logging to echo
     */
    private void setAsnShipmentMDCs(Sender sender) {
        MDC.put("Sourcing-Facility-Number", sender.getShipFromFacility().getNumber());
        MDC.put("Sourcing-Facility-Name", sender.getShipFromFacility().getName());
        MDC.put("Reference-Id", sender.getReferenceId());
        MDC.put("Sender-Create-Time", sender.getCreationDateTime().getValue());
    }

    @Transactional(propagation = Propagation.MANDATORY)
    List<CrossdockOrderHeaderEntity>processAsnPallets(Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap, List<Pallet> pallets, MutableBoolean toBeReleasedToWin) throws Exception {

        Set<CrossdockOrderHeaderEntity> crossdockOrderHeaderEntitySet = new HashSet<>();
        logger.info("processAsnPallets: Begin ProcessAsnPallets");
        for (Pallet pallet : pallets) {
            if (pallet.getId().length() == 20) {
                logger.debug("Pallet ID [{}] is 20 digits in lenght. Remove first and last character.", pallet.getId());
                pallet.setId(pallet.getId().substring(1, 19));
            }
            logger.debug("Process pallet[{}]", pallet.getId());
            //find header for the pallet by using the SKOPE Order# tied to the pallet.
            CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = findCrossdockOrderHeaderForPallet(pallet, crossdockOrderHeaderBySkopeOrderMap);

            if (crossdockOrderHeaderEntity != null) {
                CrossdockLoadEntity crossdockLoadEntity = new CrossdockLoadEntity(pallet, crossdockOrderHeaderEntity);

                CrossdockLoadEntity existingCrossDockLoad = crossdockLoadRepo.findByLoadNo(pallet.getId());
                if (existingCrossDockLoad != null) {
                    //This should never happen because the code does not reprocess route close records.  The SKOPE record would have origin_complete_ts filled in and would be skipped.
                    if (existingCrossDockLoad.getCrossdockOrderHeaderByCrossdockOrderId().getCrossdockOrderId() == crossdockOrderHeaderEntity.getCrossdockOrderId()){
                        logger.info("ProcessAsnPallets. Found existing load for LoadNumber: [{}] and tied to same Order Header: [{}] so use it.",
                                pallet.getId(), crossdockOrderHeaderEntity.getCrossdockOrderNo());
                        crossdockLoadEntity.setCrossdockLoadId(existingCrossDockLoad.getCrossdockLoadId());
                    } else {
                        logger.error("ProcessAsnPallets. Found existing load for LoadNumber: [{}] tied to another Order Header so do not process load.",
                                pallet.getId());
                        continue;
                    }
                } else {
                    logger.info("ProcessAsnPallets. Created Load No: [{}] and attached to Header No: [{}]", crossdockLoadEntity.getLoadNo(), crossdockOrderHeaderEntity.getCrossdockOrderNo());
                }

                //save or update the load record
                crossdockLoadEntity = crossdockLoadRepo.save(crossdockLoadEntity);

                //Add to the list of loads tied to this header.
                crossdockOrderHeaderEntity.getCrossdockLoadsByCrossdockOrderId().add(crossdockLoadEntity);
                crossdockOrderHeaderEntitySet.add(crossdockOrderHeaderEntity);

                //If one Order header has already been released then release entire route
                if (crossdockOrderHeaderEntity.getCrossdockOrderReleaseTs() != null) {
                    toBeReleasedToWin.setValue(true);
                }
            } else {
                logger.error("Could not find a Crossdock Order Header for Pallet[{}] based on SKOPE Order references.\nPallet: {}", pallet.getId(), pallet);
            }
        }
        return new ArrayList<>(crossdockOrderHeaderEntitySet);
    }

    public CrossdockOrderHeaderEntity findCrossdockOrderHeaderForPallet(Pallet pallet, Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap) {
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = null;
        for (String skopeOrderRefId : pallet.getOrderIdReferences()) {
            SkopeOrder skopeOrderOnPallet = new SkopeOrder(skopeOrderRefId);
            if (crossdockOrderHeaderBySkopeOrderMap.get(skopeOrderOnPallet.getSkopeOrderNo()) != null) {
                crossdockOrderHeaderEntity = crossdockOrderHeaderBySkopeOrderMap.get(skopeOrderOnPallet.getSkopeOrderNo());
                logger.debug("Use Crossdock Order Header Id[{}]. No[{}] for pallet[{}]", crossdockOrderHeaderEntity.getCrossdockOrderId(), crossdockOrderHeaderEntity.getCrossdockOrderNo(), pallet.getId());
                break;
            }
        }
        return crossdockOrderHeaderEntity;
    }

    /**
     * This method builds a list of CrossDockOrderType objects, which is what the web service must have
     * in order to generate the XML message to send down to WIN.
     *
     * @param crossdockOrderHeaderList A list of unique headers to be sent to WIN.
     * @param asnShipment              The object created from the DESP message from a vendor.
     * @param crossdockRoute           The crossdock route created for these orders.
     * @return This returns a list of CrossDockOrderType objects that will be passed to the web service to generate an XML message.
     */
    public List<CrossDockOrderType> buildCrossDockOrderTypeList(List<CrossdockOrderHeaderEntity> crossdockOrderHeaderList,
                                                                ASNShipment asnShipment, CrossdockRouteEntity crossdockRoute) {
        List<CrossDockOrderType> crossDockOrderTypeList = new ArrayList<>();
        crossdockOrderHeaderList.forEach(crossdockOrderHeaderEntity -> {
            CrossDockOrderType crossDockOrderType = new CrossDockOrderType();
            crossDockOrderType.setASNOrderFlag(FlagType.Y);
            if (crossdockOrderHeaderEntity.getCrossdockOrderCancelTs() == null) {
                crossDockOrderType.setCanceledFlag(FlagType.N);
            } else {
                crossDockOrderType.setCanceledFlag(FlagType.Y);
            }

            crossDockOrderType.setOrderNumber(crossdockOrderHeaderEntity.getCrossdockOrderNo());
            crossDockOrderType.setOrderManagementDivisionNumber(crossdockOrderHeaderEntity.getOrderManagementDivisionByOrderManagementDivisionId().getOrderManagementDivisionNo());
            crossDockOrderType.setDeliveryDate(crossdockOrderHeaderEntity.getCrossdockOrderDeliveryDt());
            crossDockOrderType.setStoreNumber(crossdockOrderHeaderEntity.getStoreByStoreId().getStoreNo());
            crossDockOrderType.setCatalogGroupNumber(crossdockOrderHeaderEntity.getCrossdockCatalogGroupByCrossdockCatalogGroupNo().getCrossdockCatalogGroupNo());

            SourcingFacilityType originFacilityType = new SourcingFacilityType();
            originFacilityType.setSourceID(crossdockOrderHeaderEntity.getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityNo());
            originFacilityType.setSourceName(crossdockOrderHeaderEntity.getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityNme());
            crossDockOrderType.setOriginSourcingFacility(originFacilityType);
            SourcingFacilityType crossDockFacilityType = new SourcingFacilityType();
            crossDockFacilityType.setSourceID(crossdockOrderHeaderEntity.getSourcingFacilityByCrossdockSourcingFacilityId().getSourcingFacilityNo());
            crossDockFacilityType.setSourceName(crossdockOrderHeaderEntity.getSourcingFacilityByCrossdockSourcingFacilityId().getSourcingFacilityNme());
            crossDockOrderType.setCrossDockingFacility(crossDockFacilityType);

            MeasurementType cube = new MeasurementType();
            cube.setValue(crossdockOrderHeaderEntity.getGrossCubeAmt().floatValue());
            cube.setUnitOfMeasure("CF");
            crossDockOrderType.setCube(cube);
            MeasurementType weight = new MeasurementType();
            weight.setValue(crossdockOrderHeaderEntity.getNetWeightAmt().floatValue());
            weight.setUnitOfMeasure("LB");
            crossDockOrderType.setWeight(weight);

            RouteCloseType routeCloseType = new RouteCloseType();
            routeCloseType.setRouteCloseFacility(originFacilityType);
            if (crossdockOrderHeaderEntity.getOriginOrderCompleteTs() != null) {
                routeCloseType.setRouteCloseTimestamp(crossdockOrderHeaderEntity.getOriginOrderCompleteTs());
            } else {
                routeCloseType.setRouteCloseTimestamp(new Date());
            }

            routeCloseType.setRouteId(crossdockRoute.getRouteNme());
            routeCloseType.setTrailerNumber(crossdockRoute.getCrossdockTrailerNo());
            routeCloseType.setCarrierCode(crossdockRoute.getCrossdockCarrierCd());
            routeCloseType.setTrailerType(crossdockRoute.getCrossdockTrailerTypeCd());
            crossDockOrderType.setRouteClose(routeCloseType);

            LoadsType loadsType = new LoadsType();
            crossdockOrderHeaderEntity.getCrossdockLoadsByCrossdockOrderId().forEach(pallet -> {
                LoadType loadType = new LoadType();
                loadType.setId(String.valueOf(pallet.getLoadNo()));
                MeasurementType palletCube = new MeasurementType();
                palletCube.setUnitOfMeasure("CF");
                palletCube.setValue(pallet.getGrossCubeAmt().floatValue());
                loadType.setCube(palletCube);

                MeasurementType palletWeight = new MeasurementType();
                palletWeight.setUnitOfMeasure("LB");
                palletWeight.setValue(pallet.getNetWeightAmt().floatValue());
                loadType.setWeight(palletWeight);

                QuantityType quantityType = new QuantityType();
                quantityType.setCases(BigInteger.valueOf(pallet.getLoadCaseQty()));
                quantityType.setUnits(BigInteger.valueOf(pallet.getLoadCaseQty()));
                loadType.setQuantity(quantityType);

                loadType.setHazmatCode("   ");
                loadType.setPosition("   ");
                loadType.setTopLoad(FlagType.N);
                loadsType.getLoad().add(loadType);
            });

            crossDockOrderType.getRouteClose().setLoads(loadsType);
            //Checks Order for DSD if true do not add to list to send to WIN
            if(!crossdockOrderHeaderEntity.isDsdOrderType()) {
                crossDockOrderTypeList.add(crossDockOrderType);
            }
        });
        return crossDockOrderTypeList;
    }

    private SyncCrossDockOrderType applicationAreaSetup(
            List<CrossDockOrderType> crossDockOrderTypes, String referenceId) {

        logger.info("Outbound ASN Order Message to Integration Services");

        SyncCrossDockOrderType syncCrossDockOrder = new SyncCrossDockOrderType();
        SyncCrossDockOrderDataAreaType dataArea = new SyncCrossDockOrderDataAreaType();
        dataArea.getCrossDockOrder().addAll(crossDockOrderTypes);
        syncCrossDockOrder.setDataArea(dataArea);

        ApplicationAreaType applicationArea = new ApplicationAreaType();
        SenderType sender = new SenderType();
        sender.setLogicalID("Supply Chain");
        sender.setComponentID("XDOC");
        sender.setTaskID("SyncCrossDockOrder");
        sender.setReferenceID(referenceId);
        applicationArea.setSender(sender);
        Date creationDateTime = new Date(System.currentTimeMillis());
        applicationArea.setCreationDateTime(creationDateTime);

        SyncType sync = new SyncType();
        ActionExpressionType actionExpression = new ActionExpressionType();
        actionExpression.setActionCode("Sync");
        ActionCriteriaType actionCriteria = new ActionCriteriaType();
        actionCriteria.getActionExpression().add(actionExpression);
        sync.getActionCriteria().add(actionCriteria);
        dataArea.setSync(sync);

        syncCrossDockOrder.setVersionID("1.0");

        syncCrossDockOrder.setSystemEnvironmentCode(systemEnvironmentCode);
        syncCrossDockOrder.setApplicationArea(applicationArea);
        return syncCrossDockOrder;
    }
}
