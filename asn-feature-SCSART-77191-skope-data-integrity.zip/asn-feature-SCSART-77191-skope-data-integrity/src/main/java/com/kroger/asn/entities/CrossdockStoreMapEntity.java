package com.kroger.asn.entities;

import javax.persistence.*;

@Entity
@Table(name = "CROSSDOCK_STORE_MAP")
public class CrossdockStoreMapEntity {
    private int crossdockStoreMapId;
    private Short adjustDeliveryDayNo;
    private CrossdockMapEntity crossdockMapByCrossdockMapId;
    private StoreEntity storeByStoreId;

    @Id
    @Column(name = "CROSSDOCK_STORE_MAP_ID", nullable = false)
    public int getCrossdockStoreMapId() {
        return crossdockStoreMapId;
    }

    public void setCrossdockStoreMapId(int crossdockStoreMapId) {
        this.crossdockStoreMapId = crossdockStoreMapId;
    }

    @Override
    public String toString() {
        return "CrossdockStoreMapEntity{" +
                "crossdockStoreMapId=" + crossdockStoreMapId +
                ", adjustDeliveryDayNo=" + adjustDeliveryDayNo +
                '}';
    }

    @Column(name = "ADJUST_DELIVERY_DAY_NO")
    public Short getAdjustDeliveryDayNo() {
        return adjustDeliveryDayNo;
    }

    public void setAdjustDeliveryDayNo(Short adjustDeliveryDayNo) {
        this.adjustDeliveryDayNo = adjustDeliveryDayNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockStoreMapEntity that = (CrossdockStoreMapEntity) o;

        if (crossdockStoreMapId != that.crossdockStoreMapId) return false;
        if (adjustDeliveryDayNo != null ? !adjustDeliveryDayNo.equals(that.adjustDeliveryDayNo) : that.adjustDeliveryDayNo != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockStoreMapId;
        result = 31 * result + (adjustDeliveryDayNo != null ? adjustDeliveryDayNo.hashCode() : 0);
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_MAP_ID", referencedColumnName = "CROSSDOCK_MAP_ID", nullable = false)
    public CrossdockMapEntity getCrossdockMapByCrossdockMapId() {
        return crossdockMapByCrossdockMapId;
    }

    public void setCrossdockMapByCrossdockMapId(CrossdockMapEntity crossdockMapByCrossdockMapId) {
        this.crossdockMapByCrossdockMapId = crossdockMapByCrossdockMapId;
    }

    @ManyToOne
    @JoinColumn(name = "STORE_ID", referencedColumnName = "STORE_ID", nullable = false)
    public StoreEntity getStoreByStoreId() {
        return storeByStoreId;
    }

    public void setStoreByStoreId(StoreEntity storeByStoreId) {
        this.storeByStoreId = storeByStoreId;
    }

}
