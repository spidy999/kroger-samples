package com.kroger.asn.entities;

import com.kroger.asn.util.CommonDefines;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Table(name = "CROSSDOCK_ORDER_HEADER")
public class CrossdockOrderHeaderEntity {

    private static final String DSD_ORDER_TYPE = "D";
    private static final String CROSS_DOCK_ORDER_TYPE = "C";
    private static final String ERRIU = "ERRIU";

    private int crossdockOrderId;
    private String orderBillingDivisionNo;
    private String crossdockOrderNo;
    private BigDecimal grossCubeAmt;
    private String grossCubeUomVlu;
    private BigDecimal netWeightAmt;


    private String netWeightUomVlu;
    private int crossdockOrderQty;
    private Timestamp crossdockOrderReleaseTs;
    private Date crossdockOrderDeliveryDt;
    private String deliveryTypeCd;
    private Timestamp originOrderCompleteTs;
    private Timestamp crossdockOrderCompleteTs;
    private Timestamp crossdockOrderCancelTs;
    private String netWeightAmtChangedFlg;
    private String grossCubeAmtChangedFlg;
    private Timestamp rowCreateTs;
    private Timestamp rowUpdateTs;
    private String rowCreateId;
    private String rowUpdateId;
    private Integer originRouteId;
    private Integer crossdockRouteId;
    private Collection<CrossdockLoadEntity> crossdockLoadsByCrossdockOrderId;
    private OrderManagementDivisionEntity orderManagementDivisionByOrderManagementDivisionId;
    private SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId;
    private SourcingFacilityEntity sourcingFacilityByCrossdockSourcingFacilityId;
    private CrossdockCatalogGroupEntity crossdockCatalogGroupByCrossdockCatalogGroupNo;
    private StoreEntity storeByStoreId;
    private CrossdockMapEntity crossdockMapByCrossdockMapId;
    private Collection<ReleaseOrderGroupXrefEntity> releaseOrderGroupXrefsByCrossdockOrderId;
    private Collection<SkopeCrossdockOrderXrefEntity> skopeCrossdockOrderXrefsByCrossdockOrderId;

    public CrossdockOrderHeaderEntity() {
    }

    public CrossdockOrderHeaderEntity(SkopeOrderEntity skopeOrder, CrossdockRouteEntity originRoute) {
        //Order number will be updated after we get the id of the order header so we can generate the order number
        this.crossdockOrderNo = ERRIU;
        this.orderBillingDivisionNo = skopeOrder.getOrderBillingDivisionNo().toUpperCase();
        this.orderManagementDivisionByOrderManagementDivisionId = skopeOrder.getOrderManagementDivisionByOrderManagementDivisionId();
        this.storeByStoreId = skopeOrder.getStoreByStoreId();
        this.crossdockCatalogGroupByCrossdockCatalogGroupNo = skopeOrder.getCrossdockCatalogGroupMapEntity().getCrossdockCatalogGroupByCrossdockCatalogGroupNo();
        this.sourcingFacilityByOriginSourcingFacilityId = skopeOrder.getSourcingFacilityBySourcingFacilityId();
        this.sourcingFacilityByCrossdockSourcingFacilityId = skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getSourcingFacilityByCrossdockSourcingFacilityId();
        this.netWeightAmt = BigDecimal.valueOf(0);
        this.crossdockOrderQty = 0;
        this.grossCubeAmt = BigDecimal.valueOf(0);
        this.crossdockOrderDeliveryDt = skopeOrder.getSkopeOrderDeliveryDt();
        this.crossdockMapByCrossdockMapId = skopeOrder.getCrossdockStoreMap().getCrossdockMapByCrossdockMapId();
        this.deliveryTypeCd = CROSS_DOCK_ORDER_TYPE.toUpperCase();
        this.rowCreateId = (CommonDefines.ASN_ID_PREFIX.toString() + sourcingFacilityByCrossdockSourcingFacilityId.getSourcingFacilityNo()).toUpperCase();
        this.originRouteId = originRoute.getRouteId();
        this.netWeightAmtChangedFlg = CommonDefines.NO.toString().toUpperCase();
        this.grossCubeAmtChangedFlg = CommonDefines.NO.toString().toUpperCase();
        this.rowCreateTs = new Timestamp(System.currentTimeMillis());
        this.rowUpdateTs = new Timestamp(System.currentTimeMillis());
    }

    //Only use this to copy the header (essentially a clone but nulled some fields)
    public CrossdockOrderHeaderEntity(CrossdockOrderHeaderEntity originalHeader) {
        this.orderBillingDivisionNo = originalHeader.getOrderBillingDivisionNo();
        this.crossdockOrderNo = null;
        this.grossCubeAmt = BigDecimal.valueOf(0);
        this.grossCubeUomVlu = originalHeader.getGrossCubeUomVlu();
        this.netWeightAmt = BigDecimal.valueOf(0);
        this.netWeightUomVlu = originalHeader.getNetWeightUomVlu();
        this.crossdockOrderQty = 0;
        //TODO: Use case 4.2.2 says we should null order release ts...verify if this is intended or if we should carry the value over since the order was already released
        this.crossdockOrderReleaseTs = originalHeader.getCrossdockOrderReleaseTs();
        this.crossdockOrderDeliveryDt = originalHeader.getCrossdockOrderDeliveryDt();
        this.deliveryTypeCd = originalHeader.getDeliveryTypeCd();
        this.originOrderCompleteTs = null;
        this.crossdockOrderCompleteTs = originalHeader.getCrossdockOrderCompleteTs();
        this.crossdockOrderCancelTs = originalHeader.getCrossdockOrderCancelTs();
        this.netWeightAmtChangedFlg = originalHeader.getNetWeightAmtChangedFlg();
        this.grossCubeAmtChangedFlg = originalHeader.getGrossCubeAmtChangedFlg();
        this.rowCreateTs = originalHeader.getRowCreateTs();
        this.rowUpdateTs = originalHeader.getRowUpdateTs();
        this.rowCreateId = originalHeader.getRowCreateId();
        this.rowUpdateId = originalHeader.getRowUpdateId();
        this.originRouteId = null;
        this.crossdockRouteId = null;
        this.crossdockLoadsByCrossdockOrderId = new ArrayList<>();
        this.crossdockLoadsByCrossdockOrderId.addAll(originalHeader.getCrossdockLoadsByCrossdockOrderId());
        this.orderManagementDivisionByOrderManagementDivisionId = originalHeader.getOrderManagementDivisionByOrderManagementDivisionId();
        this.sourcingFacilityByOriginSourcingFacilityId = originalHeader.getSourcingFacilityByOriginSourcingFacilityId();
        this.sourcingFacilityByCrossdockSourcingFacilityId = originalHeader.getSourcingFacilityByCrossdockSourcingFacilityId();
        this.crossdockCatalogGroupByCrossdockCatalogGroupNo = originalHeader.getCrossdockCatalogGroupByCrossdockCatalogGroupNo();
        this.storeByStoreId = originalHeader.getStoreByStoreId();
        this.crossdockMapByCrossdockMapId = originalHeader.getCrossdockMapByCrossdockMapId();
        this.releaseOrderGroupXrefsByCrossdockOrderId = new ArrayList<>();
        this.releaseOrderGroupXrefsByCrossdockOrderId.addAll(originalHeader.getReleaseOrderGroupXrefsByCrossdockOrderId());
        this.skopeCrossdockOrderXrefsByCrossdockOrderId = new ArrayList<>();
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CROSSDOCK_ORDER_ID", nullable = false)
    public int getCrossdockOrderId() {
        return crossdockOrderId;
    }

    public void setCrossdockOrderId(int crossdockOrderId) {
        this.crossdockOrderId = crossdockOrderId;
    }


    @Column(name = "ORDER_BILLING_DIVISION_NO", nullable = false, length = 3)
    public String getOrderBillingDivisionNo() {
        return orderBillingDivisionNo;
    }

    public void setOrderBillingDivisionNo(String orderBillingDivisionNo) {
        this.orderBillingDivisionNo = orderBillingDivisionNo;
    }


    @Column(name = "CROSSDOCK_ORDER_NO", length = 5)
    public String getCrossdockOrderNo() {
        return crossdockOrderNo;
    }

    public void setCrossdockOrderNo(String crossdockOrderNo) {
        this.crossdockOrderNo = crossdockOrderNo;
    }


    @Column(name = "GROSS_CUBE_AMT", nullable = false, precision = 2)
    public BigDecimal getGrossCubeAmt() {
        return grossCubeAmt;
    }

    public void setGrossCubeAmt(BigDecimal grossCubeAmt) {
        this.grossCubeAmt = grossCubeAmt;
    }


    @Column(name = "GROSS_CUBE_UOM_VLU", length = 30)
    public String getGrossCubeUomVlu() {
        return grossCubeUomVlu;
    }

    public void setGrossCubeUomVlu(String grossCubeUomVlu) {
        this.grossCubeUomVlu = grossCubeUomVlu;
    }


    @Column(name = "NET_WEIGHT_AMT", nullable = false, precision = 2)
    public BigDecimal getNetWeightAmt() {
        return netWeightAmt;
    }

    public void setNetWeightAmt(BigDecimal netWeightAmt) {
        this.netWeightAmt = netWeightAmt;
    }

    @Column(name = "NET_WEIGHT_UOM_VLU", length = 30)
    public String getNetWeightUomVlu() {
        return netWeightUomVlu;
    }

    public void setNetWeightUomVlu(String netWeightUomVlu) {
        this.netWeightUomVlu = netWeightUomVlu;
    }


    @Column(name = "CROSSDOCK_ORDER_QTY", nullable = false)
    public int getCrossdockOrderQty() {
        return crossdockOrderQty;
    }

    public void setCrossdockOrderQty(int crossdockOrderQty) {
        this.crossdockOrderQty = crossdockOrderQty;
    }


    @Column(name = "CROSSDOCK_ORDER_RELEASE_TS")
    public Timestamp getCrossdockOrderReleaseTs() {
        return crossdockOrderReleaseTs;
    }

    public void setCrossdockOrderReleaseTs(Timestamp crossdockOrderReleaseTs) {
        this.crossdockOrderReleaseTs = crossdockOrderReleaseTs;
    }


    @Column(name = "CROSSDOCK_ORDER_DELIVERY_DT")
    public Date getCrossdockOrderDeliveryDt() {
        return crossdockOrderDeliveryDt;
    }

    public void setCrossdockOrderDeliveryDt(Date crossdockOrderDeliveryDt) {
        this.crossdockOrderDeliveryDt = crossdockOrderDeliveryDt;
    }


    @Column(name = "DELIVERY_TYPE_CD", length = 1)
    public String getDeliveryTypeCd() {
        return deliveryTypeCd;
    }

    public void setDeliveryTypeCd(String deliveryTypeCd) {
        this.deliveryTypeCd = deliveryTypeCd;
    }


    @Column(name = "ORIGIN_ORDER_COMPLETE_TS")
    public Timestamp getOriginOrderCompleteTs() {
        return originOrderCompleteTs;
    }

    public void setOriginOrderCompleteTs(Timestamp originOrderCompleteTs) {
        this.originOrderCompleteTs = originOrderCompleteTs;
    }


    @Column(name = "CROSSDOCK_ORDER_COMPLETE_TS")
    public Timestamp getCrossdockOrderCompleteTs() {
        return crossdockOrderCompleteTs;
    }

    public void setCrossdockOrderCompleteTs(Timestamp crossdockOrderCompleteTs) {
        this.crossdockOrderCompleteTs = crossdockOrderCompleteTs;
    }


    @Column(name = "CROSSDOCK_ORDER_CANCEL_TS")
    public Timestamp getCrossdockOrderCancelTs() {
        return crossdockOrderCancelTs;
    }

    public void setCrossdockOrderCancelTs(Timestamp crossdockOrderCancelTs) {
        this.crossdockOrderCancelTs = crossdockOrderCancelTs;
    }


    @Column(name = "NET_WEIGHT_AMT_CHANGED_FLG", nullable = false, length = 1)
    public String getNetWeightAmtChangedFlg() {
        return netWeightAmtChangedFlg;
    }

    public void setNetWeightAmtChangedFlg(String netWeightAmtChangedFlg) {
        this.netWeightAmtChangedFlg = netWeightAmtChangedFlg;
    }


    @Column(name = "GROSS_CUBE_AMT_CHANGED_FLG", nullable = false, length = 1)
    public String getGrossCubeAmtChangedFlg() {
        return grossCubeAmtChangedFlg;
    }

    public void setGrossCubeAmtChangedFlg(String grossCubeAmtChangedFlg) {
        this.grossCubeAmtChangedFlg = grossCubeAmtChangedFlg;
    }


    @Column(name = "ROW_CREATE_TS", nullable = false)
    public Timestamp getRowCreateTs() {
        return rowCreateTs;
    }

    public void setRowCreateTs(Timestamp rowCreateTs) {
        this.rowCreateTs = rowCreateTs;
    }


    @Column(name = "ROW_UPDATE_TS", nullable = false)
    public Timestamp getRowUpdateTs() {
        return rowUpdateTs;
    }

    public void setRowUpdateTs(Timestamp rowUpdateTs) {
        this.rowUpdateTs = rowUpdateTs;
    }


    @Column(name = "ROW_CREATE_ID", length = 8)
    public String getRowCreateId() {
        return rowCreateId;
    }

    public void setRowCreateId(String rowCreateId) {
        this.rowCreateId = rowCreateId;
    }


    @Column(name = "ROW_UPDATE_ID", length = 8)
    public String getRowUpdateId() {
        return rowUpdateId;
    }

    public void setRowUpdateId(String rowUpdateId) {
        this.rowUpdateId = rowUpdateId;
    }


    @Column(name = "ORIGIN_ROUTE_ID")
    public Integer getOriginRouteId() {
        return originRouteId;
    }

    public void setOriginRouteId(Integer originRouteId) {
        this.originRouteId = originRouteId;
    }


    @Column(name = "CROSSDOCK_ROUTE_ID")
    public Integer getCrossdockRouteId() {
        return crossdockRouteId;
    }

    public void setCrossdockRouteId(Integer crossdockRouteId) {
        this.crossdockRouteId = crossdockRouteId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockOrderHeaderEntity that = (CrossdockOrderHeaderEntity) o;

        if (crossdockOrderId != that.crossdockOrderId) return false;
        if (crossdockOrderQty != that.crossdockOrderQty) return false;
        if (orderBillingDivisionNo != null ? !orderBillingDivisionNo.equals(that.orderBillingDivisionNo) : that.orderBillingDivisionNo != null)
            return false;
        if (crossdockOrderNo != null ? !crossdockOrderNo.equals(that.crossdockOrderNo) : that.crossdockOrderNo != null)
            return false;
        if (grossCubeAmt != null ? !grossCubeAmt.equals(that.grossCubeAmt) : that.grossCubeAmt != null) return false;
        if (grossCubeUomVlu != null ? !grossCubeUomVlu.equals(that.grossCubeUomVlu) : that.grossCubeUomVlu != null)
            return false;
        if (netWeightAmt != null ? !netWeightAmt.equals(that.netWeightAmt) : that.netWeightAmt != null) return false;
        if (netWeightUomVlu != null ? !netWeightUomVlu.equals(that.netWeightUomVlu) : that.netWeightUomVlu != null)
            return false;
        if (crossdockOrderReleaseTs != null ? !crossdockOrderReleaseTs.equals(that.crossdockOrderReleaseTs) : that.crossdockOrderReleaseTs != null)
            return false;
        if (crossdockOrderDeliveryDt != null ? !crossdockOrderDeliveryDt.equals(that.crossdockOrderDeliveryDt) : that.crossdockOrderDeliveryDt != null)
            return false;
        if (deliveryTypeCd != null ? !deliveryTypeCd.equals(that.deliveryTypeCd) : that.deliveryTypeCd != null)
            return false;
        if (originOrderCompleteTs != null ? !originOrderCompleteTs.equals(that.originOrderCompleteTs) : that.originOrderCompleteTs != null)
            return false;
        if (crossdockOrderCompleteTs != null ? !crossdockOrderCompleteTs.equals(that.crossdockOrderCompleteTs) : that.crossdockOrderCompleteTs != null)
            return false;
        if (crossdockOrderCancelTs != null ? !crossdockOrderCancelTs.equals(that.crossdockOrderCancelTs) : that.crossdockOrderCancelTs != null)
            return false;
        if (netWeightAmtChangedFlg != null ? !netWeightAmtChangedFlg.equals(that.netWeightAmtChangedFlg) : that.netWeightAmtChangedFlg != null)
            return false;
        if (grossCubeAmtChangedFlg != null ? !grossCubeAmtChangedFlg.equals(that.grossCubeAmtChangedFlg) : that.grossCubeAmtChangedFlg != null)
            return false;
        if (rowCreateTs != null ? !rowCreateTs.equals(that.rowCreateTs) : that.rowCreateTs != null) return false;
        if (rowUpdateTs != null ? !rowUpdateTs.equals(that.rowUpdateTs) : that.rowUpdateTs != null) return false;
        if (rowCreateId != null ? !rowCreateId.equals(that.rowCreateId) : that.rowCreateId != null) return false;
        if (rowUpdateId != null ? !rowUpdateId.equals(that.rowUpdateId) : that.rowUpdateId != null) return false;
        if (originRouteId != null ? !originRouteId.equals(that.originRouteId) : that.originRouteId != null)
            return false;
        if (crossdockRouteId != null ? !crossdockRouteId.equals(that.crossdockRouteId) : that.crossdockRouteId != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockOrderId;
        result = 31 * result + (orderBillingDivisionNo != null ? orderBillingDivisionNo.hashCode() : 0);
        result = 31 * result + (crossdockOrderNo != null ? crossdockOrderNo.hashCode() : 0);
        result = 31 * result + (grossCubeAmt != null ? grossCubeAmt.hashCode() : 0);
        result = 31 * result + (grossCubeUomVlu != null ? grossCubeUomVlu.hashCode() : 0);
        result = 31 * result + (netWeightAmt != null ? netWeightAmt.hashCode() : 0);
        result = 31 * result + (netWeightUomVlu != null ? netWeightUomVlu.hashCode() : 0);
        result = 31 * result + crossdockOrderQty;
        result = 31 * result + (crossdockOrderReleaseTs != null ? crossdockOrderReleaseTs.hashCode() : 0);
        result = 31 * result + (crossdockOrderDeliveryDt != null ? crossdockOrderDeliveryDt.hashCode() : 0);
        result = 31 * result + (deliveryTypeCd != null ? deliveryTypeCd.hashCode() : 0);
        result = 31 * result + (originOrderCompleteTs != null ? originOrderCompleteTs.hashCode() : 0);
        result = 31 * result + (crossdockOrderCompleteTs != null ? crossdockOrderCompleteTs.hashCode() : 0);
        result = 31 * result + (crossdockOrderCancelTs != null ? crossdockOrderCancelTs.hashCode() : 0);
        result = 31 * result + (netWeightAmtChangedFlg != null ? netWeightAmtChangedFlg.hashCode() : 0);
        result = 31 * result + (grossCubeAmtChangedFlg != null ? grossCubeAmtChangedFlg.hashCode() : 0);
        result = 31 * result + (rowCreateTs != null ? rowCreateTs.hashCode() : 0);
        result = 31 * result + (rowUpdateTs != null ? rowUpdateTs.hashCode() : 0);
        result = 31 * result + (rowCreateId != null ? rowCreateId.hashCode() : 0);
        result = 31 * result + (rowUpdateId != null ? rowUpdateId.hashCode() : 0);
        result = 31 * result + (originRouteId != null ? originRouteId.hashCode() : 0);
        result = 31 * result + (crossdockRouteId != null ? crossdockRouteId.hashCode() : 0);
        return result;
    }

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "crossdockOrderHeaderByCrossdockOrderId")
    public Collection<CrossdockLoadEntity> getCrossdockLoadsByCrossdockOrderId() {
        return crossdockLoadsByCrossdockOrderId;
    }

    public void setCrossdockLoadsByCrossdockOrderId(Collection<CrossdockLoadEntity> crossdockLoadsByCrossdockOrderId) {
        this.crossdockLoadsByCrossdockOrderId = crossdockLoadsByCrossdockOrderId;
    }

    @ManyToOne
    @JoinColumn(name = "ORDER_MANAGEMENT_DIVISION_ID", referencedColumnName = "ORDER_MANAGEMENT_DIVISION_ID")
    public OrderManagementDivisionEntity getOrderManagementDivisionByOrderManagementDivisionId() {
        return orderManagementDivisionByOrderManagementDivisionId;
    }

    public void setOrderManagementDivisionByOrderManagementDivisionId(OrderManagementDivisionEntity orderManagementDivisionByOrderManagementDivisionId) {
        this.orderManagementDivisionByOrderManagementDivisionId = orderManagementDivisionByOrderManagementDivisionId;
    }

    @ManyToOne
    @JoinColumn(name = "ORIGIN_SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID")
    public SourcingFacilityEntity getSourcingFacilityByOriginSourcingFacilityId() {
        return sourcingFacilityByOriginSourcingFacilityId;
    }

    public void setSourcingFacilityByOriginSourcingFacilityId(SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId) {
        this.sourcingFacilityByOriginSourcingFacilityId = sourcingFacilityByOriginSourcingFacilityId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID")
    public SourcingFacilityEntity getSourcingFacilityByCrossdockSourcingFacilityId() {
        return sourcingFacilityByCrossdockSourcingFacilityId;
    }

    public void setSourcingFacilityByCrossdockSourcingFacilityId(SourcingFacilityEntity sourcingFacilityByCrossdockSourcingFacilityId) {
        this.sourcingFacilityByCrossdockSourcingFacilityId = sourcingFacilityByCrossdockSourcingFacilityId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_CATALOG_GROUP_NO", referencedColumnName = "CROSSDOCK_CATALOG_GROUP_NO", nullable = false)
    public CrossdockCatalogGroupEntity getCrossdockCatalogGroupByCrossdockCatalogGroupNo() {
        return crossdockCatalogGroupByCrossdockCatalogGroupNo;
    }

    public void setCrossdockCatalogGroupByCrossdockCatalogGroupNo(CrossdockCatalogGroupEntity crossdockCatalogGroupByCrossdockCatalogGroupNo) {
        this.crossdockCatalogGroupByCrossdockCatalogGroupNo = crossdockCatalogGroupByCrossdockCatalogGroupNo;
    }

    @ManyToOne
    @JoinColumn(name = "STORE_ID", referencedColumnName = "STORE_ID", nullable = false)
    public StoreEntity getStoreByStoreId() {
        return storeByStoreId;
    }

    public void setStoreByStoreId(StoreEntity storeByStoreId) {
        this.storeByStoreId = storeByStoreId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_MAP_ID", referencedColumnName = "CROSSDOCK_MAP_ID")
    public CrossdockMapEntity getCrossdockMapByCrossdockMapId() {
        return crossdockMapByCrossdockMapId;
    }

    public void setCrossdockMapByCrossdockMapId(CrossdockMapEntity crossdockMapByCrossdockMapId) {
        this.crossdockMapByCrossdockMapId = crossdockMapByCrossdockMapId;
    }

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "crossdockOrderHeaderByCrossdockOrderId")
    public Collection<ReleaseOrderGroupXrefEntity> getReleaseOrderGroupXrefsByCrossdockOrderId() {
        return releaseOrderGroupXrefsByCrossdockOrderId;
    }

    public void setReleaseOrderGroupXrefsByCrossdockOrderId(Collection<ReleaseOrderGroupXrefEntity> releaseOrderGroupXrefsByCrossdockOrderId) {
        this.releaseOrderGroupXrefsByCrossdockOrderId = releaseOrderGroupXrefsByCrossdockOrderId;
    }

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(mappedBy = "crossdockOrderHeaderByCrossdockOrderId")
    public Collection<SkopeCrossdockOrderXrefEntity> getSkopeCrossdockOrderXrefsByCrossdockOrderId() {
        return skopeCrossdockOrderXrefsByCrossdockOrderId;
    }

    public void setSkopeCrossdockOrderXrefsByCrossdockOrderId(Collection<SkopeCrossdockOrderXrefEntity> skopeCrossdockOrderXrefsByCrossdockOrderId) {
        this.skopeCrossdockOrderXrefsByCrossdockOrderId = skopeCrossdockOrderXrefsByCrossdockOrderId;
    }

    @Transient
    public boolean isCancelled(){
        return this.crossdockOrderCancelTs != null;
    }

    @Transient
    public boolean isOriginComplete(){
        return this.originOrderCompleteTs != null;
    }

    @Transient
    public boolean isDsdOrderType(){
        return this.deliveryTypeCd.equalsIgnoreCase(DSD_ORDER_TYPE);
    }

    @Transient
    public boolean isCrossDockOrderType(){
        return this.deliveryTypeCd.equalsIgnoreCase(CROSS_DOCK_ORDER_TYPE);
    }

    @Override
    public String toString() {
        return "CrossdockOrderHeaderEntity{" +
                "crossdockOrderId=" + crossdockOrderId +
                ", orderBillingDivisionNo='" + orderBillingDivisionNo + '\'' +
                ", crossdockOrderNo='" + crossdockOrderNo + '\'' +
                ", grossCubeAmt=" + grossCubeAmt +
                ", grossCubeUomVlu='" + grossCubeUomVlu + '\'' +
                ", netWeightAmt=" + netWeightAmt +
                ", netWeightUomVlu='" + netWeightUomVlu + '\'' +
                ", crossdockOrderQty=" + crossdockOrderQty +
                ", crossdockOrderReleaseTs=" + crossdockOrderReleaseTs +
                ", crossdockOrderDeliveryDt=" + crossdockOrderDeliveryDt +
                ", deliveryTypeCd='" + deliveryTypeCd + '\'' +
                ", originOrderCompleteTs=" + originOrderCompleteTs +
                ", crossdockOrderCompleteTs=" + crossdockOrderCompleteTs +
                ", crossdockOrderCancelTs=" + crossdockOrderCancelTs +
                ", netWeightAmtChangedFlg='" + netWeightAmtChangedFlg + '\'' +
                ", grossCubeAmtChangedFlg='" + grossCubeAmtChangedFlg + '\'' +
                ", rowCreateTs=" + rowCreateTs +
                ", rowUpdateTs=" + rowUpdateTs +
                ", rowCreateId='" + rowCreateId + '\'' +
                ", rowUpdateId='" + rowUpdateId + '\'' +
                ", originRouteId=" + originRouteId +
                ", crossdockRouteId=" + crossdockRouteId +
                '}';
    }
}
