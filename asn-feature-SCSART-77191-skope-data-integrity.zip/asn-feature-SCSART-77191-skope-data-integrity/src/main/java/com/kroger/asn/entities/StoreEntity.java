package com.kroger.asn.entities;

import javax.persistence.*;
import java.util.Collection;

@Entity
@Table(name = "STORE")
public class StoreEntity {
    private int storeId;
    private int orderManagementDivisionId;
    private String storeNo;
    private String storeNme;
    private String managementZoneCd;
    private Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByStoreId;
    private Collection<CrossdockStoreMapEntity> crossdockStoreMapsByStoreId;
    private Collection<SkopeOrderEntity> skopeOrdersByStoreId;

    @Override
    public String toString() {
        return "StoreEntity{" +
                "storeId=" + storeId +
                ", orderManagementDivisionId=" + orderManagementDivisionId +
                ", storeNo='" + storeNo + '\'' +
                ", storeNme='" + storeNme + '\'' +
                ", managementZoneCd='" + managementZoneCd + '\'' +
                '}';
    }

    @Id
    @Column(name = "STORE_ID", nullable = false)
    public int getStoreId() {
        return storeId;
    }

    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    @Column(name = "ORDER_MANAGEMENT_DIVISION_ID", nullable = false, length = 10)
    public int getOrderManagementDivisionId() {
        return orderManagementDivisionId;
    }

    public void setOrderManagementDivisionId(int orderManagementDivisionId) {
        this.orderManagementDivisionId = orderManagementDivisionId;
    }

    @Column(name = "STORE_NO", nullable = false, length = 5)
    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }


    @Column(name = "STORE_NME", nullable = false, length = 20)
    public String getStoreNme() {
        return storeNme;
    }

    public void setStoreNme(String storeNme) {
        this.storeNme = storeNme;
    }


    @Column(name = "MANAGEMENT_ZONE_CD",length = 2)
    public String getManagementZoneCd() {
        return managementZoneCd;
    }

    public void setManagementZoneCd(String managementZoneCd) {
        this.managementZoneCd = managementZoneCd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StoreEntity that = (StoreEntity) o;

        if (storeId != that.storeId) return false;
        if (storeNo != null ? !storeNo.equals(that.storeNo) : that.storeNo != null) return false;
        if (storeNme != null ? !storeNme.equals(that.storeNme) : that.storeNme != null) return false;
        if (managementZoneCd != null ? !managementZoneCd.equals(that.managementZoneCd) : that.managementZoneCd != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = storeId;
        result = 31 * result + (storeNo != null ? storeNo.hashCode() : 0);
        result = 31 * result + (storeNme != null ? storeNme.hashCode() : 0);
        result = 31 * result + (managementZoneCd != null ? managementZoneCd.hashCode() : 0);
        return result;
    }

    @OneToMany(mappedBy = "storeByStoreId")
    public Collection<CrossdockOrderHeaderEntity> getCrossdockOrderHeadersByStoreId() {
        return crossdockOrderHeadersByStoreId;
    }

    public void setCrossdockOrderHeadersByStoreId(Collection<CrossdockOrderHeaderEntity> crossdockOrderHeadersByStoreId) {
        this.crossdockOrderHeadersByStoreId = crossdockOrderHeadersByStoreId;
    }

    @OneToMany(mappedBy = "storeByStoreId")
    public Collection<CrossdockStoreMapEntity> getCrossdockStoreMapsByStoreId() {
        return crossdockStoreMapsByStoreId;
    }

    public void setCrossdockStoreMapsByStoreId(Collection<CrossdockStoreMapEntity> crossdockStoreMapsByStoreId) {
        this.crossdockStoreMapsByStoreId = crossdockStoreMapsByStoreId;
    }

    @OneToMany(mappedBy = "storeByStoreId")
    public Collection<SkopeOrderEntity> getSkopeOrdersByStoreId() {
        return skopeOrdersByStoreId;
    }

    public void setSkopeOrdersByStoreId(Collection<SkopeOrderEntity> skopeOrdersByStoreId) {
        this.skopeOrdersByStoreId = skopeOrdersByStoreId;
    }

}
