package com.kroger.asn.entities;

import javax.persistence.*;

@Entity
@Table(name = "CROSSDOCK_STORE_SCHEDULE")
public class CrossdockStoreScheduleEntity {
    private long crossdockStoreScheduleId;
    private int crossdockStoreMapId;
    private short scheduleDayNo;
    private String scheduleFlag;

    @Id
    @Column(name = "CROSSDOCK_STORE_SCHEDULE_ID", nullable = false)
    public long getCrossdockStoreScheduleId() {
        return crossdockStoreScheduleId;
    }

    public void setCrossdockStoreScheduleId(long crossdockStoreScheduleId) {
        this.crossdockStoreScheduleId = crossdockStoreScheduleId;
    }

    @Column(name = "CROSSDOCK_STORE_MAP_ID", nullable = false)
    public int getCrossdockStoreMapId() {
        return crossdockStoreMapId;
    }

    public void setCrossdockStoreMapId(int crossdockStoreMapId) {
        this.crossdockStoreMapId = crossdockStoreMapId;
    }

    @Column(name = "SCHEDULE_DAY_NO", nullable = false)
    public short getScheduleDayNo() {
        return scheduleDayNo;
    }

    public void setScheduleDayNo(short scheduleDayNo) {
        this.scheduleDayNo = scheduleDayNo;
    }


    @Column(name = "SCHEDULE_FLAG", length = 1)
    public String getScheduleFlag() {
        return scheduleFlag;
    }

    public void setScheduleFlag(String scheduleFlag) {
        this.scheduleFlag = scheduleFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockStoreScheduleEntity that = (CrossdockStoreScheduleEntity) o;

        if (crossdockStoreScheduleId != that.crossdockStoreScheduleId) return false;
        if (scheduleDayNo != that.scheduleDayNo) return false;
        if (scheduleFlag != null ? !scheduleFlag.equals(that.scheduleFlag) : that.scheduleFlag != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (crossdockStoreScheduleId ^ (crossdockStoreScheduleId >>> 32));
        result = 31 * result + (int) scheduleDayNo;
        result = 31 * result + (scheduleFlag != null ? scheduleFlag.hashCode() : 0);
        return result;
    }


    @Override
    public String toString() {
        return "CrossdockStoreScheduleEntity{" +
                "crossdockStoreScheduleId=" + crossdockStoreScheduleId +
                ", scheduleDayNo=" + scheduleDayNo +
                ", scheduleFlag='" + scheduleFlag + '\'' +
                '}';
    }
}
