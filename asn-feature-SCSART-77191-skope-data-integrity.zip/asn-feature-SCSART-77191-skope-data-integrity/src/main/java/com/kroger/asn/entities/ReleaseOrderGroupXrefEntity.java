package com.kroger.asn.entities;

import javax.persistence.*;

@Entity
@Table(name = "RELEASE_ORDER_GROUP_XREF")
@IdClass(ReleaseOrderGroupXrefEntityPK.class)
public class ReleaseOrderGroupXrefEntity {
    private int releaseOrderGroupId;
    private int crossdockOrderId;
    private String serviceId;
    private ReleaseOrderGroupEntity releaseOrderGroupByReleaseOrderGroupId;
    private CrossdockOrderHeaderEntity crossdockOrderHeaderByCrossdockOrderId;

    @Id
    @Column(name = "RELEASE_ORDER_GROUP_ID", nullable = false)
    public int getReleaseOrderGroupId() {
        return releaseOrderGroupId;
    }

    public void setReleaseOrderGroupId(int releaseOrderGroupId) {
        this.releaseOrderGroupId = releaseOrderGroupId;
    }

    @Id
    @Column(name = "CROSSDOCK_ORDER_ID", nullable = false)
    public int getCrossdockOrderId() {
        return crossdockOrderId;
    }

    public void setCrossdockOrderId(int crossdockOrderId) {
        this.crossdockOrderId = crossdockOrderId;
    }

    @Override
    public String toString() {
        return "ReleaseOrderGroupXrefEntity{" +
                "releaseOrderGroupId=" + releaseOrderGroupId +
                ", crossdockOrderId=" + crossdockOrderId +
                ", serviceId='" + serviceId + '\'' +
                '}';
    }

    @Column(name = "SERVICE_ID", length = 50)
    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReleaseOrderGroupXrefEntity that = (ReleaseOrderGroupXrefEntity) o;

        if (releaseOrderGroupId != that.releaseOrderGroupId) return false;
        if (crossdockOrderId != that.crossdockOrderId) return false;
        if (serviceId != null ? !serviceId.equals(that.serviceId) : that.serviceId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = releaseOrderGroupId;
        result = 31 * result + crossdockOrderId;
        result = 31 * result + (serviceId != null ? serviceId.hashCode() : 0);
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "RELEASE_ORDER_GROUP_ID", referencedColumnName = "RELEASE_ORDER_GROUP_ID", nullable = false,insertable = false, updatable = false)
    public ReleaseOrderGroupEntity getReleaseOrderGroupByReleaseOrderGroupId() {
        return releaseOrderGroupByReleaseOrderGroupId;
    }

    public void setReleaseOrderGroupByReleaseOrderGroupId(ReleaseOrderGroupEntity releaseOrderGroupByReleaseOrderGroupId) {
        this.releaseOrderGroupByReleaseOrderGroupId = releaseOrderGroupByReleaseOrderGroupId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_ORDER_ID", referencedColumnName = "CROSSDOCK_ORDER_ID", nullable = false,insertable = false, updatable = false)
    public CrossdockOrderHeaderEntity getCrossdockOrderHeaderByCrossdockOrderId() {
        return crossdockOrderHeaderByCrossdockOrderId;
    }

    public void setCrossdockOrderHeaderByCrossdockOrderId(CrossdockOrderHeaderEntity crossdockOrderHeaderByCrossdockOrderId) {
        this.crossdockOrderHeaderByCrossdockOrderId = crossdockOrderHeaderByCrossdockOrderId;
    }

}
