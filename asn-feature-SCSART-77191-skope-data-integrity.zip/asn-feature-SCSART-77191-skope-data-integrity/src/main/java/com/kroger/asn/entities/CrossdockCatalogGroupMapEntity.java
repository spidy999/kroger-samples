package com.kroger.asn.entities;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Collection;

@Entity
@Table(name = "CROSSDOCK_CATALOG_GROUP_MAP")
public class CrossdockCatalogGroupMapEntity {

    private int crossdockCatalogGroupMapId;
    private String mapTypeCd;
    private Timestamp rowCreateTs;
    private Timestamp rowUpdateTs;
    private String rowCreateId;
    private String rowUpdateId;
    private SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId;
    private SourcingFacilityEntity sourcingFacilityByCrossdockSourcingFacilityId;
    private CatalogGroupEntity catalogGroupByOriginCatalogGroupId;
    private CrossdockCatalogGroupEntity crossdockCatalogGroupByCrossdockCatalogGroupNo;
    private Collection<CrossdockMapEntity> crossdockMapsByCrossdockCatalogGroupMapId;

    @Id
    @Column(name = "CROSSDOCK_CATALOG_GROUP_MAP_ID", nullable = false)
    public int getCrossdockCatalogGroupMapId() {
        return crossdockCatalogGroupMapId;
    }

    public void setCrossdockCatalogGroupMapId(int crossdockCatalogGroupMapId) {
        this.crossdockCatalogGroupMapId = crossdockCatalogGroupMapId;
    }


    @Column(name = "MAP_TYPE_CD", length = 1)
    public String getMapTypeCd() {
        return mapTypeCd;
    }

    public void setMapTypeCd(String mapTypeCd) {
        this.mapTypeCd = mapTypeCd;
    }


    @Column(name = "ROW_CREATE_TS", nullable = false)
    public Timestamp getRowCreateTs() {
        return rowCreateTs;
    }

    public void setRowCreateTs(Timestamp rowCreateTs) {
        this.rowCreateTs = rowCreateTs;
    }

    @Column(name = "ROW_UPDATE_TS", nullable = false)
    public Timestamp getRowUpdateTs() {
        return rowUpdateTs;
    }

    public void setRowUpdateTs(Timestamp rowUpdateTs) {
        this.rowUpdateTs = rowUpdateTs;
    }


    @Column(name = "ROW_CREATE_ID", length = 8)
    public String getRowCreateId() {
        return rowCreateId;
    }

    public void setRowCreateId(String rowCreateId) {
        this.rowCreateId = rowCreateId;
    }


    @Column(name = "ROW_UPDATE_ID", length = 8)
    public String getRowUpdateId() {
        return rowUpdateId;
    }

    public void setRowUpdateId(String rowUpdateId) {
        this.rowUpdateId = rowUpdateId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CrossdockCatalogGroupMapEntity that = (CrossdockCatalogGroupMapEntity) o;

        if (crossdockCatalogGroupMapId != that.crossdockCatalogGroupMapId) return false;
        if (mapTypeCd != null ? !mapTypeCd.equals(that.mapTypeCd) : that.mapTypeCd != null) return false;
        if (rowCreateTs != null ? !rowCreateTs.equals(that.rowCreateTs) : that.rowCreateTs != null) return false;
        if (rowUpdateTs != null ? !rowUpdateTs.equals(that.rowUpdateTs) : that.rowUpdateTs != null) return false;
        if (rowCreateId != null ? !rowCreateId.equals(that.rowCreateId) : that.rowCreateId != null) return false;
        if (rowUpdateId != null ? !rowUpdateId.equals(that.rowUpdateId) : that.rowUpdateId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = crossdockCatalogGroupMapId;
        result = 31 * result + (mapTypeCd != null ? mapTypeCd.hashCode() : 0);
        result = 31 * result + (rowCreateTs != null ? rowCreateTs.hashCode() : 0);
        result = 31 * result + (rowUpdateTs != null ? rowUpdateTs.hashCode() : 0);
        result = 31 * result + (rowCreateId != null ? rowCreateId.hashCode() : 0);
        result = 31 * result + (rowUpdateId != null ? rowUpdateId.hashCode() : 0);
        return result;
    }

    @ManyToOne
    @JoinColumn(name = "ORIGIN_SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID", nullable = false)
    public SourcingFacilityEntity getSourcingFacilityByOriginSourcingFacilityId() {
        return sourcingFacilityByOriginSourcingFacilityId;
    }

    public void setSourcingFacilityByOriginSourcingFacilityId(SourcingFacilityEntity sourcingFacilityByOriginSourcingFacilityId) {
        this.sourcingFacilityByOriginSourcingFacilityId = sourcingFacilityByOriginSourcingFacilityId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_SOURCING_FACILITY_ID", referencedColumnName = "SOURCING_FACILITY_ID", nullable = false)
    public SourcingFacilityEntity getSourcingFacilityByCrossdockSourcingFacilityId() {
        return sourcingFacilityByCrossdockSourcingFacilityId;
    }

    public void setSourcingFacilityByCrossdockSourcingFacilityId(SourcingFacilityEntity sourcingFacilityByCrossdockSourcingFacilityId) {
        this.sourcingFacilityByCrossdockSourcingFacilityId = sourcingFacilityByCrossdockSourcingFacilityId;
    }

    @ManyToOne
    @JoinColumn(name = "ORIGIN_CATALOG_GROUP_ID", referencedColumnName = "CATALOG_GROUP_ID", nullable = false)
    public CatalogGroupEntity getCatalogGroupByOriginCatalogGroupId() {
        return catalogGroupByOriginCatalogGroupId;
    }

    public void setCatalogGroupByOriginCatalogGroupId(CatalogGroupEntity catalogGroupByOriginCatalogGroupId) {
        this.catalogGroupByOriginCatalogGroupId = catalogGroupByOriginCatalogGroupId;
    }

    @ManyToOne
    @JoinColumn(name = "CROSSDOCK_CATALOG_GROUP_NO", referencedColumnName = "CROSSDOCK_CATALOG_GROUP_NO", nullable = false)
    public CrossdockCatalogGroupEntity getCrossdockCatalogGroupByCrossdockCatalogGroupNo() {
        return crossdockCatalogGroupByCrossdockCatalogGroupNo;
    }

    public void setCrossdockCatalogGroupByCrossdockCatalogGroupNo(CrossdockCatalogGroupEntity crossdockCatalogGroupByCrossdockCatalogGroupNo) {
        this.crossdockCatalogGroupByCrossdockCatalogGroupNo = crossdockCatalogGroupByCrossdockCatalogGroupNo;
    }

    @OneToMany(mappedBy = "crossdockCatalogGroupMapByCrossdockCatalogGroupMapId")
    public Collection<CrossdockMapEntity> getCrossdockMapsByCrossdockCatalogGroupMapId() {
        return crossdockMapsByCrossdockCatalogGroupMapId;
    }

    public void setCrossdockMapsByCrossdockCatalogGroupMapId(Collection<CrossdockMapEntity> crossdockMapsByCrossdockCatalogGroupMapId) {
        this.crossdockMapsByCrossdockCatalogGroupMapId = crossdockMapsByCrossdockCatalogGroupMapId;
    }

    @Override
    public String toString() {
        return "CrossdockCatalogGroupMapEntity{" +
                "crossdockCatalogGroupMapId=" + crossdockCatalogGroupMapId +
                ", mapTypeCd='" + mapTypeCd + '\'' +
                ", rowCreateTs=" + rowCreateTs +
                ", rowUpdateTs=" + rowUpdateTs +
                ", rowCreateId='" + rowCreateId + '\'' +
                ", rowUpdateId='" + rowUpdateId + '\'' +
                '}';
    }
}
