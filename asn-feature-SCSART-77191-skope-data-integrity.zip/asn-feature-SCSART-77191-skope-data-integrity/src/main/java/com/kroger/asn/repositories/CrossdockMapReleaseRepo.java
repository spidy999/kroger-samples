package com.kroger.asn.repositories;

import com.kroger.asn.entities.CrossdockMapReleaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CrossdockMapReleaseRepo extends JpaRepository<CrossdockMapReleaseEntity,Integer>
{
}
