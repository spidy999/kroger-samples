package com.kroger.asn.repositories;

import com.kroger.asn.entities.OrderManagementDivisionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderManagementDivisionRepo extends JpaRepository<OrderManagementDivisionEntity, Integer> {

    OrderManagementDivisionEntity findFirstByOrderManagementDivisionNo(String orderManagementDivisionNo);

}
