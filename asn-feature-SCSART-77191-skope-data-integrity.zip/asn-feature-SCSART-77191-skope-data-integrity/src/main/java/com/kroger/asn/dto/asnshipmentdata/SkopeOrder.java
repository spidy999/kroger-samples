package com.kroger.asn.dto.asnshipmentdata;


import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Order;

import java.beans.Transient;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SkopeOrder {
    private Long                       id;
    private Integer                    deliveryDay;
    private String                     skopeOrderNo;
    private Long                       storeId;
    private String                     storeNo;
    private Long                       catalogGroupId;
    private String                     catalogGroupNo;
    private Double                     grossCubeAmt;
    private String                     grossCubeUnitOfMeasure;
    private Double                     netWeightAmt;
    private String                     netWeightUnitOfMeasure;
    private Integer                    orderQty;
    private Long                       facilityId;
    private String                     facilityNo;
    private String                     route;
    private String                     stop;
    private Date                       orderDeliveryDate;
    private Date                       orderProcessTime;
    private Date                       orderCancelTime;
    private Date                       originFacilityOrderCompleteTime;
    private String                     orderTypeCode;
    private String                     orderBillingDivisionNo;
    private Long                       orderManagementDivisionId;
    private Date                       createDate;
    private Date                       updateDate;
    private String                     createUserId;
    private String                     updateUserId;
    private String                     pickSequence;
    private String                     processDay;
    private String                     orderManagementDivisionNo;


    public SkopeOrder()
    {
        super();
    }

    public SkopeOrder(String palletSkopeOrderReference) {
        determineOrderNumber(palletSkopeOrderReference.toUpperCase());
    }

    public SkopeOrder(Order order, String routeNumber) throws ParseException {
        determineOrderNumber(order.getId().toUpperCase());
        //set the date formatter leniency to false to ensure we only process dates in our accepted format
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        this.orderDeliveryDate = sdf.parse(order.getStoreDeliveryDate());
        this.grossCubeAmt = Double.valueOf(order.getCube());
        this.netWeightAmt = Double.valueOf(order.getWeight());
        this.orderQty = order.getCases();
        this.route = routeNumber == null ? null : routeNumber.toUpperCase();
        this.orderBillingDivisionNo = order.getOrderManagementDivisionNumber();
    }

    @Transient
    private void determineOrderNumber(String orderNumber) {
        if(orderNumber.length() < 6) {
            this.skopeOrderNo = orderNumber;
        } else {
            this.skopeOrderNo = orderNumber.substring(0,5);
        }
    }


    @Override
    public String toString() {
        return "SkopeOrder{" +
                "skopeOrderNo='" + skopeOrderNo + '\'' +
                ", deliveryDay=" + deliveryDay +
                ", storeId=" + storeId +
                ", route='" + route + '\'' +
                ", orderBillingDivisionNo='" + orderBillingDivisionNo + '\'' +
                '}';
    }


    public String toStringDebug() {
        return "SkopeOrder{" +
                "skopeOrderNo='" + skopeOrderNo + '\'' +
                ", storeId=" + storeId +
                ", storeNo='" + storeNo + '\'' +
                ", catalogGroupId=" + catalogGroupId +
                ", catalogGroupNo='" + catalogGroupNo + '\'' +
                ", facilityId=" + facilityId +
                ", facilityNo='" + facilityNo + '\'' +
                ", orderBillingDivisionNo='" + orderBillingDivisionNo + '\'' +
                ", orderManagementDivisionId=" + orderManagementDivisionId +
                ", orderManagementDivisionNo='" + orderManagementDivisionNo + '\'' +
                '}';
    }

    public String getSkopeOrderNo()
    {
        return skopeOrderNo;
    }

    public String getKrogerSkopeOrderNo()
    {
        if (skopeOrderNo == null)
            return "";

        if (orderBillingDivisionNo == null)
            return skopeOrderNo.trim();

        return orderBillingDivisionNo.trim()
                + skopeOrderNo.trim();
    }

    public void setSkopeOrderNo(String skopeOrderNo)
    {
        if (skopeOrderNo == null
                || skopeOrderNo.length() < 6)
            this.skopeOrderNo = skopeOrderNo;
        else if (skopeOrderNo.length() < 8)
            this.skopeOrderNo = skopeOrderNo.substring(0, 5);
        else
            this.skopeOrderNo = skopeOrderNo.substring(3, 8);

    }

    public Long getStoreId()
    {
        return storeId;
    }

    public void setStoreId(Long storeId)
    {
        this.storeId = storeId;
    }

    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }

    public Long getCatalogGroupId()
    {
        return catalogGroupId;
    }

    public void setCatalogGroupId(Long catalogGroupId)
    {
        this.catalogGroupId = catalogGroupId;
    }

    public String getCatalogGroupNo() {
        return catalogGroupNo;
    }

    public void setCatalogGroupNo(String catalogGroupNo) {
        this.catalogGroupNo = catalogGroupNo;
    }

    public Double getGrossCubeAmt()
    {
        return grossCubeAmt;
    }

    public void setGrossCubeAmt(Double grossCubeAmt)
    {
        this.grossCubeAmt = grossCubeAmt;
    }

    public String getGrossCubeUnitOfMeasure()
    {
        return grossCubeUnitOfMeasure;
    }

    public void setGrossCubeUnitOfMeasure(String grossCubeUnitOfMeasure)
    {
        this.grossCubeUnitOfMeasure = grossCubeUnitOfMeasure;
    }

    public String getNetWeightUnitOfMeasure()
    {
        return netWeightUnitOfMeasure;
    }

    public void setNetWeightUnitOfMeasure(String netWeightUnitOfMeasure)
    {
        this.netWeightUnitOfMeasure = netWeightUnitOfMeasure;
    }

    public Integer getOrderQty()
    {
        return orderQty;
    }

    public void setOrderQty(Integer orderQty)
    {
        this.orderQty = orderQty;
    }


    public String getRoute()
    {
        return route;
    }

    public void setRoute(String route)
    {
        this.route = route;
    }

    public String getStop()
    {
        return stop;
    }

    public void setStop(String stop)
    {
        this.stop = stop;
    }

    public Date getOrderDeliveryDate()
    {
        return orderDeliveryDate;
    }

    public void setOrderDeliveryDate(Date orderDeliveryDate)
    {
        this.orderDeliveryDate = orderDeliveryDate;
    }

    public Date getOrderProcessTime()
    {
        return orderProcessTime;
    }

    public void setOrderProcessTime(Date orderProcessTime)
    {
        this.orderProcessTime = orderProcessTime;
    }

    public Date getOrderCancelTime()
    {
        return orderCancelTime;
    }

    public void setOrderCancelTime(Date orderCancelTime)
    {
        this.orderCancelTime = orderCancelTime;
    }

    public Date getOriginFacilityOrderCompleteTime()
    {
        return originFacilityOrderCompleteTime;
    }

    public void setOriginFacilityOrderCompleteTime(Date originFacilityOrderCompleteTime)
    {
        this.originFacilityOrderCompleteTime = originFacilityOrderCompleteTime;
    }

    public Long getFacilityId()
    {
        return facilityId;
    }

    public void setFacilityId(Long facilityId)
    {
        this.facilityId = facilityId;
    }

    public String getFacilityNo() {
        return facilityNo;
    }

    public void setFacilityNo(String facilityNo) {
        this.facilityNo = facilityNo;
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Integer getDeliveryDay()
    {
        return deliveryDay;
    }

    public void setDeliveryDay(Integer deliveryDay)
    {
        this.deliveryDay = deliveryDay;
    }

    public Double getNetWeightAmt()
    {
        return netWeightAmt;
    }

    public void setNetWeightAmt(Double netWeightAmt)
    {
        this.netWeightAmt = netWeightAmt;
    }

    public String getOrderTypeCode()
    {
        return orderTypeCode;
    }

    public void setOrderTypeCode(String orderTypeCode)
    {
        this.orderTypeCode = orderTypeCode;
    }

    public String getPickSequence()
    {
        return pickSequence;
    }

    public void setPickSequence(String pickSequence)
    {
        this.pickSequence = pickSequence;
    }


    public Date getCreateDate()
    {
        return createDate;
    }

    public void setCreateDate(Date createDate)
    {
        this.createDate = createDate;
    }

    public Date getUpdateDate()
    {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate)
    {
        this.updateDate = updateDate;
    }

    public String getCreateUserId()
    {
        return createUserId;
    }

    public void setCreateUserId(String createUserId)
    {
        this.createUserId = createUserId;
    }

    public String getUpdateUserId()
    {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId)
    {
        this.updateUserId = updateUserId;
    }


    public String getProcessDay()
    {
        return processDay;
    }

    public void setProcessDay(String processDay)
    {
        this.processDay = processDay;
    }

    public Long getOrderManagementDivisionId()
    {
        return orderManagementDivisionId;
    }

    public void setOrderManagementDivisionId(Long orderManagementDivisionId)
    {
        this.orderManagementDivisionId = orderManagementDivisionId;
    }


    public String getOrderBillingDivisionNo()
    {
        return orderBillingDivisionNo;
    }

    public void setOrderBillingDivisionNo(String orderBillingDivisionNo)
    {
        this.orderBillingDivisionNo = orderBillingDivisionNo;
    }

    public String getOrderManagementDivisionNo() {
        return orderManagementDivisionNo;
    }

    public void setOrderManagementDivisionNo(String orderManagementDivisionNo) {
        this.orderManagementDivisionNo = orderManagementDivisionNo;
    }
}
