package com.kroger.asn.repository;

import com.kroger.asn.entities.ReleaseOrderGroupEntity;
import com.kroger.asn.repositories.ReleaseOrderGroupRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class ReleaseOrderGroupRepositoryTests {

    @Autowired
    ReleaseOrderGroupRepo releaseOrderGroupRepo;

    @Test
    public void testFindall() {
        List<ReleaseOrderGroupEntity> releaseOrderGroup = releaseOrderGroupRepo.findAll();
        assertEquals(470781, releaseOrderGroup.get(0).getReleaseOrderGroupId());
        assertEquals("M", releaseOrderGroup.get(0).getReleaseTypeCd());
        assertEquals("BC50718", releaseOrderGroup.get(0).getReleaseUserId());
        assertEquals("2019-04-09 03:15:02.0", releaseOrderGroup.get(0).getReleaseTs().toString());
        assertEquals(4, releaseOrderGroup.size());
    }

    @Test
    public void testSetMethods() {
        List<ReleaseOrderGroupEntity> releaseOrderGroup = releaseOrderGroupRepo.findAll();
        Timestamp ts = new Timestamp(System.currentTimeMillis());

        releaseOrderGroup.get(0).setReleaseOrderGroupId(123456);
        releaseOrderGroup.get(0).setReleaseTypeCd("T");
        releaseOrderGroup.get(0).setReleaseUserId("TEST123");
        releaseOrderGroup.get(0).setReleaseTs(ts);

        assertEquals(123456, releaseOrderGroup.get(0).getReleaseOrderGroupId());
        assertEquals("T", releaseOrderGroup.get(0).getReleaseTypeCd());
        assertEquals("TEST123", releaseOrderGroup.get(0).getReleaseUserId());
        assertEquals(ts, releaseOrderGroup.get(0).getReleaseTs());
    }
}