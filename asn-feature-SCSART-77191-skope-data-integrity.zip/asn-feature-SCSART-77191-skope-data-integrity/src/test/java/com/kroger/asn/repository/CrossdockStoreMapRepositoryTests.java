package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockStoreMapEntity;
import com.kroger.asn.repositories.CrossdockStoreMapRepo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockStoreMapRepositoryTests {

    @Autowired
    CrossdockStoreMapRepo crossdockStoreMapRepo;

    @Test
    public void testFindall() {
        List<CrossdockStoreMapEntity> crossdockStoreMapList = crossdockStoreMapRepo.findAll();
        assertEquals(31585, crossdockStoreMapList.get(0).getCrossdockStoreMapId());
        assert  crossdockStoreMapList.get(0).getAdjustDeliveryDayNo() == 0;
    }

    @Test
    public void testSetMethods() {
        List<CrossdockStoreMapEntity> crossdockStoreMap = crossdockStoreMapRepo.findAll();
        Short sh = (short) 1;

        crossdockStoreMap.get(0).setCrossdockStoreMapId(12345);
        crossdockStoreMap.get(0).setAdjustDeliveryDayNo(sh);

        assertEquals(12345, crossdockStoreMap.get(0).getCrossdockStoreMapId());
        assertEquals(sh, crossdockStoreMap.get(0).getAdjustDeliveryDayNo());
    }

    @Test
    public void testFindCrossdockStoreMapByOriginCatGroupIdAndOriginFacilityAndStoreId(){
        CrossdockStoreMapEntity crossdockStoreMap = crossdockStoreMapRepo.findCrossdockStoreMapByOriginCatGroupIdAndOriginFacilityAndStoreId(537, 10,278);

        Assert.assertNotNull(crossdockStoreMap);
        Assert.assertEquals(31585, crossdockStoreMap.getCrossdockStoreMapId());
        Assert.assertEquals(278, crossdockStoreMap.getStoreByStoreId().getStoreId());
        Assert.assertEquals("00406", crossdockStoreMap.getStoreByStoreId().getStoreNo());
        Assert.assertEquals(560, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockMapId());
        Assert.assertEquals(391, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCrossdockCatalogGroupMapId());
        Assert.assertEquals(10, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getSourcingFacilityByOriginSourcingFacilityId().getSourcingFacilityId());
        Assert.assertEquals(7, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getSourcingFacilityByCrossdockSourcingFacilityId().getSourcingFacilityId());
        Assert.assertEquals(537, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCatalogGroupByOriginCatalogGroupId().getCatalogGroupId());
        Assert.assertEquals(10, crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCatalogGroupByOriginCatalogGroupId().getSourcingFacilityId());
        Assert.assertEquals("FMD", crossdockStoreMap.getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCatalogGroupByOriginCatalogGroupId().getCatalogGroupNo());
    }

}
