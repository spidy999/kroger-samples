package com.kroger.asn.service;

import com.kroger.asn.repositories.*;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.ASNShipment;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * @author ab36672
 * Created on: 1/9/2020 10:06 AM
 */

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class AsnRouteCloseServiceMockitoTests {

    @Mock Logger logger;

    @MockBean ObjectMapper mockOM;

    @InjectMocks
    AsnRouteCloseService asnRouteCloseService;

    @Mock SourcingFacilityRepo mockedSourcingFacilityRepo;

    @Mock OrderManagementDivisionRepo mockedOrderManagementDivisionRepo;

    @Mock CatalogGroupRepo mockedCatalogGroupRepo;

    @Mock StoreRepo mockedStoreRepo;

    @Mock CrossdockStoreMapRepo mockedCrossdockStoreMapRepo;

    @Mock CrossdockStoreScheduleRepo mockedCrossdockStoreScheduleRepo;

    @Mock CrossdockRouteRepo mockedCrossdockRouteRepo;

    ASNShipment asnShipment;

    @Before
    public void setUp() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        asnShipment = objectMapper.readValue(new File("src/test/resources/asnShipmentData.json"), ASNShipment.class);
        MockitoAnnotations.initMocks(this);
    }


//    @Test
//    public void testProcessAsnRouteCloseEvent() throws IOException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        asnShipment = objectMapper.readValue(new File("src/test/resources/asnShipmentSingleOrderData.json"), ASNShipment.class);
//
//        SourcingFacilityEntity originFacilityFromRepo = new SourcingFacilityEntity();
//        OrderManagementDivisionEntity orderManagementDivisionFromRepo = new OrderManagementDivisionEntity();
//        CatalogGroupEntity catalogGroupFromRepo = new CatalogGroupEntity();
//        StoreEntity storeFromRepo = new StoreEntity();
//        CrossdockStoreMapEntity crossdockStoreMapFromRepo = new CrossdockStoreMapEntity();
//        CrossdockStoreScheduleEntity crossdockStoreScheduleFromRepo = new CrossdockStoreScheduleEntity();
//        CrossdockRouteEntity crossdockRouteFromRepo = new CrossdockRouteEntity();
//
//        originFacilityFromRepo.setSourcingFacilityId(7);
//        orderManagementDivisionFromRepo.setOrderManagementDivisionId(2);
//        catalogGroupFromRepo.setCatalogGroupId(537);
//        storeFromRepo.setStoreId(278);
//        crossdockStoreMapFromRepo.setCrossdockStoreMapId(31585);
//        crossdockStoreScheduleFromRepo.setCrossdockStoreScheduleId(1226794);
//        crossdockRouteFromRepo.setRouteId(1);
//
//        doCallRealMethod().when(mockedSourcingFacilityRepo).findBySourcingFacilityNo("014");
////        when(mockedSourcingFacilityRepo.findBySourcingFacilityNo("014")).thenReturn(originFacilityFromRepo);
//        when(mockedOrderManagementDivisionRepo.findFirstByOrderManagementDivisionNo("014")).thenReturn(orderManagementDivisionFromRepo);
//        when(mockedCatalogGroupRepo.findBySourcingFacilityIdAndCatalogGroupNo(eq(7), anyString())).thenReturn(catalogGroupFromRepo);
//        when(mockedStoreRepo.findByOrderManagementDivisionIdAndStoreNo(eq(2), anyString())).thenReturn(storeFromRepo);
//        when(mockedCrossdockRouteRepo.findBySourcingFacilityIdAndRouteNmeAndDispatchDt(eq(7),eq("AB1234"), any())).thenReturn(null);
////        when(mockedCrossdockRouteRepo.save(any(CrossdockRouteEntity.class))).thenReturn(crossdockRouteFromRepo);
//        doReturn(crossdockRouteFromRepo).when(asnRouteCloseService).saveRoute(any(CrossdockRouteEntity.class));
//
//        doCallRealMethod().when(asnRouteCloseService).processAsnEvent(asnShipment);
//        asnRouteCloseService.processAsnEvent(asnShipment);
//        verify(asnRouteCloseService).saveRoute(any(CrossdockRouteEntity.class));
//    }


    @Test
    public void testLogInvalidSkopeOrders() throws IOException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        ASNShipment asnShipment = objectMapper.readValue(new File("src/test/resources/asnShipmentData.json"), ASNShipment.class);
        TreeMap<String, List<String>> validationErrorsByOrder = new TreeMap<>();
        List<String> skopeOrderValidationErrors = new ArrayList<>();
        skopeOrderValidationErrors.add("Error 1");
        skopeOrderValidationErrors.add("Error 2");
        skopeOrderValidationErrors.add("Error 3");
        validationErrorsByOrder.put("014271590", skopeOrderValidationErrors);

        asnRouteCloseService.logInvalidData(validationErrorsByOrder, asnShipment.getSender(), asnShipment.getShipmentData().getRouteName());

        verify(logger, times(1)).error(any());

    }

//    @Test
//    public void testLogInvalidSkopeOrdersIOException() throws IOException {
//        TreeMap<String, List<String>> validationErrorsByOrder = new TreeMap<>();
//        List<String> skopeOrderValidationErrors = new ArrayList<>();
//        skopeOrderValidationErrors.add("Error 1");
//        skopeOrderValidationErrors.add("Error 2");
//        skopeOrderValidationErrors.add("Error 3");
//        validationErrorsByOrder.put("014271590", skopeOrderValidationErrors);
//
////        ObjectMapper objectMapperMock = mock(ObjectMapper.class);
////        doThrow(new IOException()).when(objectMapperMock).writeValueAsString(any());
////        when(objectMapper.writeValueAsString(any())).thenThrow(IOException.class);
////        closeServiceMock.logInvalidData(validationErrorsByOrder, asnShipment);
//
//        ObjectMapper mockOM = Mockito.mock(ObjectMapper.class);
//// old: when(mockOM.writeValueAsString(any())).thenReturn(t);
//        doThrow(new IOException()).when(mockOM).writeValueAsString(any());
//
//        asnRouteCloseService.logInvalidData(validationErrorsByOrder, asnShipment);
//
//        verify(logger, times(2)).error(any());
//
//    }

}
