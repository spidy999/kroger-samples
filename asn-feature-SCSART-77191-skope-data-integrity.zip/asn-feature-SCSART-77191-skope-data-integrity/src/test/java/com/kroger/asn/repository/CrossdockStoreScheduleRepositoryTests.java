package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockStoreScheduleEntity;
import com.kroger.asn.repositories.CrossdockStoreScheduleRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockStoreScheduleRepositoryTests {

    @Autowired
    CrossdockStoreScheduleRepo crossdockStoreScheduleRepo;

    @Test
    public void testFindall() {
        List<CrossdockStoreScheduleEntity> crossdockStoreSchedule = crossdockStoreScheduleRepo.findAll();
        assertEquals(1226000, crossdockStoreSchedule.get(0).getCrossdockStoreScheduleId());
        assertEquals(13, crossdockStoreSchedule.get(0).getScheduleDayNo());
        assertEquals("t", crossdockStoreSchedule.get(0).getScheduleFlag());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockStoreScheduleEntity> crossdockStoreSchedule = crossdockStoreScheduleRepo.findAll();
        short sh = (short) 0;

        crossdockStoreSchedule.get(0).setCrossdockStoreScheduleId(1234567);
        crossdockStoreSchedule.get(0).setScheduleDayNo(sh);
        crossdockStoreSchedule.get(0).setScheduleFlag("f");

        assertEquals(1234567, crossdockStoreSchedule.get(0).getCrossdockStoreScheduleId());
        assertEquals(sh, crossdockStoreSchedule.get(0).getScheduleDayNo());
        assertEquals("f", crossdockStoreSchedule.get(0).getScheduleFlag());
    }
}
