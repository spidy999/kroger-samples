package com.kroger.asn.service;

/**
 * @author AB36672
 * Created on: 2/14/2020 10:10 AM
 */

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.ASNShipment;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Order;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Pallet;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Transactional
@ActiveProfiles({ "unittest", "SPOOFING" })
public class AsnRouteCloseServiceValidationTests {

    @InjectMocks
    AsnRouteCloseService asnRouteCloseService;

    @Mock
    Logger logger;

    Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void generatePrettyNameTest() throws NoSuchFieldException {
        Field field = Order.class.getDeclaredField("catalogGroupNumber");
        String prettyName = asnRouteCloseService.generatePrettyName(field);

        assertEquals("Catalog Group Number", prettyName);
    }

    @Test
    public void validateFieldTypeStringTest(){
        Object fieldValue = "";
        List<String> validationErrors = new ArrayList<>();
        String invalidFieldMessage = "Invalid Id";

        asnRouteCloseService.validateByFieldType(fieldValue, invalidFieldMessage, validationErrors);

        assertEquals(1, validationErrors.size());
        assertEquals("Invalid Id" ,validationErrors.get(0));
    }

    @Test
    public void validateFieldTypeListTest(){
        Object fieldValue = new ArrayList<String>();
        List<String> validationErrors = new ArrayList<>();
        String invalidFieldMessage = "Invalid Order Id References";

        asnRouteCloseService.validateByFieldType(fieldValue, invalidFieldMessage, validationErrors);

        assertEquals(1, validationErrors.size());
        assertEquals("Invalid Order Id References" ,validationErrors.get(0));
    }

    @Test
    public void validateFieldTypeIntegerFloatOrNullTest() {
        Object fieldValue = null;
        List<String> validationErrors = new ArrayList<>();
        String invalidFieldMessage = "Invalid Cases";

        asnRouteCloseService.validateByFieldType(fieldValue, invalidFieldMessage, validationErrors);

        assertEquals(1, validationErrors.size());
        assertEquals("Invalid Cases" ,validationErrors.get(0));
    }

    @Test
    public void validateJsonFieldsNotNullTest(){
        List<String> orderIdRefs = new ArrayList<>();
        orderIdRefs.add("123");
        orderIdRefs.add("456");
        Pallet pallet = Pallet.newBuilder().setId("984").setCases(20).setCube(21).setWeight(305.2F)
                .setOrderIdReferences(orderIdRefs).build();
        List<String> validationErrors = new ArrayList<>();

        asnRouteCloseService.validateJsonFieldsNotNull(pallet, validationErrors);

        assertEquals(0, validationErrors.size());
    }

    @Test
    public void validateJsonFieldsNotNullInvalidOrderIdReferencesTest(){
        List<String> orderIdRefs = new ArrayList<>();
        Pallet pallet = Pallet.newBuilder().setId("984").setCases(20).setCube(21).setWeight(305.2F)
                .setOrderIdReferences(orderIdRefs).build();
        List<String> validationErrors = new ArrayList<>();

        asnRouteCloseService.validateJsonFieldsNotNull(pallet, validationErrors);

        assertEquals(1, validationErrors.size());
        assertTrue(validationErrors.contains("Invalid Order Id References"));
    }

    @Test
    public void validateJsonFieldsNotNullInvalidPalletIdTest(){
        List<String> orderIdRefs = new ArrayList<>();
        orderIdRefs.add("123");
        orderIdRefs.add("456");
        Pallet pallet = Pallet.newBuilder().setId("").setCases(20).setCube(21).setWeight(305.2F)
                .setOrderIdReferences(orderIdRefs).build();
        List<String> validationErrors = new ArrayList<>();

        asnRouteCloseService.validateJsonFieldsNotNull(pallet, validationErrors);

        assertEquals(1, validationErrors.size());
        assertTrue(validationErrors.contains("Invalid Id"));
    }

    @Test
    public void validateJsonFieldsNotNullInvalidPalletIdAndOrderIdRefsTest(){
        List<String> orderIdRefs = new ArrayList<>();
        Pallet pallet = Pallet.newBuilder().setId("").setCases(20).setCube(21).setWeight(305.2F)
                .setOrderIdReferences(orderIdRefs).build();
        List<String> validationErrors = new ArrayList<>();

        asnRouteCloseService.validateJsonFieldsNotNull(pallet, validationErrors);

        assertEquals(2, validationErrors.size());
        assertTrue(validationErrors.contains("Invalid Order Id References"));
        assertTrue(validationErrors.contains("Invalid Id"));
    }

    @Test
    public void validateShipmentOrdersTest() throws IOException {
        List<Order> orders = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        Set<String> uniqueSkopeOrders = new HashSet<>();
        TreeMap<String, List<String>> invalidData = new TreeMap<>();

        Order order1 = objectMapper.readValue(new File("src/test/resources/SingleAsnOrderBuilder.json"), Order.class);
        Order order2 = objectMapper.readValue(new File("src/test/resources/SingleAsnOrderBuilder.json"), Order.class);
        orders.add(order1);
        orders.add(order2);
        order1.setId("024000001");
        order2.setId("024000002");

        asnRouteCloseService.validateShipmentOrders(orders, uniqueSkopeOrders, invalidData);

        assertTrue(invalidData.isEmpty());
        assertTrue(uniqueSkopeOrders.contains("024000001"));
        assertTrue(uniqueSkopeOrders.contains("024000002"));
    }

    @Test
    public void validateShipmentOrdersTestBadOrderData() throws IOException {
        List<Order> orders = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        Set<String> uniqueSkopeOrders = new HashSet<>();
        TreeMap<String, List<String>> invalidData = new TreeMap<>();

        Order order1 = objectMapper.readValue(new File("src/test/resources/SingleAsnOrderBuilder.json"), Order.class);
        Order order2 = objectMapper.readValue(new File("src/test/resources/SingleAsnOrderBuilder.json"), Order.class);
        orders.add(order1);
        orders.add(order2);
        order1.setId("024000001");
        order1.setCatalogGroupNumber("");
        order2.setId("024000002");

        asnRouteCloseService.validateShipmentOrders(orders, uniqueSkopeOrders, invalidData);

        assertFalse(invalidData.isEmpty());
        assertFalse(uniqueSkopeOrders.contains("024000001"));
        assertTrue(uniqueSkopeOrders.contains("024000002"));
        assertEquals("SKOPE Order: 024000001", invalidData.firstKey());
        assertTrue(invalidData.get(invalidData.firstKey()).contains("Invalid Catalog Group Number"));
    }

    @Test
    public void verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrdersTest(){
        Set<String> uniqueSkopeOrders = new HashSet<>();
        Set<String> uniqueSkopeOrdersOnPallets = new HashSet<>();

        uniqueSkopeOrders.add("024000001");
        uniqueSkopeOrders.add("024000002");
        uniqueSkopeOrdersOnPallets.add("024000001");
        uniqueSkopeOrdersOnPallets.add("024000002");

        asnRouteCloseService.verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrders(uniqueSkopeOrders, uniqueSkopeOrdersOnPallets);

        verify(logger, times(0)).warn(any());
    }

    @Test
    public void verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrdersMissingSkopeOrderTest(){
        Set<String> uniqueSkopeOrders = new HashSet<>();
        Set<String> uniqueSkopeOrdersOnPallets = new HashSet<>();

        uniqueSkopeOrders.add("024000001");
        uniqueSkopeOrdersOnPallets.add("024000001");
        uniqueSkopeOrdersOnPallets.add("024000002");

        asnRouteCloseService.verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrders(uniqueSkopeOrders, uniqueSkopeOrdersOnPallets);

        verify(logger, times(1)).warn(anyString(), any(Object.class));
    }

    @Test
    public void verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrdersMissingPalletOrderTest(){
        Set<String> uniqueSkopeOrders = new HashSet<>();
        Set<String> uniqueSkopeOrdersOnPallets = new HashSet<>();

        uniqueSkopeOrders.add("024000001");
        uniqueSkopeOrders.add("024000002");
        uniqueSkopeOrdersOnPallets.add("024000002");

        asnRouteCloseService.verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrders(uniqueSkopeOrders, uniqueSkopeOrdersOnPallets);

        verify(logger, times(1)).warn(anyString(), any(Object.class));
    }

    @Test
    public void verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrdersMissingSkopeAndPalletOrderTest(){
        Set<String> uniqueSkopeOrders = new HashSet<>();
        Set<String> uniqueSkopeOrdersOnPallets = new HashSet<>();

        uniqueSkopeOrders.add("024000001");
        uniqueSkopeOrdersOnPallets.add("024000002");

        asnRouteCloseService.verifyAllSkopeOrdersOnPalletsAndPalletSkopeOrdersAsOrders(uniqueSkopeOrders, uniqueSkopeOrdersOnPallets);

        verify(logger, times(2)).warn(anyString(), any(Object.class));
    }

    @Test
    public void validateAsnRouteCloseDataPalletSkopeRefIdsNotInSkopeOrderListTest() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        SortedMap<String, List<String>> invalidData = new TreeMap<>();
        ASNShipment asnShipment = objectMapper.readValue(new File("src/test/resources/AsnShipmentPalletSkopeOrdersNotInSkopeOrderList2.json"), ASNShipment.class);
        int initialPalletListSize = asnShipment.getShipmentData().getPallets().size();

        asnRouteCloseService.validateAsnData(asnShipment.getShipmentData().getOrders(), asnShipment.getShipmentData().getPallets(), asnShipment.getSender(), asnShipment.getShipmentData().getRouteName());

//        verify(logger, times(1)).error(anyString(), any(Object.class));
        assertNotEquals(initialPalletListSize, asnShipment.getShipmentData().getPallets().size());
        assertEquals(initialPalletListSize - 1, asnShipment.getShipmentData().getPallets().size());
    }
}
