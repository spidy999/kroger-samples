package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockRouteEntity;
import com.kroger.asn.repositories.CrossdockRouteRepo;
import com.kroger.asn.service.AsnRouteCloseService;
import com.kroger.asn.util.CommonDefines;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockRouteRepositoryTests {

    @Autowired
    CrossdockRouteRepo crossdockRouteRepo;

    @Autowired
    AsnRouteCloseService asnRouteCloseService;

    @Test
    public void testRoute() {
        List<CrossdockRouteEntity> crossdockRoute = crossdockRouteRepo.findAll();
        assertEquals(3387865, crossdockRoute.get(0).getRouteId());
        assert  crossdockRoute.get(0).getSourcingFacilityId() == 14;
        assertEquals("IGW059", crossdockRoute.get(0).getRouteNme());
        assertEquals("2019-04-10", crossdockRoute.get(0).getDispatchDt().toString());
        assertEquals("398064", crossdockRoute.get(0).getCrossdockTrailerNo());
        assertEquals("TSLG", crossdockRoute.get(0).getCrossdockCarrierCd());
        assertEquals("53ZG", crossdockRoute.get(0).getCrossdockTrailerTypeCd());
        assertEquals("2019-04-10 12:17:36.0", crossdockRoute.get(0).getRouteCloseTs().toString());
        assertEquals("2019-04-10 12:17:38.0", crossdockRoute.get(0).getRowCreateTs().toString());
        assertEquals("2019-04-10 12:17:38.0", crossdockRoute.get(0).getRowUpdateTs().toString());
        assertEquals("anonymou", crossdockRoute.get(0).getRowCreateId());
        assertNull(crossdockRoute.get(0).getRowUpdateId());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockRouteEntity> crossdockRoute = crossdockRouteRepo.findAll();
        Date dt = Date.valueOf("2012-12-21");
        Timestamp ts = Timestamp.valueOf("2019-04-10 12:17:36.0");

        crossdockRoute.get(0).setRouteId(1234567);
        crossdockRoute.get(0).setSourcingFacilityId(12);
        crossdockRoute.get(0).setRouteNme("TEST12");
        crossdockRoute.get(0).setDispatchDt(dt);
        crossdockRoute.get(0).setCrossdockTrailerNo("123456");
        crossdockRoute.get(0).setCrossdockCarrierCd("TEST");
        crossdockRoute.get(0).setCrossdockTrailerTypeCd("TEST");
        crossdockRoute.get(0).setRouteCloseTs(ts);
        crossdockRoute.get(0).setRowCreateTs(ts);
        crossdockRoute.get(0).setRowUpdateTs(ts);
        crossdockRoute.get(0).setRowCreateId("TestID");
        crossdockRoute.get(0).setRowUpdateId("TestID");

        assertEquals(1234567, crossdockRoute.get(0).getRouteId());
        assert crossdockRoute.get(0).getSourcingFacilityId() == 12;
        assertEquals("TEST12", crossdockRoute.get(0).getRouteNme());
        assertEquals(dt, crossdockRoute.get(0).getDispatchDt());
        assertEquals("123456", crossdockRoute.get(0).getCrossdockTrailerNo());
        assertEquals("TEST", crossdockRoute.get(0).getCrossdockCarrierCd());
        assertEquals("TEST", crossdockRoute.get(0).getCrossdockTrailerTypeCd());
        assertEquals(ts, crossdockRoute.get(0).getRouteCloseTs());
        assertEquals(ts, crossdockRoute.get(0).getRowCreateTs());
        assertEquals(ts, crossdockRoute.get(0).getRowUpdateTs());
        assertEquals("TestID", crossdockRoute.get(0).getRowCreateId());
        assertEquals("TestID", crossdockRoute.get(0).getRowUpdateId());
    }

    @Test
    public void testSaveNewRoute() throws Exception {
        Date dt = Date.valueOf("2012-12-21");
        Timestamp ts = Timestamp.valueOf("2019-04-10 12:17:36.0");

        CrossdockRouteEntity crossdockRoute = new CrossdockRouteEntity();

        //test for adding a new route
        crossdockRoute.setSourcingFacilityId(10);
        crossdockRoute.setRouteNme("TEST12");
        crossdockRoute.setDispatchDt(dt);
        crossdockRoute.setCrossdockTrailerNo("123456");
        crossdockRoute.setCrossdockCarrierCd("TEST");
        crossdockRoute.setCrossdockTrailerTypeCd("TEST");
        crossdockRoute.setRouteCloseTs(ts);
        crossdockRoute.setRowCreateTs(ts);
        crossdockRoute.setRowUpdateTs(ts);
        crossdockRoute.setRowCreateId(CommonDefines.ASN_ID_PREFIX + "017");
        crossdockRoute.setRowUpdateId(CommonDefines.ASN_ID_PREFIX + "017");

        asnRouteCloseService.saveRoute(crossdockRoute);

        CrossdockRouteEntity crossdockRoute2 = crossdockRouteRepo.findBySourcingFacilityIdAndRouteNmeAndDispatchDt(10, "TEST12", dt);

        assert  crossdockRoute2.getSourcingFacilityId() == 10;
        assert  crossdockRoute2.getRouteNme().equals("TEST12");
        assertEquals(dt, crossdockRoute2.getDispatchDt());
        assertEquals("123456", crossdockRoute2.getCrossdockTrailerNo());
        assertEquals("TEST", crossdockRoute2.getCrossdockCarrierCd());
        assertEquals("TEST", crossdockRoute2.getCrossdockTrailerTypeCd());
        assertEquals(ts, crossdockRoute2.getRouteCloseTs());
        assertEquals(ts, crossdockRoute2.getRowCreateTs());
        assertEquals(ts, crossdockRoute2.getRowUpdateTs());
        assertEquals("ASN-017",crossdockRoute2.getRowCreateId());
        assertEquals("ASN-017", crossdockRoute2.getRowUpdateId());
    }

    @Test
    public void testSaveExistingRoute() throws Exception {
        Date dt = Date.valueOf("2019-04-10");
        Timestamp closeTs = Timestamp.valueOf("2019-04-10 12:17:36.0");
        Timestamp updateTs = Timestamp.valueOf("2019-04-10 12:17:38.0");

        CrossdockRouteEntity crossdockRoute = new CrossdockRouteEntity();

        //test for adding a new route
        crossdockRoute.setSourcingFacilityId(14);
        crossdockRoute.setRouteNme("IGW059");
        crossdockRoute.setDispatchDt(dt);
        crossdockRoute.setCrossdockTrailerNo("123456"); //updated from original route
        crossdockRoute.setCrossdockCarrierCd("TEST");   //updated from original route
        crossdockRoute.setCrossdockTrailerTypeCd("TEST");   //updated from original route
        crossdockRoute.setRouteCloseTs(closeTs);
        crossdockRoute.setRowCreateTs(updateTs);
        crossdockRoute.setRowUpdateTs(updateTs);
        crossdockRoute.setRowCreateId("anonymou");
        crossdockRoute.setRowUpdateId("TEST");

        asnRouteCloseService.saveRoute(crossdockRoute);

        CrossdockRouteEntity crossdockRoute1 = crossdockRouteRepo.findBySourcingFacilityIdAndRouteNmeAndDispatchDt(14, "IGW059", dt);
        assert  crossdockRoute1.getRouteId() == 3387865;
        assert  crossdockRoute1.getSourcingFacilityId() == 14;
        assertEquals("IGW059", crossdockRoute1.getRouteNme());
        assertEquals("2019-04-10", crossdockRoute1.getDispatchDt().toString());
        assertEquals("123456", crossdockRoute1.getCrossdockTrailerNo());    //updated from original route
        assertEquals("TEST", crossdockRoute1.getCrossdockCarrierCd());  //updated from original route
        assertEquals("TEST", crossdockRoute1.getCrossdockTrailerTypeCd());  //updated from original route
        assertEquals("2019-04-10 12:17:36.0", crossdockRoute1.getRouteCloseTs().toString());
        assertEquals("2019-04-10 12:17:38.0", crossdockRoute1.getRowCreateTs().toString());
        assertEquals("2019-04-10 12:17:38.0", crossdockRoute1.getRowUpdateTs().toString());
        assertEquals("anonymou", crossdockRoute1.getRowCreateId());
    }

    @Test
    public void testFindBySourcingFacilityIdAndRouteNmeAndDispatchDt() {
        Date dt = Date.valueOf( "2019-04-10" );
        CrossdockRouteEntity crossdockRoute = crossdockRouteRepo.findBySourcingFacilityIdAndRouteNmeAndDispatchDt(14, "IGW059", dt);
        assert  crossdockRoute.getRouteId() == 3387865;
        assert  crossdockRoute.getSourcingFacilityId() == 14;
        assertEquals("IGW059", crossdockRoute.getRouteNme());
    }
}
