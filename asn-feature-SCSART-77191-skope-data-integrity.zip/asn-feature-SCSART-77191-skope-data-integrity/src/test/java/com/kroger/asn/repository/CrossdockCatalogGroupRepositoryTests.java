package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockCatalogGroupEntity;
import com.kroger.asn.repositories.CrossdockCatalogGroupRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockCatalogGroupRepositoryTests {

    @Autowired
    CrossdockCatalogGroupRepo crossdockCatalogGroupRepo;

    @Test
    public void testFindall() {
        List<CrossdockCatalogGroupEntity> xdocCatalogGroup = crossdockCatalogGroupRepo.findAll();
        assertEquals("ALE", xdocCatalogGroup.get(0).getCrossdockCatalogGroupNo());
        assertEquals(36, xdocCatalogGroup.size());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockCatalogGroupEntity> xdocCatalogGroup = crossdockCatalogGroupRepo.findAll();
        xdocCatalogGroup.get(0).setCrossdockCatalogGroupNo("FOO");

        assertEquals("FOO", xdocCatalogGroup.get(0).getCrossdockCatalogGroupNo());
    }
}
