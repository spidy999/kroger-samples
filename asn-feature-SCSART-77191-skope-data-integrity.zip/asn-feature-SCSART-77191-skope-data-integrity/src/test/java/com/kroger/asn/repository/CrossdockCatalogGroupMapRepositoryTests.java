package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockCatalogGroupMapEntity;
import com.kroger.asn.repositories.CrossdockCatalogGroupMapRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockCatalogGroupMapRepositoryTests {

    @Autowired
    CrossdockCatalogGroupMapRepo crossdockCatalogGroupMapRepo;

    @Test
    public void testFindall() {
        List<CrossdockCatalogGroupMapEntity> xdocCatalogGroupMap = crossdockCatalogGroupMapRepo.findAll();
        assertEquals(165, xdocCatalogGroupMap.get(0).getCrossdockCatalogGroupMapId());
        assertEquals("N", xdocCatalogGroupMap.get(0).getMapTypeCd());
        assertEquals( "2010-12-22 16:56:39.0", xdocCatalogGroupMap.get(0).getRowCreateTs().toString());
        assertEquals("2010-12-22 16:56:39.0", xdocCatalogGroupMap.get(0).getRowUpdateTs().toString());
        assertEquals("TB55640", xdocCatalogGroupMap.get(0).getRowCreateId());
        assertNull(xdocCatalogGroupMap.get(0).getRowUpdateId());
        assertEquals(11, xdocCatalogGroupMap.size());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockCatalogGroupMapEntity> xdocCatalogGroupMap = crossdockCatalogGroupMapRepo.findAll();
        Timestamp ts = new Timestamp(System.currentTimeMillis());

        xdocCatalogGroupMap.get(0).setCrossdockCatalogGroupMapId(111);
        xdocCatalogGroupMap.get(0).setMapTypeCd("T");
        xdocCatalogGroupMap.get(0).setRowCreateTs(ts);
        xdocCatalogGroupMap.get(0).setRowUpdateTs(ts);
        xdocCatalogGroupMap.get(0).setRowCreateId("FOOBAR1");
        xdocCatalogGroupMap.get(0).setRowUpdateId("test");

        assertEquals(111, xdocCatalogGroupMap.get(0).getCrossdockCatalogGroupMapId());
        assertEquals("T",xdocCatalogGroupMap.get(0).getMapTypeCd());
        assertEquals(ts, xdocCatalogGroupMap.get(0).getRowCreateTs());
        assertEquals(ts, xdocCatalogGroupMap.get(0).getRowUpdateTs());
        assertEquals("FOOBAR1", xdocCatalogGroupMap.get(0).getRowCreateId());
        assertEquals("test", xdocCatalogGroupMap.get(0).getRowUpdateId());
    }
}