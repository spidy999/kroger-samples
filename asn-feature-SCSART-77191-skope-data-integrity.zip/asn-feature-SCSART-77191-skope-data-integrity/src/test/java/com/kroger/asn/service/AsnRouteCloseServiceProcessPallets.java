package com.kroger.asn.service;


import com.kroger.asn.entities.CrossdockOrderHeaderEntity;
import com.kroger.asn.repositories.CrossdockOrderHeaderRepo;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Pallet;
import org.apache.commons.lang.mutable.MutableBoolean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@ActiveProfiles({ "unittest", "SPOOFING"})
public class AsnRouteCloseServiceProcessPallets {

    @Autowired
    AsnRouteCloseService asnRouteCloseService;

    @Autowired
    CrossdockOrderHeaderRepo crossdockOrderHeaderRepo;


    @Test
    //Use case 4.1.2, 4.9.4, 4.10.4
    //Process each load in the ASN route message
    public void testProcessPalletsNullShipmentTimestamp() throws Exception {
        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap= new HashMap<>();
        List<Pallet > pallets = new ArrayList<>();
        List<String> orderNumber = new ArrayList<>();
        orderNumber.add("99999");
        orderNumber.add("99998");
        Pallet pallet =  Pallet.newBuilder().setCases(10).setId("010500017010648945").setCube(50).setWeight(23).setOrderIdReferences(orderNumber).build();
        pallets.add(pallet);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntities=  crossdockOrderHeaderRepo.findById(5587990).orElse(null);
        crossdockOrderHeaderBySkopeOrderMap.put("99998",crossdockOrderHeaderEntities);
        crossdockOrderHeaderBySkopeOrderMap.put("99999",crossdockOrderHeaderEntities);
        MutableBoolean sendToWin = new MutableBoolean();
        sendToWin.setValue(false);
        List<CrossdockOrderHeaderEntity> crossdockOrderHeadersToSendToWin = asnRouteCloseService.processAsnPallets(crossdockOrderHeaderBySkopeOrderMap,pallets, sendToWin);

        assertEquals(false, sendToWin.getValue());
        assertEquals(0, crossdockOrderHeadersToSendToWin.size());
    }

    @Test
    //Use case 4.1.2, 4.9.4, 4.10.4
    //Process each load in the ASN route message
    //Found an existing load that is already origin complete for Pallet
    public void testProcessPalletsNotNullShipmentTimeStamp() throws Exception {
        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap= new HashMap<>();
        List<Pallet > pallets = new ArrayList<>();
        List<String> orderNumber = new ArrayList<>();
        orderNumber.add("99999");
        orderNumber.add("99998");
        Pallet pallet =  Pallet.newBuilder().setCases(10).setId("010500017010648944").setCube(50).setWeight(23).setOrderIdReferences(orderNumber).build();
        pallets.add(pallet);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntities=  crossdockOrderHeaderRepo.findById(5587990).orElse(null);
        crossdockOrderHeaderBySkopeOrderMap.put("99998",crossdockOrderHeaderEntities);
        crossdockOrderHeaderBySkopeOrderMap.put("99999",crossdockOrderHeaderEntities);
        MutableBoolean sendToWin = new MutableBoolean();
        sendToWin.setValue(false);
        List<CrossdockOrderHeaderEntity> crossdockOrderHeadersToSendToWin = asnRouteCloseService.processAsnPallets(crossdockOrderHeaderBySkopeOrderMap,pallets, sendToWin);

        assertEquals(false, sendToWin.getValue());
        assertEquals(0, crossdockOrderHeadersToSendToWin.size());
    }

    @Test
    //test trim functionality for pallet IDs
    public void test20DigitPalletIdTo18DigitPalletId() throws Exception {
        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap= new HashMap<>();
        List<Pallet > pallets = new ArrayList<>();
        List<String> orderNumber = new ArrayList<>();
        orderNumber.add("99999");
        orderNumber.add("99998");
        Pallet pallet =  Pallet.newBuilder().setCases(10).setId("00105000170106489440").setCube(50).setWeight(23).setOrderIdReferences(orderNumber).build();
        pallets.add(pallet);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntities=  crossdockOrderHeaderRepo.findById(5587990).orElse(null);
        crossdockOrderHeaderBySkopeOrderMap.put("99998",crossdockOrderHeaderEntities);
        crossdockOrderHeaderBySkopeOrderMap.put("99999",crossdockOrderHeaderEntities);
        MutableBoolean sendToWin = new MutableBoolean();
        sendToWin.setValue(false);
        List<CrossdockOrderHeaderEntity> crossdockOrderHeadersToSendToWin = asnRouteCloseService.processAsnPallets(crossdockOrderHeaderBySkopeOrderMap,pallets, sendToWin);

        assertEquals(18, pallets.get(0).getId().length());
        assertEquals("010500017010648944", pallets.get(0).getId());
    }

    @Test
    //CrossdockOrderReleaseTs is populated in header
    public void testProcessPalletsReleasedTimestamp() throws Exception {
        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap= new HashMap<>();
        List<Pallet > pallets = new ArrayList<>();
        List<String> orderNumber = new ArrayList<>();
        orderNumber.add("99999");
        orderNumber.add("99998");
        Pallet pallet =  Pallet.newBuilder().setCases(10).setId("010500017010648945").setCube(50).setWeight(23).setOrderIdReferences(orderNumber).build();
        pallets.add(pallet);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntities=  crossdockOrderHeaderRepo.findById(5587996).orElse(null);
        crossdockOrderHeaderBySkopeOrderMap.put("99998",crossdockOrderHeaderEntities);
        crossdockOrderHeaderBySkopeOrderMap.put("99999",crossdockOrderHeaderEntities);
        MutableBoolean sendToWin = new MutableBoolean();
        sendToWin.setValue(false);
        List<CrossdockOrderHeaderEntity> crossdockOrderHeadersToSendToWin = asnRouteCloseService.processAsnPallets(crossdockOrderHeaderBySkopeOrderMap,pallets, sendToWin);

        assertEquals(false, sendToWin.getValue());
        assertEquals(0, crossdockOrderHeadersToSendToWin.size());
    }

    @Test
    //CrossdockOrderReleaseTs is populated in header
    public void findCrossdockOrderHeaderForPalletTests() {
        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap= new HashMap<>();
        List<Pallet > pallets = new ArrayList<>();
        List<String> orderNumber = new ArrayList<>();
        orderNumber.add("99999");
        orderNumber.add("99998");
        Pallet pallet =  Pallet.newBuilder().setCases(10).setId("010500017010648945").setCube(50).setWeight(23).setOrderIdReferences(orderNumber).build();
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntities=  crossdockOrderHeaderRepo.findById(5587996).orElse(null);
        crossdockOrderHeaderBySkopeOrderMap.put("99998",crossdockOrderHeaderEntities);
        crossdockOrderHeaderBySkopeOrderMap.put("99999",crossdockOrderHeaderEntities);
        MutableBoolean sendToWin = new MutableBoolean();
        sendToWin.setValue(false);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = asnRouteCloseService.findCrossdockOrderHeaderForPallet(pallet, crossdockOrderHeaderBySkopeOrderMap);

        assertEquals(crossdockOrderHeaderRepo.findById(5587996).orElse(null), crossdockOrderHeaderEntity);
    }
}
