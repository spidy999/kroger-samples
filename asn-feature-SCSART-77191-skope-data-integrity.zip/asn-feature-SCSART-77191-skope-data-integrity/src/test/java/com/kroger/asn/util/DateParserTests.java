package com.kroger.asn.util;

import com.kroger.commons.calendar.KrogerFiscalCalendar;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class DateParserTests {


    @Test
    public void testDateToKrogerFiscalCalendar() {
        java.sql.Date dt = java.sql.Date.valueOf("2020-1-20");

        KrogerFiscalCalendar krogerFiscalCalendar = DateParser.dateToKrogerFiscalCalendar(dt);

        Assert.assertEquals(2020, krogerFiscalCalendar.get(Calendar.YEAR));
        Assert.assertEquals(0, krogerFiscalCalendar.get(Calendar.MONTH)); //january is month 0
        Assert.assertEquals(20, krogerFiscalCalendar.get(Calendar.DATE));

    }

    @Test
    public void testDayOfTheWeek() {
        java.sql.Date dt = java.sql.Date.valueOf("2020-1-20");

        Assert.assertEquals(2, DateParser.dayOfTheWeek(dt));

    }

    @Test
    public void testDateParseConstructor(){
        IllegalStateException illegalStateException = assertThrows(IllegalStateException.class, () -> {
            DateParser dateParser = new DateParser();
        });

        assertEquals("DateParser is utility class and should not be instantiated.", illegalStateException.getMessage());
    }
}
