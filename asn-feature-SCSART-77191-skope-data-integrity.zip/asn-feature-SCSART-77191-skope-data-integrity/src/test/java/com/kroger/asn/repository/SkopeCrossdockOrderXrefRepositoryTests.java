package com.kroger.asn.repository;

import com.kroger.asn.entities.SkopeCrossdockOrderXrefEntity;
import com.kroger.asn.repositories.SkopeCrossdockOrderXrefRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class SkopeCrossdockOrderXrefRepositoryTests {

    @Autowired
    SkopeCrossdockOrderXrefRepo skopeCrossdockOrderXrefRepo;

    @Test
    public void testFindall() {
        List<SkopeCrossdockOrderXrefEntity> skopeCrossdockOrderXref = skopeCrossdockOrderXrefRepo.findAll();
        assertEquals(5587974, skopeCrossdockOrderXref.get(0).getCrossdockOrderId());
        assertEquals(9745131, skopeCrossdockOrderXref.get(0).getSkopeOrderId());
        assertNotEquals(0,skopeCrossdockOrderXref.size());
    }

    @Test
    public void testSetMethods() {
        List<SkopeCrossdockOrderXrefEntity> skopeCrossdockOrderXref = skopeCrossdockOrderXrefRepo.findAll();
        skopeCrossdockOrderXref.get(0).setCrossdockOrderId(1234567);
        skopeCrossdockOrderXref.get(0).setSkopeOrderId(1234567);

        assertEquals(1234567, skopeCrossdockOrderXref.get(0).getCrossdockOrderId());
        assertEquals(1234567, skopeCrossdockOrderXref.get(0).getSkopeOrderId());
    }
}
