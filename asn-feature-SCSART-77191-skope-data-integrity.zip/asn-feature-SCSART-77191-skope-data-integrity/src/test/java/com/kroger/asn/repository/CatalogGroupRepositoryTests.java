package com.kroger.asn.repository;

import com.kroger.asn.entities.CatalogGroupEntity;
import com.kroger.asn.repositories.CatalogGroupRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CatalogGroupRepositoryTests {

    @Autowired
    CatalogGroupRepo catalogGroupRepo;

    @Test
    public void testFindall() {
        List<CatalogGroupEntity> catalogGroup = catalogGroupRepo.findAll();
        assertEquals(63, catalogGroup.get(0).getCatalogGroupId());
        assertEquals(63, catalogGroup.get(0).getCatalogGroupId());
        assertEquals("BAN", catalogGroup.get(0).getCatalogGroupNo());
        assertEquals(26, catalogGroup.size());
    }

    @Test
    public void testSetMethods() {
        List<CatalogGroupEntity> catalogGroup = catalogGroupRepo.findAll();
        catalogGroup.get(0).setCatalogGroupId(99) ;
        catalogGroup.get(0).setCatalogGroupNo("FOO");

        assertEquals(99, catalogGroup.get(0).getCatalogGroupId());
        assertEquals("FOO", catalogGroup.get(0).getCatalogGroupNo());
    }
}
