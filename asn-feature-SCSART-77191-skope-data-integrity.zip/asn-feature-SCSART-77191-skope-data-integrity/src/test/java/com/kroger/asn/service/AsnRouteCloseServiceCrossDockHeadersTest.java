package com.kroger.asn.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kroger.asn.entities.*;
import com.kroger.asn.repositories.*;
import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNShipmentEvent;
import com.kroger.schema.canonical.core._3_0.FlagType;
import com.kroger.schema.canonical.xdoc._3_0.CrossDockOrderType;
import org.apache.commons.lang.mutable.MutableBoolean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@ActiveProfiles({ "unittest", "SPOOFING"})
public class AsnRouteCloseServiceCrossDockHeadersTest {

    @Autowired
    AsnRouteCloseService asnRouteCloseService;

    @Autowired
    CrossdockStoreMapRepo crossdockStoreMapRepo;

    @Autowired
    CrossdockMapRepo crossdockMapRepo;

    @Autowired
    SkopeOrderRepo skopeOrderRepo;

    @Autowired
    CrossdockOrderHeaderRepo crossdockOrderHeaderRepo;

    @Autowired
    CrossdockRouteRepo crossdockRouteRepo;

    @Autowired
    SourcingFacilityRepo sourcingFacilityRepo;

    @Autowired
    SkopeCrossdockOrderXrefRepo skopeCrossdockOrderXrefRepo;

    Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

    @Test
    public void generateCrossdockOrderNumberTest() {
        //simple method adds 0s to front to make 5 digits or trims from the front
        String lessThan5 = asnRouteCloseService.generateCrossdockOrderNumber("1");
        String is5 = asnRouteCloseService.generateCrossdockOrderNumber("12345");
        String moreThan5 = asnRouteCloseService.generateCrossdockOrderNumber("123456");
        assertEquals("00001", lessThan5);
        assertEquals("12345", is5);
        assertEquals("23456", moreThan5);
    }

    @Test
    public void findAvailableCrossDockOrderHeadersTest() {

        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08095");
        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = asnRouteCloseService.findAvailableCrossDockOrderHeaders(skopeOrderEntity);

        assertEquals("00004", crossdockOrderHeaderEntity.getCrossdockOrderNo());
    }

    @Test
    public void createCrossdockOrderHeaderTest() throws Exception {

        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08095");
        SkopeOrderEntity skopeOrderEntity1 = skopeOrderRepo.findBySkopeOrderNo("08017");

        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        skopeOrderEntity1.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));

        skopeOrderEntity.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());
        skopeOrderEntity1.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());

        CrossdockRouteEntity crossdockRouteEntity = crossdockRouteRepo.findByRouteId(3387865);
        CrossdockRouteEntity crossdockRouteEntity1 = crossdockRouteRepo.findByRouteId(3387899);

        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = asnRouteCloseService.createCrossdockOrderHeader(skopeOrderEntity, crossdockRouteEntity);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity1 = asnRouteCloseService.createCrossdockOrderHeader(skopeOrderEntity1, crossdockRouteEntity1);

        assertNotNull(crossdockOrderHeaderEntity.getCrossdockOrderNo());
        assertNotNull(crossdockOrderHeaderEntity1.getCrossdockOrderNo());

    }

    @Test
    public void createSkopeCrossdockOrderXrefTest() throws Exception {

        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08095");
        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = asnRouteCloseService.findAvailableCrossDockOrderHeaders(skopeOrderEntity);

        SkopeCrossdockOrderXrefEntity skopeCrossdockOrderXref = asnRouteCloseService.createSkopeCrossdockOrderXref(skopeOrderEntity, crossdockOrderHeaderEntity);

        assertEquals(9751614, skopeCrossdockOrderXref.getSkopeOrderId());
        assertEquals(5587993, skopeCrossdockOrderXref.getCrossdockOrderId());

    }

    @Test
    //4.1.2
    //match skopeOrder with crossdockOrderHeader
    public void processCrossDockHeadersMatchHeaderTest() throws Exception {
        //header "5587933" exists for this skopeOrder
        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08095");
        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        skopeOrderEntity.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());

        HashMap<String, SkopeOrderEntity> mappedSkopeOrders = new HashMap<>();
        mappedSkopeOrders.put(skopeOrderEntity.getSkopeOrderNo(), skopeOrderEntity);

        CrossdockRouteEntity crossdockRouteEntity = crossdockRouteRepo.findByRouteId(3387865);

        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap = asnRouteCloseService.processCrossDockHeaders(mappedSkopeOrders, crossdockRouteEntity );

        //Verify Crossdock order is not cancelled (cancel ts is null)
        // not DSD (delivery_type_cd is C)
        // not already closed by a route close (origin_complete_ts  is null)
        assertEquals(5587993, crossdockOrderHeaderBySkopeOrderMap.get("08095").getCrossdockOrderId());
        assertNull(crossdockOrderHeaderBySkopeOrderMap.get("08095").getCrossdockOrderCancelTs());
        assertEquals("C",crossdockOrderHeaderBySkopeOrderMap.get("08095").getDeliveryTypeCd());
    }

    @Test
    //4.4.2
    //Create Crossdock order header
    public void processCrossDockHeadersCreateHeaderCompleteTest() throws Exception {
        //no header exists for this order
        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08018");
        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        skopeOrderEntity.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());

        HashMap<String, SkopeOrderEntity> mappedSkopeOrders = new HashMap<>();
        mappedSkopeOrders.put(skopeOrderEntity.getSkopeOrderNo(), skopeOrderEntity);

        CrossdockRouteEntity crossdockRouteEntity = crossdockRouteRepo.findByRouteId(3387865);

        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap = asnRouteCloseService.processCrossDockHeaders(mappedSkopeOrders, crossdockRouteEntity );

        //crossdockOrderHeader is created for order
        assertEquals("014", crossdockOrderHeaderBySkopeOrderMap.get("08018").getOrderBillingDivisionNo());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getOrderManagementDivisionByOrderManagementDivisionId());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getStoreByStoreId());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getGrossCubeAmt());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getNetWeightAmt());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getCrossdockOrderQty());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getCrossdockOrderDeliveryDt());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getSourcingFacilityByOriginSourcingFacilityId());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getSourcingFacilityByCrossdockSourcingFacilityId());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getCrossdockCatalogGroupByCrossdockCatalogGroupNo());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getCrossdockMapByCrossdockMapId());
        assertNotNull(crossdockOrderHeaderBySkopeOrderMap.get("08018").getRowCreateTs());
        //Xref is created for order
        assertNotNull(skopeCrossdockOrderXrefRepo.findAllBySkopeOrderId(9751605));
    }

    @Test
    //4.11.2
    //Find Crossdock header for load using the SKOPE order
    //Crossdock Header is marked cancelled, crossdock_order_cancel_dt is populated
    //System does nothing with load and moves to process next load
    public void processCrossDockHeadersCancelledTest() throws Exception {
        //crossdockOrderHeader is mapped in the Xref table, crossdockOrderHeader is cancelled.
        //otherwise a Cancelled crossdockOrderHeader will never be pulled from the database
        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08020");
        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31586));
        skopeOrderEntity.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31586).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());

        //crossdockOrderHeader is not cancelled
        SkopeOrderEntity skopeOrderEntity1 = skopeOrderRepo.findBySkopeOrderNo("08095");
        skopeOrderEntity1.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        skopeOrderEntity1.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());

        HashMap<String, SkopeOrderEntity> mappedSkopeOrders = new HashMap<>();
        mappedSkopeOrders.put(skopeOrderEntity.getSkopeOrderNo(), skopeOrderEntity);
        mappedSkopeOrders.put(skopeOrderEntity1.getSkopeOrderNo(), skopeOrderEntity1);

        CrossdockRouteEntity crossdockRouteEntity = crossdockRouteRepo.findByRouteId(3387865);

        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap = asnRouteCloseService.processCrossDockHeaders(mappedSkopeOrders, crossdockRouteEntity );

        //processCrossDockHeaders passes over cancelled header, only non-cancelled headers remain
        assertEquals(1,crossdockOrderHeaderBySkopeOrderMap.size());
        assertEquals(5587993, crossdockOrderHeaderBySkopeOrderMap.get("08095").getCrossdockOrderId());
    }

    @Test
    public void calculateHeaderCubeWeightAndQtyTest() throws Exception {
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = crossdockOrderHeaderRepo.getOne(5587974);
        asnRouteCloseService.calculateHeaderCubeWeightAndQty(crossdockOrderHeaderEntity);

        assertEquals(BigDecimal.valueOf(239.34), crossdockOrderHeaderEntity.getGrossCubeAmt());
        assertEquals(BigDecimal.valueOf(6808.46), crossdockOrderHeaderEntity.getNetWeightAmt());
        assertEquals(630, crossdockOrderHeaderEntity.getCrossdockOrderQty());
    }

    @Test
    public void finalizeCrossDockOrderHeadersTest() throws Exception {
        //need to set header id that has a skope order not complete and will create a new header
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = crossdockOrderHeaderRepo.getOne(5587990);
        List<CrossdockOrderHeaderEntity> crossdockOrderHeaderEntityList = new ArrayList<>();
        CrossdockStoreMapEntity crossdockStoreMapEntity = crossdockStoreMapRepo.getOne(31658);
        SkopeCrossdockOrderXrefEntity xrefToStay = skopeCrossdockOrderXrefRepo.findFirstByCrossdockOrderIdAndAndSkopeOrderId(5587990, 9999998).get();
        SkopeCrossdockOrderXrefEntity xrefToMove = skopeCrossdockOrderXrefRepo.findFirstByCrossdockOrderIdAndAndSkopeOrderId(5587990, 9999999).get();

        for (SkopeCrossdockOrderXrefEntity skopeCrossdockOrderXrefEntity : crossdockOrderHeaderEntity.getSkopeCrossdockOrderXrefsByCrossdockOrderId()) {
            skopeCrossdockOrderXrefEntity.getSkopeOrderBySkopeOrderId().setCrossdockStoreMap(crossdockStoreMapEntity);
        }

        MutableBoolean sendToWin = new MutableBoolean();
        sendToWin.setValue(false);
        crossdockOrderHeaderEntityList.add(crossdockOrderHeaderEntity);
        asnRouteCloseService.finalizeCrossDockOrderHeaders(crossdockOrderHeaderEntityList, sendToWin);

        assertNotEquals(0, crossdockOrderHeaderEntity.getSkopeCrossdockOrderXrefsByCrossdockOrderId().size());
        assertTrue(crossdockOrderHeaderEntity.getSkopeCrossdockOrderXrefsByCrossdockOrderId().contains(xrefToStay));
        assertFalse(crossdockOrderHeaderEntity.getSkopeCrossdockOrderXrefsByCrossdockOrderId().contains(xrefToMove));
    }

    @Test
    //4.5.2
    //match skopeOrder with crossdockOrderHeader DSD
    public void processCrossDockHeadersMatchHeaderDSDTest() throws Exception {
        //header "55879334" exists for this DSD skopeOrder
        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08019");
        skopeOrderEntity.setCrossdockStoreMap(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585));
        skopeOrderEntity.setCrossdockCatalogGroupMapEntity(crossdockStoreMapRepo.findByCrossdockStoreMapId(31585).getCrossdockMapByCrossdockMapId().getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId());

        HashMap<String, SkopeOrderEntity> mappedSkopeOrders = new HashMap<>();
        mappedSkopeOrders.put(skopeOrderEntity.getSkopeOrderNo(), skopeOrderEntity);

        CrossdockRouteEntity crossdockRouteEntity = crossdockRouteRepo.findByRouteId(3387865);

        Map<String, CrossdockOrderHeaderEntity> crossdockOrderHeaderBySkopeOrderMap = asnRouteCloseService.processCrossDockHeaders(mappedSkopeOrders, crossdockRouteEntity );

        //Verify Crossdock order is not cancelled (cancel ts is null)
        // DSD (delivery_type_cd is D)
        // not already closed by a route close (origin_complete_ts  is null)
        assertEquals(5587994, crossdockOrderHeaderBySkopeOrderMap.get("08019").getCrossdockOrderId());
        assertNull(crossdockOrderHeaderBySkopeOrderMap.get("08019").getCrossdockOrderCancelTs());
        assertEquals("D",crossdockOrderHeaderBySkopeOrderMap.get("08019").getDeliveryTypeCd());
    }

    @Test
    public void BuildCrossDockOrderTypeList() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        ASNShipmentEvent asnShipmentEvent = objectMapper.readValue(new File("src/test/resources/asnShipmentExistingHeaderOneSkopeOrderNotOriginComplete.json"), ASNShipmentEvent.class);
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = crossdockOrderHeaderRepo.getOne(5587990);
        CrossdockRouteEntity crossdockRouteEntity = crossdockRouteRepo.findByRouteId(3387865);
        List<CrossdockOrderHeaderEntity> crossdockHeaderList = new ArrayList<>();
        crossdockHeaderList.add(crossdockOrderHeaderEntity);

        List<CrossDockOrderType> crossDockOrderTypes =  asnRouteCloseService.buildCrossDockOrderTypeList(crossdockHeaderList,asnShipmentEvent.getAsnShipment(),crossdockRouteEntity);

        assertEquals("024",crossDockOrderTypes.get(0).getOrderManagementDivisionNumber());
        assertEquals("00001",crossDockOrderTypes.get(0).getOrderNumber());
        assertEquals("00346",crossDockOrderTypes.get(0).getStoreNumber());
        assertEquals("FMD",crossDockOrderTypes.get(0).getCatalogGroupNumber());
        assertEquals("017",crossDockOrderTypes.get(0).getOriginSourcingFacility().getSourceID());
        assertEquals("024", crossDockOrderTypes.get(0).getCrossDockingFacility().getSourceID());
        //logic sets cancel flag to N if cancel timestamp is NULL   next 2 lines of code check this
        assertNull(crossdockHeaderList.get(0).getCrossdockOrderCancelTs());
        assertEquals(FlagType.N,crossDockOrderTypes.get(0).getCanceledFlag());
        assertEquals(0, crossDockOrderTypes.get(0).getRouteClose().getLoads().getLoad().size());

    }

}
