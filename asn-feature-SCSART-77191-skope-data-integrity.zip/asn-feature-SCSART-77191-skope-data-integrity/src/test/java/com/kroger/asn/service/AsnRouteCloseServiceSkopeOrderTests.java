package com.kroger.asn.service;

import com.kroger.asn.dto.asnshipmentdata.SkopeOrder;
import com.kroger.asn.entities.CrossdockStoreMapEntity;
import com.kroger.asn.entities.SkopeOrderEntity;
import com.kroger.asn.entities.SourcingFacilityEntity;
import com.kroger.asn.repositories.CrossdockMapRepo;
import com.kroger.asn.repositories.CrossdockStoreMapRepo;
import com.kroger.asn.repositories.SkopeOrderRepo;
import com.kroger.asn.repositories.SourcingFacilityRepo;
import com.kroger.asn.util.errors.SkopeOrderValidationException;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.*;
import org.codehaus.jackson.map.ObjectMapper;
import org.hamcrest.CoreMatchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@ActiveProfiles({ "unittest", "SPOOFING" })
public class AsnRouteCloseServiceSkopeOrderTests {

    @Autowired
    AsnRouteCloseService asnRouteCloseService;

    @Autowired
    CrossdockStoreMapRepo crossdockStoreMapRepo;

    @Autowired
    CrossdockMapRepo crossdockMapRepo;

    @Autowired
    SkopeOrderRepo skopeOrderRepo;

    @Autowired
    SourcingFacilityRepo sourcingFacilityRepo;



    Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

    @Test
    public void testCreateSkopeOrder() {
        //given a valid skopeOrder object, return a valid skopeOrderEntity
        Date dt = Date.valueOf("2012-12-21");

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setFacilityId(10L);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setRoute("TEST");

        CrossdockStoreMapEntity crossdockStoreMap = crossdockStoreMapRepo.findByCrossdockStoreMapId(31585);
        SkopeOrderEntity skopeOrderEntity = asnRouteCloseService.createSkopeOrder(skopeOrder, crossdockStoreMap);

        assertEquals("014", skopeOrderEntity.getOrderBillingDivisionNo());
        assertEquals("12.0", skopeOrderEntity.getSkopeNetWeightAmt().toString());

        skopeOrderRepo.save(skopeOrderEntity);
        SkopeOrderEntity savedSkopeOrder = skopeOrderRepo.save(skopeOrderEntity);

        int id = savedSkopeOrder.getSkopeOrderId();
        SkopeOrderEntity newRecord = skopeOrderRepo.findById(id).orElseThrow(() -> new EntityNotFoundException(String.valueOf(id)));

        assertEquals(id, newRecord.getSkopeOrderId());
        assertEquals("014", newRecord.getOrderBillingDivisionNo());

    }

    @Test
    public void testCreateSkopeOrderEntityNotFoundException() {
        //given a invalid skopeOrder object, throw exception
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            Date dt = Date.valueOf("2012-12-21");

            SkopeOrder skopeOrder = new SkopeOrder();
            skopeOrder.setOrderBillingDivisionNo("014");
            skopeOrder.setSkopeOrderNo("Test");
            skopeOrder.setOrderDeliveryDate(dt);
            skopeOrder.setStoreId((long) 278);
            skopeOrder.setCatalogGroupId((long) 537);
            skopeOrder.setOriginFacilityOrderCompleteTime(dt);
            skopeOrder.setGrossCubeAmt(12.0);
            skopeOrder.setNetWeightAmt(12.0);
            skopeOrder.setOrderQty(12);

            //invalid OrderManagementDivisionId
            skopeOrder.setOrderManagementDivisionId((long) 100);

            CrossdockStoreMapEntity crossdockStoreMap = crossdockStoreMapRepo.findByCrossdockStoreMapId(31585);
            SkopeOrderEntity skopeOrderEntity = asnRouteCloseService.createSkopeOrder(skopeOrder, crossdockStoreMap);

        });


        assertEquals("Unable to find OrderManagementDivision with id 100", exception.getMessage());

    }

    @Test
    public void testFindCrossDockMapForSkopeOrder() {
        //given a valid skopeOrder object, find a compatible crossDockMap
        Date dt = Date.valueOf("2012-12-21");

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setFacilityId((long) 10);

        CrossdockStoreMapEntity crossdockStoreMap = asnRouteCloseService.findCrossDockMapForSkopeOrder(skopeOrder);

        assertEquals(31585, crossdockStoreMap.getCrossdockStoreMapId());
    }

    @Test
    public void testFindCrossDockMapForSkopeOrderCrossdockStoreMapNull() {
        //given a invalid skopeOrder object, do not find a compatible crossDockMap
        Date dt = Date.valueOf("2012-12-21");

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setFacilityId((long) 10);

        // invalid store ID to create null crossdockStoreMap
        skopeOrder.setStoreId((long) 1);

        CrossdockStoreMapEntity crossdockStoreMap = asnRouteCloseService.findCrossDockMapForSkopeOrder(skopeOrder);

        assertNull(crossdockStoreMap);
    }

    @Test
    public void testFindCrossDockMapForSkopeOrder14day() {
        //given a valid skopeOrder object, find a compatible crossDockMap with 14 day schedule
        Date dt = Date.valueOf("2012-12-21");

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);

        skopeOrder.setFacilityId((long) 10);

        CrossdockStoreMapEntity crossdockStoreMap = asnRouteCloseService.findCrossDockMapForSkopeOrder(skopeOrder);

        assertEquals(31585, crossdockStoreMap.getCrossdockStoreMapId());

    }

    @Test
    public void testFindCrossDockMapForSkopeOrderCrossdockStoreMapNullNoAvailableDay() {
        //given a valid skopeOrder object with invalid date, do not find a compatible crossDockMap
        Date dt = Date.valueOf("2012-12-20");//date changed to invalid delivery date

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);

        skopeOrder.setFacilityId((long) 10);

        CrossdockStoreMapEntity crossdockStoreMap = asnRouteCloseService.findCrossDockMapForSkopeOrder(skopeOrder);

        assertNull(crossdockStoreMap);

    }

    @Test
    public void testFindCrossDockMapForSkopeOrderCrossdockStoreMapNullMarkedIgnore() {
        //given a valid skopeOrder object with a date marked ignore, do not find a compatible crossDockMap
        Date dt = Date.valueOf("2012-12-19");//date changed to ignored delivery date

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);

        skopeOrder.setFacilityId((long) 10);

        CrossdockStoreMapEntity crossdockStoreMap = asnRouteCloseService.findCrossDockMapForSkopeOrder(skopeOrder);

        assertNull(crossdockStoreMap);

    }


    // Use case 4.1.1 "skope order is mapped in Crossdock, skope order exists in Crossdock, and  SKOPE order is NOT complete in database.
    // But always assume vendor is sending completed SKOPE orders. Currently no skope order complete flag in JSON SCHEMA"
    @Test
    public void testProcessSkopeOrdersOrderAlreadyExists() throws Exception {

        Date dt = Date.valueOf("2012-12-21");

        SkopeOrder skopeOrder = new SkopeOrder();
        SkopeOrder skopeOrder1 = new SkopeOrder();

        //orders have completed timestamp, orders in database do not
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("08095");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(20.00);
        skopeOrder.setNetWeightAmt(50.00);
        skopeOrder.setOrderQty(8);
        skopeOrder.setFacilityId((long) 10);

        skopeOrder1.setOrderBillingDivisionNo("014");
        skopeOrder1.setSkopeOrderNo("08017");
        skopeOrder1.setOrderDeliveryDate(dt);
        skopeOrder1.setOrderManagementDivisionId((long) 2);
        skopeOrder1.setStoreId((long) 278);
        skopeOrder1.setCatalogGroupId((long) 537);
        skopeOrder1.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder1.setGrossCubeAmt(40.00);
        skopeOrder1.setNetWeightAmt(80.00);
        skopeOrder1.setOrderQty(9);
        skopeOrder1.setFacilityId((long) 10);

        List<SkopeOrder> skopeOrders = new ArrayList<>();
        skopeOrders.add(skopeOrder);
        skopeOrders.add(skopeOrder1);

        //process skope orders updates 2 orders
        Map<String, SkopeOrderEntity> mappedSkopeOrders = asnRouteCloseService.processSkopeOrders(skopeOrders, null);
        assertEquals(2, mappedSkopeOrders.size());

        //order updated is the original order verified by primary key SKOPE_ID
        assertEquals(9751614, mappedSkopeOrders.get("08095").getSkopeOrderId());
        assertEquals(9751604, mappedSkopeOrders.get("08017").getSkopeOrderId());

        SkopeOrderEntity skopeOrderEntity = skopeOrderRepo.findBySkopeOrderNo("08095");
        SkopeOrderEntity skopeOrderEntity2 = skopeOrderRepo.findBySkopeOrderNo("08017");

        //both the hash map and database now have complete timestamps
        assertNotNull(skopeOrderEntity.getSourceFacilityOrderCmplTs());
        assertNotNull(mappedSkopeOrders.get("08095").getSourceFacilityOrderCmplTs());

        assertNotNull(skopeOrderEntity2.getSourceFacilityOrderCmplTs());
        assertNotNull(mappedSkopeOrders.get("08017").getSourceFacilityOrderCmplTs());

    }

    @Test
    //Use case 4.4.1 "create SKOPE order"
    //ASN Route Close message with load from Vendor - SKOPE order does not exist in the Crossdock database and is mapped and assume SKOPE order is complete in the vendor JSON.
    public void testProcessSkopeOrdersNewSkopeOrder() throws Exception {
        Date dt = Date.valueOf("2012-12-21");

        // 2 new SKOPE orders
        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("TEST");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setFacilityId((long) 10);
        skopeOrder.setRoute("TEST");

        SkopeOrder skopeOrder1 = new SkopeOrder();
        skopeOrder1.setOrderBillingDivisionNo("014");
        skopeOrder1.setSkopeOrderNo("TEST1");
        skopeOrder1.setOrderDeliveryDate(dt);
        skopeOrder1.setOrderManagementDivisionId((long) 2);
        skopeOrder1.setStoreId((long) 278);
        skopeOrder1.setCatalogGroupId((long) 537);
        skopeOrder1.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder1.setGrossCubeAmt(12.0);
        skopeOrder1.setNetWeightAmt(0.0);
        skopeOrder1.setOrderQty(12);
        skopeOrder1.setFacilityId((long) 10);
        skopeOrder1.setRoute("TEST1");

        List<SkopeOrder> skopeOrders = new ArrayList<>();
        skopeOrders.add(skopeOrder);
        skopeOrders.add(skopeOrder1);

        //hash map contains two orders
        Map<String, SkopeOrderEntity> mappedSkopeOrders = asnRouteCloseService.processSkopeOrders(skopeOrders, null);
        assertEquals(2, mappedSkopeOrders.size());

        SkopeOrderEntity returnedSkopeOrder1 = mappedSkopeOrders.get("TEST");
        SkopeOrderEntity returnedSkopeOrder2 = mappedSkopeOrders.get("TEST1");

        //Assert that the orders inserted in db and returned is equal to the json data (skopeorder)
        assertEquals(skopeOrder.getSkopeOrderNo(),returnedSkopeOrder1.getSkopeOrderNo());
        assertEquals(skopeOrder1.getSkopeOrderNo(),returnedSkopeOrder2.getSkopeOrderNo());


        assertNotNull(returnedSkopeOrder1.getSourceFacilityOrderCmplTs());
        assertNotNull(returnedSkopeOrder2.getSourceFacilityOrderCmplTs());
        assertNotNull(returnedSkopeOrder1.getOrderManagementDivisionId());
        assertNotNull(returnedSkopeOrder2.getOrderManagementDivisionId());
        assertNotNull(returnedSkopeOrder1.getStoreId());
        assertNotNull(returnedSkopeOrder2.getStoreId());
        assertNotNull(returnedSkopeOrder1.getCatalogGroupId());
        assertNotNull(returnedSkopeOrder2.getCatalogGroupId());

    }

    @Test
    //Use case 4.8.1 Route Close message with load from Vendor - SKOPE order marked cancelled
    // "System does nothing and skips this SKOPE order since order already marked cancelled in the database"
    public void testProcessSkopeOrdersOrderCancelled() throws Exception {

        Date dt = Date.valueOf("2012-12-21");

        //maps to skopeOrderEntity that is cancelled in the database
        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("07939");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setFacilityId((long) 10);
        skopeOrder.setRoute("TEST");

        //new SKOPE order
        SkopeOrder skopeOrder1 = new SkopeOrder();
        skopeOrder1.setOrderBillingDivisionNo("014");
        skopeOrder1.setSkopeOrderNo("Test1");
        skopeOrder1.setOrderDeliveryDate(dt);
        skopeOrder1.setOrderManagementDivisionId((long) 2);
        skopeOrder1.setStoreId((long) 278);
        skopeOrder1.setCatalogGroupId((long) 537);
        skopeOrder1.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder1.setGrossCubeAmt(12.0);
        skopeOrder1.setNetWeightAmt(0.0);
        skopeOrder1.setOrderQty(12);
        skopeOrder1.setFacilityId((long) 10);
        skopeOrder1.setRoute("TEST1");

        List<SkopeOrder> skopeOrders = new ArrayList<>();
        skopeOrders.add(skopeOrder);
        skopeOrders.add(skopeOrder1);

        //processSkopeOrders given 2 skope orders passes over cancelled order
        Map<String, SkopeOrderEntity> mappedSkopeOrders = asnRouteCloseService.processSkopeOrders(skopeOrders, null);
        assertEquals(1, mappedSkopeOrders.size());

        //mapped SKOPE order (07939) is cancelled and should not be returned
        assertNull(mappedSkopeOrders.get("07939"));
    }


    @Test
    public void testProcessSkopeOrdersCrossdockStoreMapNull() throws Exception {
        Date dt = Date.valueOf("2012-12-21");

        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("Test");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setFacilityId((long) 10);

        // invalid store ID to create null crossdockStoreMap
        skopeOrder.setStoreId((long) 1);

        List<SkopeOrder> skopeOrders = new ArrayList<>();
        skopeOrders.add(skopeOrder);

        ASNShipment asnShipment = new ASNShipment();
        ShipmentData shipmentData = new ShipmentData();
        Pallet pallet = new Pallet();
        List<Pallet> palletList = new ArrayList<>();
        List<String> orderIdReferences = new ArrayList<>();
        orderIdReferences.add("12345");
        pallet.setOrderIdReferences(orderIdReferences);
        asnShipment.setShipmentData(shipmentData);
        palletList.add(pallet);
        asnShipment.getShipmentData().setPallets(palletList);
        //invalid map has been skipped over
        Map<String, SkopeOrderEntity> mappedSkopeOrders = asnRouteCloseService.processSkopeOrders(skopeOrders, asnShipment.getShipmentData().getPallets());
        assertEquals(0, mappedSkopeOrders.size());

    }

    @Test
    public void testProcessSkopeOrdersOrderCompleted() throws Exception {
        Date dt = Date.valueOf("2012-12-21");
        Timestamp ts = Timestamp.valueOf("2019-04-10 12:17:36.0");

        //maps to skopeOrderEntity that is already completed in the database
        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setOrderBillingDivisionNo("014");
        skopeOrder.setSkopeOrderNo("07403");
        skopeOrder.setOrderDeliveryDate(dt);
        skopeOrder.setOrderManagementDivisionId((long) 2);
        skopeOrder.setStoreId((long) 278);
        skopeOrder.setCatalogGroupId((long) 537);
        skopeOrder.setOriginFacilityOrderCompleteTime(dt);
        skopeOrder.setGrossCubeAmt(12.0);
        skopeOrder.setNetWeightAmt(12.0);
        skopeOrder.setOrderQty(12);
        skopeOrder.setFacilityId((long) 10);

        List<SkopeOrder> skopeOrders = new ArrayList<>();
        skopeOrders.add(skopeOrder);

        //completed SKOPE order has been skipped over
        Map<String, SkopeOrderEntity> mappedSkopeOrders = asnRouteCloseService.processSkopeOrders(skopeOrders, null);
        assertEquals(0, mappedSkopeOrders.size());

    }

    @Test
    public void testValidateSkopeOrder(){
        List<String> validationErrors = new ArrayList<>();

        assertDoesNotThrow(() -> {
            String routeName = "Test12";
            String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                    new EntityNotFoundException("Unable to find origin facility."));
            Order order = Order.newBuilder().setId("014271590").setStoreNumber("00406").setStoreDeliveryDate("2125-01-01")
                    .setCatalogGroupNumber("MLK").setOrderManagementDivisionNumber("014").setCube(12).setWeight(401.305f).setCases(10).build();

            SkopeOrder skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);

            assertNotNull(skopeOrder);
            assertEquals(2L, skopeOrder.getOrderManagementDivisionId().longValue());
            assertEquals(357L, skopeOrder.getCatalogGroupId().longValue());
            assertEquals(278L, skopeOrder.getStoreId().longValue());
            assertEquals(0, validationErrors.size());
        });



    }

    @Test
    public void testValidateSkopeOrderWithOrderDeliveryDateInPast(){
        List<String> validationErrors = new ArrayList<>();
        String routeName = "Test12";
        String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
        SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                new EntityNotFoundException("Unable to find origin facility."));
        Order order = Order.newBuilder().setId("014271590").setStoreNumber("00406").setStoreDeliveryDate("2001-01-01")
                .setCatalogGroupNumber("MLK").setOrderManagementDivisionNumber("014").setCube(12).setWeight(401.305f).setCases(10).build();

        SkopeOrder skopeOrder = null;
        try {
            skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);
        } catch (SkopeOrderValidationException e) {
            e.printStackTrace();
        }

        assertNull(skopeOrder);
        assertEquals(1, validationErrors.size());
        assertEquals("SKOPE Order delivery date must be in the future", validationErrors.get(0));
}

    @Test
    public void testValidateSkopeOrderWithOrderDeliveryDateInvalidFormat(){
        List<String> validationErrors = new ArrayList<>();
        String routeName = "Test12";
        String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
        SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                new EntityNotFoundException("Unable to find origin facility."));
        Order order = Order.newBuilder().setId("014271590").setStoreNumber("00406").setStoreDeliveryDate("02-10-2099")
                .setCatalogGroupNumber("MLK").setOrderManagementDivisionNumber("014").setCube(12).setWeight(401.305f).setCases(10).build();

        SkopeOrder skopeOrder = null;
        try {
            skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);
        } catch (SkopeOrderValidationException e) {
            e.printStackTrace();
        }

        assertNull(skopeOrder);
        assertEquals(1, validationErrors.size());
        assertThat(validationErrors.get(0), CoreMatchers.containsString("Unable to parse delivery date:"));
    }

    @Test
    public void testValidateSkopeOrderStoreEntityNull(){
        List<String> validationErrors = new ArrayList<>();
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            String routeName = "Test12";
            String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                    new EntityNotFoundException("Unable to find origin facility."));
            Order order = Order.newBuilder().setId("014271590").setStoreNumber("11111").setStoreDeliveryDate("2125-01-01")
                    .setCatalogGroupNumber("MLK").setOrderManagementDivisionNumber("014").setCube(12).setWeight(401.305f).setCases(10).build();

            SkopeOrder skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);

        });

        assertEquals("Unable to find Entity for Store when validating SKOPE Order", exception.getMessage());
        assertEquals(1, validationErrors.size());
        assertThat(validationErrors.get(0), CoreMatchers.containsString("Store not found in store table. Order Management Division:"));
    }

    @Test
    public void testValidateSkopeOrderCatalogGroupEntityNull(){
        List<String> validationErrors = new ArrayList<>();

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            String routeName = "Test12";
            String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                    new EntityNotFoundException("Unable to find origin facility."));
            Order order = Order.newBuilder().setId("014271590").setStoreNumber("11111").setStoreDeliveryDate("2125-01-01")
                    .setCatalogGroupNumber("MMM").setOrderManagementDivisionNumber("014").setCube(12).setWeight(401.305f).setCases(10).build();

            SkopeOrder skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);


        });

        assertEquals("Unable to find Entity for OrderManagementDivision or CatalogGroup when validating SKOPE Order", exception.getMessage());
        assertEquals(1, validationErrors.size());
        assertEquals("Catalog group MMM for facility 014 was not found in the catalog group table", validationErrors.get(0));
    }

    @Test
    public void testValidateSkopeOrderWithOrderManagementDivisionEntityNull(){
        List<String> validationErrors = new ArrayList<>();
        Exception exception = assertThrows(EntityNotFoundException.class, () -> {
            String routeName = "Test12";
            String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                    new EntityNotFoundException("Unable to find origin facility."));
            Order order = Order.newBuilder().setId("014271590").setStoreNumber("11111").setStoreDeliveryDate("2125-01-01")
                    .setCatalogGroupNumber("MLK").setOrderManagementDivisionNumber("099").setCube(12).setWeight(401.305f).setCases(10).build();
            SkopeOrder skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);

        });

        assertEquals("Unable to find Entity for OrderManagementDivision or CatalogGroup when validating SKOPE Order", exception.getMessage());
        assertEquals(1, validationErrors.size());
        assertEquals("Order management division number 099 not found in table", validationErrors.get(0));
    }

    @Test
    public void testValidateSkopeOrderCatalogGroupEntityAndOrderManagementDivisionEntityBothNull(){
        List<String> validationErrors = new ArrayList<>();

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            String routeName = "Test12";
            String originFacilityShipmentTs = "2015-02-10T01:58:09-05:00";
            SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                    new EntityNotFoundException("Unable to find origin facility."));
            Order order = Order.newBuilder().setId("014271590").setStoreNumber("11111").setStoreDeliveryDate("2125-01-01")
                    .setCatalogGroupNumber("MMM").setOrderManagementDivisionNumber("099").setCube(12).setWeight(401.305f).setCases(10).build();

            SkopeOrder skopeOrder = asnRouteCloseService.validateSkopeOrder(order, originFacility, validationErrors, routeName, currentTimestamp);
        });

        assertEquals("Unable to find Entity for OrderManagementDivision or CatalogGroup when validating SKOPE Order", exception.getMessage());
        assertEquals(2, validationErrors.size());
        assertEquals("Order management division number 099 not found in table", validationErrors.get(0));
        assertEquals("Catalog group MMM for facility 014 was not found in the catalog group table", validationErrors.get(1));
    }

    @Test
    public void testValidateSkopeRecords() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        ASNShipment asnShipment = objectMapper.readValue(new File("src/test/resources/asnShipmentData.json"), ASNShipment.class);
        SourcingFacilityEntity originFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                new EntityNotFoundException("Unable to find origin facility."));
        TreeMap<String, List<String>> validationErrorsByOrder = new TreeMap<>();
        List<SkopeOrder> validSkopeOrders = new ArrayList<>();

        validSkopeOrders = asnRouteCloseService.validateSkopeRecords(asnShipment.getShipmentData().getOrders(),originFacility,validationErrorsByOrder, currentTimestamp, asnShipment.getShipmentData().getRouteName());

        assertEquals(2,validSkopeOrders.size());
        assertEquals(0, validationErrorsByOrder.size());
    }

}