package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockLoadEntity;
import com.kroger.asn.repositories.CrossdockLoadRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockLoadRepositoryTests {

    @Autowired
    CrossdockLoadRepo crossdockLoadRepo;

    @Test
    public void testFindall() {
        List<CrossdockLoadEntity> crossdockLoad = crossdockLoadRepo.findAll();
        assertEquals(12631313, crossdockLoad.get(0).getCrossdockLoadId());
        assertEquals("010500017010648944", crossdockLoad.get(0).getLoadNo());
        assertEquals("37.86", crossdockLoad.get(0).getGrossCubeAmt().toString());
        assertNotEquals(0, crossdockLoad.size());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockLoadEntity> crossdockLoad = crossdockLoadRepo.findAll();
        BigDecimal bd = new BigDecimal(12.12);

        crossdockLoad.get(0).setCrossdockLoadId(12345678);
        crossdockLoad.get(0).setLoadNo("123456789101112131");
        crossdockLoad.get(0).setGrossCubeAmt(bd);

        assertEquals(12345678, crossdockLoad.get(0).getCrossdockLoadId());
        assertEquals("123456789101112131", crossdockLoad.get(0).getLoadNo());
        assertEquals(bd, crossdockLoad.get(0).getGrossCubeAmt());
    }
}
