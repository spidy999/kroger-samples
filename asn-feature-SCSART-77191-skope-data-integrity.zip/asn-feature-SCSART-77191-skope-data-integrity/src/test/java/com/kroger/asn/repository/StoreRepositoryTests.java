package com.kroger.asn.repository;

import com.kroger.asn.entities.StoreEntity;
import com.kroger.asn.repositories.StoreRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class StoreRepositoryTests {

    @Autowired
    StoreRepo storeRepo;

    @Test
    public void testFindall() {
        List<StoreEntity> store = storeRepo.findAll();
        assertEquals(278, store.get(0).getStoreId());
        assertEquals("00406", store.get(0).getStoreNo());
        assertEquals("Kroger", store.get(0).getStoreNme());
        assertEquals("05", store.get(0).getManagementZoneCd());
    }

    @Test
    public void testSetMethods() {
        List<StoreEntity> store = storeRepo.findAll();
        store.get(0).setStoreId(123);
        store.get(0).setStoreNo("12345");
        store.get(0).setStoreNme("Test Store");
        store.get(0).setManagementZoneCd("01");

        assertEquals(123, store.get(0).getStoreId());
        assertEquals("12345", store.get(0).getStoreNo());
        assertEquals("Test Store", store.get(0).getStoreNme());
        assertEquals("01", store.get(0).getManagementZoneCd());
    }
}
