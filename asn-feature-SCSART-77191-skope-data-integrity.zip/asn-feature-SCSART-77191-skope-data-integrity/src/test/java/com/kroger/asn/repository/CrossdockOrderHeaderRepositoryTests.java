package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockOrderHeaderEntity;
import com.kroger.asn.repositories.CrossdockOrderHeaderRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.TimeZone;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockOrderHeaderRepositoryTests {

    @Autowired
    CrossdockOrderHeaderRepo crossdockOrderHeaderRepo;

    private Logger logger = LoggerFactory.getLogger(CrossdockOrderHeaderRepositoryTests.class);

    @Test
    public void testFindall() {
        List<CrossdockOrderHeaderEntity> crossdockOrderHeader = crossdockOrderHeaderRepo.findAll();
        logger.info("What is COH Value??? [{}]",crossdockOrderHeader.get(0).toString());
        logger.info("Timezone?? [{}]", TimeZone.getDefault());
        assertEquals(5587973, crossdockOrderHeader.get(0).getCrossdockOrderId());
        assertEquals("024", crossdockOrderHeader.get(0).getOrderBillingDivisionNo());
        assertEquals("87973", crossdockOrderHeader.get(0).getCrossdockOrderNo());
        assertEquals("149.95", crossdockOrderHeader.get(0).getGrossCubeAmt().toString());
        assertNull(crossdockOrderHeader.get(0).getGrossCubeUomVlu());
        assertEquals("3959.57", crossdockOrderHeader.get(0).getNetWeightAmt().toString());
        assertNull(crossdockOrderHeader.get(0).getNetWeightUomVlu());
        assertEquals(354, crossdockOrderHeader.get(0).getCrossdockOrderQty());
        assertEquals("2019-04-09 03:15:02.0", crossdockOrderHeader.get(0).getCrossdockOrderReleaseTs().toString());
        assertEquals("2019-04-10", crossdockOrderHeader.get(0).getCrossdockOrderDeliveryDt().toString());
        assertEquals("C", crossdockOrderHeader.get(0).getDeliveryTypeCd());
        assertEquals("2019-04-09 01:53:04.0", crossdockOrderHeader.get(0).getOriginOrderCompleteTs().toString());
        assertEquals("2019-04-10 00:37:55.0", crossdockOrderHeader.get(0).getCrossdockOrderCompleteTs().toString());
        assertNull(crossdockOrderHeader.get(0).getCrossdockOrderCancelTs());
        assertEquals("N", crossdockOrderHeader.get(0).getNetWeightAmtChangedFlg());
        assertEquals("N", crossdockOrderHeader.get(0).getGrossCubeAmtChangedFlg());
        assertEquals("2019-04-09 01:53:10.0", crossdockOrderHeader.get(0).getRowCreateTs().toString());
        assertEquals("2019-04-09 03:15:02.0", crossdockOrderHeader.get(0).getRowUpdateTs().toString());
        assertEquals("anonymou", crossdockOrderHeader.get(0).getRowCreateId());
        assertEquals("BC50718", crossdockOrderHeader.get(0).getRowUpdateId());
        assert crossdockOrderHeader.get(0).getOriginRouteId() ==3385840;
        assert crossdockOrderHeader.get(0).getCrossdockRouteId() == 3387242;
        assertNotEquals(0, crossdockOrderHeader.size());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockOrderHeaderEntity> crossdockOrderHeader = crossdockOrderHeaderRepo.findAll();
        Timestamp ts = Timestamp.valueOf("2019-04-10 12:17:36.0");
        Date dt = Date.valueOf("2012-12-21");
        BigDecimal bd = new BigDecimal(12.12);

        crossdockOrderHeader.get(0).setCrossdockOrderId(1234567);
        crossdockOrderHeader.get(0).setOrderBillingDivisionNo("123");
        crossdockOrderHeader.get(0).setCrossdockOrderNo("12345");
        crossdockOrderHeader.get(0).setGrossCubeAmt(bd);
        crossdockOrderHeader.get(0).setGrossCubeUomVlu("test");
        crossdockOrderHeader.get(0).setNetWeightAmt(bd);
        crossdockOrderHeader.get(0).setNetWeightUomVlu("test");
        crossdockOrderHeader.get(0).setCrossdockOrderQty(123);
        crossdockOrderHeader.get(0).setCrossdockOrderReleaseTs(ts);
        crossdockOrderHeader.get(0).setCrossdockOrderDeliveryDt(dt);
        crossdockOrderHeader.get(0).setDeliveryTypeCd("T");
        crossdockOrderHeader.get(0).setOriginOrderCompleteTs(ts);
        crossdockOrderHeader.get(0).setCrossdockOrderCompleteTs(ts);
        crossdockOrderHeader.get(0).setCrossdockOrderCancelTs(ts);
        crossdockOrderHeader.get(0).setNetWeightAmtChangedFlg("T");
        crossdockOrderHeader.get(0).setGrossCubeAmtChangedFlg("T");
        crossdockOrderHeader.get(0).setRowCreateTs(ts);
        crossdockOrderHeader.get(0).setRowUpdateTs(ts);
        crossdockOrderHeader.get(0).setRowCreateId("TEST123");
        crossdockOrderHeader.get(0).setRowUpdateId("TEST123");
        crossdockOrderHeader.get(0).setOriginRouteId(1234567);
        crossdockOrderHeader.get(0).setCrossdockRouteId(1234567);

        assertEquals(1234567, crossdockOrderHeader.get(0).getCrossdockOrderId());
        assertEquals("123", crossdockOrderHeader.get(0).getOrderBillingDivisionNo());
        assertEquals("12345", crossdockOrderHeader.get(0).getCrossdockOrderNo());
        assertEquals(bd, crossdockOrderHeader.get(0).getGrossCubeAmt());
        assertEquals("test", crossdockOrderHeader.get(0).getGrossCubeUomVlu());
        assertEquals(bd, crossdockOrderHeader.get(0).getNetWeightAmt());
        assertEquals("test", crossdockOrderHeader.get(0).getNetWeightUomVlu());
        assertEquals(123, crossdockOrderHeader.get(0).getCrossdockOrderQty());
        assertEquals(ts, crossdockOrderHeader.get(0).getCrossdockOrderReleaseTs());
        assertEquals(dt, crossdockOrderHeader.get(0).getCrossdockOrderDeliveryDt());
        assertEquals("T", crossdockOrderHeader.get(0).getDeliveryTypeCd());
        assertEquals(ts, crossdockOrderHeader.get(0).getOriginOrderCompleteTs());
        assertEquals(ts, crossdockOrderHeader.get(0).getCrossdockOrderCompleteTs());
        assertEquals(ts, crossdockOrderHeader.get(0).getCrossdockOrderCancelTs());
        assertEquals("T", crossdockOrderHeader.get(0).getNetWeightAmtChangedFlg());
        assertEquals("T", crossdockOrderHeader.get(0).getGrossCubeAmtChangedFlg());
        assertEquals(ts, crossdockOrderHeader.get(0).getRowCreateTs());
        assertEquals(ts, crossdockOrderHeader.get(0).getRowUpdateTs());
        assertEquals("TEST123", crossdockOrderHeader.get(0).getRowCreateId());
        assert crossdockOrderHeader.get(0).getRowUpdateId().equals("TEST123");
        assert crossdockOrderHeader.get(0).getOriginRouteId() == 1234567;
        assert crossdockOrderHeader.get(0).getCrossdockRouteId() == 1234567;
    }

    @Test
    public void testCrossdockOrderHeaderClone(){
        CrossdockOrderHeaderEntity crossdockOrderHeaderEntity = crossdockOrderHeaderRepo.getOne(5587974);

        CrossdockOrderHeaderEntity clonedHeader = new CrossdockOrderHeaderEntity(crossdockOrderHeaderEntity);

        assertEquals(0, clonedHeader.getCrossdockOrderId());
        assertNull(clonedHeader.getCrossdockOrderNo());
        assertNull(clonedHeader.getOriginOrderCompleteTs());
        assertNull(clonedHeader.getOriginRouteId());
        assertNull(clonedHeader.getCrossdockRouteId());
        assertEquals(BigDecimal.valueOf(0), clonedHeader.getNetWeightAmt());
        assertEquals(BigDecimal.valueOf(0), clonedHeader.getGrossCubeAmt());
        assertEquals(0, clonedHeader.getCrossdockOrderQty());
        assertEquals(0, clonedHeader.getSkopeCrossdockOrderXrefsByCrossdockOrderId().size());


        assertNotEquals(crossdockOrderHeaderEntity.getCrossdockOrderId(), clonedHeader.getCrossdockOrderId());
        assertNotEquals(crossdockOrderHeaderEntity.getCrossdockOrderNo(), clonedHeader.getCrossdockOrderNo());
        assertNotEquals(crossdockOrderHeaderEntity.getOriginOrderCompleteTs(), clonedHeader.getOriginOrderCompleteTs());
        assertNotEquals(crossdockOrderHeaderEntity.getOriginRouteId(), clonedHeader.getOriginRouteId());
        assertNotEquals(crossdockOrderHeaderEntity.getCrossdockRouteId(), clonedHeader.getCrossdockRouteId());
        assertNotEquals(crossdockOrderHeaderEntity.getNetWeightAmt(), clonedHeader.getNetWeightAmt());
        assertNotEquals(crossdockOrderHeaderEntity.getGrossCubeAmt(), clonedHeader.getGrossCubeAmt());
        assertNotEquals(crossdockOrderHeaderEntity.getCrossdockOrderQty(), clonedHeader.getCrossdockOrderQty());
        assertNotEquals(crossdockOrderHeaderEntity.getSkopeCrossdockOrderXrefsByCrossdockOrderId().size(), clonedHeader.getSkopeCrossdockOrderXrefsByCrossdockOrderId().size());

    }
}