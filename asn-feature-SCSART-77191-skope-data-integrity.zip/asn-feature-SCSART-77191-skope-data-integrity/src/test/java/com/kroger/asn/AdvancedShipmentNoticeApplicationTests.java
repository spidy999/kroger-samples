package com.kroger.asn;

import com.kroger.asn.entities.CatalogGroupEntity;
import com.kroger.asn.entities.CrossdockRouteEntity;
import com.kroger.asn.entities.OrderManagementDivisionEntity;
import com.kroger.asn.repositories.CatalogGroupRepo;
import com.kroger.asn.repositories.CrossdockRouteRepo;
import com.kroger.asn.repositories.OrderManagementDivisionRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collection;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class AdvancedShipmentNoticeApplicationTests {


    @Autowired
    CrossdockRouteRepo crossDockRouteRepo;

    @Autowired
    CatalogGroupRepo catalogGroupRepo;

    @Autowired
    OrderManagementDivisionRepo orderManagementDivisionRepo;

    @Test
    public void contextLoads() {
        // just verifies the project builds
    }

    @Test
    public void testCrossdockRepo(){

        //Left in was for running findAll query to validate connection is working and reading data...
        List<CrossdockRouteEntity> crossDockRoutes = crossDockRouteRepo.findAll();
        List<OrderManagementDivisionEntity> mgtDiv = orderManagementDivisionRepo.findAll();


       Collection<CatalogGroupEntity> catalogGroupEntities = catalogGroupRepo.findAll();




        crossDockRoutes.forEach((routObj)->System.out.println(routObj));

        System.out.println("Finished");

    }

}
