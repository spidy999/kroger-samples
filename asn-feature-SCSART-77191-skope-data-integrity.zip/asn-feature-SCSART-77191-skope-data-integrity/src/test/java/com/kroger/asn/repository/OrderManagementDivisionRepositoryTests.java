package com.kroger.asn.repository;

import com.kroger.asn.entities.OrderManagementDivisionEntity;
import com.kroger.asn.repositories.OrderManagementDivisionRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class OrderManagementDivisionRepositoryTests {

    @Autowired
    OrderManagementDivisionRepo orderManagementDivisionRepo;

    @Test
    public void testFindall() {
        List<OrderManagementDivisionEntity> mgtDiv = orderManagementDivisionRepo.findAll();
        assertEquals(1, mgtDiv.get(0).getOrderManagementDivisionId());
        assertEquals("011", mgtDiv.get(0).getOrderManagementDivisionNo());
        assertEquals("Atlanta", mgtDiv.get(0).getOrderManagementDivisionNme());
        assertEquals(mgtDiv.size(), 71);
    }

    @Test
    public void testSetMethods() {
        List<OrderManagementDivisionEntity> mgtDiv = orderManagementDivisionRepo.findAll();
        mgtDiv.get(0).setOrderManagementDivisionId(2);
        mgtDiv.get(0).setOrderManagementDivisionNo("123");
        mgtDiv.get(0).setOrderManagementDivisionNme("Test Location");

        assertEquals(2, mgtDiv.get(0).getOrderManagementDivisionId());
        assertEquals("123", mgtDiv.get(0).getOrderManagementDivisionNo());
        assertEquals("Test Location", mgtDiv.get(0).getOrderManagementDivisionNme());
    }
}
