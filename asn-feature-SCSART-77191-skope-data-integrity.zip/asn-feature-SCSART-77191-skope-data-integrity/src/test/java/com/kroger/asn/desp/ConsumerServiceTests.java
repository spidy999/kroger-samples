package com.kroger.asn.desp;

import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNShipmentEvent;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.IOException;

/**
 * @author AB36672
 * Created on: 12/19/2019 12:21 PM
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class ConsumerServiceTests {

    @Test
    public void mapDespMessageToObjectTest() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        ASNShipmentEvent asnShipmentEvent = objectMapper.readValue(new File("src/test/resources/asnShipment.json"), ASNShipmentEvent.class);

        Assert.assertEquals("ASN-app", asnShipmentEvent.getEventHeader().getSource());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getSender());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getSender().getShipFromFacility());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getShipmentData());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getShipmentData().getPallets());
        Assert.assertEquals(2, asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().size());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getOrderIdReferences());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getShipmentData().getOrders());
        Assert.assertEquals(2, asnShipmentEvent.getAsnShipment().getShipmentData().getOrders().size());
        Assert.assertNotNull(asnShipmentEvent.getAsnShipment().getShipmentData());
        Assert.assertEquals("096-20150210005809-420841", asnShipmentEvent.getAsnShipment().getSender().getReferenceId());
        Assert.assertEquals("017", asnShipmentEvent.getAsnShipment().getSender().getShipFromFacility().getNumber());
        Assert.assertEquals("MRTD", asnShipmentEvent.getAsnShipment().getShipmentData().getCarrierCode());
        Assert.assertEquals("C13001", asnShipmentEvent.getAsnShipment().getShipmentData().getRouteName());
        Assert.assertEquals("010500017004091305", asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getId());
        Assert.assertEquals(11.94, asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getCube(), 0.001f);
        Assert.assertEquals(299.050, asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getWeight(), 0.0001f);
        Assert.assertEquals(45, asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getCases());
        Assert.assertEquals(2, asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getOrderIdReferences().size());
        Assert.assertEquals("02498765", asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getOrderIdReferences().get(0));
        Assert.assertEquals("02443217", asnShipmentEvent.getAsnShipment().getShipmentData().getPallets().get(0).getOrderIdReferences().get(1));
        Assert.assertEquals("02498765", asnShipmentEvent.getAsnShipment().getShipmentData().getOrders().get(0).getId());
        Assert.assertEquals("00346", asnShipmentEvent.getAsnShipment().getShipmentData().getOrders().get(0).getStoreNumber());
        Assert.assertEquals("FMD", asnShipmentEvent.getAsnShipment().getShipmentData().getOrders().get(0).getCatalogGroupNumber());
        Assert.assertEquals("024", asnShipmentEvent.getAsnShipment().getShipmentData().getOrders().get(0).getOrderManagementDivisionNumber());
        Assert.assertEquals("2020-02-23", asnShipmentEvent.getAsnShipment().getShipmentData().getOrders().get(0).getStoreDeliveryDate());
    }

}
