package com.kroger.asn.repository;

import com.kroger.asn.entities.ReleaseOrderGroupXrefEntity;
import com.kroger.asn.repositories.ReleaseOrderGroupXrefRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class ReleaseOrderGroupXrefRepositoryTests {

    @Autowired
    ReleaseOrderGroupXrefRepo releaseOrderGroupXrefRepo;

    @Test
    public void testFindall() {
        List<ReleaseOrderGroupXrefEntity> releaseOrderGroupXref = releaseOrderGroupXrefRepo.findAll();
        assertEquals(471448, releaseOrderGroupXref.get(0).getReleaseOrderGroupId());
        assertEquals(5597020, releaseOrderGroupXref.get(0).getCrossdockOrderId());
        assertEquals("851391d0-d4fb-4ba9-a65a-c44f6ef6a64f", releaseOrderGroupXref.get(0).getServiceId());
        assertEquals(5, releaseOrderGroupXref.size());
    }

    @Test
    public void testSetMethods() {
        List<ReleaseOrderGroupXrefEntity> releaseOrderGroupXref = releaseOrderGroupXrefRepo.findAll();
        releaseOrderGroupXref.get(0).setReleaseOrderGroupId(123456);
        releaseOrderGroupXref.get(0).setCrossdockOrderId(1234567);
        releaseOrderGroupXref.get(0).setServiceId("123456t1-t1t2-1tt2-t12t-t12t3tt4t56t");

        assertEquals(123456, releaseOrderGroupXref.get(0).getReleaseOrderGroupId());
        assertEquals(1234567, releaseOrderGroupXref.get(0).getCrossdockOrderId());
        assertEquals("123456t1-t1t2-1tt2-t12t-t12t3tt4t56t", releaseOrderGroupXref.get(0).getServiceId());
    }
}
