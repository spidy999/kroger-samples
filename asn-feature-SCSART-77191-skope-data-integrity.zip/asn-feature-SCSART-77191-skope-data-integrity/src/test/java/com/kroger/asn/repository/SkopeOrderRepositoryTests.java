package com.kroger.asn.repository;

import com.kroger.asn.entities.SkopeOrderEntity;
import com.kroger.asn.repositories.CrossdockStoreMapRepo;
import com.kroger.asn.repositories.SkopeOrderRepo;
import com.kroger.asn.service.AsnRouteCloseService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class SkopeOrderRepositoryTests {

    @Autowired
    SkopeOrderRepo skopeOrderRepo;

    @Autowired
    AsnRouteCloseService asnRouteCloseService;

    @Autowired
    CrossdockStoreMapRepo crossdockStoreMapRepo;

    @Test
    public void testFindall() {
        List<SkopeOrderEntity> skopeOrder = skopeOrderRepo.findAll();
        assertEquals(9743877, skopeOrder.get(0).getSkopeOrderId());
        assertEquals("014", skopeOrder.get(0).getOrderBillingDivisionNo());
        assertEquals("07403", skopeOrder.get(0).getSkopeOrderNo());
        assertEquals("0.00", skopeOrder.get(0).getSkopeGrossCubeAmt().toString());
        assertNull(skopeOrder.get(0).getSkopeGrossCubeUomVlu());
        assertEquals("0.00", skopeOrder.get(0).getSkopeNetWeightAmt().toString());
        assertNull(skopeOrder.get(0).getSkopeNetWeightUomVlu());
        assertEquals(0, skopeOrder.get(0).getSkopeOrderQty());
        assertEquals("KCI809", skopeOrder.get(0).getRouteNo());
        assertNull(skopeOrder.get(0).getStopNo());
        assertEquals("2019-04-10", skopeOrder.get(0).getSkopeOrderDeliveryDt().toString());
        assertEquals("1970-01-05 10:35:00.0", skopeOrder.get(0).getSkopeOrderProcessTs().toString());
        assertEquals("2019-04-08 18:29:31.0", skopeOrder.get(0).getSourceFacilityOrderCmplTs().toString());
        assertNull(skopeOrder.get(0).getSkopeOrderCancelTs());
        assertEquals("2019-04-08 18:29:34.0", skopeOrder.get(0).getRowCreateTs().toString());
        assertEquals("2019-04-09 04:49:44.0", skopeOrder.get(0).getRowUpdateTs().toString());
        assertEquals("anonymou", skopeOrder.get(0).getRowCreateId());
        assertEquals("JH77390", skopeOrder.get(0).getRowUpdateId());
        assertNull(skopeOrder.get(0).getLabelsQty());
        assertEquals("", skopeOrder.get(0).getPickSequenceNo());
        assertEquals("2", skopeOrder.get(0).getProcessDayCd());
        assertEquals("N", skopeOrder.get(0).getOrderMethodCreateCd());
    }

    @Test
    public void testSetMethods() {
        List<SkopeOrderEntity> skopeOrderEntity = skopeOrderRepo.findAll();
        Date dt = Date.valueOf("2012-12-21");
        Timestamp ts = Timestamp.valueOf("2019-04-10 12:17:36.0");
        BigDecimal bd = new BigDecimal(12.12);

        skopeOrderEntity.get(0).setSkopeOrderId(1234567);
        skopeOrderEntity.get(0).setOrderBillingDivisionNo("123");
        skopeOrderEntity.get(0).setSkopeOrderNo("12345");
        skopeOrderEntity.get(0).setSkopeGrossCubeAmt(bd);
        skopeOrderEntity.get(0).setSkopeGrossCubeUomVlu("Test");
        skopeOrderEntity.get(0).setSkopeNetWeightAmt(bd);
        skopeOrderEntity.get(0).setSkopeNetWeightUomVlu("Test");
        skopeOrderEntity.get(0).setSkopeOrderQty(1);
        skopeOrderEntity.get(0).setRouteNo("TEST12");
        skopeOrderEntity.get(0).setStopNo("1");
        skopeOrderEntity.get(0).setSkopeOrderDeliveryDt(dt);
        skopeOrderEntity.get(0).setSkopeOrderProcessTs(ts);
        skopeOrderEntity.get(0).setSourceFacilityOrderCmplTs(ts);
        skopeOrderEntity.get(0).setSkopeOrderCancelTs(ts);
        skopeOrderEntity.get(0).setRowCreateTs(ts);
        skopeOrderEntity.get(0).setRowUpdateTs(ts);
        skopeOrderEntity.get(0).setRowCreateId("Test");
        skopeOrderEntity.get(0).setRowUpdateId("TEST123");
        skopeOrderEntity.get(0).setLabelsQty(1);
        skopeOrderEntity.get(0).setPickSequenceNo("1");
        skopeOrderEntity.get(0).setProcessDayCd("1");
        skopeOrderEntity.get(0).setOrderMethodCreateCd("T");

        assertEquals(1234567, skopeOrderEntity.get(0).getSkopeOrderId());
        assertEquals("123", skopeOrderEntity.get(0).getOrderBillingDivisionNo());
        assertEquals("12345", skopeOrderEntity.get(0).getSkopeOrderNo());
        assertEquals(bd, skopeOrderEntity.get(0).getSkopeGrossCubeAmt());
        assertEquals("Test", skopeOrderEntity.get(0).getSkopeGrossCubeUomVlu());
        assertEquals(bd, skopeOrderEntity.get(0).getSkopeNetWeightAmt());
        assertEquals("Test", skopeOrderEntity.get(0).getSkopeNetWeightUomVlu());
        assertEquals(1, skopeOrderEntity.get(0).getSkopeOrderQty());
        assertEquals("TEST12", skopeOrderEntity.get(0).getRouteNo());
        assertEquals("1", skopeOrderEntity.get(0).getStopNo());
        assertEquals(dt, skopeOrderEntity.get(0).getSkopeOrderDeliveryDt());
        assertEquals(ts, skopeOrderEntity.get(0).getSkopeOrderProcessTs());
        assertEquals(ts, skopeOrderEntity.get(0).getSourceFacilityOrderCmplTs());
        assertEquals(ts, skopeOrderEntity.get(0).getSkopeOrderCancelTs());
        assertEquals(ts, skopeOrderEntity.get(0).getRowCreateTs());
        assertEquals(ts, skopeOrderEntity.get(0).getRowUpdateTs());
        assertEquals("Test", skopeOrderEntity.get(0).getRowCreateId());
        assertEquals("TEST123", skopeOrderEntity.get(0).getRowUpdateId());
        assert skopeOrderEntity.get(0).getLabelsQty() == 1;
        assertEquals("1", skopeOrderEntity.get(0).getPickSequenceNo());
        assertEquals("1", skopeOrderEntity.get(0).getProcessDayCd());
        assertEquals("T", skopeOrderEntity.get(0).getOrderMethodCreateCd());

    }

}