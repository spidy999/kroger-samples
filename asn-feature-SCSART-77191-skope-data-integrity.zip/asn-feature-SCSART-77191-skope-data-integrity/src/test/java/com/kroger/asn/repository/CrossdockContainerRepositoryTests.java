package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockContainerEntity;
import com.kroger.asn.repositories.CrossdockContainerRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockContainerRepositoryTests {

    @Autowired
    CrossdockContainerRepo crossdockContainerRepo;

    @Test
    public void testFindall() {
        List<CrossdockContainerEntity> crossdockContainer = crossdockContainerRepo.findAll();
        assertEquals(1, crossdockContainer.get(0).getContainerId());
        assert  crossdockContainer.get(0).getCubeAmt() == 79.0;
        assertEquals("A", crossdockContainer.get(0).getLabelFormatCd());
        assert  crossdockContainer.get(0).getLabelQty() == 2;
        assertEquals(2, crossdockContainer.size());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockContainerEntity> crossdockContainer = crossdockContainerRepo.findAll();
        crossdockContainer.get(0).setContainerId(2);
        crossdockContainer.get(0).setCubeAmt(10.0);
        crossdockContainer.get(0).setLabelFormatCd("T");
        crossdockContainer.get(0).setLabelQty(1);

        assertEquals(2, crossdockContainer.get(0).getContainerId());
        assert  crossdockContainer.get(0).getCubeAmt() == 10.0;
        assertEquals("T", crossdockContainer.get(0).getLabelFormatCd());
        assert  crossdockContainer.get(0).getLabelQty() == 1;
    }
}
