package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockMapEntity;
import com.kroger.asn.repositories.CrossdockMapRepo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockMapRepositoryTests {

    @Autowired
    CrossdockMapRepo crossdockMapRepo;

    @Test
    public void testFindall() {
        List<CrossdockMapEntity> crossdockMap = crossdockMapRepo.findAll();
        assertEquals(229, crossdockMap.get(0).getCrossdockMapId());
        assertEquals("2011-02-14 15:00:00.0", crossdockMap.get(0).getCrossdockMapStartTs().toString());
        assertEquals("2020-12-31 23:59:00.0", crossdockMap.get(0).getCrossdockMapEndTs().toString());
        assertEquals("Memphis Deli", crossdockMap.get(0).getCrossdockMapNme());
        assertEquals("A", crossdockMap.get(0).getCrossdockScheduleCalendarCd());
        assertEquals("B", crossdockMap.get(0).getReleaseCd());
        assertEquals("2010-12-22 17:00:05.0", crossdockMap.get(0).getRowCreateTs().toString());
        assertEquals("2016-07-21 09:58:01.0", crossdockMap.get(0).getRowUpdateTs().toString());
        assertEquals("TB55640", crossdockMap.get(0).getRowCreateId());
        assertEquals("MH82281", crossdockMap.get(0).getRowUpdateId());
        assertEquals(7, crossdockMap.size());
    }

    @Test
    public void testSetMethods() {
        List<CrossdockMapEntity> crossdockMap = crossdockMapRepo.findAll();
        Timestamp ts = Timestamp.valueOf("2019-04-10 12:17:36.0");

        crossdockMap.get(0).setCrossdockMapId(100);
        crossdockMap.get(0).setCrossdockMapStartTs(ts);
        crossdockMap.get(0).setCrossdockMapEndTs(ts);
        crossdockMap.get(0).setCrossdockMapNme("Test Location");
        crossdockMap.get(0).setCrossdockScheduleCalendarCd("T");
        crossdockMap.get(0).setReleaseCd("T");
        crossdockMap.get(0).setRowCreateTs(ts);
        crossdockMap.get(0).setRowUpdateTs(ts);
        crossdockMap.get(0).setRowCreateId("TEST123");
        crossdockMap.get(0).setRowUpdateId("TEST123");

        assertEquals(100, crossdockMap.get(0).getCrossdockMapId());
        assertEquals(ts, crossdockMap.get(0).getCrossdockMapStartTs());
        assertEquals(ts, crossdockMap.get(0).getCrossdockMapEndTs());
        assertEquals("Test Location", crossdockMap.get(0).getCrossdockMapNme());
        assertEquals("T", crossdockMap.get(0).getCrossdockScheduleCalendarCd());
        assertEquals("T", crossdockMap.get(0).getReleaseCd());
        assertEquals(ts, crossdockMap.get(0).getRowCreateTs());
        assertEquals(ts, crossdockMap.get(0).getRowUpdateTs());
        assertEquals("TEST123", crossdockMap.get(0).getRowCreateId());
        assertEquals("TEST123", crossdockMap.get(0).getRowUpdateId());
    }

    @Test
    public void testFindOneCrossdockMap() {
        CrossdockMapEntity crossdockMap = crossdockMapRepo.findByCrossdockMapId(560);

        Assert.assertNotNull(crossdockMap);
        Assert.assertEquals(560, crossdockMap.getCrossdockMapId());
        Assert.assertEquals(391, crossdockMap.getCrossdockCatalogGroupMapByCrossdockCatalogGroupMapId().getCrossdockCatalogGroupMapId());
        Assert.assertEquals(2, crossdockMap.getOrderManagementDivisionByOrderManagementDivisionId().getOrderManagementDivisionId());
    }

    @Test
    public void testDetermineIfCrossDockScheduleCalendarCD14Day() {
        CrossdockMapEntity crossdockMap7 = crossdockMapRepo.findByCrossdockMapId(561);
        CrossdockMapEntity crossdockMap14 = crossdockMapRepo.findByCrossdockMapId(435);

        Assert.assertEquals(561, crossdockMap7.getCrossdockMapId());
        Assert.assertEquals("A", crossdockMap7.getCrossdockScheduleCalendarCd());
        Assert.assertFalse(crossdockMap7.determineIfCrossDockScheduleCalendarCD14Day());

        Assert.assertEquals(435, crossdockMap14.getCrossdockMapId());
        Assert.assertEquals("B", crossdockMap14.getCrossdockScheduleCalendarCd());
        Assert.assertTrue(crossdockMap14.determineIfCrossDockScheduleCalendarCD14Day());

    }

    @Test
    public void testFindDayOfWeek() {
        java.sql.Date dt = java.sql.Date.valueOf("2020-1-20");

        CrossdockMapEntity crossdockMap7 = crossdockMapRepo.findByCrossdockMapId(561);
        CrossdockMapEntity crossdockMap14 = crossdockMapRepo.findByCrossdockMapId(435);

        Assert.assertEquals(2, crossdockMap7.findDayOfWeek(dt));
        Assert.assertEquals(9, crossdockMap14.findDayOfWeek(dt));

    }
}