package com.kroger.asn.repository;

import com.kroger.asn.entities.CrossdockMapReleaseEntity;
import com.kroger.asn.repositories.CrossdockMapReleaseRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class CrossdockMapReleaseRepositoryTests {

    @Autowired
    CrossdockMapReleaseRepo crossdockMapReleaseRepo;

    @Test
    public void testFindall() { // no data was provided to make the MapRelease table
//        List<CrossdockMapReleaseEntity> crossdockMapRelease = crossdockMapReleaseRepo.findAll();
//        assertEquals(crossdockMapRelease.get(0).getCrossdockMapId(), 278);
//        assertEquals(crossdockMapRelease.get(0).getProcessDayNo(), "00406");
//        assertEquals(crossdockMapRelease.get(0).getSkopeOrderRequestTs().toString(), "Kroger");
//        assertEquals(crossdockMapRelease.get(0).getOrderReleaseToWinTs().toString(), "05");
//        assertEquals(crossdockMapRelease.size(), 0);
    }
}
