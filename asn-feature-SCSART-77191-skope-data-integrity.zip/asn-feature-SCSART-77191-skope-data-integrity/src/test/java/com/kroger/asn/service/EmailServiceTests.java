package com.kroger.asn.service;

import com.kroger.asn.dto.asnshipmentdata.SkopeOrder;
import com.kroger.desp.commons.supplychainwarehouseoperations.asnshipment.Pallet;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
@Ignore
public class EmailServiceTests {
    @Autowired
    EmailService emailService;

    //Test email functionality. Because this runs through the actual code, be sure to change the recipients in the code
    @Test
    public void sendEmailTest() {
        Map<String, SkopeOrder> skopeOrderMap = new HashMap<>();
        SkopeOrder skopeOrder = new SkopeOrder();
        skopeOrder.setSkopeOrderNo("011123450");
        skopeOrder.setFacilityNo("011");
        skopeOrder.setStoreNo("00123");
        skopeOrder.setOrderManagementDivisionId(123L);
        skopeOrderMap.put("12345", skopeOrder);

        //Pallet with invalid load ID, should get logged
        List<Pallet> palletsOnRouteClose = new ArrayList<>();
        Pallet myPallet = new Pallet();
        myPallet.setId("11111111111");
        List<String> orderIDRefs = new ArrayList<>();
        orderIDRefs.add("12345");
        myPallet.setOrderIdReferences(orderIDRefs);
        palletsOnRouteClose.add(myPallet);

        //Pallet with valid load ID, should not get logged
        Pallet palletWithGoodLoadIDs = new Pallet();
        palletWithGoodLoadIDs.setId("22222222222");
        List<String> orderIDRefs2 = new ArrayList<>();
        orderIDRefs2.add("98765");
        palletWithGoodLoadIDs.setOrderIdReferences(orderIDRefs2);
        palletsOnRouteClose.add(palletWithGoodLoadIDs);

        emailService.sendNoStoreMapFoundEmail(skopeOrderMap, palletsOnRouteClose);
    }
}
