package com.kroger.asn.repository;

import com.kroger.asn.entities.SourcingFacilityEntity;
import com.kroger.asn.repositories.SourcingFacilityRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.EntityNotFoundException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({ "unittest", "SPOOFING" })
public class SourcingFacilityRepositoryTests {

    @Autowired
    SourcingFacilityRepo sourcingFacilityRepo;

    @Test
    public void testFindall() {
        List<SourcingFacilityEntity> sourcingFacility = sourcingFacilityRepo.findAll();
        assertEquals(7, sourcingFacility.get(0).getSourcingFacilityId());
        assertEquals("014", sourcingFacility.get(0).getSourcingFacilityNo());
        assertEquals("CINCINNATI", sourcingFacility.get(0).getSourcingFacilityNme());
        assertEquals("DC", sourcingFacility.get(0).getSourcingFacilityTypeCd());
        assertNull(sourcingFacility.get(0).getSourcingFacilityTimezoneCd());
        assertNull(sourcingFacility.get(0).getLastLoadId());
        assertEquals(0, sourcingFacility.get(0).getLastOrderNo());
    }

    @Test
    public void testSetMethods() {
        List<SourcingFacilityEntity> sourcingFacility = sourcingFacilityRepo.findAll();
        sourcingFacility.get(0).setSourcingFacilityId(1);
        sourcingFacility.get(0).setSourcingFacilityNo("123");
        sourcingFacility.get(0).setSourcingFacilityNme("Test Location");
        sourcingFacility.get(0).setSourcingFacilityTypeCd("TE");
        sourcingFacility.get(0).setSourcingFacilityTimezoneCd("01");
        sourcingFacility.get(0).setLastLoadId(1234);
        sourcingFacility.get(0).setLastOrderNo(1);

        assertEquals(1, sourcingFacility.get(0).getSourcingFacilityId());
        assertEquals("123", sourcingFacility.get(0).getSourcingFacilityNo());
        assertEquals("Test Location", sourcingFacility.get(0).getSourcingFacilityNme());
        assertEquals("TE", sourcingFacility.get(0).getSourcingFacilityTypeCd());
        assertEquals("01", sourcingFacility.get(0).getSourcingFacilityTimezoneCd());
        assert sourcingFacility.get(0).getLastLoadId() == 1234;
        assertEquals(1, sourcingFacility.get(0).getLastOrderNo());
    }


    @Test
    public void testfindBySourcingFacilityNo() {
        SourcingFacilityEntity sourcingFacility = sourcingFacilityRepo.findBySourcingFacilityNo("014").orElseThrow(()->
                new EntityNotFoundException("Unable to find origin facility."));
        assertEquals("014", sourcingFacility.getSourcingFacilityNo());
    }
}

