package com.kroger.asn.desp;

import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNOrderSummaryEvent;
import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNShipmentEvent;
import com.kroger.streaming.configuration.DespKafkaProperties;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * @author ab36672
 * Created on: 1/7/2020 3:44 PM
 */

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles({"unittest", "SPOOFING"})
public class ProducerTests {

    @Autowired
    DespKafkaProperties despKafkaProperties;


    @Test
    public void sendASNShipmentEventTest() throws IOException, ExecutionException, InterruptedException {
        Map<String, Object> properties = despKafkaProperties.buildProducerProperties();
        properties.put("key.serializer", StringSerializer.class.getName());
        properties.put("value.serializer", KafkaAvroSerializer.class.getName());
        ObjectMapper objectMapper = new ObjectMapper();
        ProducerRecord producerRecord = new ProducerRecord<>("sc_warehouse_operations", objectMapper.readValue(new File("src/test/resources/asnshipment.json"), ASNShipmentEvent.class));
        Producer<String, ASNShipmentEvent> asnShipmentEventProducer = new KafkaProducer<String, ASNShipmentEvent>(properties);
        Future<RecordMetadata> future = asnShipmentEventProducer.send(producerRecord);
        System.out.println("Message Commit offset: " + future.get().offset());
    }

    @Test
    public void sendASNOrderSummaryTest() throws IOException, ExecutionException, InterruptedException {
        Map<String, Object> properties = despKafkaProperties.buildProducerProperties();
        properties.put("key.serializer", StringSerializer.class.getName());
        properties.put("value.serializer", KafkaAvroSerializer.class.getName());
        ObjectMapper objectMapper = new ObjectMapper();
        ProducerRecord producerRecord = new ProducerRecord<>("sc_warehouse_operations", objectMapper.readValue(new File("src/test/resources/asnOrderSummary.json"), ASNOrderSummaryEvent.class));
        Producer<String, ASNOrderSummaryEvent> asnOrderSummaryEventProducer = new KafkaProducer<String, ASNOrderSummaryEvent>(properties);
        Future<RecordMetadata> future = asnOrderSummaryEventProducer.send(producerRecord);
        System.out.println("Message Commit offset: " + future.get().offset());
    }

}
