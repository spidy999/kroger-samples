package com.kroger.asn.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kroger.desp.events.supplychainwarehouseoperations.asnshipment.ASNShipmentEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
@ActiveProfiles({ "unittest", "SPOOFING" })
public class AsnRouteCloseWebmethodsTest {

    @Autowired
    AsnRouteCloseService asnRouteCloseService;

    @Test
    public void testCallingWebService() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        ASNShipmentEvent asnShipmentEvent = objectMapper.readValue(new File("src/test/resources/asnShipmentExistingHeaderOneSkopeOrderNotOriginComplete.json"), ASNShipmentEvent.class);
        asnRouteCloseService.processAsnRouteCloseEvent(asnShipmentEvent.getAsnShipment());
    }
}
