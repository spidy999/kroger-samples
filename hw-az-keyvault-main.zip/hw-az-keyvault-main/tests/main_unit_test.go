package test

import (
	// "errors"
	// "fmt"
	"testing"

	// "regexp"

	// "github.com/Jeffail/gabs"
	"github.com/gruntwork-io/terratest/modules/terraform"
	// "github.com/stretchr/testify/assert"
)

func TestUT_PermsCodeCoverage(t *testing.T) {
	t.Parallel()

	tfOptions := &terraform.Options{
		TerraformDir: "./fixtures/keyvault_perms",
	}

	// Terraform init and plan only
	tfPlanOutput := "terraform.tfplan"
	terraform.Init(t, tfOptions)
	terraform.RunTerraformCommand(t, tfOptions, terraform.FormatArgs(tfOptions, "plan", "-out="+tfPlanOutput)...)

	// // read the plan output
	// planJSON, err := terraform.RunTerraformCommandAndGetStdoutE(
	// 	t, tfOptions, terraform.FormatArgs(&terraform.Options{}, "show", "-json", tfPlanOutput)...,
	// )
	// if err != nil {
	// 	t.Fatal(err)
	// }

	// // parse the output
	// jsonParsed, err := gabs.ParseJSON([]byte(planJSON))
	// if err != nil {
	// 	t.Fatal(err)
	// }

	// // name conformance check
	// ValidateRandomUUID(t, jsonParsed)

}
