package test // This integration test is to make sure kv will built with multiple

import (
	"testing"

	"time"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestIT_KeyVaultAllOptions(t *testing.T) {
	t.Parallel()
	// retryable errors in terraform testing.
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "./fixtures/multi_access_policies", // Run the integration testing with multiple access policies
		NoColor:      true,
	})

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	// Get Terraform output
	expectedSecretName2 := terraform.Output(t, terraformOptions, "keyvault_secret_name")
	expectedKeyName2 := terraform.Output(t, terraformOptions, "keyvault_key_name")

	// Assert that the key vault secret is formatted as expected
	assert.Equal(t, "password", expectedSecretName2)

	assert.Equal(t, "key", expectedKeyName2)

	// sleep before running destroy (through the above defer message)
	time.Sleep(5 * time.Minute)
}
