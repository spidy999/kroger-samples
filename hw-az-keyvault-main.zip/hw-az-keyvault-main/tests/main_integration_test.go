package test

import (
	"testing"

	"time"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestIT_KeyVault(t *testing.T) {
	t.Parallel()
	// retryable errors in terraform testing.
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "./fixtures/main",
		NoColor:      true,
	})

	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	// Get Terraform output
	keyVaultName := terraform.Output(t, terraformOptions, "keyvault_name")
	expectedSecretName := terraform.Output(t, terraformOptions, "keyvault_secret_name")
	expectedKeyName := terraform.Output(t, terraformOptions, "keyvault_key_name")
	expectedSecretNameRBAC := terraform.Output(t, terraformOptions, "keyvault_secret_name_rbac")
	expectedKeyNameRBAC := terraform.Output(t, terraformOptions, "keyvault_key_name_rbac")
	expectedSecretNameRBACpim := terraform.Output(t, terraformOptions, "keyvault_secret_name_rbac_pim")
	expectedKeyNameRBACpim := terraform.Output(t, terraformOptions, "keyvault_key_name_rbac_pim")

	// Assert that the key vault name is formatted as expected - RBAC KV is override value so this test is invalid for that KV
	assert.Regexp(t, "hw-([A-Za-z0-9]){8}-dev-kv", keyVaultName)

	// Assert that the key vault secret is formatted as expected
	assert.Equal(t, "password", expectedSecretNameRBAC)
	assert.Equal(t, "key", expectedKeyNameRBAC)
	assert.Equal(t, "password", expectedSecretNameRBACpim)
	assert.Equal(t, "key", expectedKeyNameRBACpim)
	assert.Equal(t, "password", expectedSecretName)
	assert.Equal(t, "key", expectedKeyName)

	// sleep before running destroy (through the above defer message)
	time.Sleep(5 * time.Minute)
}
