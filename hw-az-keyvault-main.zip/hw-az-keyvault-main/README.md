# Health & Wellness Azure Key Vault Module

[![Module Terraform Tests](https://github.com/krogertechnology/hw-az-keyvault/actions/workflows/call-ru-terratest-go-modules.yml/badge.svg)](https://github.com/krogertechnology/hw-az-keyvault/actions/workflows/call-ru-terratest-go-modules.yml) [![Module Tag & Release](https://github.com/krogertechnology/hw-az-keyvault/actions/workflows/call-ru-terraform-module-tag-and-release.yml/badge.svg)](https://github.com/krogertechnology/hw-az-keyvault/actions/workflows/call-ru-terraform-module-tag-and-release.yml)

<!-- DO NOT ADD LINES TO THE README HERE! -->
<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Description](#description)
  - [Notes](#notes)
- [Requirements](#requirements)
- [Providers](#providers)
- [Modules](#modules)
- [Resources](#resources)
- [Inputs](#inputs)
- [Outputs](#outputs)
- [Examples](#examples)
  - [Override Name](#override-name)
  - [Version of Azurerm < 3](#version-of-azurerm--3)
- [Useful Links](#useful-links)
  - [Here is a link to the standards for making a pull request to one of these Terraform module repos](#here-is-a-link-to-the-standards-for-making-a-pull-request-to-one-of-these-terraform-module-repos)
- [Change Log](#change-log)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

<!--  \/  \/  \/ START - Only manually edit between these two lines \/  \/  \/ -->

## Description
This module will deploy a keyvault and add permissions to the repo service principal to manage the KV and secrets therein.

### Notes

- Permission is granted via this module to the service principal that will be provisioning the Terraform in order to create, read, update, or delete key vault resources such as Keys, Secrets, or Certificates.

  **You shouldn't try to upgrade until you verify that the plan_apply workflow has the ability to pass "SKIP_REFRESH".**

  Check the .github/terraform-plan-apply for:

  - the on: workflow_dispatch with the RUN_REFRESH parameter
  - the job: wd_plan_apply that passes the RUN_REFRESH parameter

  **To upgrade this module**

  1. Changing the soft_delete_retention_days causes the kv to be recreated. You can avoid this by sending in the override variable soft_delete_retention_days = 7 # Previous kv module had this set at 7 days.
  2. Upgrading to/past version v0.3.0 turns on the firewall so you will need to make sure there is an access policy for your infrastructure to connect to the keyvault as well as sending in the override variable additional_subnet_ids with a list of the subnets that will need access to the keyvault.
  3. If you are upgrading azurerm2 to 3 or higher you will want to add the additional keyvault features to the azurerm provider typically in the providers.tf file to look something like this:

     ```
      provider "azurerm" {
      skip_provider_registration = "true"
      subscription_id            = var.subscription_id
      features {
        key_vault {
          purge_soft_delete_on_destroy    = false
          recover_soft_deleted_key_vaults = true
          # available when min version azurerm => 3
          purge_soft_deleted_certificates_on_destroy = false
          purge_soft_deleted_keys_on_destroy         = false
          purge_soft_deleted_secrets_on_destroy      = false
          recover_soft_deleted_certificates          = true
          recover_soft_deleted_secrets               = true
          recover_soft_deleted_keys                  = true
        }
      }
     }
     ```

  4. Remove the pipeline permissions sent into the module from calling terraform (the module automatically adds pipeline permissions to the KV and contents)
  5. The initial merge plan/apply will fail. You will need to run the wd_plan_apply manual workflow on appropriate branch with SKIP_REFRESH = true
  6. If you still see an error like this:
     Error: A resource with the ID "/subscriptions/.../.../providers/Microsoft.KeyVault/vaults/hw-kv-test-dev-kv/objectId/..." already exists - to be managed via Terraform this resource needs to be imported into the State.

     you will need to make sure you are using the latest plan_apply workflow
     [Example plan-apply workflow with skip-refresh](https://github.com/krogertechnology/hw-eprncoldbackup-inf/pull/19/files)

- If you see an error like "Cycle: module.keyvault.var.resource_group_name (expand)..." check for circular dependencies.
  Ex: Defining a Key Vault Access Policy for a web app identity and including the key vault URI in the web app's app settings

- Key vault name is created using the hw-{application-name}-{environment}-kv standard. The total length of the name has a maximum of 24 characters. In the event that this naming convention cannot be used, please add a value for the key_vault_name_override variable. (See [Name Override Example](###Name-Override-Example))

- A peered endpoint private endpoint in the same subscription and region will not be created by default. If this is needed, set the enable_region_private_endpoint variable to true. If connectivity from on-prem is required, set the enable_prod_eus2_private_endpoint variable to true to create a peered endpoint in the Prod East US 2 region.

- Terraform tests are not able to test the peered private endpoint (PE) connectivity if only a regional PE is created, as the runners rely on DNS through the Prod East US 2 PE. Existing tests for things like secrets will fail due to DNS non-resolution, which is the expected behavior. Only resources in the same subscription and region as the regional PE will be able to access the Key Vault. Runners ARE able to successfully query the Key Vault is the Prod East US 2 PE is in place.

- Expiration dates on all secrets and keys created using this module are ignored through the lifecycle meta-argument. This is to avoid terraform from removing the expiration date after any change, and Azure from adding it back in. 

<!--  /\  /\  /\ END - Only manually edit between these two lines   /\  /\  /\ -->
<!--  Don't Edit Below This Line -->
<!-- BEGIN_TF_DOCS -->


## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | >= 1.5.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.0.0, < 4 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.1.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azuread"></a> [azuread](#provider\_azuread) | >= 1.5.0 |
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.0.0, < 4 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_pvt_endpoint_keyvault_eastus2p"></a> [pvt\_endpoint\_keyvault\_eastus2p](#module\_pvt\_endpoint\_keyvault\_eastus2p) | https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-pvt-endpoint-v0.2.0.tar.gz | n/a |
| <a name="module_pvt_endpoint_keyvault_region_based"></a> [pvt\_endpoint\_keyvault\_region\_based](#module\_pvt\_endpoint\_keyvault\_region\_based) | https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-pvt-endpoint-v0.2.0.tar.gz | n/a |

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |
| [azurerm_key_vault_access_policy.access](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_access_policy.pipeline_key_vault_ap](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy) | resource |
| [azurerm_key_vault_key.keys](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_key) | resource |
| [azurerm_key_vault_secret.secrets](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_secret) | resource |
| [azurerm_monitor_diagnostic_setting.kv](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/monitor_diagnostic_setting) | resource |
| [azurerm_pim_eligible_role_assignment.pim_roles](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/pim_eligible_role_assignment) | resource |
| [azurerm_role_assignment.assigned_roles](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment) | resource |
| [azuread_group.group](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/group) | data source |
| [azuread_service_principal.spn](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/service_principal) | data source |
| [azuread_user.user](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/user) | data source |
| [azurerm_client_config.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_resource_group.main](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/subscription) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_access_policies"></a> [access\_policies](#input\_access\_policies) | (Optional) List of access policies for the Key Vault. | `any` | `[]` | no |
| <a name="input_additional_ip_whitelist"></a> [additional\_ip\_whitelist](#input\_additional\_ip\_whitelist) | (Optional) additional authorized ip addresses to  be whitelisted. This list is concatenated with ip\_whitelist | `list(string)` | `[]` | no |
| <a name="input_additional_subnet_ids"></a> [additional\_subnet\_ids](#input\_additional\_subnet\_ids) | (Optional) additional authorized Vnet subnets by subnet id for things like the app serve subnet id. This list is concatenated with 'subnet\_ids' | `list(string)` | `[]` | no |
| <a name="input_application_name"></a> [application\_name](#input\_application\_name) | Name of the application. Used for enforcing Key Vault naming convention hw-{application\_name}-{environment}-kv. Application\_Name and Environment must equal 19 or fewer characters. | `string` | n/a | yes |
| <a name="input_assigned_roles"></a> [assigned\_roles](#input\_assigned\_roles) | Map of: object\_ids = rbac\_role\_name name Where the obj\_id will be assigned the RABC permission on the KV via PIM. from the role table here: https://learn.microsoft.com/en-us/azure/key-vault/general/rbac-guide?tabs=azure-cli | `map(string)` | `{}` | no |
| <a name="input_bypass"></a> [bypass](#input\_bypass) | Services allowed to bypass firewall | `string` | `"AzureServices"` | no |
| <a name="input_default_action"></a> [default\_action](#input\_default\_action) | Deny or Allow access by default | `string` | `"Deny"` | no |
| <a name="input_enable_pim_roles"></a> [enable\_pim\_roles](#input\_enable\_pim\_roles) | (Optional) ** Warning ** There is an issue with the Terrafrom provider where PIM roles have been problematic to import. Use this Boolean flag to allow PIM role deployments anyway. This option is not currently available and will be ignored | `bool` | `false` | no |
| <a name="input_enable_prod_eus2_private_endpoint"></a> [enable\_prod\_eus2\_private\_endpoint](#input\_enable\_prod\_eus2\_private\_endpoint) | (Optional) Boolean flag to specify whether a private endpoint is created in Prod EUS2 for on-prem connectivity. | `bool` | `false` | no |
| <a name="input_enable_rbac_authorization"></a> [enable\_rbac\_authorization](#input\_enable\_rbac\_authorization) | (Optional) Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions. Defaults to false. | `bool` | `false` | no |
| <a name="input_enable_region_private_endpoint"></a> [enable\_region\_private\_endpoint](#input\_enable\_region\_private\_endpoint) | (Optional) Boolean flag to specify whether a private endpoint is created in the same region as the keyvault. | `bool` | `false` | no |
| <a name="input_enabled_for_deployment"></a> [enabled\_for\_deployment](#input\_enabled\_for\_deployment) | (Optional) Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. Defaults to false. | `bool` | `false` | no |
| <a name="input_enabled_for_disk_encryption"></a> [enabled\_for\_disk\_encryption](#input\_enabled\_for\_disk\_encryption) | (Optional) Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. Defaults to false. | `bool` | `false` | no |
| <a name="input_enabled_for_template_deployment"></a> [enabled\_for\_template\_deployment](#input\_enabled\_for\_template\_deployment) | (Optional) Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault. Defaults to false. | `bool` | `false` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Application environment. Used for enforcing Key Vault naming convention hw-{application\_name}-{environment}-kv. Application\_Name and Environemnt must equal 19 or fewer characters. | `string` | n/a | yes |
| <a name="input_ip_whitelist"></a> [ip\_whitelist](#input\_ip\_whitelist) | until a more maintainable solution becomes available, restrict access to trusted carrier grade IP space | `list(string)` | <pre>[<br>  "158.48.0.0/16"<br>]</pre> | no |
| <a name="input_key_vault_name_override"></a> [key\_vault\_name\_override](#input\_key\_vault\_name\_override) | (Optional) Key vault name, if a nonstandard naming convention is required. Max 24 characters due to key vault naming limits. | `string` | `""` | no |
| <a name="input_keys"></a> [keys](#input\_keys) | A list of keys for the Key Vault. | `any` | `[]` | no |
| <a name="input_monitoring-qradar-eventhub"></a> [monitoring-qradar-eventhub](#input\_monitoring-qradar-eventhub) | Event hub details to send audit events to qradar | <pre>map(object({<br>    name                  = string<br>    authorization_rule_id = string<br>  }))</pre> | <pre>{<br>  "centralus": {<br>    "authorization_rule_id": "/subscriptions/2912a3d7-4fae-4252-9f75-670d4c28b63a/resourceGroups/cloud-monitoring/providers/Microsoft.EventHub/namespaces/qradar-eventhub-namespace-centralus/authorizationRules/RootManageSharedAccessKey",<br>    "name": "centralus-firewall-diagnostic-logs"<br>  },<br>  "eastus2": {<br>    "authorization_rule_id": "/subscriptions/2912a3d7-4fae-4252-9f75-670d4c28b63a/resourceGroups/cloud-monitoring/providers/Microsoft.EventHub/namespaces/qradar-eventhub-namespace/authorizationRules/RootManageSharedAccessKey",<br>    "name": "insights-operational-logs"<br>  }<br>}</pre> | no |
| <a name="input_pim_roles"></a> [pim\_roles](#input\_pim\_roles) | Map of: object\_ids = rbac\_role\_name name Where the obj\_id will be assigned the RABC permission on the KV. See from the role table here: https://learn.microsoft.com/en-us/azure/key-vault/general/rbac-guide?tabs=azure-cli | `map(string)` | `{}` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of an existing resource group for the Key Vault. | `string` | n/a | yes |
| <a name="input_secrets"></a> [secrets](#input\_secrets) | A list of secrets for the Key Vault. | `any` | `[]` | no |
| <a name="input_sku"></a> [sku](#input\_sku) | (Required) The Name of the SKU used for this Key Vault. Possible values are standard and premium. | `string` | `"standard"` | no |
| <a name="input_soft_delete_retention_days"></a> [soft\_delete\_retention\_days](#input\_soft\_delete\_retention\_days) | (Optional) The number of days that items should be retained for once soft-deleted.<br>  This value can be between 7 and 90 (the default) days.<br>  This field can only be configured one time and cannot be updated.<br>  https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault#soft_delete_retention_days | `number` | `90` | no |
| <a name="input_subnet_ids"></a> [subnet\_ids](#input\_subnet\_ids) | authorized Vnet subnets by subnet id. these are for the GHA Runner and are concattenated with additional\_subnet\_ids | `list(string)` | <pre>[<br>  "/subscriptions/45c9a658-02d1-4c1b-a2ec-0a38383c3259/resourceGroups/networking-centralus/providers/Microsoft.Network/virtualNetworks/vnet-tsa-centralus-spoke/subnets/snet-cicd-runners-centralus-nonprod",<br>  "/subscriptions/306745aa-39f3-4d56-bce9-c911c5f9c467/resourceGroups/networking-centralus/providers/Microsoft.Network/virtualNetworks/vnet-tsa-centralus-spoke/subnets/snet-cicd-runners-centralus-prod"<br>]</pre> | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resources. | <pre>object({<br>    spm-id           = number<br>    owner            = string<br>    lob              = string<br>    application-name = string<br>    cost-center      = string<br>  })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_keyvault_id"></a> [keyvault\_id](#output\_keyvault\_id) | The ID of the Key Vault. |
| <a name="output_keyvault_keys"></a> [keyvault\_keys](#output\_keyvault\_keys) | A mapping of secret names and URIs. |
| <a name="output_keyvault_name"></a> [keyvault\_name](#output\_keyvault\_name) | Name of the key vault. |
| <a name="output_keyvault_secrets"></a> [keyvault\_secrets](#output\_keyvault\_secrets) | A mapping of secret names and URIs. |
| <a name="output_keyvault_uri"></a> [keyvault\_uri](#output\_keyvault\_uri) | The URI of the Key Vault, used for performing operations on keys and secrets. |

## Examples

```hcl
terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "> 3"
    }
  }
}

provider "azurerm" {
  skip_provider_registration = "true"
  subscription_id            = var.subscription_id
  features {
    key_vault {
      # available in 2.x
      purge_soft_delete_on_destroy    = false
      recover_soft_deleted_key_vaults = true

      # available when min version azurerm => 3
      purge_soft_deleted_certificates_on_destroy = false
      purge_soft_deleted_keys_on_destroy         = false
      purge_soft_deleted_secrets_on_destroy      = false
      recover_soft_deleted_certificates          = true
      recover_soft_deleted_secrets               = true
      recover_soft_deleted_keys                  = true
    }
  }
}

resource "random_password" "hw_user_password" {
  length           = 16
  special          = true
  override_special = "_%@"
  lower            = true
  upper            = true
  numeric          = true
}

module "keyvault" {
  source                          = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-keyvault-.tar.gz"
  application_name                = "my-application"
  environment                     = "dev"
  resource_group_name             = "my-application-dev-rg"
  sku                             = "standard"
  soft_delete_retention_days      = 7
  enabled_for_deployment          = false
  enabled_for_disk_encryption     = false
  enabled_for_template_deployment = false
  enable_rbac_authorization       = false
  additional_subnet_ids           = [] # Add list of strings for subnets that need access to the keyvault"
  access_policies = [
    {
      object_ids = ["SomeSpecialServicePrincipal"]
      secret_permissions = [
        "Get",
        "List",
        "Purge",
        "Delete",
        "Set"
      ]
    },
    {
      service_principal_names = ["myServicePrincipal", "myOtherServicePrincipal"]
      key_permissions = [
        "Create",
        "List"
      ]
    },
    {
      group_names = ["hw-az-example-group"]
      storage_permissions = [
        "Get",
        "List"
      ]
    },
    {
      object_ids = ["abcdefgh-ijkl-mnop-qrst-uvwxyz123456"]
      certificate_permissions = [
        "Create"
      ]
    },
    {
      user_principal_names = ["your.email@kroger.com"]
      secret_permissions = [
        "Get",
        "List"
      ]
      storage_permissions = [
        "Get",
        "List"
      ]
    }
  ]
  secrets = [
    {
      name            = "password"
      value           = random_password.hw_user_password.result
      content_type    = "string"               #optional
      not_before_date = "1970-01-01T00:00:00Z" #optional
      expiration_date = "1970-01-01T00:00:00Z" #optional
    }
  ]
  keys = [
    {
      name     = "example-key"
      key_type = "RSA"
      key_opts = [
        "decrypt",
        "encrypt",
        "sign",
        "unwrapKey",
        "verify",
        "wrapKey",
      ]
      key_size        = 2048                   #optional
      curve           = "P-256"                #optional
      not_before_date = "1970-01-01T00:00:00Z" #optional
      expiration_date = "1970-01-01T00:00:00Z" #optional
    }
  ]
  tags = {
    spm-id : 1234,
    owner : "your.email-at-kroger.com",
    lob : "Health&Wellness",
    application-name : "my-application",
    cost-center : "1234"
  }
}
```
### Override Name
```hcl
module "keyvault" {
  source                  = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-keyvault-.tar.gz"
  application_name        = "my-application"
  environment             = "dev"
  key_vault_name_override = "my-overridden-kv-name"
  resource_group_name     = "my-application-dev-rg"
}
```

### Version of Azurerm < 3
```hcl
terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "< 3"
    }
  }
}

provider "azurerm" {
  skip_provider_registration = "true"
  subscription_id            = var.subscription_id
  features {
    key_vault {
      purge_soft_delete_on_destroy    = false
      recover_soft_deleted_key_vaults = true
    }
  }
}

resource "random_password" "hw_user_password" {
  length           = 16
  special          = true
  override_special = "_%@"
  lower            = true
  upper            = true
  numeric          = true
}

module "keyvault" {
  source                          = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-keyvault-.tar.gz"
  application_name                = "my-application"
  environment                     = "dev"
  resource_group_name             = "my-application-dev-rg"
  sku                             = "standard"
  soft_delete_retention_days      = 7
  enabled_for_deployment          = false
  enabled_for_disk_encryption     = false
  enabled_for_template_deployment = false
  enable_rbac_authorization       = false
  access_policies = [
    {
      object_ids = ["SomeSpecialServicePrincipal"]
      secret_permissions = [
        "Get",
        "List",
        "Purge",
        "Delete",
        "Set"
      ]
    },
    {
      service_principal_names = ["myServicePrincipal", "myOtherServicePrincipal"]
      key_permissions = [
        "Create",
        "List"
      ]
    },
    {
      group_names = ["hw-az-example-group"]
      storage_permissions = [
        "Get",
        "List"
      ]
    },
    {
      object_ids = ["abcdefgh-ijkl-mnop-qrst-uvwxyz123456"]
      certificate_permissions = [
        "Create"
      ]
    },
    {
      user_principal_names = ["your.email@kroger.com"]
      secret_permissions = [
        "Get",
        "List"
      ]
      storage_permissions = [
        "Get",
        "List"
      ]
    }
  ]
  secrets = [
    {
      name            = "password"
      value           = random_password.hw_user_password.result
      content_type    = "string"               #optional
      not_before_date = "1970-01-01T00:00:00Z" #optional
      expiration_date = "1970-01-01T00:00:00Z" #optional
    }
  ]
  keys = [
    {
      name     = "example-key"
      key_type = "RSA"
      key_opts = [
        "decrypt",
        "encrypt",
        "sign",
        "unwrapKey",
        "verify",
        "wrapKey",
      ]
      key_size        = 2048                   #optional
      curve           = "P-256"                #optional
      not_before_date = "1970-01-01T00:00:00Z" #optional
      expiration_date = "1970-01-01T00:00:00Z" #optional
    }
  ]
  tags = {
    spm-id : 1234,
    owner : "your.email@kroger.com",
    lob : "Health&Wellness",
    application-name : "my-application",
    cost-center : "1234"
  }
}
```


<!-- END_TF_DOCS -->

## Useful Links

- [Azure Naming Standards - Health and Wellness](https://confluence.kroger.com/confluence/pages/viewpage.action?pageId=167664066)
- Click for [Terraform Module Usage, Requirements, and Testing](https://confluence.kroger.com/confluence/display/HW/Terraform+Module+Usage%2C+Requirements%2C+and+Testing)

### Here is a link to the standards for making a pull request to one of these Terraform module repos

    Note: you may have to open the link a second time if you get redirected to the confluence logon page.

[H&W Terraform Coding Standards#Pull Requests to module repos](https://confluence.kroger.com/confluence/pages/viewpage.action?pageId=186982308#H&WTerraformCodingStandards-PullRequeststomodulerepos)

## Change Log

The [change log](CHANGELOG.md) is automated via Release Tags and PR Titles by [github-changes](https://github.com/lalitkapoor/github-changes), provided under MIT License by 2014 Lalit Kapoor.

The change log is composed of Git Tags with the date along with each pull requests title. The pull request number as well as the author is noted. If you already have a change log, github-changes will replace it.
