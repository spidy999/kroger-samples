## Change Log
- [#81](https://github.com/krogertechnology/hw-az-keyvault/pull/81) hwart-120179 Small change in RBAC example to force auto docs run (@Rob-Bosma-KR)
- [#80](https://github.com/krogertechnology/hw-az-keyvault/pull/80) HWART-120179 Renamed folder to not have spaces to run doctocs (@Rob-Bosma-KR)
- [#79](https://github.com/krogertechnology/hw-az-keyvault/pull/79) HWART-120179 Minor change to readme example to test specific documentation labeled PR (@Rob-Bosma-KR)

### v1.2.0 (2024/05/03 19:23 +00:00)
- [#77](https://github.com/krogertechnology/hw-az-keyvault/pull/77) HWART-120179 Adding assigned RBAC roles and PIM RBAC roles to KV module (@Rob-Bosma-KR)
- [#76](https://github.com/krogertechnology/hw-az-keyvault/pull/76) HWART-121484: Update peter-evans/create-or-update-project-card@v2 to v3 (@zeevani-v-cb)
- [#74](https://github.com/krogertechnology/hw-az-keyvault/pull/74) HWART-116072: Change caller RU workflows to inherit secrets (@zeevani-v-cb)
- [#73](https://github.com/krogertechnology/hw-az-keyvault/pull/73) Revert "Revert "HWART-116140: Upgrade terratest from v0.44.0 to v0.46.11 to support super-linter v5"" (@zeevani-v-cb)
- [#72](https://github.com/krogertechnology/hw-az-keyvault/pull/72) Revert "HWART-116140: Upgrade terratest from v0.44.0 to v0.46.11 to support super-linter v5" (@zeevani-v-cb)
- [#70](https://github.com/krogertechnology/hw-az-keyvault/pull/70) HWART-116140: Upgrade terratest from v0.44.0 to v0.46.11 to support super-linter v5 (@zeevani-v-cb)
- [#61](https://github.com/krogertechnology/hw-az-keyvault/pull/61) HWART-110734: Upgrade terratest to 0.44.0 (@zeevani-v-cb)
- [#60](https://github.com/krogertechnology/hw-az-keyvault/pull/60) HWART-112876: Remove USE_OIDC_AUTH from calling workflows (@andrew-s-cb)

### v1.1.2 (2023/10/09 14:14 +00:00)
- [#54](https://github.com/krogertechnology/hw-az-keyvault/pull/54) HWART-108841: Update secrets and keys to ignore expiration dates (@zeevani-v-cb)

### v1.1.1 (2023/09/12 15:22 +00:00)
- [#53](https://github.com/krogertechnology/hw-az-keyvault/pull/53) HWART-106767 fix log deprecation and remove unused retention policy for qradar (@Rob-Bosma-KR)

### v1.1.0 (2023/03/24 17:07 +00:00)
- [#48](https://github.com/krogertechnology/hw-az-keyvault/pull/48) HWART-95468: Adding key rotate perms to GHA policy (@paul-p-cb)
- [#46](https://github.com/krogertechnology/hw-az-keyvault/pull/46) HWART-90296 Standardize and simplify README.md (@Rob-Bosma-KR)
- [#45](https://github.com/krogertechnology/hw-az-keyvault/pull/45) HWART-93647 - Removing the one time use only workflows (@anitha-doddapaneni-kr)
- [#43](https://github.com/krogertechnology/hw-az-keyvault/pull/43) Nojira/readme updates for   additional_subnet_ids  and provider updates (@Rob-Bosma-KR)
- [#42](https://github.com/krogertechnology/hw-az-keyvault/pull/42) Update README.md for upgrade info re:  soft_delete_retention_days (@Rob-Bosma-KR)

### v1.0.1 (2022/11/10 18:54 +00:00)
- [#40](https://github.com/krogertechnology/hw-az-keyvault/pull/40) Update soft_delete_retention_days to 90 to fix lots of Medium snyk warnings (@Rob-Bosma-KR)

### v1.0.0 (2022/10/26 16:00 +00:00)
- [#39](https://github.com/krogertechnology/hw-az-keyvault/pull/39) HWART-84184: Bump azurerm version to facilitate azurerm 3.0 consumption (@paul-p-cb)
- [#38](https://github.com/krogertechnology/hw-az-keyvault/pull/38) Adding kap.yaml file (@Rob-Bosma-KR)

### v0.6.1 (2022/08/23 19:20 +00:00)
- [#36](https://github.com/krogertechnology/hw-az-keyvault/pull/36) HWART-83135 - Adds certificate permissions to the github runner access policy (@LanceZeligman-KR)
- [#35](https://github.com/krogertechnology/hw-az-keyvault/pull/35) Fix readme for duplicate pipeline policies created upgrading version  <=2 to >2 (@Rob-Bosma-KR)
- [#34](https://github.com/krogertechnology/hw-az-keyvault/pull/34) gh-saas-tool file distribution (@donald-picard-kr, @svchwgithub)

### v0.6.0 (2022/07/21 12:39 +00:00)
- [#32](https://github.com/krogertechnology/hw-az-keyvault/pull/32) HWART-82686 Add the ability to create private endpoints on peered Vents based on region, as well as a dedicated Prod EUS 2 private endpoint (@paul-p-cb)
- [#30](https://github.com/krogertechnology/hw-az-keyvault/pull/30) HWART-81724 update and test new terratest oidc auth workflow and credentials (@donald-picard-kr)

### v0.5.1 (2022/07/08 14:13 +00:00)
- [#27](https://github.com/krogertechnology/hw-az-keyvault/pull/27) Feature/hwart 80911 additional access policy testing, documentation (@Rob-Bosma-KR)
- [#28](https://github.com/krogertechnology/hw-az-keyvault/pull/28) add project card to workflows (@donald-picard-kr)

### v0.5.0 (2022/07/01 12:58 +00:00)
- [#26](https://github.com/krogertechnology/hw-az-keyvault/pull/26) add new log category and metric (@gregory-ware)

### v0.4.2 (2022/06/03 18:00 +00:00)
- [#23](https://github.com/krogertechnology/hw-az-keyvault/pull/23) fix issue where keyvault is deleted before access policies on terraform destroy (@donald-picard-kr)

### v0.4.1 (2022/05/31 18:37 +00:00)
- [#22](https://github.com/krogertechnology/hw-az-keyvault/pull/22) Correct authorization(r/R)ules typo (@Rob-Bosma-KR)

### v0.4.0 (2022/05/31 17:23 +00:00)
- [#20](https://github.com/krogertechnology/hw-az-keyvault/pull/20) Feature/hwart 76460 update for support of azurerm greater than v3, also works with versions >2 and <3 (@donald-picard-kr)
- [#19](https://github.com/krogertechnology/hw-az-keyvault/pull/19) hwart 77504 Update to module template v0.5.1 (@donald-picard-kr)

### v0.3.0 (2022/04/07 15:31 +00:00)
- [#18](https://github.com/krogertechnology/hw-az-keyvault/pull/18) Turning on firewall, Creating permissions for runners to access KV in deployment and testing (@Rob-Bosma-KR)
- [#17](https://github.com/krogertechnology/hw-az-keyvault/pull/17) add in 3 minute delay for testing (@donald-picard-kr)

### v0.2.0 (2022/03/31 13:35 +00:00)
- [#15](https://github.com/krogertechnology/hw-az-keyvault/pull/15) Feature/hwart 67864 firewallon (@Rob-Bosma-KR)

### v0.1.1 (2022/03/30 19:12 +00:00)
- [#14](https://github.com/krogertechnology/hw-az-keyvault/pull/14) Convert to reusable Workflow (@Rob-Bosma-KR)
- [#11](https://github.com/krogertechnology/hw-az-keyvault/pull/11) Add pre-requisite SP requirements to readme (@Rob-Bosma-KR)

### v0.1.0 (2022/01/28 17:14 +00:00)
- [#10](https://github.com/krogertechnology/hw-az-keyvault/pull/10) adding qradar.tf file, updated variables.tf to include qradar vars. l… (@henry-w-cb)

### v0.0.8 (2021/11/15 17:03 +00:00)
- [#7](https://github.com/krogertechnology/hw-az-keyvault/pull/7) Code convention compliance updates (@LanceZeligman-KR)
- [#8](https://github.com/krogertechnology/hw-az-keyvault/pull/8) update with modules template file (@donald-picard-kr)

### v0.0.7 (2021/07/09 21:10 +00:00)
- [#6](https://github.com/krogertechnology/hw-az-keyvault/pull/6) Bug: Key Permission (@christian-d-cb)

### v0.0.6 (2021/07/09 13:50 +00:00)
- [#5](https://github.com/krogertechnology/hw-az-keyvault/pull/5) Bug: Access Policy Fix (@christian-d-cb)

### v0.0.5 (2021/07/08 15:14 +00:00)
- [#4](https://github.com/krogertechnology/hw-az-keyvault/pull/4) Network ACL Fix (@christian-d-cb)

### v0.0.4 (2021/07/01 15:23 +00:00)
- [#3](https://github.com/krogertechnology/hw-az-keyvault/pull/3) Updated workflow and supporting files for documentation and testing t… (@travis-crowder-kr)

### v0.0.3 (2021/06/11 17:42 +00:00)
- [#2](https://github.com/krogertechnology/hw-az-keyvault/pull/2) Added Name Creation Support (@christian-d-cb)

### v0.0.2 (2021/05/27 18:03 +00:00)
- [#1](https://github.com/krogertechnology/hw-az-keyvault/pull/1) HWART-60098: Initial Azure Key Vault Module (#1) (@christian-d-cb)