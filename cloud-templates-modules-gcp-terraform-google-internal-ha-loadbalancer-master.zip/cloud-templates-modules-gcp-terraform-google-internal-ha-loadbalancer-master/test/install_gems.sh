#!/usr/bin/env bash

set -ex

git clone https://gitlab.kroger.com/cloud-templates/modules/gcp/test-kitchen-gems.git /tmp/gem_management

# Configure gems
echo 'install: --no-rdoc --no-ri' >> $HOME/.gemrc
cd /tmp/gem_management
gem sources -r https://rubygems.org/
gem install rubygems-update
update_rubygems --no-document
cp /tmp/gem_management/Gemfile ${CI_PROJECT_DIR}/
mv /tmp/gem_management/vendor ${CI_PROJECT_DIR}/vendor

# Install gems
cd ${CI_PROJECT_DIR}
bundle install --local