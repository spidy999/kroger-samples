# encoding: utf-8
# copyright: 2019, Cloudreach

title 'Baseline tests'

project_name = attribute('project_name')
region = 'us-central1'
name = 'test-kitchen'
ip_name = "#{name}-static-ip"
rule_name = "#{name}-forwarding-rule"

control 'Check baseline' do
  impact 1.0
  title 'Baseline control test'
  desc 'This makes sure the module creates successfully and has some common configuration requirements'

  # Check frontend static IP
  describe google_compute_address(project: project_name, location: region, name: ip_name) do
    its('name') { should eq ip_name }
    its('region') { should match region }
  end

  # Check frontend forwarding rule
  describe google_compute_forwarding_rule(project: project_name, region: region, name: rule_name) do
    it { should exist }
    its('name') { should eq rule_name }
    its('region') { should match region }
  end
end