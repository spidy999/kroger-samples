# terraform-google-internal-ha-loadbalancer

## Test status

[![Test status for master branch](https://gitlab.kroger.com/cloud-templates/modules/gcp/terraform-google-internal-ha-loadbalancer/badges/master/pipeline.svg)](https://gitlab.kroger.com/cloud-templates/modules/gcp/terraform-google-internal-ha-loadbalancer/commits/master)

## Overview

A Terraform module that creates a Load Balancer backed by 2 managed instance groups.

## Usage

Reference this module as part of the GitLab Infrastructure pipeline for your project using Terraform.

### Example

```hcl
module "internallb" {
    source                = "git::https://gitlab.kroger.com/cloud-templates/modules/gcp/terraform-google-internal-ha-loadbalancer.git?ref=v2.0.0"
    name                  = "loadbalancer-name"
    shared_vpc_project    = "shared-vpc-project"
    region                = "region"
    subnetwork            = "subnetwork"
    backend_timeout_sec   = "60"
    healthcheck_timeout   = "60"
    healthcheck_check_interval_sec = "60"
    port                  = "port"
    project_id            = "project-id"
    backend_group_1       = "${module.mig-1.instance_group}"
    backend_group_2       = "${module.mig-2.instance_group}"
}
```

## Inputs

| Name | Description | Type | Default | Required |
|------|---------|:----:|:-----:|:-----:|
| backend_group_1 | The name or URI of a Compute Engine instance group (google_compute_region_instance_group_manager.xyz.instance_group) that can receive traffic. Instance groups must contain at least one instance. Reference the instance group from your mig module. | string | n/a | yes |
| backend_group_2 | The name or URI of a Compute Engine instance group (google_compute_region_instance_group_manager.xyz.instance_group) that can receive traffic. Instance groups must contain at least one instance.  Reference the instance group from your mig module. | string | n/a | yes |
| backend_timeout_sec |The number of secs to wait for a backend to respond to a request before considering the request failed. Defaults to 30. | string | n/a | yes |
| healthcheck_check_interval_sec |How often (in seconds) to send a health check. The default value is 5 seconds. | string | n/a | yes |
| healthcheck_timeout | How long (in seconds) to wait before claiming failure. The default value is 5 seconds. It is invalid for timeoutSec to have greater value than checkIntervalSec. | string | n/a | yes |
| ip_address_labels| list of labels for the IP address | `map` | `{}` | yes |
| labels | labels for forwarding rule | `map` | `{}` | no |
| name | name of load balancer | list | `<list>` | no |
| port | The TCP port number for the TCP health check request. The default value is 443. | string | n/a | yes |
| project_id | project to deploy to | string | n/a | yes |
| region | The Region in which the created address should reside. If it is not provided, the provider region is used. | string | n/a | yes |
| shared_vpc_project | project where shared vpc lives | string | n/a | yes |
| subnetwork | subnet to deploy to | string | n/a | yes |


## Outputs

| Name | Description |
|------|-------------|

## Notes

An example can be found here: https://gitlab.kroger.com/cloud-templates/gcp-terraform-implementations/ha-gce-deployment/tree/master

`backend_group_1` and `backend_group_2` can also be cluster instance groups. You may need to add additional interpolation to your instance group:

```
backend_group_1 = "${replace(element(google_container_cluster.cluster-name.instance_group_urls, 1), "Manager", "")}"
```

# Development & contributing

Develop new features in a feature branch named `feature/<feature-description>.` Tests will run in any branch following this naming standard as well as any branch named `test`. Once tests pass (see [Testing](#testing)), create a merge request (MR) into the Master branch.

Version your changes in the Master branch when merged and tests pass. Features and new features should follow [Semantic Versioning](https://semver.org/):

```
Given a version number MAJOR.MINOR.PATCH, increment the:

1. MAJOR version when you make backwards-incompatible changes,
2. MINOR version when you add functionality in a backwards-compatible manner, and
3. PATCH version when you make backwards-compatible bug fixes.

Additional labels for pre-release and build metadata are available as extensions to the MAJOR.MINOR.PATCH format.
```

## Testing

Add any new test Terraform as needed in `test/terraform`, with tests written in `test/integration/baseline/`. See [How to configure tests](#how-to-configure-tests) for more details on configuring tests. If changes do not need testing (e.g. README updates), add `[skip ci]` to the commit message or MR title.

Using [Test Kitchen for Terraform](https://github.com/newcontext-oss/kitchen-terraform) to deploy testing resources, and [InSpec for GCP](https://www.inspec.io/docs/reference/resources/#gcp-resources) to write tests.

### Testing TODOs

- Tests currently run in the kr-3533-test-d project, which is also used for other development testing. This could move to a different project dedicated to Test Kitchen.
- Test Kitchen and Inspec are currently installed on Gitlab runners using Ruby gems from a Kroger repo (https://gitlab.kroger.com/cloud-templates/modules/gcp/test-kitchen-gems) due to network limitations. This should either be fixed by
    - (Preferred) Baking all gems and configuration into a Gitlab runner or in the container used by the runner job
    - Allow connectivity to rubygems from the Gitlab runners used

### How to set up testing

_Skip this section if tests are already set up in this repository._ 

1. Create a `test` branch to be used before merging new code into `master`
    - Protect this branch (Settings > Repository; Allow maintainers + developers to push/merge). This prevents anyone from deleting it.
2. Set the `KITCHEN_SERVICE_ACCOUNT_KEY` CI variable (**Settings > CI / CD > Environment variables**) to the base64-encoded key for the GCP Service Account to be used in the test project
3. Copy the following to your module:
    - `test/` directory
    - .gitlab-ci.yml
    - .kitchen.yml
4. Add a badge to your README (see this README) showing the status of the test pipeline

### How to write and run tests

1. Modify files in `test/terraform/` to use your module as you might in a pipeline or in example code
    - The `source` parameter for modules should be `../../`
    - Put variable assignments in `test/terraform/vars.auto.tfvars`
2. Modify attributes as needed for your tests
    - Declare them in `test/integration/inspec.yml`
    - Assign them values in `test/integration/attributes.yml`
    - Use them as needed in your `.rb` files used for testing
    - These will probably map very closely to your Terraform vars
3. Write your tests using InSpec in `test/integration/baseline/controls/`
    - These can be in any `*.rb` files
    - Note that control names should all be different
    - All controls will run and tested
4. Commit and a test will run
5.  The test job will show results in the job details, but you can also download two artifacts that show report status
    - report.txt (duplicate of what's shown at the end of the console)
    - report.html (html-formatted report with colors and snippets of code where any failures happened)