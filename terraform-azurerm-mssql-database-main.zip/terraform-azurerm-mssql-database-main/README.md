# terraform-azurerm-mssql-database
Terraform-azurerm-mssql_database is a thin wrapper of multiple modules focusing around creating a SQL Server Database. With a goal of enabling developers to standup SQL Server Database resource with minimal effort and Kroger resource tag standards.                           

## Dependencies
[Terraform](https://www.terraform.io/downloads.html) ~> 1.5.0

### Providers:
- [azurerm](https://registry.terraform.io/providers/hashicorp/azurerm) >= 3.0.0, < 4.0.0

### Child Modules:
- "github.com/krogertechnology/terraform-azurerm-mssql-elasticpool.git?ref=1.0.4"
- "github.com/krogertechnology/terraform-azurerm-mssql-server.git?ref=1.0.4"

## Basic Usage
 * Terraform Code: 
```HCL

module "sql_server" {
  source                       = "github.com/krogertechnology/terraform-azurerm-mssql-server.git?ref=1.0.2"

  # Kroger variables
  lob                          = "SCMF TECH"
  owner                        = "YOUR-EMAIL@kroger.com"
  cost_center                  = "Your Cost Center"
  spm_id                       = "Your SPM ID"
  application_name             = "Your Application Name"
  environment                  = "Your Environment"
  
  # Module required
  name                         = "Your SQl Server DB Name"
  server_id                    = "Your SQl Server ID"
  elastic_pool_id              = "Your SQl Server elastic pool ID"
}

```

## Github Workflow Yaml: 
```yaml
name: EXAMPLE

on: 
  workflow_dispatch:

  push:
    branches:
      - main

defaults: 
  run:
    shell: bash

env:
  ARM_CLIENT_SECRET: ${{secrets.YOUR_SP_TOKEN}}
  ARM_CLIENT_ID: # your AZURE Service Prinicipal GUID
  ARM_TENANT_ID: # your AZURE Tenant ID GUID
  ARM_SUBSCRIPTION_ID: # your AZURE Subscripition ID GUID
  TF_IN_AUTOMATION: true
  TF_VAR_arm_client_secret: ${{secrets.YOUR_SP_TOKEN}}

jobs:
  testing_module:
    name: Testing Module
    
    runs-on: [kubernetes, self-hosted]
    container:
      image: krogertechnology-docker.jfrog.io/fst/workflow-runner:latest
      credentials:
        username: s7702jfrogP@kroger.com
        password: ${{secrets.ARTIFACTORY_API_KEY}}

    defaults: 
      run:
        working-directory: # Your Terraform files directory

    steps:
      - name: Checkout
        uses: actions/checkout@v3

      - name: Terraform Check Format
        run: terraform fmt -check
    
    # This is required in order to use the Mandalorian Modules 
      - name: Set GitHub Credentials
        uses: krogertechnology/grant-internal-repo-access@1.1.0
        with:
          kt-internal-repo-key: ${{secrets.KT_INTERAL_REPO_KEY}} 
      
      - name: Terraform Init
        run: terraform init -input=false

      - name: Terraform Apply

        run: terraform apply -auto-approve -input=false 
```
