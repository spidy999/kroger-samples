
# Azure Web App Building Block

<!-- **********  Update reponames in links below with your repo name ********** -->
[![Module Terraform Tests](https://github.com/krogertechnology/hw-az-webapp/actions/workflows/terraform-tests.yml/badge.svg)](https://github.com/krogertechnology/hw-az-webapp/actions/workflows/terraform-tests.yml) [![Module Tag & Release](https://github.com/krogertechnology/hw-az-webapp/actions/workflows/module-tag-release.yml/badge.svg)](https://github.com/krogertechnology/hw-az-webapp/actions/workflows/module-tag-release.yml)

<!-- DO NOT ADD LINES TO THE README HERE! -->
<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->

- [Description](#description)
  - [This module only supports Linux type Web apps (Linux/Java, Linux/Node, Linux/PHP, Linux/Python or Linux/Ruby).](#this-module-only-supports-linux-type-web-apps-linuxjava-linuxnode-linuxphp-linuxpython-or-linuxruby)
- [⚠ Azurerm 3.0 Migration ⚠](#%E2%9A%A0-azurerm-30-migration-%E2%9A%A0)
- [⚠ Azurerm 3.0 Migration - from azurerm_app_service_plan, azurerm_app_service and azurerm_app_service_slot (no module) ⚠](#%E2%9A%A0-azurerm-30-migration---from-azurerm_app_service_plan-azurerm_app_service-and-azurerm_app_service_slot-no-module-%E2%9A%A0)
- [Requirements](#requirements)
- [Providers](#providers)
- [Modules](#modules)
- [Resources](#resources)
- [Inputs](#inputs)
- [Outputs](#outputs)
- [Examples](#examples)
- [Useful Links](#useful-links)
  - [Here is a link to the standards for making a pull request to one of these Terraform module repos](#here-is-a-link-to-the-standards-for-making-a-pull-request-to-one-of-these-terraform-module-repos)
- [Change Log](#change-log)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

<!--  \/  \/  \/ START - Only manually edit between these two lines \/  \/  \/ -->

## Description

### This module only supports Linux type Web apps (Linux/Java, Linux/Node, Linux/PHP, Linux/Python or Linux/Ruby).

Consumption plans are not supported due to vnet limitations.

See the following link for additional documentation:

https://azure.microsoft.com/en-us/products/app-service/#documentation

This building block is intended to provide best practices for applications using [Azure Web Apps](https://azure.microsoft.com/en-us/services/app-service/web/). It is expected that anyone who consumes this module will provide a Key Vault URI until the central Key Vault has been created. In addition to that, they are expected to provide the name of the secrets for the artifactory user and artifactory password as they would be seen in the created Key Vault, the module will create the required keyvault reference. Both the App Service and the App Service Slot will need an access policy to the keyvault, the identities have been provided as outputs. This building block no longer requires the app_gateway_subnet_id as an input variable. Instead this should be added as a part of the additional_subnet_restrictions array, see the examples for additional information.

Here is a link to the standards for making a pull request to one of these Terraform Module Repo  
 Note: you may have to open the link a second time if you get redirected to the confluence logon page.  
[H&W Terraform Coding Standards#Pull Requests to module repos](https://confluence.kroger.com/confluence/pages/viewpage.action?pageId=186982308#H&WTerraformCodingStandards-PullRequeststomodulerepos)

## ⚠ Azurerm 3.0 Migration ⚠

Projects with existing WebApp module consumption can incrementally upgrade the module version to reduce the amount of Terraform state file manipulations needed in a single upgrade. For projects with a WebApp module < v2.0.0, upgrading to v2.0.0 will allow for the use of Azurerm 3.0 without requiring Terraform state file manipulation. WebApp module v2.1.0 replaces the deprecated azurerm_app_service_plan with azurerm_service_plan, and will require Terraform state file manipulation. WebApp module v2.2.0 replaces the azurerm_app_service and azurerm_app_service_slot with azurerm_linux_web_app and azurerm_linux_web_app_slot, and will require Terraform state file manipulation.

Please note that WebApp module v2.0.0 and v2.1.0 contain deprecated resources that will be removed in Azurerm 4.0, so these versions should be treated as incremental upgrades, with the goal being to upgrade the module version to v2.2.0 or greater.

To upgrade your azurerm Application Service Plan (ASP) and Web App to the >= 3.0 azurerm service plan and app without destroying the originals, you will need to manipulate the terraform state file to perform multiple terraform state rm and terraform state imports by following the example below and our Terraform Advanced Usage documentation (linked below):

Example Module Definition

```
module "foo_web_app" {
  source                         = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-webapp-v1.4.2.tar.gz"
  ...
}
```

First, upgrade module to v2.2.0 like so

```
module "foo_web_app" {
  source                         = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-webapp-v2.2.0.tar.gz"
  ...
}
```

Be sure to validate all inputs are sane and accounted for.

Save but do not yet push this change to origin. Following our guide for terraform state change linked below, acquire the terraform state file (this will require you to PIM up per the instructions).

For the App Service Plan:

Perform a `terraform state list`. Copy the Web App Service Plan path, it will look similar to `module.foo_web_app.azurerm_app_service_plan.webapp_svc_plan`.

Using the path acquire the resource id. `echo module.foo_web_app.azurerm_app_service_plan.webapp_svc_plan | terraform console`

Now we remove the resource id. `terraform state rm module.foo_web_app.azurerm_app_service_plan.webapp_svc_plan`

Finally, we import the new resource using the old resource id. `terraform state import module.foo_web_app.azurerm_service_plan.webapp_svc_plan <resource id>`

This process needs to be repeated for the Web App Service and the Web App Service Slots.

For the Web App Service:

Perform a `terraform state list`. Copy the Web App Service path, it will look similar to `module.foo_webapp_web.azurerm_app_service.web`.

Using the path acquire the resource id. `echo module.foo_webapp_web.azurerm_app_service.web | terraform console`

Now we remove the resource id. `terraform state rm module.foo_webapp_web.azurerm_app_service.web`

Finally, we import the new resource using the old resource id. `terraform state import module.foo_webapp_web.azurerm_linux_web_app.web <resource id>`

For the Web App Service Slots:

Perform a `terraform state list`. Copy the Web App Service Slots path, it will look similar to `module.foo_webapp_web.azurerm_app_service_slot.web_slots`.

Using the path acquire the resource id. `echo module.foo_webapp_web.azurerm_app_service_slot.web_slots | terraform console`

Now we remove the resource id. `terraform state rm module.foo_webapp_web.azurerm_app_service_slot.web_slots`

Finally, we import the new resource using the old resource id. `terraform state import module.foo_webapp_web.azurerm_linux_web_app_slot.web_slots <resource id>`

For additional documentation please visit
https://confluence.kroger.com/confluence/display/HW/Terraform+Advanced+Usage
https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/guides/migrating-from-deprecated-resources
https://github.com/hashicorp/terraform-provider-azurerm/blob/main/website/docs/guides/3.0-upgrade-guide.html.markdown

## ⚠ Azurerm 3.0 Migration - from azurerm_app_service_plan, azurerm_app_service and azurerm_app_service_slot (no module) ⚠

To upgrade your web app created with the azurerm_app_service_plan and azurerm_app_service to the >= 3.0 azurerm web app module without destroying the originals, you will need to:

- Use the "web_app_plan_name_override" and "web_app_name_override" in your call to the web app module to make sure your web app and its app service plan will use the same names as are currently deployed.
- Perform a "terraform state mv" on the app service plan to the new service plan. (See below)
- Perform a "terraform state mv" on the web app to the new linux web app. (See below)

1.  Make your changes to the terraform in a feature branch and push up to github
2.  Make a draft PR and refer to the action plan_only/plan
3.  Take note of the terraform instance name of azurerm_app_service_plan that is to be destroyed from the example below (azurerm_app_service_plan.web_service_plan) as well as its resource ID (/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/serverFarms/ASP-hwreportalservicedevrg-9c62).

```
# azurerm_app_service_plan.web_service_plan will be destroyed
 # (azurerm_app_service_plan.web_service_plan is not in configuration)
 - resource "azurerm_app_service_plan" "web_service_plan" {
     - id = "/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/serverFarms/ASP-hwreportalservicedevrg-9c62" -> null
```

4.  Take note of the terraform instance name of the app service tied to the app service plan that is to be destroyed from the example below (azurerm_app_service.web) as well as its resource ID
    (/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/sites/reportal-service-dev)

```
 # azurerm_app_service.web will be destroyed
 # (because azurerm_app_service.web is not in configuration)
 - resource "azurerm_app_service" "web_service_plan"
     - id = "/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/sites/reportal-service-dev" -> null
```

5.  Take note of the terraform instance name of azurerm_service_plan that is to be created from the example below (module.webapp.azurerm_service_plan.web_service_plan)

```
 # module.webapp.azurerm_service_plan.web_service_plan will be created
 + resource "azurerm_service_plan" "web_service_plan"
```

6.  Take note of the terraform instance name of azurerm_linux_web_app that is to be created from the example below (module.webapp.azurerm_linux_web_app.web)

```
 # module.webapp.azurerm_linux_web_app.web will be created
 + resource "azurerm_linux_web_app" "web"
```

7.  Take note of the terraform instance name of azurerm_linux_web_app_slot that is to be created from the example below (module.webapp.azurerm_linux_web_app_slot.web_slots)

```
 # module.webapp.azurerm_linux_web_app_slot.web_slots will be created
 + resource "azurerm_linux_web_app_slot" "web_slots"
```

8. PIM up to contributor in hw-terraform-nonprod-rg or hw-terraform-rg
9. Make a snapshot back-up of your terraform state file
10. CD to the root directory of your application terraform
11. az login # login to Azure CLI
12. az account set --subscription HealthAndWellnessNonProd # or HealthAndWellnessProd
13. terraform init -backend-config="./backends/dev.hcl" # or appropriate environment
14. set some variables based on your data above:

- asp_destroyed=azurerm_app_service_plan.web_service_plan
- asp_created=module.webapp.azurerm_service_plan.web_service_plan
- asp_resource='/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/serverFarms/ASP-hwreportalservicedevrg-9c62'
- app_destroyed=azurerm_app_service.web_service_plan
- app_created= module.webapp.azurerm_linux_web_app.web
- app_resource='/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/sites/reportal-service-dev'
- app_destroyed=azurerm_app_service_slot.web_slots
- app_created= module.webapp.azurerm_linux_web_app_slot.web_slots
- app_resource='/subscriptions/67775f55-e7ed-48fa-9fba-be26310c6431/resourceGroups/hw-reportal-service-dev-rg/providers/Microsoft.Web/sites/reportal-service-dev/slots/staging'
- Terraform import will prompt for JFROG_USER and JFROG_TOKEN but they aren't used by the import. Adding those variables with dummy values to the import statement will avoid unnecessary prompts.

15. terraform state mv $asp_destroyed $asp_created # replace terraform reference for the app service plan to the new reference
16. terraform state mv $app_destroyed $app_created # replace terraform reference for the web app to the new reference
17. terraform import -var-file="tfvars-dev.tfvars" -var="JFROG_USER=fake" -var="JFROG_TOKEN=fake" $asp_created $asp_resource
18. terraform import -var-file="tfvars-dev.tfvars" -var="JFROG_USER=fake" -var="JFROG_TOKEN=fake" $app_created $app_resource
19. The other infrastructure will be destroyed and recreated for the web app as appropriate, but that infrastructure doesn't hold any data so it doesn't hurt to let it recreate (swift connections, app slots, etc.)
20. Go back to the plan and re-run and you should have a whole lot less replacing going on.

<!--  /\  /\  /\ END - Only manually edit between these two lines   /\  /\  /\ -->
<!--  Don't Edit Below This Line -->
<!-- BEGIN_TF_DOCS -->


## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.0.0, <4 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | >= 3.0.0, <4 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_linux_web_app.web](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_web_app) | resource |
| [azurerm_linux_web_app_slot.web_slots](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/linux_web_app_slot) | resource |
| [azurerm_service_plan.web_service_plan](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/service_plan) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_additional_ip_restrictions"></a> [additional\_ip\_restrictions](#input\_additional\_ip\_restrictions) | List of ip restrictions to apply to the web app. | <pre>list(object({<br>    ip_address = string<br>    name       = string<br>    priority   = string<br>    action     = string<br>  }))</pre> | n/a | yes |
| <a name="input_additional_subnet_restrictions"></a> [additional\_subnet\_restrictions](#input\_additional\_subnet\_restrictions) | List of subnet restrictions to apply to the web app. | <pre>list(object({<br>    virtual_network_subnet_id = string<br>    name                      = string<br>    priority                  = string<br>    action                    = string<br>  }))</pre> | n/a | yes |
| <a name="input_always_on"></a> [always\_on](#input\_always\_on) | Setting to keep web app always running. | `string` | `true` | no |
| <a name="input_app_port"></a> [app\_port](#input\_app\_port) | Port for the app to use for website | `string` | `"8080"` | no |
| <a name="input_app_settings"></a> [app\_settings](#input\_app\_settings) | Web app config settings. | `map(string)` | `{}` | no |
| <a name="input_artifactory_password"></a> [artifactory\_password](#input\_artifactory\_password) | Azure Key Vault Secret reference containing password that will be used to log into Artifactory | `string` | `""` | no |
| <a name="input_artifactory_user"></a> [artifactory\_user](#input\_artifactory\_user) | Azure Key Vault Secret reference containing username that will be used to log into Artifactory | `string` | `""` | no |
| <a name="input_asp_os_type"></a> [asp\_os\_type](#input\_asp\_os\_type) | The type of OS used for the app service plan. Possible values are Windows, Linux and WindowsContainer. | `string` | `"Linux"` | no |
| <a name="input_asp_sku_name"></a> [asp\_sku\_name](#input\_asp\_sku\_name) | Used to select the Application Service Plan SKU for the Web ASP | `string` | `"P1v3"` | no |
| <a name="input_asp_worker_count"></a> [asp\_worker\_count](#input\_asp\_worker\_count) | Used to select the number of workers associated with the ASP | `string` | `"2"` | no |
| <a name="input_auto_heal_enabled"></a> [auto\_heal\_enabled](#input\_auto\_heal\_enabled) | Enables or disables app auto heal. When enabled, must define auto\_heal\_settings below | `bool` | `false` | no |
| <a name="input_auto_heal_setting"></a> [auto\_heal\_setting](#input\_auto\_heal\_setting) | MUST choose at least one trigger for auto heal but can use all available | <pre>object({<br>    trigger = object({<br>      status_code = optional(list(object({<br>        count             = number<br>        interval          = string<br>        path              = optional(string)<br>        status_code_range = string<br>        sub_status        = optional(number)<br>      })))<br>      slow_request = optional(list(object({<br>        count      = number<br>        interval   = string<br>        path       = optional(string)<br>        time_taken = string<br>      })))<br>      requests = optional(list(object({<br>        count    = number<br>        interval = string<br>      })))<br>    })<br>    action = object({<br>      minimum_process_execution_time = string<br>    })<br>  })</pre> | <pre>{<br>  "action": {<br>    "minimum_process_execution_time": "00:00:00"<br>  },<br>  "trigger": {}<br>}</pre> | no |
| <a name="input_client_affinity_enabled"></a> [client\_affinity\_enabled](#input\_client\_affinity\_enabled) | Should the App Service send session affinity cookies, which route client requests in the same session to the same instance | `string` | `true` | no |
| <a name="input_connection_strings"></a> [connection\_strings](#input\_connection\_strings) | One or more connection\_string blocks.<br>  Each map object must contain Name, Type and Value<br>  See https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/app_service#connection_string | <pre>list(object({<br>    name  = string<br>    type  = string<br>    value = string<br>  }))</pre> | `[]` | no |
| <a name="input_create_service_plan"></a> [create\_service\_plan](#input\_create\_service\_plan) | The app service plan name will be generated if not set | `bool` | `false` | no |
| <a name="input_detailed_error_messages"></a> [detailed\_error\_messages](#input\_detailed\_error\_messages) | n/a | `bool` | `false` | no |
| <a name="input_docker_image_tag"></a> [docker\_image\_tag](#input\_docker\_image\_tag) | The version tag of the docker image | `string` | `"latest"` | no |
| <a name="input_docker_registry_url"></a> [docker\_registry\_url](#input\_docker\_registry\_url) | Url of the Docker Registry, defaults to the Dev url. For Production deploys, override with https://krogertechnology.jfrog.io/artifactory | `string` | `"https://krogertechnology-docker-dev.jfrog.io/"` | no |
| <a name="input_docker_url"></a> [docker\_url](#input\_docker\_url) | Url of the docker container which is need to be updated for the app environment is building | `string` | `"krogertechnology-docker-dev.jfrog.io/hw/dunder-poc"` | no |
| <a name="input_environment"></a> [environment](#input\_environment) | Application environment. Used for enforcing Naming and Tagging Convention | `string` | `"dev"` | no |
| <a name="input_failed_request_tracing"></a> [failed\_request\_tracing](#input\_failed\_request\_tracing) | n/a | `bool` | `false` | no |
| <a name="input_ftps_state"></a> [ftps\_state](#input\_ftps\_state) | (Optional) State of FTP / FTPS service for this function app. | `string` | `"Disabled"` | no |
| <a name="input_identity"></a> [identity](#input\_identity) | (Required) Specifies the identity type of the App Service.<br>  Possible values are SystemAssigned (where Azure will generate a Service Principal for you),<br>  UserAssigned where you can specify the Service Principal IDs in the identity\_ids field, and SystemAssigned, <br>  UserAssigned which assigns both a system managed identity as well as the specified user assigned identities.<br>  Defaults to SystemAssigned | `string` | `"SystemAssigned"` | no |
| <a name="input_identity_ids"></a> [identity\_ids](#input\_identity\_ids) | (Optional) Specifies a list of user managed identity ids to be assigned. Required if type is UserAssigned. | `list(string)` | `[]` | no |
| <a name="input_keyvault_uri"></a> [keyvault\_uri](#input\_keyvault\_uri) | (Required) Allows for overriding the default keyvault of the module with a user supplied one. In the future, this will default to the central keyvault. | `string` | `""` | no |
| <a name="input_location"></a> [location](#input\_location) | The location to create the web app. | `string` | `"eastus2"` | no |
| <a name="input_logging_retention"></a> [logging\_retention](#input\_logging\_retention) | n/a | <pre>object({<br>    retention_in_days = number<br>    retention_in_mb   = number<br>  })</pre> | <pre>{<br>  "retention_in_days": 1,<br>  "retention_in_mb": 100<br>}</pre> | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | The name of the resource group in which to create the web app. | `string` | n/a | yes |
| <a name="input_service_plan_id"></a> [service\_plan\_id](#input\_service\_plan\_id) | The id of the app service plan that will host the web app, one will be created if none are provided and if create\_app\_service\_plan is true | `string` | `""` | no |
| <a name="input_service_plan_subnet_id"></a> [service\_plan\_subnet\_id](#input\_service\_plan\_subnet\_id) | The id of subnet that contains the app service plan (asp) that the web app will use.  This is assigned to the virtual\_network\_subnet\_id in the module. | `string` | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to be applied to the web app. | <pre>object({<br>    spm-id           = number<br>    owner            = string<br>    lob              = string<br>    application-name = string<br>    cost-center      = string<br>  })</pre> | n/a | yes |
| <a name="input_vnet_route_all_enabled"></a> [vnet\_route\_all\_enabled](#input\_vnet\_route\_all\_enabled) | Set to true to enable routing of all traffic from your app into the VNet | `bool` | `false` | no |
| <a name="input_web_app_name"></a> [web\_app\_name](#input\_web\_app\_name) | The name of the web app. | `string` | `"app-name"` | no |
| <a name="input_web_app_name_override"></a> [web\_app\_name\_override](#input\_web\_app\_name\_override) | Used to override the naming conventions used in this module for a webapp | `string` | `""` | no |
| <a name="input_web_app_plan_name_override"></a> [web\_app\_plan\_name\_override](#input\_web\_app\_plan\_name\_override) | Used to override the naming convention of the app service plan naming conventions | `string` | `""` | no |
| <a name="input_web_app_slot_name"></a> [web\_app\_slot\_name](#input\_web\_app\_slot\_name) | Web slot for harness deployment which depends on where it will be deployed | `string` | `"staging"` | no |
| <a name="input_web_app_type"></a> [web\_app\_type](#input\_web\_app\_type) | Used to determine if the app service is a web app or an api service app. Available choices are web or service | `string` | `"web"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_site_url"></a> [site\_url](#output\_site\_url) | Azure URL of the App Service. |
| <a name="output_web_id"></a> [web\_id](#output\_web\_id) | The ID of the App Service. |
| <a name="output_web_service_plan_id"></a> [web\_service\_plan\_id](#output\_web\_service\_plan\_id) | The ID of the App Service Plan within which the Web App was created. |
| <a name="output_webapp_identity"></a> [webapp\_identity](#output\_webapp\_identity) | The Principal ID for the Service Principal associated with the Managed Service Identity of this App Service. |
| <a name="output_webapp_name"></a> [webapp\_name](#output\_webapp\_name) | The name of the App Service. |
| <a name="output_webapp_slot_identity"></a> [webapp\_slot\_identity](#output\_webapp\_slot\_identity) | The Principal ID for the Service Principal associated with the Managed Service Identity of this App Service Slot. |

## Examples

```hcl
module "test" {
  source                 = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-webapp-v2.5.2.tar.gz"
  web_app_name           = "My App"
  resource_group_name    = "the_resource_group"
  location               = "eastus2"
  app_service_plan_id    = azurerm_service_plan.asp.id
  service_plan_subnet_id = azurerm_subnet.subnet.id
  tags = {
    spm-id : 12345,
    owner : "test owner",
    lob : "test lob",
    application-name : "test application"
    cost-center : "test cost"
  }
  asp_subnet_id = azurerm_subnet.subnet.id
  additional_ip_restrictions = [
    {
      ip_address = "0.0.0.0/0"
      name       = "test"
      priority   = "110"
      action     = "Allow"
    }
  ]
  additional_subnet_restrictions = [
    {
      virtual_network_subnet_id = azurerm_subnet.subnet.id
      name                      = "app gateway"
      priority                  = "100"
      action                    = "Allow"
    }
  ]
  # scm_ip_restriction = []
  app_settings = {
    BUILD_VERSION = ""
  }
}

module "test_2" {
  source                 = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-webapp-v2.5.2.tar.gz"
  web_app_name           = "My App 2"
  resource_group_name    = "the_resource_group"
  location               = "eastus2"
  app_service_plan_id    = azurerm_service_plan.asp.id
  service_plan_subnet_id = azurerm_subnet.subnet.id
  tags = {
    spm-id : 12345,
    owner : "test owner",
    lob : "test lob",
    application-name : "test application"
    cost-center : "test cost"
  }
  asp_subnet_id = azurerm_subnet.subnet.id
  additional_ip_restrictions = [
    {
      ip_address = "0.0.0.0/0"
      name       = "test"
      priority   = "110"
      action     = "Allow"
    }
  ]
  additional_subnet_restrictions = [
  ]
  # scm_ip_restriction = []
  app_settings = {
    BUILD_VERSION = ""
  }
}

module "test_3_auto_heal" {
  source                 = "https://krogertechnology.jfrog.io/artifactory/kroger-hw-azure/tf-modules/hw-az-webapp-v2.5.2.tar.gz"
  web_app_name           = "My App 3"
  resource_group_name    = "the_resource_group"
  location               = "eastus2"
  app_service_plan_id    = azurerm_service_plan.asp.id
  service_plan_subnet_id = azurerm_subnet.subnet.id
  vnet_route_all_enabled = var.vnet_route_all_enabled
  tags = {
    spm-id : 12345,
    owner : "test owner",
    lob : "test lob",
    application-name : "test application"
    cost-center : "test cost"
  }
  asp_subnet_id = azurerm_subnet.subnet.id
  additional_ip_restrictions = [
    {
      ip_address = "0.0.0.0/0"
      name       = "test"
      priority   = "110"
      action     = "Allow"
    }
  ]
  additional_subnet_restrictions = [
  ]
  # scm_ip_restriction = []
  app_settings = {
    BUILD_VERSION = ""
  }

  #toggle auto heal
  auto_heal_enabled = true
  auto_heal_setting = {
    trigger = {
      status_code = [
        {
          count             = 10
          interval          = "00:05:00"
          status_code_range = "500-599"
        }
      ]
    }
    action = {
      minimum_process_execution_time = "00:05:00"
    }
  }
}

```


<!-- END_TF_DOCS -->

## Useful Links

- [Azure Naming Standards - Health and Wellness](https://confluence.kroger.com/confluence/pages/viewpage.action?pageId=167664066)
- Click for [Terraform Module Usage, Requirements, and Testing](https://confluence.kroger.com/confluence/display/HW/Terraform+Module+Usage%2C+Requirements%2C+and+Testing)

### Here is a link to the standards for making a pull request to one of these Terraform module repos

    Note: you may have to open the link a second time if you get redirected to the confluence logon page.

[H&W Terraform Coding Standards#Pull Requests to module repos](https://confluence.kroger.com/confluence/pages/viewpage.action?pageId=186982308#H&WTerraformCodingStandards-PullRequeststomodulerepos)

## Change Log

The [change log](CHANGELOG.md) is automated via Release Tags and PR Titles by [github-changes](https://github.com/lalitkapoor/github-changes), provided under MIT License by 2014 Lalit Kapoor.

The change log is composed of Git Tags with the date along with each pull requests title. The pull request number as well as the author is noted. If you already have a change log, github-changes will replace it.
