package test

import (
	"crypto/tls"
	"fmt"
	"testing"
	"time"

	httpHelper "github.com/gruntwork-io/terratest/modules/http-helper"
	"github.com/gruntwork-io/terratest/modules/terraform"
)

func TestIT_TestFirstScenario(t *testing.T) {
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "./fixtures/main/test_one/",
		NoColor:      true,
	})
	// At the end of the test, run `terraform destroy`
	defer terraform.Destroy(t, terraformOptions)
	// Run `terraform init` and `terraform apply`
	terraform.InitAndApply(t, terraformOptions)

	// Printed before Sleep method is invoked
	fmt.Println("Sleeping for 90 seconds")

	// Calling Sleep method
	time.Sleep(90 * time.Second)

	// Run `terraform output` to get the value of an output variable
	siteurl := terraform.Output(t, terraformOptions, "site_url")

	// Call the web app and look for a 200 response with retries and sleep to account for build time variances
	retries := 10
	sleep := 10 * time.Second
	httpHelper.HttpGetWithRetryWithCustomValidation(t, siteurl, &tls.Config{}, retries, sleep,
		func(statusCode int, body string) bool {
			return statusCode >= 200
		},
	)
}

func TestIT_TestSecondScenario(t *testing.T) {
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "./fixtures/main/test_two/",
		NoColor:      true,
	})
	// At the end of the test, run `terraform destroy`
	defer terraform.Destroy(t, terraformOptions)
	// Run `terraform init` and `terraform apply`
	terraform.InitAndApply(t, terraformOptions)

	// Printed before Sleep method is invoked
	fmt.Println("Sleeping for 90 seconds")

	// Calling Sleep method
	time.Sleep(90 * time.Second)

	// Run `terraform output` to get the value of an output variable
	siteurl := terraform.Output(t, terraformOptions, "site_url")

	// Call the web app and look for a 200 response with retries and sleep to account for build time variances
	retries := 10
	sleep := 10 * time.Second
	httpHelper.HttpGetWithRetryWithCustomValidation(t, siteurl, &tls.Config{}, retries, sleep,
		func(statusCode int, body string) bool {
			// We're not deploying an actual application so we're going to see a 503 error currently
			return statusCode >= 200
		},
	)
}

func TestIT_TestThirdScenario(t *testing.T) {
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "./fixtures/main/test_three/",
		NoColor:      true,
	})
	// At the end of the test, run `terraform destroy`
	defer terraform.Destroy(t, terraformOptions)
	// Run `terraform init` and `terraform apply`
	terraform.InitAndApply(t, terraformOptions)

	// Printed before Sleep method is invoked
	fmt.Println("Sleeping for 90 seconds")

	// Calling Sleep method
	time.Sleep(90 * time.Second)

	// Run `terraform output` to get the value of an output variable
	siteurl := terraform.Output(t, terraformOptions, "site_url")

	// Call the web app and look for a 200 response with retries and sleep to account for build time variances
	retries := 10
	sleep := 10 * time.Second
	httpHelper.HttpGetWithRetryWithCustomValidation(t, siteurl, &tls.Config{}, retries, sleep,
		func(statusCode int, body string) bool {
			// We're not deploying an actual application so we're going to see a 503 error currently
			return statusCode >= 200
		},
	)
}
