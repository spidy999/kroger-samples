### Enter your notes about this pull request here (if any)
<p>


<!--- Do not edit any of the lines below this one -->
</p>
<font size="1"><sub>end of manually added comments.</sub></font>

### Module Pull Request Approval Standards Checklist

Do not approve pull requests unless [Module Coding Standards](https://confluence.kroger.com/confluence/display/HW/Health+and+Wellness+Terraform+Coding+Standards#HealthandWellnessTerraformCodingStandards-GithubModuleRepositoryStandards) are followed

- [ ] [Required Labels](https://confluence.kroger.com/confluence/display/HW/Health+and+Wellness+Terraform+Coding+Standards#HealthandWellnessTerraformCodingStandards-RequiredLabels) Set?
  - Appropriate for action
  - One of: skip-release, major, minor, patch, documentation
- [ ] Examples updated to reflect changes in this PR (./examples/)
- [ ] [Module Coding Standards](https://confluence.kroger.com/confluence/display/HW/Health+and+Wellness+Terraform+Coding+Standards#HealthandWellnessTerraformCodingStandards-GithubModuleRepositoryStandards) met?
- [ ] All Checks Passed
  - No checks awaiting approval
  - :heavy_check_mark: on all pull requests checks in PR summary
- [ ] [Appropriate pull request title](https://confluence.kroger.com/confluence/display/HW/Health+and+Wellness+Terraform+Coding+Standards#HealthandWellnessTerraformCodingStandards-TerraformModulePullRequestTitleStandards) (This becomes the changelog entry)
  - Title should start with HWART-####
  - Title should include what is changing. May also contain why.
  - Title must include notes about breaking changes or added features (if any)
