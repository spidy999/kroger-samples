## Change Log

### v2.5.2 (2024/03/14 12:23 +00:00)
- [#45](https://github.com/krogertechnology/hw-az-webapp/pull/45) HWART-116140: Upgrade terratest from v0.40.15 to v0.46.11 to support super-linter v5 (@zeevani-v-cb)

### v2.5.1 (2024/02/29 17:03 +00:00)
- [#44](https://github.com/krogertechnology/hw-az-webapp/pull/44) HWART-106124: Add vnet_route_all_enabled to web slot resource (@andrew-s-cb)

### v2.5.0 (2024/02/28 21:58 +00:00)
- [#43](https://github.com/krogertechnology/hw-az-webapp/pull/43) HWART-106124: Add vnet_route_all_enabled argument to module (@andrew-s-cb)

### v2.4.0 (2024/02/23 16:12 +00:00)
- [#41](https://github.com/krogertechnology/hw-az-webapp/pull/41) HWART-106124: Configure module for auto heal settings (@andrew-s-cb)
- [#40](https://github.com/krogertechnology/hw-az-webapp/pull/40) HWART-111137: Change caller RU workflows to inherit secrets (@zeevani-v-cb)
- [#38](https://github.com/krogertechnology/hw-az-webapp/pull/38) HWART-90296 Standardize and simplify README.md (@Rob-Bosma-KR)

### v2.3.0 (2023/01/06 17:24 +00:00)
- [#37](https://github.com/krogertechnology/hw-az-webapp/pull/37) HWART-91231: Removed swift connections and added virtual network subnet id to alleviate bug in terraform code that sets networking to null, cleaned up old code (@paul-p-cb)

### v2.2.0 (2022/12/13 17:31 +00:00)
- [#36](https://github.com/krogertechnology/hw-az-webapp/pull/36) HWART-82141: Update web app and web app slot resources to new azurerm 3.x versions, please see readme for how to upgrade (@donald-picard-kr, @paul-p-cb)

### v2.1.0 (2022/10/31 18:04 +00:00)
- [#35](https://github.com/krogertechnology/hw-az-webapp/pull/35) HWART-82141: Update ASP to replace deprecated azurerm_app_service_plan with new azurerm_service_plan (@paul-p-cb)

### v2.0.0 (2022/10/26 16:03 +00:00)
- [#33](https://github.com/krogertechnology/hw-az-webapp/pull/33) HWART-84184: Bump terraform and azurerm versions to facilitate azurerm 3.0 consumption (@paul-p-cb)
- [#31](https://github.com/krogertechnology/hw-az-webapp/pull/31) Adding kap.yaml file (@Rob-Bosma-KR)
- [#29](https://github.com/krogertechnology/hw-az-webapp/pull/29) NoJira - Rename snyk-security-scan.yml to call-snyk-security-scan.yml to meet standards (@donald-picard-kr)

### v1.4.2 (2022/08/05 19:26 +00:00)
- [#28](https://github.com/krogertechnology/hw-az-webapp/pull/28) Adding new solo snyk security scan workflow (@donald-picard-kr, @LanceZeligman-KR)

### v1.4.1 (2022/07/11 13:18 +00:00)
- [#27](https://github.com/krogertechnology/hw-az-webapp/pull/27) Set SKU var default value to be a validatable value. (@LanceZeligman-KR)
- [#26](https://github.com/krogertechnology/hw-az-webapp/pull/26) add project card to workflows (@donald-picard-kr)
- [#25](https://github.com/krogertechnology/hw-az-webapp/pull/25) HWART-80892 update terratest (@donald-picard-kr)

### v1.4.0 (2022/06/28 18:34 +00:00)
- [#24](https://github.com/krogertechnology/hw-az-webapp/pull/24) added ftps_state var disabled by default (@paul-p-cb)

### v1.3.1 (2022/05/20 14:02 +00:00)
- [#23](https://github.com/krogertechnology/hw-az-webapp/pull/23) Hardcodes https_only true for the web slot (@LanceZeligman-KR)

### v1.3.0 (2022/05/13 19:57 +00:00)
- [#22](https://github.com/krogertechnology/hw-az-webapp/pull/22) Removes the app_gateway_subnet_id variable to add support for AVI and Private Endpoint solutions (@LanceZeligman-KR)
- [#21](https://github.com/krogertechnology/hw-az-webapp/pull/21) Update to module template v0.5.1 - no release (@donald-picard-kr)
- [#19](https://github.com/krogertechnology/hw-az-webapp/pull/19) fix for breaking change (@donald-picard-kr)

### v1.2.3 (2022/03/28 14:53 +00:00)
- [#17](https://github.com/krogertechnology/hw-az-webapp/pull/17) Add snyk recommendations to module (@kevinbathrick-kr)
- [#16](https://github.com/krogertechnology/hw-az-webapp/pull/16) updating release template to latest (@mike-franzosa-sg)

### v1.2.2 (2022/01/19 22:08 +00:00)
- [#15](https://github.com/krogertechnology/hw-az-webapp/pull/15) Adding subnet restriction var (@mike-franzosa-sg)

### v1.2.1 (2021/09/23 20:03 +00:00)
- [#14](https://github.com/krogertechnology/hw-az-webapp/pull/14) adding vnet connection for the app service slot (@LanceZeligman-KR)

### v1.2.0 (2021/09/17 18:37 +00:00)
- [#12](https://github.com/krogertechnology/hw-az-webapp/pull/12) Feature/slot identity output (@LanceZeligman-KR)
- [#13](https://github.com/krogertechnology/hw-az-webapp/pull/13) Merge in module template (@donald-picard-kr, @LanceZeligman-KR, @olakunle-fasesimi-kr, @christian-d-cb, @travis-crowder-kr, @gregory-ware, @paul-p-cb)

### v1.1.0 (2021/09/13 14:56 +00:00)
- [#11](https://github.com/krogertechnology/hw-az-webapp/pull/11) Revert "Revert "Feature/hwart 64073"" (@LanceZeligman-KR)
- [#10](https://github.com/krogertechnology/hw-az-webapp/pull/10) Revert "Feature/hwart 64073" (@LanceZeligman-KR)
- [#9](https://github.com/krogertechnology/hw-az-webapp/pull/9) Feature/hwart 64073 (@LanceZeligman-KR)
- [#8](https://github.com/krogertechnology/hw-az-webapp/pull/8) Update CHANGELOG.md [skip ci] (@krogertechnology)

### v1.0.0 (2021/09/01 18:53 +00:00)
- [#6](https://github.com/krogertechnology/hw-az-webapp/pull/6) Add slots/settings for deployment (@olakunle-fasesimi-kr, @christian-d-cb)

### v0.0.4 (2021/07/26 20:07 +00:00)
- [#5](https://github.com/krogertechnology/hw-az-webapp/pull/5) migrate to new template format (@gregory-ware, @travis-crowder-kr)

### v0.0.3 (2021/06/04 20:17 +00:00)
- [#4](https://github.com/krogertechnology/hw-az-webapp/pull/4) remove erroneous provider declaration from module (@paul-p-cb)

### v0.0.2 (2021/06/03 13:02 +00:00)
- [#3](https://github.com/krogertechnology/hw-az-webapp/pull/3) removed java settings for containers (@paul-p-cb, @christian-d-cb)

### v0.0.1 (2021/05/17 12:47 +00:00)
- [#2](https://github.com/krogertechnology/hw-az-webapp/pull/2) HWART-51639 to main (@paul-p-cb, @christian-d-cb)
- [#1](https://github.com/krogertechnology/hw-az-webapp/pull/1) Update tf ver for security (#1) (@kevinbathrick-kr)