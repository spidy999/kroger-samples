package com.kroger.storesys.apps.config;

import io.swagger.annotations.Api;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Profile({
        "local",
        "swagger"})
@Configuration
@EnableSwagger2
class SwaggerConfiguration {
    @Bean
    public Docket customImplementation() {
        return new Docket(DocumentationType.SWAGGER_2).select()
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class)).build().apiInfo(apiInfo())
                .useDefaultResponseMessages(false);
    }

    private ApiInfo apiInfo() {
        String title = "Shipper UPC Xplod API";
        String description = "This API fetches the children UPCs contained within a provided Shipper UPC, including quantity and item description.";
        String version = "1.0";
        String termsOfServiceUrl = "";
        //Contact contact = new Contact("In-Store Applications Team", "https://confluence.kroger.com/confluence/display/MAS", "");
        String contact = "APP-ISA (In-Store Applications)";
        String license = "";
        String licenseUrl = "";
        ApiInfo apiInfo = new ApiInfo(
                title,
                description,
                version,
                termsOfServiceUrl,
                contact,
                licenseUrl,
                license
        );
        return apiInfo;
    }
}
