package com.kroger.storesys.apps.dto;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
public class Data {
    public List<ShipperChild> getData() {
        return data;
    }

    public void setData(List<ShipperChild> data) {
        this.data = data;
    }

    private List<ShipperChild> data;
}
