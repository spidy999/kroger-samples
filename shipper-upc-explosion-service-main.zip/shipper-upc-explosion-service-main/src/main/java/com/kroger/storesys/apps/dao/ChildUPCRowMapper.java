package com.kroger.storesys.apps.dao;

import com.kroger.storesys.apps.dto.ShipperChild;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ChildUPCRowMapper implements RowMapper<ShipperChild> {
    @Override
    public ShipperChild mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new ShipperChild(rs.getString("CON_DSC_TX"), rs.getString("CON_UPC_NO"), rs.getInt("CAS_CON_CNT_QY"));
    }
}
