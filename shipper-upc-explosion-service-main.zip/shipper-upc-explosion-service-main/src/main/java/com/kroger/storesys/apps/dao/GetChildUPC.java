package com.kroger.storesys.apps.dao;

import com.kroger.storesys.apps.dto.ShipperChild;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;


@Getter
@Component
@NoArgsConstructor
public class GetChildUPC {
    @Autowired
    JdbcTemplate shipperJDBCTemplate;

    private static String SQL = "SELECT CCO.CON_UPC_NO, TCO.CON_DSC_TX, CCO.CAS_CON_CNT_QY " +
        "FROM PID.PIDCASCO CCO  INNER JOIN PID.PIDPDTCA TCA ON CCO.CAS_UPC_NO = TCA.CAS_UPC_NO " +
        "INNER JOIN PID.PIDPDTCO TCO ON CCO.CON_UPC_NO = TCO.CON_UPC_NO WHERE CCO.CAS_CON_CNT_QY > 0 " +
        "AND TCA.CAS_SHP_FL = 'Y' " +
        "AND CCO.CAS_UPC_NO = ? " +
        "GROUP BY CCO.CON_UPC_NO,TCO.CON_DSC_TX, CCO.CAS_CON_CNT_QY ORDER BY 1, 3";

    public List<ShipperChild> getChildUPCByShipperUPC(String shipperUPC) {
        List<ShipperChild> listShipperChild = shipperJDBCTemplate.query(SQL, new Object[] { shipperUPC }, new ChildUPCRowMapper());
        return listShipperChild;
    }
}
