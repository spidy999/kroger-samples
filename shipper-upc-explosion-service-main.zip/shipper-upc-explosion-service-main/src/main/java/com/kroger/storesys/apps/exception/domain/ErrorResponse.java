package com.kroger.storesys.apps.exception.domain;

import org.springframework.http.HttpStatus;

import java.io.Serializable;

public class ErrorResponse {
    protected int httpStatus;
    protected String appErrorCode;
    protected Object detail;

    protected String transactionId;
    protected String correlationId;

    private ErrorResponse()
    {
    }

    public static ErrorResponse of(int httpStatus, String appErrorCode, Object detail)
    {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.httpStatus = httpStatus;
        errorResponse.appErrorCode = appErrorCode;
        errorResponse.detail = detail;
        return errorResponse;
    }

    public static ErrorResponse of(HttpStatus httpStatus, String appErrorCode,
                                   Object detail)
    {
        return of(httpStatus.value(), appErrorCode, detail);
    }

    public ErrorResponse withTransactionId(String transactionId)
    {
        this.transactionId = transactionId;
        return this;
    }

    public ErrorResponse withCorrelationId(String correlationId)
    {
        this.correlationId = correlationId;
        return this;
    }

    public int getHttpStatus()
    {
        return httpStatus;
    }

    public String getAppErrorCode()
    {
        return appErrorCode;
    }

    public Object getDetail()
    {
        return detail;
    }

    public String getTransactionId()
    {
        return transactionId;
    }

    public String getCorrelationId()
    {
        return correlationId;
    }

    /**
     * Message object for an application. Uses a key intended to be looked up in a resource
     * bundle along with the parameters to fill in place holders in the message.
     */
    public static class Message implements Serializable
    {
        private static final long serialVersionUID = -6445400472465496649L;
        /**
         * Message Key
         */
        private final String key;
        /**
         * Message parameter values
         */
        private final Object[] parameters;
        /**
         * Message field
         */
        private final Field field;

        /**
         * Message constructor with key and no parameters
         *
         * @param key Key for message
         */
        public Message(String key)
        {
            this.key = key;
            this.parameters = new Object[0];
            this.field = null;
        }

        /**
         * Message constructor with key and field
         *
         * @param key Key for message
         * @param field Field for message
         */
        public Message(String key, Field field)
        {
            this.key = key;
            this.parameters = new Object[0];
            this.field = field;
        }

        /**
         * Message constructor with key and parameters
         *
         * @param key Key for message
         * @param parameters Parameters for message
         */
        public Message(String key, Object... parameters)
        {
            this.key = key;
            this.parameters = new Object[parameters.length];
            System.arraycopy(parameters, 0, this.parameters, 0, parameters.length);
            this.field = null;
        }

        /**
         * Message constructor with key and parameters
         *
         * @param key Key for message
         * @param field Field for message
         * @param parameters Parameters for message
         */
        public Message(String key, Field field, Object... parameters)
        {
            this.key = key;
            this.parameters = new Object[parameters.length];
            System.arraycopy(parameters, 0, this.parameters, 0, parameters.length);
            this.field = field;
        }

        /**
         * Get message key.
         *
         * @return Message Key
         */
        public String getKey()
        {
            return key;
        }

        /**
         * Get message parameters.
         *
         * @return
         */
        public Object[] getParameters()
        {
            Object[] parameters = new Object[this.parameters.length];
            System.arraycopy(this.parameters, 0, parameters, 0, this.parameters.length);
            return parameters;
        }

        /**
         * Get message field.
         *
         * @return MessageField
         */
        public Field getField()
        {
            return field;
        }

        /**
         * Field (in the UI) for an message.
         */
        public static class Field implements Serializable
        {
            private static final long serialVersionUID = -5774019523083800566L;
            /**
             * Field name
             */
            private final String name;

            /**
             * Field constructor with name
             *
             * @param name Name for field
             */
            public Field(String name)
            {
                this.name = name;
            }

            /**
             * Get field name.
             *
             * @return Field Name
             */
            public String getName()
            {
                return name;
            }
        }
    }
}
