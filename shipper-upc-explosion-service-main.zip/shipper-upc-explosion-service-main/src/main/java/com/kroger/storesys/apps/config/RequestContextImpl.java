package com.kroger.storesys.apps.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;

import static com.kroger.storesys.apps.config.GlobalConstants.CORRELATION_ID;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;
import static org.springframework.context.annotation.ScopedProxyMode.INTERFACES;
import static org.springframework.web.context.WebApplicationContext.SCOPE_REQUEST;
import static java.util.UUID.randomUUID;

@Component(value = "RequestContext")
@Scope(value = SCOPE_REQUEST, proxyMode = INTERFACES)
public class RequestContextImpl implements RequestContext {
    private static final String FORWARDED_FOR = "X-Forwarded-For";
    private static final String hostAddress;
    static {
        String s;
        try {
            s = InetAddress.getLocalHost().getHostAddress();
        } catch (Exception ignored) {
            s = "";
        }
        hostAddress = s;
    }

    private final HttpServletRequest request;
    private final String clientIpAddress;
    private final String correlationId;
    private final String transactionId;
    private final String remoteUser;
    private final String requestUri;
    private final String guid;
    //@Value("${spring.application.version}")
    private String applicationVersion = "1.0";
    private final long startTime;
    private long dbStartTime=0;
    private long dbEndTime=0;
    private long EndTime;

    @Autowired
    RequestContextImpl(HttpServletRequest request) {
        this.request = request;
        clientIpAddress = (request.getRemoteAddr()!=null)? request.getRemoteAddr():(request.getHeader(FORWARDED_FOR)!=null)?request.getHeader(FORWARDED_FOR): "";
        this.remoteUser = request.getRemoteUser() == null ? "ANONYMOUS" : request.getRemoteUser();

        transactionId = randomUUID().toString();
        correlationId = defaultIfBlank(request.getHeader(CORRELATION_ID), transactionId);
        this.startTime = System.currentTimeMillis();
        this.requestUri = request.getRequestURI();
        this.guid = request.getRequestURI().replaceAll("/shipperupc/","");
    }

    public HttpServletRequest getRequest() { return request; }

    public String getServerIpAddress() { return hostAddress; }

    public String getClientIpAddress() { return clientIpAddress; }

    public String getCorrelationId() { return correlationId; }

    public String getTransactionId() { return transactionId; }

    public String getRemoteUser() {
        return remoteUser;
    }

    public String getRequestUri() {
        return requestUri;
    }
    public String getGuid() {
        return guid;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getDbStartTime() {
        return dbStartTime;
    }

    public void setDbStartTime(long dbStartTime) {
        this.dbStartTime = dbStartTime;
    }

    public long getDbEndTime() {
        return dbEndTime;
    }

    public void setDbEndTime(long dbEndTime) {
        this.dbEndTime = dbEndTime;
    }

    public long getEndTime() {
        return EndTime;
    }

    public void setEndTime(long endTime) {
        EndTime = endTime;
    }

    public String getApplicationVersion() {
        return applicationVersion;
    }

    public void setApplicationVersion(String applicationVersion) {
        this.applicationVersion = applicationVersion;
    }
}
