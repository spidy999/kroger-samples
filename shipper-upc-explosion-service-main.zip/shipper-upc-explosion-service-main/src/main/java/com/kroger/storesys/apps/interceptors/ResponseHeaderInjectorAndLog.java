package com.kroger.storesys.apps.interceptors;

import com.kroger.storesys.apps.config.RequestContext;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.kroger.storesys.apps.config.GlobalConstants.CORRELATION_ID;
import static com.kroger.storesys.apps.config.GlobalConstants.TRANSACTION_ID;

public class ResponseHeaderInjectorAndLog extends HandlerInterceptorAdapter {
    private final RequestContext requestContext;

    public ResponseHeaderInjectorAndLog(RequestContext requestContext) {
        this.requestContext = requestContext;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        response.setHeader(CORRELATION_ID, requestContext.getCorrelationId());
        response.setHeader(TRANSACTION_ID, requestContext.getTransactionId());

        return super.preHandle(request, response, handler);
    }
}
