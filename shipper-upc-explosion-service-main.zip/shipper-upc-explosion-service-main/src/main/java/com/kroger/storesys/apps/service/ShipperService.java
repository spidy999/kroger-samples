package com.kroger.storesys.apps.service;

import com.kroger.storesys.apps.dto.Data;

public interface ShipperService {
    public Data getShipperData(String upc);
}
