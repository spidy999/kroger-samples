package com.kroger.storesys.apps.exception.domain;

import java.util.List;

public class ApiError {
    private List<ApiRootCause> root_cause;
    private String code;
    private String reason;
    private String timestamp;

    public ApiError(List<ApiRootCause> root_cause, String code, String reason, String timestamp) {
        this.root_cause = root_cause;
        this.code = code;
        this.reason = reason;
        this.timestamp = timestamp;
    }


    public List<ApiRootCause> getRoot_cause() {
        return root_cause;
    }

    public void setRoot_cause(List<ApiRootCause> root_cause) {
        this.root_cause = root_cause;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
