package com.kroger.storesys.apps.exception;

import com.kroger.storesys.apps.exception.domain.ErrorResponse;

import java.util.List;

public class ApplicationException extends RuntimeException{
    private static final long serialVersionUID = -7225858643363022513L;

    /**
     * Message Object for Exception
     */
    private final ErrorResponse.Message messageObject;

    /**
     * Message List for Exception
     */
    private final List<String> messages;

    /**
     * Message List for Exception
     */
    private final List<ErrorResponse.Message> messageObjects;

    /**
     * Message Field Object for Exception
     */
    private final ErrorResponse.Message.Field messageField;

    /**
     * Message Field Objects for Exception
     */
    private final List<ErrorResponse.Message.Field> messageFields;

    /**
     * Create exception for an application problem
     *
     * @param message Message string for exception message.
     */
    public ApplicationException(String message)
    {
        super(message);
        this.messages = null;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param message Message string for exception message.
     * @param messageField Message field for exception message.
     */
    public ApplicationException(String message, ErrorResponse.Message.Field messageField)
    {
        super(message);
        this.messages = null;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = messageField;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messages Messages (strings) for exception message.
     */
    public ApplicationException(List<String> messages)
    {
        super((messages != null && !messages.isEmpty()) ? messages.get(0) : null);
        this.messages = messages;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messages Messages (strings) for exception message.
     * @param messageFields Message fields for exception message.
     */
    public ApplicationException(List<String> messages, List<ErrorResponse.Message.Field> messageFields)
    {
        super((messages != null && !messages.isEmpty()) ? messages.get(0) : null);
        this.messages = messages;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = messageFields;
    }

    /**
     * Create exception for an application problem
     *
     * @param message Message string for exception message.
     * @param cause Root cause for exception.
     */
    public ApplicationException(String message, Throwable cause)
    {
        super(message, cause);
        this.messages = null;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param message Message string for exception message.
     * @param messageField Message field for exception message.
     * @param cause Root cause for exception.
     */
    public ApplicationException(String message, ErrorResponse.Message.Field messageField,
                                Throwable cause)
    {
        super(message, cause);
        this.messages = null;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = messageField;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messages Messages (strings) for exception message.
     * @param cause Root cause for exception.
     */
    public ApplicationException(List<String> messages, Throwable cause)
    {
        super((messages != null && !messages.isEmpty()) ? messages.get(0) : null, cause);
        this.messages = messages;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messages Messages (strings) for exception message.
     * @param messageFields Message fields for exception message.
     * @param cause Root cause for exception.
     */
    public ApplicationException(List<String> messages, List<ErrorResponse.Message.Field> messageFields,
                                Throwable cause)
    {
        super((messages != null && !messages.isEmpty()) ? messages.get(0) : null, cause);
        this.messages = messages;
        this.messageObject = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = messageFields;
    }

    /**
     * Create exception for an application problem
     *
     * @param messageObject Message object to show user a formatted message.
     */
    public ApplicationException(ErrorResponse.Message messageObject)
    {
        super();
        this.messageObject = messageObject;
        this.messages = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messageObjects Message objects to show user a formatted message.
     */
    public static ApplicationException createExceptionWithMessages(
            List<ErrorResponse.Message> messageObjects)
    {
        return new ApplicationException(messageObjects, null, null);
    }

    /**
     * Create exception for an application problem
     *
     * @param messageObject Message object to show user a formatted message.
     * @param message Message string for exception message.
     */
    public ApplicationException(ErrorResponse.Message messageObject, String message)
    {
        super(message);
        this.messageObject = messageObject;
        this.messages = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messageObject Message object to show user a formatted message.
     * @param throwable Root cause for exception.
     */
    public ApplicationException(ErrorResponse.Message messageObject, Throwable throwable)
    {
        super(throwable);
        this.messageObject = messageObject;
        this.messages = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param  messageObjects Message object to show user a formatted message.
     * @param throwable Root cause for exception.
     */
    public static ApplicationException createExceptionWithMessages(
            List<ErrorResponse.Message> messageObjects, Throwable throwable)
    {
        return new ApplicationException(messageObjects, null, throwable);
    }

    /**
     * Create exception for an application problem
     *
     * @param messageObject Message object to show user a formatted message.
     * @param message Message string for exception message.
     * @param throwable Root cause for exception.
     */
    public ApplicationException(ErrorResponse.Message messageObject, String message, Throwable throwable)
    {
        super(message, throwable);
        this.messageObject = messageObject;
        this.messages = null;
        this.messageObjects = null;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Create exception for an application problem
     *
     * @param messageObjects Message objects to show user a formatted message.
     * @param message Message string for exception message.
     * @param throwable Root cause for exception.
     */
    public ApplicationException(List<ErrorResponse.Message> messageObjects, String message,
                                Throwable throwable)
    {
        super(message, throwable);
        this.messageObject = null;
        this.messages = null;
        this.messageObjects = messageObjects;
        this.messageField = null;
        this.messageFields = null;
    }

    /**
     * Get the message object of the exception if present.
     *
     * @return MessageObject if present
     */
    public ErrorResponse.Message getMessageObject()
    {
        return messageObject;
    }

    /**
     * Get the messages (String) of the exception if present.
     *
     * @return Messages if present
     */
    public List<String> getMessages()
    {
        return messages;
    }

    /**
     * Get the message objects of the exception if present.
     *
     * @return MessageObjects if present
     */
    public List<ErrorResponse.Message> getMessageObjects()
    {
        return messageObjects;
    }

    /**
     * Get the message field of the exception if present.
     *
     * @return MessageField if present
     */
    public ErrorResponse.Message.Field getMessageField()
    {
        return messageField;
    }

    /**
     * Get the message fields of the exception if present.
     *
     * @return MessageFields if present
     */
    public List<ErrorResponse.Message.Field> getMessageFields()
    {
        return messageFields;
    }
}
