package com.kroger.storesys.apps.exception.domain;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.List;

public class BindValidationErrors {
    List<ObjectError> globalErrors = new ArrayList<>();
    int errorCount;

    public List<ApiRootCause> getRootCauses() {
        return rootCauses;
    }

    List<ApiRootCause> rootCauses= new ArrayList<ApiRootCause>();
    MultiValueMap<String, ValidationFieldError> validationFieldErrors = new LinkedMultiValueMap();
    boolean hasGlobalErrors;
    boolean hasFieldErrors;
    boolean hasErrors;
    String nestedPath;

    public BindValidationErrors(BindingResult bindingResult)
    {
        this.hasGlobalErrors = bindingResult.hasGlobalErrors();
        this.globalErrors = bindingResult.getGlobalErrors();
        this.hasErrors = bindingResult.hasErrors();
        this.hasFieldErrors = bindingResult.hasFieldErrors();
        for (FieldError fieldError : bindingResult.getFieldErrors())
        {
            this.validationFieldErrors.add(fieldError.getField(),
                    new ValidationFieldError(fieldError));
            this.rootCauses.add(new ApiRootCause(fieldError.getField(),fieldError.getDefaultMessage()+fieldError.getRejectedValue()));
        }
        this.errorCount = bindingResult.getErrorCount();
        this.nestedPath = bindingResult.getNestedPath();
    }

    public List<ObjectError> getGlobalErrors()
    {
        return globalErrors;
    }

    public int getErrorCount()
    {
        return errorCount;
    }

    public MultiValueMap<String, ValidationFieldError> getValidationFieldErrors()
    {
        return validationFieldErrors;
    }

    public boolean isHasGlobalErrors()
    {
        return hasGlobalErrors;
    }

    public boolean isHasFieldErrors()
    {
        return hasFieldErrors;
    }

    public boolean isHasErrors()
    {
        return hasErrors;
    }

    public String getNestedPath()
    {
        return nestedPath;
    }

    public static class ValidationFieldError
    {

        private String fieldName;
        private String defaultMessage;
        private Object rejectedValue;

        public ValidationFieldError(FieldError fieldError)
        {
            this.defaultMessage = fieldError.getDefaultMessage();
            this.fieldName = fieldError.getField();
            this.rejectedValue = fieldError.getRejectedValue();
        }

        public String getFieldName()
        {
            return fieldName;
        }

        public String getDefaultMessage()
        {
            return defaultMessage;
        }

        public Object getRejectedValue()
        {
            return rejectedValue;
        }
    }
}
