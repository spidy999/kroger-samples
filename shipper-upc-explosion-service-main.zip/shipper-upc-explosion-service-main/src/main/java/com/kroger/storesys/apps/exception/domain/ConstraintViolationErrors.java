package com.kroger.storesys.apps.exception.domain;

import javax.validation.ConstraintViolation;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class ConstraintViolationErrors {
    private List<ApiRootCause> rootCauses = new ArrayList<ApiRootCause>();

    public List<ApiRootCause> getRootCauses() {
        return rootCauses;
    }
    public ConstraintViolationErrors(Set<ConstraintViolation<?>> ConstraintViolations)
    {

        for (ConstraintViolation<?> violation : ConstraintViolations)
        {

            this.rootCauses.add(new ApiRootCause(violation.getRootBeanClass().getName() + " " +
                    violation.getPropertyPath(),violation.getMessage()));
        }

    }
}
