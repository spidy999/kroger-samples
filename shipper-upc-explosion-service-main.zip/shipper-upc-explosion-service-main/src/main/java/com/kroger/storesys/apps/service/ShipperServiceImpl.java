package com.kroger.storesys.apps.service;

import com.kroger.storesys.apps.dao.GetChildUPC;
import com.kroger.storesys.apps.dto.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.kroger.storesys.apps.logging.LogUtil.APP_LOG;

@Component
public class ShipperServiceImpl implements ShipperService {
    @Autowired
    private GetChildUPC getChildUPC;

    public Data getShipperData(String upc) {
        APP_LOG.info("fetching children of shipper upc");
        return buildData(upc);
    }

    private Data buildData(String upc) {
        Data dt = new Data();
        /*List<ShipperChild> sc = new ArrayList<ShipperChild>();
        sc.add(new ShipperChild("FERR RCHR GIFT BOX", "0000980012019", 24));
        sc.add(new ShipperChild("FERR DIAMOND VAL GB", "0000980012021", 8));*/

        dt.setData(getChildUPC.getChildUPCByShipperUPC(upc));
        return dt;
    }
}
