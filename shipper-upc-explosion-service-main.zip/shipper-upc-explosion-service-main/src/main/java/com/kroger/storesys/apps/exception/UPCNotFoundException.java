package com.kroger.storesys.apps.exception;

public class UPCNotFoundException extends RuntimeException{
    private static final long serialVersionUID = 4931889730288437690L;
    private String upc;

    public UPCNotFoundException() {
    }

    public UPCNotFoundException(String message) {
        super(message);
    }

    public String getUPC() {
        return upc;
    }

    public UPCNotFoundException setUPC(String s) {
        upc = s;
        return this;
    }

    public String toString() {
        return "UPCNotFoundException(upc=" + this.getUPC() + ")";
    }
}
