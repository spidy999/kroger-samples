package com.kroger.storesys.apps.controller;

import com.kroger.storesys.apps.dto.Data;
import com.kroger.storesys.apps.service.ShipperService;
import io.swagger.annotations.*;
import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.validation.constraints.Pattern;
import java.time.format.DateTimeFormatter;
import java.time.*;

import static org.springframework.http.MediaType.APPLICATION_XML_VALUE;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static com.kroger.storesys.apps.logging.LogUtil.APP_LOG;

@RestController
@Validated
@Api(value = "shipperupc", description = "ShipperUPC Xplode Service")
public class ShipperController {
    private final ShipperService shipperService;

    @Autowired
    public ShipperController(ShipperService shipperService) {
        this.shipperService = shipperService;
    }

    @ApiOperation(value = "Get Children UPCs", notes = "Fetches children UPCs contained inside of a Shipper UPC")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "This id is used to correlate log entries between platforms.",
                name = "X-Correlation-Id", paramType = "header", required = true, dataType = "String")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 204, message = "No Content"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 503, message = "Service Unavailable"),
    })
    @RequestMapping(
            value = "shipperupc/{upc}",
            method = GET,
            produces = APPLICATION_XML_VALUE
    )
    public ResponseEntity<Data> getShipperData(@Pattern(regexp = "\\d{12,13}") @PathVariable(value = "upc", required = true) String upc) {
        APP_LOG.info("received shipper upc: " + upc);

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH");
        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
        ZonedDateTime est = utc.withZoneSameInstant(ZoneId.of("America/New_York"));
        APP_LOG.info("current time: " + est);

        //do not query PID during midnight to 2AM maintenance window
        if (Integer.parseInt(dtf.format(est)) >= 00 && Integer.parseInt(dtf.format(est)) < 02) {
            APP_LOG.error("PID maintenance window. returning NO_CONTENT");
            return new ResponseEntity<Data>((Data) null, HttpStatus.NO_CONTENT);
        }
        else
        {
            APP_LOG.info("Outside of PID Maintenance Window. Get Shipper Data.");
            Data response = shipperService.getShipperData(upc);
            if (response.getData().isEmpty()) {
                APP_LOG.error("response is empty. returning NO_CONTENT");
                return new ResponseEntity<Data>(response, HttpStatus.NO_CONTENT);
            } else {
                APP_LOG.info("response is good.");
                return new ResponseEntity<Data>(response, HttpStatus.OK);
            }
        }
    }
}
