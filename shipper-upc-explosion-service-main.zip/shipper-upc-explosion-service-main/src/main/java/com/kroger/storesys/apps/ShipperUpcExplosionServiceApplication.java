package com.kroger.storesys.apps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipperUpcExplosionServiceApplication
{
	public static void main(String[] args)
	{
		SpringApplication.run(ShipperUpcExplosionServiceApplication.class, args);
	}
}
