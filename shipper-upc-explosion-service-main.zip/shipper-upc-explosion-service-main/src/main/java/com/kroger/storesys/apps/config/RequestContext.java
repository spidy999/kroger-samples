package com.kroger.storesys.apps.config;

import javax.servlet.http.HttpServletRequest;

public interface RequestContext {
    HttpServletRequest getRequest();

    String getServerIpAddress();
    String getClientIpAddress();
    String getTransactionId();
    String getCorrelationId();
    long getStartTime();
    long getDbEndTime();
    void setDbStartTime(long l);
    void setDbEndTime(long l);

    String getRemoteUser();
    String getRequestUri();
    String getGuid();
    String getApplicationVersion();
}
