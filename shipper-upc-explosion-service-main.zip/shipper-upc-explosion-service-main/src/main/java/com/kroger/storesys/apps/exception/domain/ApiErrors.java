package com.kroger.storesys.apps.exception.domain;

import java.util.ArrayList;
import java.util.List;

public class ApiErrors {
    private ApiError errors;
    public ApiError getErrors() {
        return errors;
    }

    private ApiErrors(ApiError errors) {
        this.errors = errors;
    }

    public static ApiErrors buildErrors(String code, String reason) {
        String currentTimeStamp = String.valueOf(System.currentTimeMillis());
        List<ApiRootCause> rootCauses =  new ArrayList<ApiRootCause>();
        rootCauses.add(new ApiRootCause(code,reason,currentTimeStamp));
        return  new ApiErrors(new ApiError(rootCauses,code,reason,currentTimeStamp));

    }

    public static ApiErrors buildErrors(String code,String reason,List<ApiRootCause> rootCauses){
        String currentTimeStamp = String.valueOf(System.currentTimeMillis());
        return  new ApiErrors(new ApiError(rootCauses,code,reason,currentTimeStamp));
    }
}
