package com.kroger.storesys.apps.exception;

import com.kroger.storesys.apps.exception.domain.ApiErrors;
import com.kroger.storesys.apps.exception.domain.BindValidationErrors;
import com.kroger.storesys.apps.exception.domain.ConstraintViolationErrors;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.validation.ConstraintViolationException;

import static com.kroger.storesys.apps.logging.LogUtil.APP_LOG;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Catch all exception handler to return an error 500. You should really fix these exceptions.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrors> handleException(Exception e)
    {
        APP_LOG.error(" Unexpected Exception caught in GlobalExceptionHandler", e);
        return new ResponseEntity<ApiErrors>(ApiErrors.buildErrors(HttpStatus.INTERNAL_SERVER_ERROR.toString(),"servererror"),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Access denied exception handler to return FORBIDDEN HTTP status code
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiErrors> handleAccessDeniedException(AccessDeniedException e)
    {
        APP_LOG.error("Access Denied Exception", e);
        return new ResponseEntity<ApiErrors>(
                ApiErrors.buildErrors(HttpStatus.FORBIDDEN.toString(),"forbidden"),HttpStatus.FORBIDDEN);

    }
    /**
     * Custom error handler to return bad request for invalid input
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status,
            WebRequest request)
    {
        APP_LOG.error("Validation Exception", ex);
        BindValidationErrors errors = new BindValidationErrors(ex.getBindingResult());
        return new ResponseEntity<Object>(ApiErrors.buildErrors(HttpStatus.BAD_REQUEST.toString(), "validation",errors.getRootCauses()),

                HttpStatus.BAD_REQUEST);
    }
    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        String error = ex.getParameterName() + " parameter is missing";
        return new ResponseEntity<Object>(ApiErrors.buildErrors(HttpStatus.BAD_REQUEST.toString(), error),

                HttpStatus.BAD_REQUEST);
    }
    /**
     * Custom error handler to return bad request for invalid input
     */
    @Override
    protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers,
                                                         HttpStatus status, WebRequest request)
    {
        APP_LOG.error("Validation Exception", ex);
        BindValidationErrors errors = new BindValidationErrors(ex.getBindingResult());
        return new ResponseEntity<Object>(ApiErrors.buildErrors(HttpStatus.BAD_REQUEST.toString(), "validation",errors.getRootCauses()),

                HttpStatus.BAD_REQUEST);
    }
    /**
     * Custom error handle to return bad request for an constraintv iolation exception
     */
    @ExceptionHandler({ ConstraintViolationException.class })
    public ResponseEntity<Object> handleConstraintViolation(
            ConstraintViolationException ex, WebRequest request) {
        APP_LOG.error("Constraint Exception", ex);
        ConstraintViolationErrors errors = new ConstraintViolationErrors(ex.getConstraintViolations());
        return new ResponseEntity<Object>(ApiErrors.buildErrors(HttpStatus.BAD_REQUEST.toString(), "UPC is not valid",errors.getRootCauses()),

                HttpStatus.BAD_REQUEST);
    }

    /**
     * Custom error handle to return bad request for an application exception
     */
    @ExceptionHandler(DataAccessException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ApiErrors handleException(DataAccessException e) {
        APP_LOG.error("DataAccess Exception", e);
        return ApiErrors.buildErrors(HttpStatus.INTERNAL_SERVER_ERROR.toString(), "Unable to retrieve the data");
    }


    /**
     * Custom error handle to return bad request for an application exception
     */
    @ExceptionHandler(UPCNotFoundException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ApiErrors handleException(UPCNotFoundException e) {
        APP_LOG.error("UPC Not FoundException", e);
        return ApiErrors.buildErrors(HttpStatus.NOT_FOUND.toString(), e.toString());
    }
}
