package com.kroger.storesys.apps.dto;

public class ShipperChild {
    public String getDescription() {
        return description;
    }

    public String getUpc() {
        return upc;
    }

    public int getQty() {
        return qty;
    }

    private String description;
    private String upc;
    private int qty;

    public ShipperChild(String description, String upc, int qty) {
        this.description = description;
        this.upc = upc;
        this.qty = qty;
    }
}
