package com.kroger.storesys.apps.exception.domain;

public class ApiRootCause {
    private String code;
    private String reason;
    private String timestamp;

    public ApiRootCause(String code, String reason, String timestamp) {
        this.code = code;
        this.reason = reason;
        this.timestamp = timestamp;
    }

    public ApiRootCause(String code, String reason) {
        this.code = code;
        this.reason = reason;
        this.timestamp = String.valueOf(System.currentTimeMillis());
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
