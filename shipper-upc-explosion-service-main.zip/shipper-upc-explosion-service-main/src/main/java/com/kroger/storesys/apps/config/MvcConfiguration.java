package com.kroger.storesys.apps.config;

import com.kroger.storesys.apps.interceptors.ResponseHeaderInjectorAndLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class MvcConfiguration extends WebMvcConfigurerAdapter {
    @Autowired
    private RequestContext requestContext;

    @Override public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new ResponseHeaderInjectorAndLog(requestContext));
    }
}
