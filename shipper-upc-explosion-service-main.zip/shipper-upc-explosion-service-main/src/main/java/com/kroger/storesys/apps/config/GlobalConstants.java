package com.kroger.storesys.apps.config;

public class GlobalConstants {
    public static final String CORRELATION_ID = "X-Correlation-Id";
    public static final String TRANSACTION_ID = "Transaction-Id";
}
