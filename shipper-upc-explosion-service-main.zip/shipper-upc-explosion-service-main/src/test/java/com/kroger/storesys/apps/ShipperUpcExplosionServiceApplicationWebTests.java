package com.kroger.storesys.apps;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.web.ServletTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.testSecurityContext; 

@ActiveProfiles(profiles = { "unittest", "SPOOFING"  })
@TestExecutionListeners(listeners = { ServletTestExecutionListener.class,
    DependencyInjectionTestExecutionListener.class, WithSecurityContextTestExecutionListener.class  })
public abstract class ShipperUpcExplosionServiceApplicationWebTests extends ShipperUpcExplosionServiceApplicationTests
{
    private MockMvc mockMvc;

    @Autowired
    private FilterChainProxy springSecurityFilterChain; 
    @Autowired
    private WebApplicationContext webApplicationContext;

    @Before
    public void setup()
    {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).addFilter(springSecurityFilterChain).defaultRequest(get("/").with(testSecurityContext())).build();
    }

    public MockMvc getMockMvc()
    {
        return mockMvc;
    }
}