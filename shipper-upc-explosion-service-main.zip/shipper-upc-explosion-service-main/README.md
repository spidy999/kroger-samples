<div align="center">
	<h1>shipper upc explosion service</h1>
</div>

# Overview <!-- omit in toc -->

Service to check PID for Shipper UPCs and returns exploded UPCs known sometimes as children UPCs. This service is used by the ChainTrack application on the ISP in the store. This service was written by the APP-ISA team.  