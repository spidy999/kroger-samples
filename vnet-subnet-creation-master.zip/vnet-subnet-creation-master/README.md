# vnet-subnet-creation

# THIS REPO IS NOW ARCHIVED IN FAVOR OF https://github.com/krogertechnology/terraform-azurerm-kps-subnet. PLEASE PUSH CHANGES THERE INSTEAD

Terraform Subnet Creation Module by KPS/Alcatraz team

This module's main goal was **dynamic allocation** of subnets of differing sizes.  We also emphasized redicing ip address space loss by putting differing sized subnets next to eachother like a /23 doesnt butt up against a /22. 

To achieve those two goals our architecture was to first lean into Azure API to programatically pull our state of taken IPs then decide on the next IP to take based on the criteria of the desired netmask/subnet to create. To do this KPS chose to divide its ip space for their platform, a /19, into multiple /22 *virtually* allocated subnets. Then we decided to only put like cidr netmasks in the same /22 subnet. These /22s are what you will define as **parent_cidr_subnet** below when asking for a subnet and you should map out and only request the same size of subnet to be provisioned in each /22

You should do the same as KPS when using this module. Keep track of what virtually allocated parent subnets you will use for each differing sizes of subnets you want to provision. You can keep those next to the instantiation of this module and pass them accordingly.

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 0.13 |

## Providers

| Name | Version |
|------|---------|
| azurerm | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| environment | Name of the environment that requires the subnet. This is used in the naming convention of the subnet: <project\_name>\_<environment>\_<cidr> | `string` | n/a | yes |
| netmask | Desired netmask for the subnet to create. Example: "26". | `string` | n/a | yes |
| parent\_cidr\_subnets | List of parent subnets with the same netmask to build the subnet. | `list` | n/a | yes |
| project\_name | Name of the project that requires the subnet. This is used in the naming convention of the subnet: <project\_name>\_<environment>\_<cidr> | `string` | n/a | yes |
| route\_table\_next\_hop\_az\_fw\_ip | Contains the IP address for the Azure Firewall where packets should be forwarded to. | `string` | n/a | yes |
| route\_table\_rg\_location | Location of the Resource Group to create the route table. | `string` | n/a | yes |
| route\_table\_rg\_name | Name of the Resource Group to create the route table. | `string` | n/a | yes |
| service\_endpoints | List of strings of the desired Azure Services that the team want open in their subnet. Refer to: https://docs.microsoft.com/en-us/azure/virtual-network/virtual-network-service-endpoints-overview for possible values. Example: ["Microsoft.Sql"] | `list(string)` | n/a | yes |
| vnet\_name | Name of the Virtual Network you want to create the subnet in. | `string` | n/a | yes |
| vnet\_resource\_group\_name | Name of the resource group to create the resources in. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| route\_table\_name | n/a |
| selected\_cidr\_subnet | n/a |
| selected\_subnet\_name | n/a |
| subnet\_address\_prefixes | n/a |
| subnet\_id | n/a |
| subnet\_name | n/a |

