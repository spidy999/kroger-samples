# terraform-azurerm-network-subnets

Creates a resource group and manages subnets for existing vnets
