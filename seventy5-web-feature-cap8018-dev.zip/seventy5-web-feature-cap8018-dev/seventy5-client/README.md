# Angular (LTS) EAF Seed

## Getting Started

You'll need Node 6+ and NPM 3+ to run this project [Node](https://nodejs.org/en/download/).

After installing the latest versions of Node and NPM, install the Angular CLI

Run `npm install -g @angular/cli` to install the Angular CLI commands `ng`

## Running the development server
Run `npm start` to start the project on `http://localhost:4200` with a proxy server pointing to `http://localhost:8080`. The app will automatically reload if you change any of the source files.

You can change the proxy locations by modifying the `proxy.conf.json` file.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Dependency Issues

If you're having trouble installing dependencies add the following entries to the .npmrc file.
`npm config set registry http://artifactory.kroger.com/artifactory/api/npm/npm-repo`

## Points of Interest

### Routing
Routing is controlled by the file `/app/src/app-routing.module.ts`

#### Custom URL Parameters

```ts
{
  path: 'grid',
  component: GridComponent,
  children: [
    {
      path: 'basic/:type',
      component: GridBasicComponent
    },
    {
      path: 'advanced/:type',
      component: GridAdvancedComponent
    }
  ]
}
```

This section defines custom URL parameters under the `grid/` route.

These parameters are given in the file `/src/app/common/navbar/navbar.component.html`.
```html
<a [routerLink]="['grid/basic', 'someURLparameter']" routerLinkActive #rlaO="routerLinkActive">Basic Grid</a>
```

This `<a>` tag will route the user to `/grid/basic/someURLparameter`, with the text "someURLparameter" passed in under the name `type`.  This parameter can be captured and used inside the component loaded by the route.

#### Error Handling
```ts
{
  path: '**',
  redirectTo: ''
}
```

This section captures all URLs not defined in the list of routes and redirects them to the `''` route.  In this seed repo, the `''` route loads the `HomeComponent`.