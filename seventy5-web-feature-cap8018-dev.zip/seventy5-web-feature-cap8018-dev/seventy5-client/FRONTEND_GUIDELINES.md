### Use of Types

A type can be introduced either by interfaces or classes.

```ts
// user.ts (declaring a class) option 1
export class User {
    firstName: string;
    lastName: string;
}
```
 
```ts 
// store.ts (declaring a class) option 2
export class Store {
    constructor(public address: string, public telephone: string) {
    }
}
```
 
```ts 
// store.ts (declaring a interface) option 3
export interface Store {
    address: string;
    telephone: string;
}
```


All three options are valid Type declarations, Option 2 allows to assign fields values via the class constructor, nevertheless, we can avoid the use of constructors using Object literals.

E.g.

```ts
// user.ts
export class User {
    firstName: string;
    lastName: string;
}
```
 
```ts 
// app.component.ts
const admin: User = {
    firstName: "Edward",
    lastName: "Smith"
}
```

### Method signature

Methods are commonly used in components and services, using method signature allows us to safely refactor our code without side effects, JS Docs are recommended for documentation purposes.

```ts
// user.service.ts
 
 
 /**
   * Updates the user by publishing it to the currentUser Observable.
   *
   * @param user - The user to update
   */
updateUser(user: User): void {
    this.currentUser.next(user);
}
```
### Template Literals

The use of ES6 Template Literals is preferred over String concatenation

E.g.

```ts
// String concatenation
let title = "Welcome " + user.firstName + ", this is your profile..."
```

```ts 
// Template literals
let title = `Welcome ${user.firstName}, this is your profile...`
```

### Component declaration

An ideal component declaration should have reduced business logic on it, this code can be moved to services. The use of RxJS and the `async` pipe is also encouraged. The length of the file shouldn't be more than 300 lines.


```ts
//user-profile.component.ts
 
 
@Component({
    selector: 'user-profile',
    template: `
        <div *ngIf="user$|async; else loading">
            Welcome {{(user$|async).firstName}}
        </div>
        <ng-template #loading>Loading...</ng-template>
    `
})
class UserProfileComponent {
    user$: Observable<User> = this.userService.getUser() 
    constructor(private userService: UserService){
     
    }
}
```

### Callbacks and Array.prototype methods

Use arrow functions instead of the traditional syntax (`function(e,i){}`), this prevents undesired changes in the value of `this` as arrow functions don't create a new scopes.

Use map, filter, find, and reduce whenever possible.

E.g.

```ts
const target = myList.filter(element => element.selected)
                    .map(element => ({label: element.name, value: element}))
                    .find(element => element.label === 'Store-1');
```

This example filters selected elements, maps them into a new structure (`{label:element.name,value:element}`) and finds the single element with label `'Store-1'`.

### Project structure

The following is the recommended project structure, each module is self contained (has its own models, services, pipes and components)


```bash
Project Structure
.
+-- src/
¦   +-- app/
¦   ¦   +-- features/
¦   ¦   ¦   +-- about-us/
¦   ¦   ¦   ¦   +-- models/
¦   ¦   ¦   ¦   +-- pipes/
¦   ¦   ¦   ¦   +-- services/
¦   ¦   ¦   ¦   ¦   +-- about-us.service.spec.ts
¦   ¦   ¦   ¦   ¦   +-- about-us.service.ts
¦   ¦   ¦   ¦   +-- about-us.component.css
¦   ¦   ¦   ¦   +-- about-us.component.html
¦   ¦   ¦   ¦   +-- about-us.component.spec.ts
¦   ¦   ¦   ¦   +-- about-us.component.ts
¦   ¦   ¦   ¦   +-- about-us.module.ts
¦   ¦   ¦   +-- contact/
¦   ¦   ¦       +-- models/
¦   ¦   ¦       +-- pipes/
¦   ¦   ¦       +-- services/
¦   ¦   ¦       ¦   +-- contact.service.spec.ts
¦   ¦   ¦       ¦   +-- contact.service.ts
¦   ¦   ¦       +-- contact.component.css
¦   ¦   ¦       +-- contact.component.html
¦   ¦   ¦       +-- contact.component.spec.ts
¦   ¦   ¦       +-- contact.component.ts
¦   ¦   ¦       +-- contact.module.ts
¦   ¦   +-- shared/
¦   ¦   +-- app.component.css
¦   ¦   +-- app.component.html
¦   ¦   +-- app.component.spec.ts
¦   ¦   +-- app.component.ts
¦   ¦   +-- app.module.ts
¦   +-- assets/
¦   +-- environments/
¦   ¦   +-- environment.prod.ts
¦   ¦   +-- environment.ts
¦   +-- browserslist
¦   +-- favicon.ico
¦   +-- index.html
¦   +-- karma.conf.js
¦   +-- main.ts
¦   +-- polyfills.ts
¦   +-- styles.css
¦   +-- tsconfig.app.json
¦   +-- tsconfig.spec.json
¦   +-- tslint.json
+-- README.md
+-- angular.json
+-- package-lock.json
+-- package.json
+-- tsconfig.json
+-- tslint.json
```

