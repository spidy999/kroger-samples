import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {UserService} from '@shared/services/user/user.service';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private userService: UserService) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.userService.getUser()) {
      if (this.userService.isSupport() || this.userService.isCorp()) {
        return true;
      } else if (this.userService.isGuard() || this.userService.isContributor()) {
        // Currently only this tab is allowed for Guard and Contrib
        if (state.url === '/app-salvage' || state.url === '/user-profiles' || state.url === '/app-about') {
          return true;
        } else {
          this.router.navigate(['/']).then();
          return false;
        }
      } else if (this.userService.isDivisionManager()) {
        if (state.url === '/app-occ-reports' || state.url === '/user-profiles' || state.url === '/app-about') {
          return true;
        } else {
            this.router.navigate(['/']).then();
            return false;
          }
        }
    } else {
      if (state.url.toString().includes('/app-store-work-bench')) {
        return true;
      }
    }
    // not logged in so redirect to login page with the return url
    this.router.navigate(['/'], { queryParams: { returnUrl: state.url }}).then();
    return false;
  }
}
