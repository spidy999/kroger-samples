import { Injectable } from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {ActivatedRouteSnapshot, CanActivate, Router} from '@angular/router';

@Injectable()
export class RoleGuardService implements CanActivate {

  constructor(public userService: UserService,
              public router: Router) {}
  canActivate(route: ActivatedRouteSnapshot): boolean {
    const expectedRole = route.data.expectedRole;
    return !!(this.userService.getUser() || this.userService.hasRole(expectedRole));
  }
}
