import {CommonModule} from '@angular/common';
import {AppComponent} from './app.component';
import {HttpClientModule} from '@angular/common/http';
import {BrowserModule} from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CoreModule} from '@app/core/core.module';
import {AppRoutingModule} from './app-routing.module';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {TemplateModule} from '@app/templates/template.module';
import {ServicesModule} from '@shared/services/services.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RootStoreModule} from '@app/root-store/root-store.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    CoreModule,
    FormsModule,
    CommonModule,
    PrimengModule,
    BrowserModule,
    ServicesModule,
    TemplateModule,
    RootStoreModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AppRoutingModule
  ],
  bootstrap: [AppComponent],
  exports: [],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule {}
