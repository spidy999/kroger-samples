import {Menu} from 'primeng/menu';
import {MenuItem} from 'primeng/api';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {select, Store} from '@ngrx/store';
import { AuthService, User } from 'kroger-ng-oauth2';
import {AppState} from '@app/root-store/app.reducer';
import {ActivatedRoute, Router} from '@angular/router';
import {UserProfile} from '@shared/domain/userProfile';
import {UtilService} from '@shared/services/util/util.service';
import { UserService } from '@app/shared/services/user/user.service';
import * as fromUserActions from '@app/root-store/user-info/user-info.action';
import * as fromStoreNodeActions from '@app/root-store/store-node/store-node.action';
import {getUserInfoState, validateUser} from '@app/root-store/user-info/user-info.selector';
import * as fromDivisionActions from '@app/root-store/divisions/divisions.action';
import * as fromFacilityInfoActions from '@app/root-store/facility-info/facility-info.action';
import * as fromUserSettingsActions from '@app/root-store/user-settings/user-settings.action';
import {Component, ChangeDetectorRef, OnInit, NgZone, AfterViewInit, OnDestroy} from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit, AfterViewInit, OnDestroy {

  public facilityData: any;
  public isAuthenticated = false;
  public checkRouterLink = false;
  public currentUser: User = {};
  public menuItems: MenuItem[];
  public userInfo: UserProfile;
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private ngZone: NgZone,
              private router: Router,
              private store: Store<AppState>,
              private route: ActivatedRoute,
              private ref: ChangeDetectorRef,
              private authService: AuthService,
              private userService: UserService,
              private utilService: UtilService) {}

  ngOnInit() {
    this.checkRouterLink = window.location.pathname.toString().includes('/app-store-work-bench');
    const isIE = /msie\s|trident\//i.test(window.navigator.userAgent);
    if (isIE && !this.checkRouterLink) {
      this.utilService.showBrowserCompatibility();
    }
    this.store.pipe(select(getUserInfoState), takeUntil(this.destroy)).subscribe(state => this.userInfo = state);
    this.store.pipe(select(validateUser), takeUntil(this.destroy)).subscribe(state => {
      this.isAuthenticated = state;
      if (this.isAuthenticated) {
        this.store.dispatch(new fromDivisionActions.DivisionsStart());
        this.store.dispatch(new fromStoreNodeActions.StoreNodeStart());
        this.store.dispatch(new fromFacilityInfoActions.FacilityInfoStart());
        this.store.dispatch(new fromUserSettingsActions.UserAppSettingsStart());
        this.navigateToDefaultUrl();
      }
    });
  }

  public openUserToggleMenu(event, menuItem: Menu) {
    this.menuItems = this.loadMenuItem();
    menuItem.toggle(event);
  }

  public loadMenuItem() {
    return [
      {label: 'Settings', icon: 'fa fa-cog',
       command: () => this.ngZone.run(() => this.router.navigateByUrl('/user-profiles')).then()},
      {label: 'Sign Out', icon: 'fa fa-sign-out',
       command: () =>  this.doLogout()}
      ];
  }

  ngAfterViewInit() {
    $('.navbar-nav>li>a').on('click', function () {
      $('.navbar-collapse').collapse('hide');
    });
  }

  // On hitting kroger logo it should reroute to default page
  public navigateToDefaultUrl() {
      if (this.userService.isGuard() || this.userService.isContributor()) {
        this.ngZone.run(() => this.router.navigateByUrl('/app-salvage')).then();
      } else {
        this.ngZone.run(() => this.router.navigateByUrl('/app-home')).then();
      }
  }

  public doLogout() {
    this.store.dispatch(new fromUserActions.Logout());
  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
