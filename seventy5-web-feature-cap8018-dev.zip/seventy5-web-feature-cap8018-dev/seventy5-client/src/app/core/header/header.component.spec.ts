import {FormBuilder} from '@angular/forms';
import {Store, StoreModule} from '@ngrx/store';
import {provideMockStore} from '@ngrx/store/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { HeaderComponent } from './header.component';
import {AppState} from '@app/root-store/app.reducer';
import { RouterTestingModule } from '@angular/router/testing';
import {AuthService, KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {UtilService} from '@shared/services/util/util.service';
import { UserService } from '@app/shared/services/user/user.service';
import {userInfoReducer} from '@app/root-store/user-info/user-info.reducer';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let authService: AuthService;
  let userService: UserService;
  let utilService: UtilService;
  let store: Store<AppState>;

  const initialState = {
    user: {
      user: {
        username: 'SUPPORT',
        fullName: 'Application Support',
        firstName: 'Support',
        lastName: 'Support',
        title: 'Application Support'
      },
      isAuthenticated: true
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        KrogerNgAuthModule,
        RouterTestingModule,
        StoreModule.forRoot({
          user: userInfoReducer
        }),
        HttpClientTestingModule
      ],
      declarations: [
        HeaderComponent
      ],
      providers: [
        UserService,
        FormBuilder,
        UserService,
        UtilService,
        provideMockStore({ initialState })
      ],
      schemas:   [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    store = TestBed.inject(Store);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    authService = TestBed.inject(AuthService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
