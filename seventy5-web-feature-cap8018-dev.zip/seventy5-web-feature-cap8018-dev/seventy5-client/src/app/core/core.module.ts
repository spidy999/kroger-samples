import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { KrogerNgAuthModule } from 'kroger-ng-oauth2';
import {NavbarAuthDirective} from '@core/has-role.directive';
import {TemplateModule} from '@app/templates/template.module';
import { PrimengModule } from '@shared/primeng/primeng.module';
import {HomeComponent} from '@core/home/home.component';
import {AboutComponent} from '@core/about/about.component';
import { HeaderComponent } from './header/header.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import {SpoofingComponent} from '@core/spoofing/spoofing.component';
import { NotFoundComponent } from './error-modals/not-found/not-found.component';
import { ServerErrorComponent } from './error-modals/server-error/server-error.component';
import { UnauthorizedComponent } from './error-modals/unauthorized/unauthorized.component';
import { UnknownErrorComponent } from './error-modals/unknown-error/unknown-error.component';
import { ServiceUnavailableComponent } from './error-modals/service-unavailable/service-unavailable.component';
import { BrowserCompatibilityComponent } from './error-modals/browser-compatibility/browser-compatibility.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    PrimengModule,
    TemplateModule,
    KrogerNgAuthModule
  ],
  declarations: [
    HomeComponent,
    AboutComponent,
    HeaderComponent,
    NavbarComponent,
    FooterComponent,
    NotFoundComponent,
    SpoofingComponent,
    NavbarAuthDirective,
    ServerErrorComponent,
    UnauthorizedComponent,
    UnknownErrorComponent,
    ServiceUnavailableComponent,
    BrowserCompatibilityComponent
  ],
  exports: [
    HomeComponent,
    HeaderComponent,
    AboutComponent,
    NavbarComponent,
    FooterComponent,
    SpoofingComponent,
    NotFoundComponent,
    NavbarAuthDirective,
    ServerErrorComponent,
    UnauthorizedComponent,
    UnknownErrorComponent,
    ServiceUnavailableComponent,
    BrowserCompatibilityComponent
  ],
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class CoreModule { }
