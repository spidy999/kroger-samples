import {Store} from '@ngrx/store';
import { Component } from '@angular/core';
import {AppState} from '@app/root-store/app.reducer';
import * as fromUserActions from '@app/root-store/user-info/user-info.action';

@Component({
  selector: 'unauthorized-resource',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.less']
})
export class UnauthorizedComponent {

  constructor(private store: Store<AppState>) { }

  logout() {
    this.store.dispatch(new fromUserActions.Logout());
  }

}
