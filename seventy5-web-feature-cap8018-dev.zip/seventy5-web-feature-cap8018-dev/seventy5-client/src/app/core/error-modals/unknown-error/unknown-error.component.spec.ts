import {MessageService} from 'primeng/api';
import { RouterTestingModule } from '@angular/router/testing';
import { PrimengModule } from '@shared/primeng/primeng.module';
import { UtilService } from '@shared/services/util/util.service';
import { UnknownErrorComponent } from './unknown-error.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('UnknownErrorComponent', () => {
  let component: UnknownErrorComponent;
  let fixture: ComponentFixture<UnknownErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [  RouterTestingModule, PrimengModule ],
      declarations: [ UnknownErrorComponent ],
      providers: [
        UtilService,
        MessageService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnknownErrorComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
