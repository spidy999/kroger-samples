import { MessageService } from 'primeng/api';
import { Component, OnInit } from '@angular/core';
import { UtilService } from '@app/shared/services/util/util.service';

@Component({
  selector: 'unknown-error',
  templateUrl: './unknown-error.component.html',
  styleUrls: ['./unknown-error.component.less']
})
export class UnknownErrorComponent implements OnInit {
  constructor(private util: UtilService,
              private msgService: MessageService) {}

  ngOnInit() {
    this.util.getToastMessages().subscribe((messages) => {
      if (messages instanceof Array) {
        this.msgService.addAll(messages);
      } else {
        this.msgService.add(messages);
      }
    });
  }

}
