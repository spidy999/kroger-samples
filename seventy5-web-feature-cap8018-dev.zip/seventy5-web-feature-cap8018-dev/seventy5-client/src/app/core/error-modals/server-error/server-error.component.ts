import { Router } from '@angular/router';
import { Component } from '@angular/core';
import { UtilService } from '@shared/services/util/util.service';

@Component({
  selector: 'server-error',
  templateUrl: './server-error.component.html',
  styleUrls: ['./server-error.component.less']
})
export class ServerErrorComponent {

  errorMessage$ = this.util.getErrorMessage();
  constructor(private router: Router,
              private util: UtilService) { }

  goHome() {
    this.router.navigate(['/']).then();
    this.util.hideErrorModal();
  }

  close() {
    this.util.hideErrorModal();
  }
}
