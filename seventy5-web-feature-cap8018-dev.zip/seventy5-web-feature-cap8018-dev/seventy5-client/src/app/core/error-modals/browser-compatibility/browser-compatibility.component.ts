import {Component} from '@angular/core';
import { UtilService } from '@app/shared/services/util/util.service';

@Component({
  selector: 'browser-compatibility',
  templateUrl: './browser-compatibility.component.html',
  styleUrls: ['./browser-compatibility.component.less']
})
export class BrowserCompatibilityComponent {

  constructor(private util: UtilService) { }

  close() {
    this.util.hideBrowserCompatibility();
  }

}
