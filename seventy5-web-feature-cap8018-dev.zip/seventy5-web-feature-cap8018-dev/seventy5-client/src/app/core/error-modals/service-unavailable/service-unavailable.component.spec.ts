import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { PrimengModule } from '@shared/primeng/primeng.module';
import { UtilService } from '@app/shared/services/util/util.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ServiceUnavailableComponent } from './service-unavailable.component';

describe('ServiceUnavailableComponent', () => {
  let component: ServiceUnavailableComponent;
  let fixture: ComponentFixture<ServiceUnavailableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [  RouterTestingModule, PrimengModule ],
      declarations: [ ServiceUnavailableComponent ],
      providers: [ UtilService ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceUnavailableComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
