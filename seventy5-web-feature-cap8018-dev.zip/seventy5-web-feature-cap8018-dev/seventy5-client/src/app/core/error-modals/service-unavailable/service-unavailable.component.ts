import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from '@shared/services/util/util.service';

@Component({
  selector: 'service-unavailable',
  templateUrl: './service-unavailable.component.html',
  styleUrls: ['./service-unavailable.component.less']
})
export class ServiceUnavailableComponent {

  errorMessage$ = this.util.getErrorMessage();
  constructor(private router: Router, private util: UtilService) {}

  goHome() {
    this.router.navigate(['/']).then();
    this.util.hideErrorModal();
  }

  close() {
    this.util.hideErrorModal();
  }
}
