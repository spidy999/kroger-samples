import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UtilService } from '@shared/services/util/util.service';

@Component({
  selector: 'not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.less']
})
export class NotFoundComponent {

  constructor(private router: Router,
              private util: UtilService) { }

  goHome() {
    this.util.hideErrorModal();
    this.router.navigate(['/']).then();
  }

  close() {
    this.util.hideErrorModal();
  }

}
