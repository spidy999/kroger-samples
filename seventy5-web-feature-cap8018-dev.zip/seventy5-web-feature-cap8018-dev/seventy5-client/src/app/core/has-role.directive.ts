import {AuthService} from 'kroger-ng-oauth2';
import {Directive, ElementRef, Input, OnChanges, Renderer2} from '@angular/core';

@Directive({
  selector: '[krHasRole]'
})
export class NavbarAuthDirective implements OnChanges {

  @Input() hasPermission: String[];
  private isAuthenticated: any;
  private readonly beforeStyle: string;
  constructor(
    private readonly el: ElementRef,
    private readonly renderer: Renderer2,
    private readonly authService: AuthService
  ) {
    this.beforeStyle = window.getComputedStyle(this.el.nativeElement).display;

    this.authService.auth.subscribe(data => {
      if (data.authData.authenticated) {
        this.isAuthenticated = true;
      } else {
        this.isAuthenticated = false;
        this.renderer.setStyle(this.el.nativeElement, 'display', 'none');
      }
      this.checkChange();
    });

    if (this.isAuthenticated) {
      this.renderer.setStyle(
        this.el.nativeElement,
        'display',
        this.beforeStyle
      );
    } else {
      this.renderer.setStyle(this.el.nativeElement, 'display', 'none');
    }
  }

  ngOnChanges() {
    this.checkChange();
  }

  checkChange() {
    const hasRole = this.authService.hasRole(this.hasPermission.toString());
    if (hasRole) {
      this.renderer.setStyle(
        this.el.nativeElement,
        'display',
        this.beforeStyle
      );
    } else {
      this.renderer.setStyle(this.el.nativeElement, 'display', 'none');
    }
  }
}
