import {FormBuilder} from '@angular/forms';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { AboutComponent } from './about.component';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {UserService} from '@shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';

describe('AboutComponent', () => {
  let component: AboutComponent;
  let fixture: ComponentFixture<AboutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        KrogerNgAuthModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      providers: [
        UserService,
        FormBuilder,
        FacilityService
      ],
      declarations: [ AboutComponent ],
      schemas:   [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
