import {Store} from '@ngrx/store';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {Component, OnDestroy} from '@angular/core';
import {AuthService, User} from 'kroger-ng-oauth2';
import {AppState} from '@app/root-store/app.reducer';
import * as fromUser from '@app/root-store/user-info/user-info.action';

@Component({
  selector: 'app-spoofing',
  templateUrl: './spoofing.component.html',
  styleUrls: ['./spoofing.component.less']
})
export class SpoofingComponent implements OnDestroy {
  public baseUrl = '';
  public spoofing = false;
  public userInfo: User = {};
  public isAuthenticated: boolean;
  private destroy: Subject<boolean> = new Subject<boolean>();

  public authConfig = {
    baseUrl: this.baseUrl,
    meEndpoint: this.baseUrl + '/api/me',
    logoutUrl: this.baseUrl + '/logout',
    initAuthCodeUrl: this.spoofing ? this.baseUrl + '/login' : this.baseUrl,
    gatewayUrl: this.baseUrl,
    shouldAuthenticateOnInit: false
  };

  constructor(private authService: AuthService,
              private store: Store<AppState>) {
    this.authService.auth.pipe(takeUntil(this.destroy)).subscribe((data) => {
      if (data.authData.authenticated) {
        this.userInfo = data.authData.user;
        this.store.dispatch(new fromUser.Login({
          user: this.userInfo,
          isAuthenticated: true
        }));
      } else {
        this.isAuthenticated = false;
        this.userInfo = null;
      }
    });
  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
