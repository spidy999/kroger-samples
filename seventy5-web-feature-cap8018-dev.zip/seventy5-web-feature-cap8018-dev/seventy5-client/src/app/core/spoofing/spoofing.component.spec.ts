import {FormBuilder} from '@angular/forms';
import {Store, StoreModule} from '@ngrx/store';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {provideMockStore} from '@ngrx/store/testing';
import { SpoofingComponent } from './spoofing.component';
import {UserService} from '@shared/services/user/user.service';
import {AuthService, KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {userInfoReducer, UserState} from '@app/root-store/user-info/user-info.reducer';

describe('SpoofingComponent', () => {
  let component: SpoofingComponent;
  let authService: AuthService;
  let userService: UserService;
  let store: Store<UserState>;
  let fixture: ComponentFixture<SpoofingComponent>;

  const initialState = {
    user: {
      user: {
        username: 'SUPPORT',
        fullName: 'Application Support',
        firstName: 'Support',
        lastName: 'Support',
        title: 'Application Support'
      },
      isAuthenticated: true
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        KrogerNgAuthModule,
        StoreModule.forRoot({
          user: userInfoReducer
        })
      ],
      declarations: [ SpoofingComponent ],
      providers: [
        UserService,
        AuthService,
        FormBuilder,
        provideMockStore({ initialState })
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpoofingComponent);
    store = TestBed.inject(Store);
    authService = TestBed.inject(AuthService);
    userService = TestBed.inject(UserService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
