import {FormBuilder} from '@angular/forms';
import {APP_BASE_HREF} from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { NavbarComponent } from './navbar.component';
import { KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {NavbarAuthDirective} from '@core/has-role.directive';
import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {UserService} from '@shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';

describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        KrogerNgAuthModule,
        RouterTestingModule
      ],
      declarations: [
        NavbarComponent,
        NavbarAuthDirective
      ],
      providers: [
      {
        provide: APP_BASE_HREF,
        useValue: '/'
      },
        UserService,
        FormBuilder,
        FacilityService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
