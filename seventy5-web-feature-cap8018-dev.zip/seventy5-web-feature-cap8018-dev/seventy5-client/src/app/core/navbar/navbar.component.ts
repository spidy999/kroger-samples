import { Component, OnInit } from '@angular/core';
import {Constants} from '@shared/models/constants';
import {Permission} from '@shared/models/permissions';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.less']
})
export class NavbarComponent implements OnInit {
  public permission: any = Permission;
  public week: number = Constants.DAYS_IN_WEEK;
  constructor() { }

  ngOnInit() {}

}
