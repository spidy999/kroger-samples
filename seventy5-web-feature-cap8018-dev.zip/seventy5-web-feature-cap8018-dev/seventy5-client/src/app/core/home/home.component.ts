import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {ActivatedRoute, Router} from '@angular/router';
import {UserService} from '@shared/services/user/user.service';
import {Component, NgZone, OnDestroy, OnInit} from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit, OnDestroy {

  private destroy: Subject<boolean> = new Subject<boolean>();
  constructor(private zone: NgZone,
              private router: Router,
              private route: ActivatedRoute,
              public userService: UserService) { }

  ngOnInit() {
    if (this.userService.getUser()) {
      this.reDirectToAuthorizedResource();
    }
    this.userService.auth.pipe(takeUntil(this.destroy)).subscribe(data => {
      if (data.authData.authenticated) {
        this.reDirectToAuthorizedResource();
      } else {
        const returnUrl = this.route.snapshot.queryParams['returnUrl'];
        if (returnUrl) {
          this.router.navigate([returnUrl]).then();
        }
      }
    });
  }

  reDirectToAuthorizedResource() {
    this.userService.doNextAuth();
    if (this.userService.isCorp() || this.userService.isSupport()) {
      this.zone.run( () => {
        const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/app-dashboard';
        if (returnUrl) {
          this.router.navigate([returnUrl]).then();
        }
      });
    } else if (this.userService.isGuard() || this.userService.isContributor()) {
      this.zone.run(() => {
        const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/app-salvage';
        if (returnUrl) {
          this.router.navigate([returnUrl]).then();
        }
      });
    } else if (this.userService.isDivisionManager()) {
      this.zone.run(() => {
        const returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/app-occ-reports';
        if (returnUrl) {
          this.router.navigate([returnUrl]).then();
        }
      });
    }
  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }

}
