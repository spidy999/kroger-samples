import {
  ChartLayoutOption,
  CustomCalendarOption
} from '@shared/domain/appSettings';

export const user_menu = {
  calendarOptions : [
    {label: 'Current Week', value: CustomCalendarOption.CURRENT_WEEK },
    {label: 'Last Week', value: CustomCalendarOption.LAST_WEEK },
    {label: 'Current Month', value: CustomCalendarOption.CURRENT_MONTH }
  ],

  chartOptions : [
    {label: 'Table', value: ChartLayoutOption.TABLE },
    {label: 'Line/Trend', value: ChartLayoutOption.LINE_CHART },
    {label: 'Bar', value: ChartLayoutOption.BAR_CHART },
  ]
};
