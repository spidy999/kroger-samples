import {AppComponent} from './app.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {AuthService, KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { UtilService } from '@shared/services/util/util.service';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        KrogerNgAuthModule,
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [AuthService, UtilService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  it('should create the app', async(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    expect(component).toBeTruthy();
  }));

  it(`should have as title 'app'`, async(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    expect(component).toBeTruthy();
  }));
});

