import {Store} from '@ngrx/store';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { tap, catchError } from 'rxjs/operators';
import { HTTP_STATUS } from '@shared/models/shared';
import {AppState} from '@app/root-store/app.reducer';
import { UtilService } from '@shared/services/util/util.service';
import * as fromUserActions from '@app/root-store/user-info/user-info.action';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpErrorResponse, HttpResponse } from '@angular/common/http';

@Injectable()
export class GlobalHttpInterceptor implements HttpInterceptor {
    constructor(private util: UtilService,
                public store: Store<AppState>) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            tap(
            resp => {
                if (resp instanceof HttpResponse) {
                    if (resp.status === HTTP_STATUS.SUCCESS) {
                        // all good
                        return;
                    } else {
                        // not good
                        let message = 'Unknown Error';

                        if (resp.body && resp.body.statusInfo && resp.body.statusInfo.messages) {
                            message = resp.body.statusInfo.messages[0];
                        } else if ( resp.statusText ) {
                            message = resp.statusText;
                        }
                        throw { message };
                    }
                }
            }),
            catchError(
            err => {
                if (err instanceof HttpErrorResponse) {
                    const { status, message, error: msg } = err;
                    if (msg instanceof ProgressEvent) {
                        if (message.includes('api/')) {
                            this.util.addToastMessage({
                                severity: 'warn',
                                summary: 'Network Error',
                                detail: 'Slow or No connection, please check yout network settings'
                            });
                        }
                        throw err;
                    }

                    switch (status) {
                        case HTTP_STATUS.SUCCESS:
                            // not an error
                            // probably expecting a JSON and received something else, (HTML or plain text)
                            break;
                        case HTTP_STATUS.UNAUTHORIZED:
                            this.logout();
                            break;
                        case HTTP_STATUS.NOT_FOUND:
                            this.util.showErrorModal(status);
                            break;
                        case HTTP_STATUS.GATEWAY_TIMEOUT:
                            this.util.addToastMessage({
                                severity: 'warn',
                                summary: 'Network Error',
                                detail: 'Slow or No connection, please check yout network settings'
                            });
                            break;
                        case HTTP_STATUS.SERVER_ERROR:
                        case HTTP_STATUS.SERVICE_UNAVAILABLE:
                            this.util.setErrorMessage(`[${err.statusText}] : ${msg.errors ? msg.errors.reason : msg}`);
                            this.util.showErrorModal(status);
                            break;
                        default:
                            this.util.addToastMessage({
                                severity: 'warn',
                                summary: err.statusText,
                                detail: msg && msg.errors ? msg.errors : msg
                            });
                            break;
                    }
                } else {
                    this.util.addToastMessage({
                        severity: 'warn',
                        summary: 'Unexpected error',
                        detail: err.message
                    });
                }
                throw err;
            }));
    }

    logout() {
      this.store.dispatch(new fromUserActions.Logout());
    }
}
