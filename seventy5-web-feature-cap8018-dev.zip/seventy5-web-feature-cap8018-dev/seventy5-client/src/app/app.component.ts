import {Component} from '@angular/core';
import {AuthService} from 'kroger-ng-oauth2';
import {UtilService} from '@shared/services/util/util.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  errorType$ = this.util.getErrorModal();
  browserCompatibility$ = this.util.getBrowserCompatibility();

  constructor(private util: UtilService,
              private authService: AuthService) {
    this.authService.auth.subscribe((data) => {
      if (data.authData.error && data.authData.error.type === 'http_error') {
        this.authService.clearErrors();
      }
    });
  }
}
