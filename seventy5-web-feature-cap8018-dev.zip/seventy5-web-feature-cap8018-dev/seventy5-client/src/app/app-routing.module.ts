import {NgModule} from '@angular/core';
import {HomeComponent} from '@core/home/home.component';
import {AboutComponent} from '@core/about/about.component';
import {ExtraOptions, PreloadAllModules, RouterModule, Routes} from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'app-dashboard',
    loadChildren: () => import('@features/dashboard/dashboard.module').then(m => m.DashboardModule)
  },
  {
    path: 'app-occ-reports',
    loadChildren: () => import('@features/cardboard-tracking/cardboard-tracking.module').then(m => m.CardboardTrackingModule)
  },
  {
    path: 'app-salvage',
    loadChildren: () => import('@features/salvage/salvage.module').then(m => m.SalvageModule)
  },
  {
    path: 'app-admin',
    loadChildren: () => import('@features/admin/admin.module').then(m => m.AdminModule)
  },
  {
    path: 'app-email-configuration',
    loadChildren: () => import('@features/email-configuration/email-configuration.module').then(m => m.EmailConfigurationModule)
  },
  {
    path: 'app-store-work-bench',
    loadChildren: () => import('@features/store-work-bench/store-work-bench.module').then(m => m.StoreWorkBenchModule)
  },
  {
    path: 'user-profiles',
    loadChildren: () => import('@features/user-profiles/user-profiles.module').then(m => m.UserProfilesModule)
  },
  {
    path: 'app-about',
    component: AboutComponent
  },
  {
    path: '**',
    redirectTo: ''
  }
];

const options: ExtraOptions = {
  preloadingStrategy: PreloadAllModules
};

@NgModule({
  imports: [RouterModule.forRoot(routes, options)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
