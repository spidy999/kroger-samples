import { Pipe, PipeTransform } from '@angular/core';
/*
 * Format a boolean to human-readable format.
 *
 * Takes an type argument that defaults to YES_NO.
 * Can be Y_N, T_F, TRUE_FALSE, ON_OFF, ACTIVE_INACTIVE, or YES_NO
 *
 * Usage:
 *   value | type:YES_NO
 * Example:
 *   {{ true | boolean:YES_NO }}
 *   formats to: Yes
*/
@Pipe({name: 'boolean'})
export class BooleanPipe implements PipeTransform {

  transform(value: boolean, type: string): string {

    if (!type) {
      type = 'YES_NO';
    }

    switch (type) {
      case 'YES_NO':
        return (value) ? 'Yes' : 'No';
      case 'Y_N':
        return (value) ? 'Y' : 'N';
      case 'T_F':
        return (value) ? 'T' : 'F';
      case 'TRUE_FALSE':
        return (value) ? 'True' : 'False';
      case 'ON_OFF':
        return (value) ? 'On' : 'Off';
      case 'ACTIVE_INACTIVE':
        return (value) ? 'Active' : 'Inactive';
      default:
        return (value) ? 'true' : 'false';
    }
  }
}
