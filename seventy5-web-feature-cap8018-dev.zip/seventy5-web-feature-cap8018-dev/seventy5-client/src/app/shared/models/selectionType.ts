import {ChartLayoutOption, SelectChartOptions} from '@shared/domain/appSettings';

export const Selection = {
  [SelectChartOptions.TABLE]: {label: 'Table', value: ChartLayoutOption.TABLE, icon: 'fa fa-fw fa-table'},
  [SelectChartOptions.BAR_CHART]: {label: 'Bar', value: ChartLayoutOption.BAR_CHART, icon: 'fa fa-fw fa-bar-chart'},
  [SelectChartOptions.LINE_CHART]: {label: 'Line', value: ChartLayoutOption.LINE_CHART, icon: 'fa fa-fw fa-line-chart'},
  [SelectChartOptions.TREND_LINE]: {label: 'Trend Line', value: SelectChartOptions.TREND_LINE, icon: 'fa fa-fw fa-line-chart'}
};
