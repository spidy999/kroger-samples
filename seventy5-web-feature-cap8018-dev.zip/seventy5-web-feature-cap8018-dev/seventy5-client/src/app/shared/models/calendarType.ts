export enum CalendarType {
  CURRENT_WEEK_CALENDAR = 'currentWeekCalendar',
  PREVIOUS_WEEK_CALENDAR = 'previousWeekCalendar',
  DAY_CALENDAR = 'dayCalendar',
}

