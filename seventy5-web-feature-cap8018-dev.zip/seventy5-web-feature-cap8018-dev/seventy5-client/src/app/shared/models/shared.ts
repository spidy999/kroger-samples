
export class Tree<T> {
    public value: any ;
    public children: Tree<T> [];
    public selected: boolean;
    public expanded: boolean;
    public partiallySelected: boolean;
    public level: number;
    constructor(value: any) {
        this.value = value;
        this.children = new Array<Tree<T>>();
        this.selected = false;
        this.partiallySelected = false;
        this.expanded = false;
        this.level = 0;
    }
}

export enum HTTP_STATUS {
    NOT_FOUND = 404,
    UNAUTHORIZED = 401,
    SERVER_ERROR = 500,
    SERVICE_UNAVAILABLE = 503,
    SUCCESS = 200,
    BAD_REQUEST = 400,
    GATEWAY_TIMEOUT = 504
}
