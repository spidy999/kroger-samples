
export class GetDistrictData {
  public  divisionNo: string;
  public  districtDetails?: DistrictData[];
  public  startDate: string;
  public  endDate: string;
}

export class GetDistrictDetailData {
  public  divisionNo: string;
  public districtCode: string;
  public  storeDetails?: StoresData[];
  public  startDate: string;
  public  endDate: string;
}

export class DistrictDetails {
  public  divisionNo: string;
  public district: string;
  public  startDate: string;
  public  endDate: string;
}

export class DistrictData {
  constructor(
  public  districtCode: string,
  public  storeScanCount: number,
  public dcScanCount: number,
  public notWeighedCount: number,
  public actualWeight: number,
  public sensorVariance: string,
  public baleSensorCount: number) {}
}

export class StoresData {
  constructor(
    public  districtCode: string,
    public  facilityNumber: string,
    public  storeScanCount: number,
    public dcScanCount: number,
    public notWeighedCount: number,
    public actualWeight: number,
    public sensorVariance: string,
    public baleSensorCount: number) {}
}

export class GetDcData {
  public  startDate: string;
  public  endDate: string;
  public period?: number[];
  public facilityId: number;
}


export class ReportDataSet {
  constructor(public label: string, public data: any, public fill: boolean,
              public borderColor: string, public backgroundColor?: string,
              public divisionNo?: string, public district?: string) {
  }
}

export class ChartData {
  constructor(public labels?: any,
              public datasets?: Dataset[],
              public options?: Options) {}
}

export class Dataset {
  constructor(public data: any, public fill?: boolean, public label?: string | string[],
              public borderColor?: string | string[], public backgroundColor?: string | string[],
              public hoverBackgroundColor?: string | string[], public type?: string,
              public showInLegend?: boolean, public borderDash?: number[],
              public yAxisID?: string, public lineTension?: any) {}
}

export class Options {
  constructor(public legend: Legend) {}
}

export class Legend {
  constructor(public display: boolean,
              public position: string) {}
}


export class StoreData {
  constructor( public storeNo: string, public itemQuantity: number, public insertedDate?: any) {
  }
}

export class DateRange {
  public  startDate: string;
  public  endDate: string;
  public period?: number[];
}

export class ReportDates {
  public today: string;
  public yesterday: string;
  public startDayOfWeek: string;
  public endDayOfWeek: string;
  public previousWeek: DateRange;
  public currentWeek: DateRange;
  public trendLineDates: DateRange;
  public displayDates: DateRange;
}

export class ChartDetails {
  title?: string;
  data: ChartData;
  helpText?: string;
  detailUrl?: string;
  height?: string;
  columns?: string[];
  dataKey?: string;
  footer?: Footer;
  limit?: number;
}

export class Footer {
  header?: string;
  storeTotal?: number;
  sensorTotal?: number;
}

export enum ReportType {
  DC_ACTIVITY = 'DC_ACTIVITY',
  STORE_ACTIVITY = 'STORE_ACTIVITY'
}
