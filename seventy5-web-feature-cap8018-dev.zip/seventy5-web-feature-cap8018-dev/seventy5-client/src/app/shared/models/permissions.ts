
/**
Current User Roles
1.	Support
2.	Corporate
3.	Contributor
4.	Guard
5.	Division Manager

Support ('oa-svnfiv-support-4064')
  -	should see all the tabs.

Corporate('oa-svnfiv-corp-4064')
  -	should see all the tabs in web application except ( Administration, SMW-DashBoard),
  can only see [Enterprise Dashboard] under dashboard-tab

Contributor('oa-svnfiv-contrib-4064')
  -	can see everything under salvage-tab ( Search BOL, Create BOL, Close BOL, In-Progress BOL).

Guard ('oa-svnfiv-guard-4064')
  -	can only see [ close BOL ] under salvage-tab.

Division Manager ('oa-svnfiv-divmgr-4064')
  -	can only see [ Bale Production ] and [ Store Activity] under Cardboard Tracking-tab.
 */


export enum Roles {
  SUPPORT = 'oa-svnfiv-support-4064',
  CORP = 'oa-svnfiv-corp-4064',
  DIVISION_MANAGER = 'oa-svnfiv-divmgr-4064',
  GUARD = 'oa-svnfiv-guard-4064',
  CONTRIBUTOR = 'oa-svnfiv-contrib-4064',
  STORE_MANAGER = 'oa-svnfiv-strmgr-4064',
  PUBLIC = ''
}

export const Permission = {
  SALVAGE :         [Roles.SUPPORT, Roles.CORP, Roles.CONTRIBUTOR, Roles.GUARD],
  OCC_REPORTS :     [Roles.SUPPORT, Roles.CORP, Roles.DIVISION_MANAGER],
  ABOUT :           [Roles.SUPPORT, Roles.CORP, Roles.CONTRIBUTOR, Roles.GUARD, Roles.DIVISION_MANAGER],
  DASHBOARD :       [Roles.SUPPORT, Roles.CORP],
  SMW_DASHBOARD :   [Roles.SUPPORT, Roles.PUBLIC],
  USER_PROFILE:     [Roles.SUPPORT, Roles.CORP, Roles.CONTRIBUTOR, Roles.GUARD],
  EMAIL_CONFIGURATION:  [Roles.SUPPORT, Roles.CORP],
  ADMINISTRATION :  [Roles.SUPPORT]
};
