export interface Notification {
  heading: string;
  message: string;
  severity: NotificationSeverity | string;
}

export enum NotificationSeverity {
  ERROR = 'error',
  WARN = 'warning',
  INFO = 'info',
  SUCCESS = 'success'
}

export interface ToastDetails {
  title?: string;
  message?: string;
  toastType?: string;
}
