export class DateRange {
  private _startDate: String;
  private _stopDate: String;
  private _bolStatus: String;

  get startDate(): String {
    return this._startDate;
  }

  set startDate(value: String) {
    this._startDate = value;
  }

  get stopDate(): String {
    return this._stopDate;
  }

  set stopDate(value: String) {
    this._stopDate = value;
  }


  get bolStatus(): String {
    return this._bolStatus;
  }

  set bolStatus(value: String) {
    this._bolStatus = value;
  }
}

export class Dates {
  constructor(public startDate: any,
              public stopDate: any,
              public period?: number[],
              public calendarFlag?: boolean) {}
}
