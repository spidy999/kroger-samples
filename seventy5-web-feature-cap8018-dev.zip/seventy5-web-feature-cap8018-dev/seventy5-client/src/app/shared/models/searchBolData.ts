import { SalvageMaterialType } from '../domain/salvageMaterialType';

export class SearchBolData {
  facilityId?: number;
  status?: string;
  trailerNo?: any;
  destination?: string;
  salvageMaterialType?: SalvageMaterialType;
  gpsId?: any;
  startDate?: string;
  endDate?: string;
  period?: number[];
  bolId?: any;
}

export class SearchBolPageObject {
  content: SearchBolData[];
  totalRecords: number;
  pageIndex: number;
}

export class TransferBolData {
  public  bolId: number;
  public  euid: string;
  public  doorNo: string;
}

export interface SearchBolParamsData {
  bolId?: number;
  destination?: string;
  facilityId?: number;
  salvageMaterialType?: SalvageMaterialType;
  startDate?: any;
  endDate?: any;
  status?: string;
}

