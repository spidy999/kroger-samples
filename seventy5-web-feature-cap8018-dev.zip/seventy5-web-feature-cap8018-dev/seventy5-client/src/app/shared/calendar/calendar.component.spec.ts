import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalendarComponent } from './calendar.component';
import {RouterTestingModule} from '@angular/router/testing';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { KrogerNgAuthModule } from 'kroger-ng-oauth2';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {FormBuilder} from '@angular/forms';
import {FacilityService} from '@shared/services/facility/facility.service';

describe('CalendarComponent', () => {
  let component: CalendarComponent;
  let dateService: DateService;
  let fiscalDateService: FiscalDateService;
  let userService: UserService;
  let fixture: ComponentFixture<CalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        PrimengModule,
        KrogerNgAuthModule,
        BrowserAnimationsModule,
        RouterTestingModule
      ],
      declarations: [ CalendarComponent ],
      providers: [
        DateService,
        FormBuilder,
        FacilityService,
        FiscalDateService,
        UserService
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalendarComponent);
    dateService = TestBed.inject(DateService);
    userService = TestBed.inject(UserService);
    fiscalDateService = TestBed.inject(FiscalDateService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
