import { CommonModule } from '@angular/common';
import {PrimengModule} from '@shared/primeng/primeng.module';
import { CalendarComponent } from './calendar.component';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';

@NgModule({
  imports: [
    CommonModule,
    PrimengModule
  ],
  declarations: [ CalendarComponent],
  exports: [ CalendarComponent ],
  providers: [
    FiscalDateService
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class CalendarModule { }
