import {select, Store} from '@ngrx/store';
import {Dates} from '@shared/models/dateRange';
import {Constants} from '@shared/models/constants';
import {AppState} from '@app/root-store/app.reducer';
import {CalendarType} from '@shared/models/calendarType';
import {DateService} from '@shared/services/date/date.service';
import {UserService} from '@shared/services/user/user.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {AppSettings, CustomCalendarOption} from '@shared/domain/appSettings';
import {getAppSettingsState} from '@app/root-store/user-settings/user-settings.selector';
const HOURS = 24;

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.less']
})
export class CalendarComponent implements OnInit {

  public today: Date;
  public year: any;
  public month: any;
  public currentWeek: any;
  public previousWeek: any;
  public maximumDate: any;
  public dateRange: any = [];
  public appSettings: AppSettings;
  public dateRangeDisplay: any = [];
  public hoverDateText = 'Select Date Range';
  public selectedCalendarType = CalendarType;
  @Input() public calendarType: CalendarType;
  @Input() disabled = false;
  @Output() close = new EventEmitter();

  constructor(private dateService: DateService,
              private userService: UserService,
              private readonly store: Store<AppState>,
              private fiscalDateService: FiscalDateService) {}

  ngOnInit() {
    this.today = new Date();
    this.year = this.today.getFullYear();
    this.month = this.today.getMonth();
    this.previousWeek = this.today.setDate(this.today.getDate() - Constants.DAYS_IN_WEEK);
    this.currentWeek = this.today.setDate(this.today.getDate() + Constants.DAYS_IN_WEEK);
    this.maximumDate = this.today;
    this.maximumDate.setHours(HOURS, 0, 0, 0);
    this.getUserAppSettings();
  }

  public calculateWeekDate(evt) {
    const startDay = new Date(evt);
    startDay.setDate(startDay.getDate() - startDay.getDay());
    const endDay = new Date(startDay);
    endDay.setDate(startDay.getDate() + Constants.DAYS_IN_WEEK - 1);
    this.calculateCalendarDates(startDay, endDay);
  }

  public calculateDayDate(evt) {
    const startDay = new Date(evt);
    startDay.setDate(startDay.getDate());
    const endDay = new Date(startDay);
    endDay.setDate(startDay.getDate());
    this.calculateCalendarDates(startDay, endDay);
  }

  private calculateCalendarDates(startDay, endDay) {
    if (endDay > this.maximumDate) {
      endDay = this.maximumDate;
    }
    if (this.dateRange[0] && startDay < this.dateRange[0]) {
      this.dateRange[0] = startDay;
    } else if (this.dateRange[1] && endDay > this.dateRange[1]) {
      this.dateRange[1] = endDay;
    } else {
      this.dateRange[0] = startDay;
      this.dateRange[1] = endDay;
    }
    this.dateRangeDisplay[0] = this.dateRange[0];
    this.dateRangeDisplay[1] = this.dateRange[1];
    const period: number[] = this.calculatePeriods(this.dateRangeDisplay[0], this.dateRangeDisplay[1]);
    const calendar: Dates = {
      startDate: this.dateRangeDisplay[0],
      stopDate: this.dateRangeDisplay[1],
      period: period,
      calendarFlag: true
    };
    this.dateService.doNextCalendar(calendar);
  }

  private getUserAppSettings() {

    this.store.pipe(select(getAppSettingsState)).subscribe(settings => {
      this.appSettings = settings;
      if (!settings) { return; }
      if (this.calendarType === this.selectedCalendarType.DAY_CALENDAR) {
        this.calculateDayDate(this.today);
      } else if (settings.customCalendarOption === CustomCalendarOption.LAST_WEEK) {
        this.calculateWeekDate(this.previousWeek);
      } else if (settings.customCalendarOption === CustomCalendarOption.CURRENT_WEEK) {
        this.calculateWeekDate(this.currentWeek);
      } else if (settings.customCalendarOption === CustomCalendarOption.CURRENT_MONTH) {
        const firstDay = new Date(this.year, this.month, 1);
        const lastDay = new Date(this.year, this.month + 1, 0);
        this.calculateCalendarDates(firstDay, lastDay);
      } else if (this.calendarType === this.selectedCalendarType.PREVIOUS_WEEK_CALENDAR) {
        this.calculateWeekDate(this.previousWeek);
      } else if (this.calendarType === this.selectedCalendarType.CURRENT_WEEK_CALENDAR) {
        this.calculateWeekDate(this.currentWeek);
      }
    });
  }

  setHoverText(evt) {
    const hoverDay = new Date(evt['year'], evt['month'], evt['day']);
    this.hoverDateText = this.fiscalDateService.getKrogerWeek(hoverDay);
  }

  calculatePeriods(startDate, endDate) {
    const period: number[] = [];
    const startPrd = new Date(startDate);
    const endPrd = new Date(endDate);
    period.push(this.fiscalDateService.getPrd(startPrd));
    period.push(this.fiscalDateService.getPrd(endPrd));
    return period;
  }
}
