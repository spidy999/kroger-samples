import {Subject} from 'rxjs/Subject';
import {SelectItem} from 'primeng/api';
import {map, share} from 'rxjs/operators';
import {Observable} from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import {AuthService} from 'kroger-ng-oauth2';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FormBuilder, FormGroup} from '@angular/forms';
import { Roles } from '@app/shared/models/permissions';
import {
  AppSettings,
  ChartLayoutOption,
  CustomCalendarOption
} from '@shared/domain/appSettings';

@Injectable({providedIn: 'root'})
export class UserService {
  public auth: Observable<any>;
  private appSettingsForm: FormGroup;
  private authEvent = new Subject<void>();
  private printLocations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  constructor(private http: HttpClient,
              private fb: FormBuilder,
              private authService: AuthService) {
    this.auth = authService.auth;
  }

  isCorp() {
    return (this.authService.hasRole(Roles.CORP));
  }

  isSupport() {
    return this.authService.hasRole(Roles.SUPPORT);
  }

  isGuard() {
    return this.authService.hasRole(Roles.GUARD);
  }

  isContributor() {
    return this.authService.hasRole(Roles.CONTRIBUTOR);
  }

  isDivisionManager() {
    return this.authService.hasRole(Roles.DIVISION_MANAGER);
  }

  getUserEuid() {
    return this.authService.getUser().username;
  }

  getAuth() {
    return this.authEvent;
  }

  doNextAuth() {
    this.authEvent.next();
  }

  getUser() {
    return this.authService.getUser();
  }

  hasRole(role: string) {
    return this.authService.hasRole(role);
  }

  login() {
    return this.authService.login();
  }

  logout() {
    return this.authService.logout();
  }

  /*App Settings*/
  userAppSettingsForm(): FormGroup {
    this.appSettingsForm = this.fb.group({
      chartLayoutOption: [ChartLayoutOption.TABLE],
      customCalendarOption: [CustomCalendarOption.CURRENT_WEEK]
    });
    return this.appSettingsForm;
  }

  getUserAppSettingsFromServer(): Observable<AppSettings> {
    return this.http.get<AppSettings> (`api/appSettings/`) .pipe(share());
  }

  updateUserAppSettings(appSettings: AppSettings): Observable<AppSettings> {
    return this.http.put<AppSettings> (`api/appSettings/`, appSettings).pipe(
      map(response => response)
    );
  }

  getPrintLocations(): BehaviorSubject<SelectItem[]> {
    return this.printLocations$;
  }
}
