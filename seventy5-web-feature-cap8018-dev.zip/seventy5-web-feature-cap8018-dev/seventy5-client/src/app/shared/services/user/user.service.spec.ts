import {FormBuilder} from '@angular/forms';
import { UserService } from './user.service';
import { TestBed, inject } from '@angular/core/testing';
import {AuthService, KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {FacilityService} from '@shared/services/facility/facility.service';

describe('UserService', () => {
  let userService: UserService;
  let authService: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [KrogerNgAuthModule],
      providers: [
        UserService,
        FormBuilder,
        AuthService,
        FacilityService
      ]
    });
  });

  beforeEach(() => {
    userService = TestBed.inject(UserService);
    authService = TestBed.inject(AuthService);
  });

  it('should be created', inject([UserService], (service: UserService) => {
    expect(service).toBeTruthy();
  }));
});
