import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Store} from '@shared/domain/store';
import {HttpClient} from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class StoreService {
    getAllDistrictsForDivision: any;

  constructor(private http: HttpClient) {}

  getAllStoresForDivision(division: string): Observable<Store[]> {
    return this.http.get<Store[]>('api/store/' + division);
  }

  setActiveDcFlag(stores: Store[], isActive: boolean) {
    return this.http.post(`api/store/activedc/${isActive}`, stores);
  }

  saveStore(store: Store): Observable<Store> {
    return this.http.post<Store>('api/store', store);
  }

  addStore(store: Store): Observable<Store> {
    return this.http.post<Store>('api/store/add', store);
  }

  deleteStore(divisionNumber: string, storeNumber: string): Observable<any> {
    return this.http.delete<Store>(`api/store/delete/${divisionNumber}/${storeNumber}`);
  }
}
