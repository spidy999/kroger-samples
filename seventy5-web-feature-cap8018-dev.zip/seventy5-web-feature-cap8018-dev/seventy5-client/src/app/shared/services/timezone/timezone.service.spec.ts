import { TimezoneService } from './timezone.service';
import {TestBed, inject, flush} from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('TimezoneService', () => {
  let timezoneService: TimezoneService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TimezoneService]
    });
  });

  beforeEach(() => {
    timezoneService = TestBed.inject(TimezoneService);
  });

  it('should be created', inject([TimezoneService], (service: TimezoneService) => {
    expect(service).toBeTruthy();
  }));

  it('should get all timezones', inject([TimezoneService, HttpTestingController],
    (service: TimezoneService, httpMock: HttpTestingController) => {
      service.getTimeZones()
        .subscribe(data => expect(data[0].label).toBe('America/New_York'));
      const req = httpMock.expectOne('api/timezone');
      req.flush([{'label': 'America/New_York', 'value': 'gmt+5'}]);
      httpMock.verify();
    }));

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));
});
