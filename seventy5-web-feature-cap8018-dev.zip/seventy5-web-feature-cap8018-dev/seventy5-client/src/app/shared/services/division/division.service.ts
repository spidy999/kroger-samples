import {Subject} from 'rxjs/Subject';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {Division, DivisionObject} from '@shared/domain/division';
import {map} from 'rxjs/operators';

@Injectable({providedIn: 'root'})
export class DivisionService {
  private divisionNumber: Subject<string> = new Subject<string>();

  constructor(private http: HttpClient) {}

  getIncludedDivisions(): Observable<Division[]> {
    return this.http.get<any>('api/division/included')
        .pipe(
          map(response => response),
        );
  }

  getAllDivisions(): Observable<DivisionObject[]> {
    return this.http.get<DivisionObject[]>('api/division')
      .pipe(
        map(res => res)
      );
  }

  saveDivision(division: DivisionObject): Observable<Division> {
    return this.http.post<Division>('api/division/update', division)
      .pipe(
        map(res => res)
      );
  }

  addDivision(division: DivisionObject): Observable<Division> {
    return this.http.post<Division>('api/division/insert', division)
      .pipe(
        map(res => res)
      );
  }

  deleteDivision(divisionNumber: string): Observable<any> {
    return this.http.delete<DivisionObject>('api/division/delete/' + divisionNumber)
      .pipe(
        map(res => res)
      );
  }

  doNextDivision(division: string): void {
    this.divisionNumber.next(division);
  }

  getDivisionNumber(): Observable<string> {
    return this.divisionNumber;
  }
}
