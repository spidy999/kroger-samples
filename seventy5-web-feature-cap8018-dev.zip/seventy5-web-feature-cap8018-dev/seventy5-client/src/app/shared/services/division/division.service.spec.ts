import { DivisionService } from './division.service';
import { TestBed, inject } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

describe('DivisionService', () => {
  let divisionService: DivisionService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DivisionService]
    });
  });

  beforeEach(() => {
    divisionService = TestBed.inject(DivisionService);
  });

  it('should be created', inject([DivisionService], (service: DivisionService) => {
    expect(service).toBeTruthy();
  }));
});
