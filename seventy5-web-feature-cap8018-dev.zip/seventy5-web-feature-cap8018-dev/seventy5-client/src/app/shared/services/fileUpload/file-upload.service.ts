import { Injectable } from '@angular/core';
import {BaleSensor} from '@features/admin/models/BaleSensor';
const POINTTWOFIVE = .25;
const POINTFIVE = .5;
const FIVE = 5;
const TEN = 10;
const QUARTER = 25;
const HALF = 50;
const HALFAQUARTER = 75;
const PERCENT = 100;

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  constructor() { }

  public static calculateBarSpeed(arr): number {
    let count = 0;
    const value = arr.length;
    if (value < HALF) {
      count = PERCENT;
    } else if (value < PERCENT) {
      count = HALFAQUARTER;
    } else if (value < PERCENT * FIVE) {
      count = QUARTER;
    } else if (value < PERCENT * TEN) {
      count = QUARTER - TEN;
    } else if (value < PERCENT * QUARTER) {
      count = TEN;
    } else if (value < PERCENT * HALF) {
      count = FIVE;
    } else if (value < PERCENT * HALFAQUARTER) {
      count = 3;
    } else if (value > PERCENT * PERCENT && value <= PERCENT * PERCENT * FIVE) {
      count = 2;
    } else if (value > PERCENT * PERCENT * FIVE && value <= PERCENT * PERCENT * 2) {
      count = 1;
    } else if (value > PERCENT * PERCENT * 2 && value <= PERCENT * PERCENT * FIVE) {
      count = POINTFIVE;
    } else if (value > PERCENT * PERCENT * FIVE) {
      count = POINTTWOFIVE;
    }
    return count;
  }

  public static setBarStyle(count: number): any {
    let color = '';
    if (count <= QUARTER) {
      color = 'redBar';
    } else if (count > QUARTER && count <= HALF) {
      color = 'orangeBar';
    } else if (count > HALF && count <= HALFAQUARTER) {
      color = 'yellowBar';
    } else if (count > HALFAQUARTER) {
      color = 'greenBar';
    }
    return color;
  }

  static isCSVFile(file: any) {
    return file.name.endsWith('.csv');
  }

  static getHeaderArray(csvRecordsArr: any) {
    const headers = csvRecordsArr[0].split(',');
    const headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  static getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    const dataArr = [];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      const data = csvRecordsArray[i].split(',');
      if (data.length === headerLength) {
        const csvRecord: BaleSensor = new BaleSensor();
        csvRecord.divisionNo = data[0].trim();
        csvRecord.storeNo = data[1].trim();
        csvRecord.sensorId = data[2].trim();
        csvRecord.sensorEventStartTs = data[3].trim();
        csvRecord.index = data[4].trim();
        csvRecord.baleScanned = data[5].trim();
        csvRecord.createdDate = data[6].trim();
        dataArr.push(csvRecord);
      }
    }
    return dataArr;
  }

  static checkHeaders(headers) {
    const sortedHeaders: String[] = [];
    headers.forEach(header => sortedHeaders.push(header));
    const defaultHeaders = ['BIL_DIV_NO', 'STO_NO', 'SENSOR_ID', 'SENSOR_EVENT_START_TS', 'index', 'Baled_Scanned', 'Created_Date'];
    return headers && JSON.stringify(sortedHeaders) === JSON.stringify(defaultHeaders);
  }

}
