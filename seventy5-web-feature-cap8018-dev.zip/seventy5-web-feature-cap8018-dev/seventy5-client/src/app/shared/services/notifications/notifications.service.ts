import {Subject} from 'rxjs/Subject';
import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {NotificationSeverity, ToastDetails, Notification} from '@shared/models/Notification';

@Injectable({providedIn: 'root'})
export class NotificationsService {

  public toastMessage: any;
  public notificationsSource: BehaviorSubject<Notification> = new BehaviorSubject<Notification>(null);
  public emitMessage  = new Subject<ToastDetails>();

  constructor() { }

  registerToastMessage(toast: any) {
    if (!this.toastMessage && toast) {
      this.toastMessage = toast;
    }
  }

  notify(severity: string, heading: string, message: string) {
    const notification: Notification = {
      heading: heading,
      message: message,
      severity: severity
    };
    this.addNotification(notification);
  }

  showSuccess(title: string, detail: string) {
    this.notify(NotificationSeverity.SUCCESS, title, detail);
  }

  showError(title: string, detail: string) {
    this.notify(NotificationSeverity.ERROR, title, detail);
  }

  showInfo(title: string, detail: string) {
    this.notify(NotificationSeverity.INFO, title, detail);
  }

  showWarning(title: string, detail: string) {
    this.notify(NotificationSeverity.WARN, title, detail);
  }

  addNotification(notification: Notification): void {
    if (notification && this.toastMessage) {

      const toast = this.toastMessage.createToast({
        message: notification.message || '',
        heading: notification.heading || '',
        kind: notification.severity || NotificationSeverity.INFO
      });
      this.notificationsSource.next(toast);
    }
  }
}
