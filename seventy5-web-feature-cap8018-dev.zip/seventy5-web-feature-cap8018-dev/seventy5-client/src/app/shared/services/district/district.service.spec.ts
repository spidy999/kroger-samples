import { DistrictService } from './district.service';
import { TestBed, inject } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

describe('DistrictService', () => {
  let districtService: DistrictService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DistrictService]
    });
  });

  beforeEach(() => {
    districtService = TestBed.inject(DistrictService);
  });

  it('should be created', inject([DistrictService], (service: DistrictService) => {
    expect(service).toBeTruthy();
  }));
});
