import {map} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {District} from '@app/shared/domain/district';

@Injectable({providedIn: 'root'})
export class DistrictService {

  constructor(private http: HttpClient) {}

  getDistrictsForDivision(divisionNumber: string, supplyFlag: boolean): Observable<District[]> {
    if (supplyFlag) {
      return this.http.get<any>('api/findAllSupplyDistrictsForDivision/' + divisionNumber)
        .pipe(
          map(response => response),
        );
    } else {
      return this.http.get<any>('api/findAllByDivision/' + divisionNumber)
        .pipe(
          map(response => response),
        );
    }
  }
}
