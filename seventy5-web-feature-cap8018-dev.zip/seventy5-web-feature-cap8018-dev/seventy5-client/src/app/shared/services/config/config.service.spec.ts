import { ConfigService } from './config.service';
import { TestBed, inject } from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
const STORE = 410;

describe('ConfigService', () => {
  let configService: ConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ConfigService]
    });
  });

  beforeEach(() => {
    configService = TestBed.inject(ConfigService);
  });

  it('should be created', inject([ConfigService], (service: ConfigService) => {
    expect(service).toBeTruthy();
  }));

  it('should load Constants From Server', inject([ConfigService, HttpTestingController],
    (service: ConfigService, httpMock: HttpTestingController) => {
      service.loadConstantsFromServer().subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/config/constantsForClient`);
      expect(req.request.method).toEqual('GET');
      req.flush({data: [{storeId: STORE}]});
      httpMock.verify();
  }));
});
