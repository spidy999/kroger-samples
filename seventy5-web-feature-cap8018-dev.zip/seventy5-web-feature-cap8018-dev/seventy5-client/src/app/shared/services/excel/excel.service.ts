import {saveAs} from 'file-saver';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {timeout} from 'rxjs/operators/timeout';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ToastDetails} from '@shared/models/Notification';
const TIMEOUT = 120000; // Time out for 2 minutes.

@Injectable({
  providedIn: 'root'
})
export class ExcelService {

  constructor(private http: HttpClient) { }

  public static createExcelFile(response) {
    // Determine what to name the file on the file system.
    let fileName = 'downloaded-file.tmp';
    if (response && response.headers && response.headers.get('Content-Disposition')) {
      try {
        const contentDispositionHeader: string = response.headers.get('Content-Disposition');
        const parts: string[] = contentDispositionHeader.split(';');
        fileName = parts[1].split('=')[1];
      } catch (e) {
        if (console) {
          console.error('Error parsing Content-Disposition header. %s', e);
        }
      }
    }

    // Set the MIME type if we have one.
    const blobOptions = {type: 'application.vnd.ms-excel'};

    // Create a Blob and save it to the file system.
    const blob = new Blob([response.body], blobOptions);
    saveAs(blob, fileName);
  }

  public static displayToastMessage(type: string, customMessage?: any): ToastDetails {
    let toastDetails: ToastDetails;
    if (type === 'success') {
      toastDetails = {
        title: 'Success',
        message: 'Excel report downloaded successfully',
        toastType: 'success'
      };
    } else if (customMessage != null ) {
      toastDetails = {
        title: 'Failure',
        message: `Your request couldn't be processed right now.
        please try back later.`,
        toastType: 'error'
      };
    } else {
      toastDetails = {
        title: 'Failure',
        message: 'Something went wrong, please try back later.',
        toastType: 'error'
      };
    }
    return toastDetails;
  }

  /**
   * Downloads a file from a REST controller by POSTing a JSON object to a controller.
   *
   * The response should contain a 'Content-Disposition' header containing the name of the file to
   * download.  If this is missing, 'downloaded-file.tmp' will be used.
   *
   * If you know the MIME type of the file to be downloaded make sure to specify it, otherwise you
   * can leave it null and hope the browser can detect it.
   *
   * @param dataToPost
   * @param url
   */

  downloadExcelReport(dataToPost, url): Observable<any> {
    const httpHeaders = new HttpHeaders({
      'Content-Type' : 'application/json',
      'Cache-Control': 'no-cache',
      'Accept': 'application/vnd.ms-excel'
    });
    const options = {headers: httpHeaders};
    return this.http.post(url, dataToPost, {...options, observe: 'response', responseType: 'blob'} )
      .pipe(timeout(TIMEOUT));
  }
}
