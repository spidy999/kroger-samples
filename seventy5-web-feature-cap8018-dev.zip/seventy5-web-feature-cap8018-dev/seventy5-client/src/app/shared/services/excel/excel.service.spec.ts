import { ExcelService } from './excel.service';
import { TestBed } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

describe('ExcelService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule]
  }));

  it('should be created', () => {
    const service: ExcelService = TestBed.inject(ExcelService);
    expect(service).toBeTruthy();
  });
});
