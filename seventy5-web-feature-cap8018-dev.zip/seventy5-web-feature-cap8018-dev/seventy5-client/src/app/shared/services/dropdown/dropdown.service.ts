import {map} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class DropdownService {

  constructor(private http: HttpClient) {}

  // Load enum values from the server to populate select (i.e. drop-down) controls.
  loadByName(enumName): Observable<any> {
    return this.http.get<any>('api/enumeration/' + enumName)
      .pipe(map(response => response));
  }

}
