import { DropdownService } from './dropdown.service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { TestBed, inject } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

describe('DropdownService', () => {
  let dropdownService: DropdownService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DropdownService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  });

  beforeEach(() => {
    dropdownService = TestBed.inject(DropdownService);
  });

  it('should be created', inject([DropdownService], (service: DropdownService) => {
    expect(service).toBeTruthy();
  }));
});
