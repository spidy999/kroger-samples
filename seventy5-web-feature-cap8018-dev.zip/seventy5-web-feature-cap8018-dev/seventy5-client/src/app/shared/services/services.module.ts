import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RoleGuardService} from '@app/role-guard.service';
import {UtilService} from '@shared/services/util/util.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {ConfigService} from '@shared/services/config/config.service';
import {DateService} from '@shared/services/date/date.service';
import {DistrictService} from '@shared/services/district/district.service';
import {DivisionService} from '@shared/services/division/division.service';
import {DropdownService} from '@shared/services/dropdown/dropdown.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {FileUploadService} from '@shared/services/fileUpload/file-upload.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {StoreService} from '@shared/services/store/store.service';
import {TimezoneService} from '@shared/services/timezone/timezone.service';
import {UserService} from '@shared/services/user/user.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';

@NgModule({
  imports: [
    CommonModule
  ],
  providers: [
    UtilService,
    ConfigService,
    RoleGuardService,
    DateService,
    DistrictService,
    DivisionService,
    FiscalDateService,
    DropdownService,
    ExcelService,
    FacilityService,
    FileUploadService,
    ModalService,
    NotificationsService,
    StoreService,
    TimezoneService,
    UserService,
    UtilService,
    ValidatorsService
  ],
  declarations: [],
  exports: []
})
export class ServicesModule { }
