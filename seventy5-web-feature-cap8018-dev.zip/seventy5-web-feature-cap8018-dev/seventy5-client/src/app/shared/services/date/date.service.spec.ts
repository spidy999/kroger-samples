import * as moment from 'moment';
import {FormBuilder} from '@angular/forms';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {inject, TestBed} from '@angular/core/testing';
import {DateService} from './date.service';
import {UserService} from '../user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';

const HOURS = 24;
const TRUNC_SECONDS = 19;
const TRUNC_MIN_SEC = 10;

describe('DateService', () => {

  let dateService: DateService;
  let userService: UserService;
  let today;
  let yesterday;
  let startDateOfWeek;
  let endDateOfWeek;
  let startOfYear;
  let previousYear;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [KrogerNgAuthModule],
      providers: [DateService, FormBuilder, UserService, FacilityService]
    });
  });

  beforeEach(() => {
    dateService = TestBed.inject(DateService);
    userService = TestBed.inject(UserService);
    today = moment().format('YYYY-MM-DD hh:mm A');
    yesterday = moment().subtract(HOURS, 'hours').format('YYYY-MM-DD hh:mm A');
    startDateOfWeek = moment().startOf('week').toISOString();
    endDateOfWeek = moment().endOf('week').toISOString();
    startOfYear = moment().startOf('year');
    previousYear = moment().subtract('1', 'year').toISOString();
  });

  it('should be created', inject([DateService], (service: DateService) => {
    expect(service).toBeTruthy();
  }));

  it('should get previous year', () =>   {
    expect(DateService.getPreviousYear().slice(0, TRUNC_SECONDS)).toEqual(previousYear.slice(0, TRUNC_SECONDS));
  });

  it('should get date for request', () =>   {
    const expectedDate = '2021-01-03 12:00 PM';
    const actualDate = 'Sun Jan 03 2021 12:00:00';
    expect(DateService.getDateForRequest(actualDate)).toBe(expectedDate);
  });

  it('should check selected Dates', () =>   {
    const startDate = new Date('2019/06/18');
    const endDate = new Date('2019/08/21');
    expect(DateService.checkSelectedDate(startDate, endDate)).
    toBe(true);

    expect(DateService.checkSelectedDate(startDate, null)).
    toBe(true);

    expect(DateService.checkSelectedDate(null, null)).
    toBe(false);
  });

  it('should convert to Date', () =>   {
    const dateString = '2019-08-02';
    const expectedDate = new Date('2019/08/02');
    expect(DateService.toDate(dateString)).toEqual(expectedDate);
  });

  it('should get last 24 hours', () =>   {
    const expectedDate = { startDate: yesterday, endDate: today};
    expect(DateService.getLast24hours()).toEqual(expectedDate);
  });

  it('should get start date of the Year', () =>   {
    expect(DateService.getStartOfYear()).toEqual(startOfYear);
  });

  it('should get yesterday date', () =>   {
    expect(DateService.getYesterdayDate().slice(0, TRUNC_MIN_SEC)).toBeLessThan(today.slice(0, TRUNC_MIN_SEC));
  });

  it('should get start date of week', () =>   {
    expect(DateService.getStartDayOfWeek()).toEqual(startDateOfWeek);
  });

  it('should get end date of week', () =>   {
    expect(DateService.getEndDayOfWeek()).toEqual(endDateOfWeek);
  });

  it('should get name of the day', () =>   {
    const givenDate = '2020-03-24';
    const expected = 'TUE';
    expect(DateService.getDayName(givenDate)).toEqual(expected);
  });
});
