
/* tslint:disable:no-magic-numbers */
import * as moment from 'moment';
import {Injectable} from '@angular/core';

@Injectable({providedIn: 'root'})
export class FiscalDateService {

  static isDate(dateObj ) {
    return !((typeof (dateObj) !== 'object') || isNaN(dateObj.getTime()));
  }

  static getDateForEnterpriseDisplay(date): string {
    return 'WEEK OF ' + moment(date).format('MM/DD');
  }

  getKrogerWeek(dateObj) {
    dateObj = this.getDateObj(dateObj);
    return `Period ${this.getPrd(dateObj)} - Week ${this.getWoy(dateObj)}`;
  }

  getKrogerQuarterPeriodWeek(date) {
    date = this.getDateObj(date);
    return `Q${this.getQtr(date)} - P${this.getPrd(date)} - W${this.getWop(date)}`;
  }

  getFiscalInfo( dateObj ) {
    dateObj = this.getDateObj( dateObj );

    return {
      'Date' : dateObj.toDateString()	// full date string
      , 'Fiscal Year' : this.getBoy( dateObj ).getFullYear()	// fiscal year
      , 'Quarter' : this.getQtr( dateObj )
      , 'Week of Quarter' : this.getWoq( dateObj )
      , 'Day of Quarter' : this.getDoq( dateObj )
      , 'Period' : this.getPrd( dateObj )
      , 'Week of Period' : this.getWop( dateObj )
      , 'Day of Period' : this.getDop( dateObj )
      , 'Week of Year' : this.getWoy( dateObj )
      , 'Day of Week' : this.getDow( dateObj )
      , 'Day of Year' : this.getDoy( dateObj )
    };
  }


  // get the fiscal beginning of year (boy) for a given date
  // the first day/week of the fiscal year always falls on a Sunday between 1/29 and 2/4
  getBoy( dateObj ) {
    dateObj = this.getDateObj( dateObj );
    const yr = dateObj.getFullYear()
      , boy = new Date();

    for ( let y = yr; y > yr - 2; y-- ) {	// check the year of the passed in date and the previous year
      const checkDate = new Date( '1/29/' + y );	// start with 1/29
      for ( let i = 0; i < 7; i++ ) {
        if ( checkDate.getDay() === 0 ) {
          boy.setTime( checkDate.getTime() );
          // how does the passed in date compare to the boy?
          if ( this.dateDiff('d', dateObj, boy) <= 0 ) {
            return boy;
          }
        }
        checkDate.setDate( checkDate.getDate() + 1 );	// increment the date to check
      }
    }
  }


  // get beginning of week based (bow) on date
  getBow( dateObj ) {
    dateObj = this.getDateObj( dateObj );

    // get the beginning of week (bow) by getting the day of week
    dateObj.setDate( parseInt(dateObj.getDate(), 10) - dateObj.getDay() ); 	// dateObj.getDay() returns 0-6

    return dateObj;
  }


  // get day of year by subtracting the date from the boy
  getDoy( dateObj ) {
    dateObj = this.getDateObj( dateObj );
    const boy = this.getBoy( dateObj );

    return this.dateDiff( 'd', boy, dateObj ) + 1;
  }


  // get day of week
  getDow( dateObj ) {
    dateObj = this.getDateObj( dateObj );
    return dateObj.getDay() + 1;
  }


  // get day of period
  getDop( dateObj ) {
    dateObj = this.getDateObj( dateObj );
    const wop = this.getWop( dateObj );
    const dow = this.getDow( dateObj );

    return 7 * wop - ( 7 - dow );
  }

  // get day of quarter
  getDoq( dateObj ) {
    dateObj = this.getDateObj( dateObj );
    const woq = this.getWoq( dateObj );
    const dow = this.getDow( dateObj );

    return 7 * woq - ( 7 - dow );
  }

  // get period number based on the week
  getPrd( dateObj ) {
    return Math.min( Math.ceil( this.getWoy( dateObj ) / 4 ), 13 );
  }

  // get quarter of year based on the week
  getQtr( dateObj ) {
    const woy = this.getWoy( dateObj );
    if ( woy <= 16 ) {
      return 1;
    }
    if ( woy <= 28 ) {
      return 2;
    }
    if ( woy <= 40 ) {
      return 3;
    }
    if ( woy <= 53 ) {
      return 4;
    }
  }

  getWoq( dateObj ) {
    const woy = this.getWoy( dateObj );
    if ( woy <= 16 ) {
      return woy;
    }
    if ( woy <= 28 ) {
      return woy - 16;
    }
    if ( woy <= 40 ) {
      return woy - 28;
    }
    if ( woy <= 53 ) {
      return woy - 40;
    }
    /*if( woy === 53 ) {
              return 16;	// not sure why this jumps to 16, but this is how it is in EDW
          }*/
  }

  // get week of year based on date
  getWoy ( dateObj ) {
    return 1 + this.dateDiff( 'w', this.getBoy( dateObj ), this.getBow( dateObj ) );
  }


  // get week of period
  getWop( dateObj ) {
    let wop = 0;
    const woy = this.getWoy( dateObj );
    switch ( woy ) {
      case 53:
        wop = 5;
        break;
      default:
        wop = ( ( woy  - 1 ) % 4 ) + 1;
        break;
    }

    return wop;
  }


  // get is beginning of quarter
  getIsBoq( dateObj ) {
    switch ( this.getWoy( dateObj ) ) {
      case 1:
      case 17:
      case 29:
      case 41:
        return true;
      default:
        return false;
    }
  }

  getDateFromFiscal( strFiscal ) {
    let retDate
      , w = 0
      , yr = strFiscal.match(/\bF?Y\s?(\d\d\d\d)\b/i); /* look for 4 digit year */

    if ( yr !== null ) {
      yr = yr[1];
    } else {
      throw new Error('Not a fiscal date'); /* no year was passed, so throw an error */
    }

    /* use the last possible 1st date of fiscal year */
    retDate = this.getBoy('2/4/' + yr );

    /* check if a quarter is passed in, if it is, then convert and add weeks */
    let qtr = strFiscal.match(/\bF?Q\s?0?([1-4])\b/i); // 1-4
    if ( qtr !== null ) {
      qtr = parseInt(qtr[1], 10);
      switch ( qtr ) {
        case 1:
          w = 0;
          break;
        case 2:
          w = 16;
          break;
        case 3:
          w = 28;
          break;
        case 4:
          w = 40;
          break;
      }
    }

    /* check if a period is passed in, then convert and add weeks	*/
    let prd = strFiscal.match(/\bF?P\s?([0-1]?\d)\b/i); // 1-13
    if ( prd !== null ) {
      prd = parseInt(prd[1], 10);
      if ( prd >= 1 && prd <= 13 ) {
        w = ( prd - 1 ) * 4;
      }
    }

    /* if the period and quarter are null, assume the week is week of year,
               otherwise, add the number of weeks to the existing w value
          */
    let wk = strFiscal.match(/\bF?W\s?([0-5]?\d)\b/i); // 0-53
    if ( wk !== null ) {
      wk = parseInt( wk[1], 10);
      if ( prd === null && qtr === null ) {
        if ( wk >= 1 && wk <= 53 ) {
          w = wk - 1;
        }
      } else {
        /* assumes week of period, and a period can have up to 5 weeks */
        if ( prd !== null ) {
          if ( wk >= 1 && wk <= 5 ) {
            w = w + wk - 1;
          }
        } else {
          /* at this point, qtr is not null, assume week of quarter, and can have up to 16 weeks */
          if ( wk >= 1 && wk <= 16 ) {
            w = w + wk - 1;
          }
        }
      }
    }

    retDate = this.dateAdd( retDate, 7 * w );

    return retDate;
  }

  // takes a date string or date object and returns the date object
  // if the string is empty, then return a new Date
  getDateObj( dateObj ) {
    let dt;
    if ( typeof( dateObj ) === 'string' || dateObj === null ) {
      if ( dateObj !== '' ) {
        dt = new Date( dateObj );
      } else {
        dt = new Date();
      }
    } else {
      try {
        dt = new Date( dateObj.getTime() );	// IE8 throws error here
      } catch ( e ) {
        dt = new Date();
      }
    }

    if ( ! FiscalDateService.isDate( dt ) ) {
      try {
        /* so far, dateObj is not a date, check if it is a fiscal type date, check if it is a fiscal type date */
        dt = this.getDateFromFiscal( dateObj );
      } catch ( e ) {
        dt = new Date();
      }
    }
    // strip out the time portion
    dt.setHours(0, 0, 0, 0);

    return dt;
  }


  // returns the difference of date2-date1 in dateParts
  dateDiff(datePart, date1, date2) {
    let divisor;

    date1 = this.getDateObj( date1 );
    date2 = this.getDateObj( date2 );

    switch (datePart) {
      case 'ms':	// milliseconds
        divisor = 1;
        break;
      case 's':	// seconds
        divisor = 1000;
        break;
      case 'n':	// minutes
        divisor = 1000 * 60;
        break;
      case 'h':	// hours
        divisor = 1000 * 60 * 60;
        break;
      case 'd':	// day
        divisor = 1000 * 60 * 60 * 24;
        break;
      case 'w':	// week
        divisor = 1000 * 60 * 60 * 24 * 7;
        break;
    }
    return Math.round( ( date2 - date1 ) / divisor );
  }

  // adds a # of days to the passed in date
  dateAdd( dateObj, days ) {
    const dt = this.getDateObj( dateObj );
    dt.setDate( parseInt(dt.getDate(), 10) + days );
    return dt;
  }

}
