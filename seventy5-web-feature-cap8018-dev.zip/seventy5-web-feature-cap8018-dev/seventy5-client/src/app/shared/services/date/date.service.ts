import {Moment} from 'moment';
import * as moment from 'moment';
import {Subject} from 'rxjs/Subject';
import {Injectable} from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {Dates} from '@shared/models/dateRange';
import {DateRange, ReportDates} from '@shared/models/reportData';

const YEAR_LENGTH = 4;
const DAY_LENGTH = 2;
const MONTH_LENGTH = 2;
const YEAR_START_POS = 0;
const MONTH_START_POS = 5;
const DAY_START_POS = 8;
const HOURS = 24;

@Injectable({providedIn: 'root'})
export class DateService {

  private calendar: Subject<Dates> = new Subject<Dates>();
  constructor() {}

  static getDateForRequest(date, formatter?: string): string {
      return moment(new Date(date)).format( 'YYYY-MM-DD hh:mm A');
  }

  static getLast24hours(): DateRange {
    const now = moment();
    const today = moment().format('YYYY-MM-DD hh:mm A');
    const yesterday = now.subtract(HOURS, 'hours').format('YYYY-MM-DD hh:mm A');
    return {startDate: yesterday, endDate: today};
  }

  static getStartOfYear() {
    const date = moment();
    return date.startOf('year');
  }

  static getPreviousYear() {
    const now = moment();
    return now.subtract('1', 'year').toISOString();
  }

  static getKrogerFiscalYear(date) {
    return moment(new Date(date)).add(1, 'months').startOf('month')
      .add(1, 'weeks').startOf('week').toISOString();
  }

  static getCustomDate(day?, weeks?, month?, year?) {
    const customDate = DateService.getStartOfYear();
    return  customDate.add(month, 'months').startOf('month')
      .add(weeks, 'weeks').startOf('week').toISOString();
  }

  static getIsoString(date, formatter?: string) {
    if (formatter) {
      return moment(date, formatter).toISOString();
    } else {
      return moment(date).toISOString();
    }
  }

  /* date parameter should be ISO string */
  static getMonthDayYearFormat(date): string {
    return moment(new Date(date)).format('MM/DD/YYYY');
  }

  static getUTCDateFormat(date): string {
    return moment(new Date(date)).utc().format('MM/DD/YYYY');
  }

  static formatISODateStringForBOLDisplay(date): string {
    const year = date.substr(YEAR_START_POS, YEAR_LENGTH);
    const month = date.substr(MONTH_START_POS, MONTH_LENGTH);
    const day = date.substr(DAY_START_POS, DAY_LENGTH);

    return `${month}/${day}/${year}`;
  }

  static checkSelectedDate(selectedDate, compareDate) {
    if (selectedDate && compareDate) {
      return selectedDate <= compareDate;
    } else if (selectedDate) {
      return true;
    }
    return false;
  }

  static toDate(dateStr) {
    const [year, month, day] = dateStr.split('-');
    return new Date(year, month - 1, day);
  }

  static getYesterdayDate() {
    const now = moment();
    return now.subtract('1', 'days').startOf('day').toISOString();
  }

  static getStartDayOfWeek() {
    const now = moment();
    return now.startOf('week').toISOString();
  }

  static getEndDayOfWeek() {
    const now = moment();
    return now.endOf('week').toISOString();
  }

  static getDayName(date: string) {
    return moment(date).format('dddd').toUpperCase().substring(0, 3);
  }

  static getListOfDatesBetweenRange(startDate, endDate): Moment[] {
    const dates: Moment[] = [];
    const momentStart = moment(startDate);
    const momentEnd = moment(endDate);
    if (startDate && endDate && momentStart.isSameOrBefore(momentEnd)) {
      while (momentStart.isSameOrBefore(momentEnd)) {
        dates.push(moment(momentStart));
        momentStart.add(1, 'd');
      }
    }
    return dates;
  }

  static getTodayDate() {
    const now = moment();
    return now.startOf('day').toISOString();
  }

  static calculateReportDates(): ReportDates {
    /* For the total Bale Count and Average Bale counts*/

    const today = DateService.getTodayDate();
    const yesterday = DateService.getYesterdayDate();
    const startDayOfWeek = DateService.getStartDayOfWeek();
    const endDayOfWeek = DateService.getEndDayOfWeek();
    const previousWeek: DateRange = {startDate: yesterday, endDate: yesterday};
    const currentWeek: DateRange = {startDate: startDayOfWeek, endDate: today};

    /*  For the trendLine Bale counts.
        if current date > krogerFiscal date (feb 1st day of 1st week)
            =>  show the date range from krogerFiscal date to current date first day of that week.
            =>  send the date range from krogerFiscal date to current date to backend.
        if current date < krogerFiscal date (feb 1st day of 1st week)
            =>  show the date range from previous year kroger Fiscal date to current date first day of that week.
            =>  send the date range from previous year kroger Fiscal date to current date to backend. */

    const krogerFiscalDate = DateService.getCustomDate(null, 1, 1, null);

    let trendLineDates: DateRange;
    if (krogerFiscalDate > today) {
      const previousYear = DateService.getPreviousYear();
      const KrogerStartDate = DateService.getKrogerFiscalYear(previousYear);
      trendLineDates = { startDate: KrogerStartDate, endDate: today};
    } else {
      trendLineDates = { startDate: krogerFiscalDate, endDate: today};
    }
    const displayStartDate = DateService.getMonthDayYearFormat(trendLineDates.startDate);
    const displayEndDate = DateService.getMonthDayYearFormat(startDayOfWeek);
    const displayDates: DateRange = {startDate: displayStartDate , endDate: displayEndDate};

    return {
      today: DateService.getMonthDayYearFormat(today),
      yesterday: DateService.getMonthDayYearFormat(yesterday),
      startDayOfWeek: DateService.getMonthDayYearFormat(startDayOfWeek),
      endDayOfWeek: DateService.getMonthDayYearFormat(endDayOfWeek),
      previousWeek: previousWeek,
      currentWeek: currentWeek,
      displayDates: displayDates,
      trendLineDates: trendLineDates
    };
  }

  doNextCalendar(calendar: Dates): void {
    this.calendar.next(calendar);
  }

  getCalendar(): Observable<Dates> {
    return this.calendar;
  }

}
