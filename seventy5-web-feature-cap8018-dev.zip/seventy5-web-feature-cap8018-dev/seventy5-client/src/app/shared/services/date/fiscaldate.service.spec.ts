import {FormBuilder} from '@angular/forms';
import {UserService} from '../user/user.service';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { TestBed, inject } from '@angular/core/testing';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {FacilityService} from '@shared/services/facility/facility.service';

describe('FiscalDateService', () => {

  let userService: UserService;
  let fiscalDateService: FiscalDateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [KrogerNgAuthModule],
      providers: [FiscalDateService, FormBuilder, UserService, FacilityService]
    });
  });

  beforeEach(() => {
    fiscalDateService = TestBed.inject(FiscalDateService);
    userService = TestBed.inject(UserService);
  });

  it('should be created', inject([FiscalDateService], (service: FiscalDateService) => {
    expect(service).toBeTruthy();
  }));

  it('should get Kroger Period Week 2018/07/22', () =>   {
    const actualDate = new Date('2018/07/22');
    const expectedResult = 'Period 7 - Week 25';
    expect(fiscalDateService.getKrogerWeek(actualDate)).toEqual(expectedResult);
  });

  it('should get Kroger Period Week 2019/04/22', () =>   {
    const actualDate = new Date('2019/04/22');
    const expectedResult = 'Period 3 - Week 12';
    expect(fiscalDateService.getKrogerWeek(actualDate)).toEqual(expectedResult);
  });
});
