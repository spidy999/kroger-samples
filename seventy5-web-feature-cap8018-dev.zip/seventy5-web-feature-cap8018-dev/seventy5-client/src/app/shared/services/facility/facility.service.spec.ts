import { FacilityService } from './facility.service';
import { TestBed, inject } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

describe('FacilityService', () => {
  let facilityService: FacilityService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [FacilityService]
    });
  });

  beforeEach(() => {
    facilityService = TestBed.inject(FacilityService);
  });

  it('should be created', inject([FacilityService], (service: FacilityService) => {
    expect(service).toBeTruthy();
  }));
});
