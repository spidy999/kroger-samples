import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {map, share} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {of} from 'rxjs/internal/observable/of';
import {FacilityData} from '@app/shared/domain/facilityData';

@Injectable({providedIn: 'root'})
export class FacilityService {

  private facilityList: {[key: string]: FacilityData} = {};

  constructor(private http: HttpClient) {}

  getAllFacilities(): Observable<FacilityData[]> {
    return this.http.get<FacilityData[]>('api/facility').pipe(share());
  }

  getFacilityDataById(facilityId): Observable<FacilityData> {
    if (this.facilityList[facilityId]) {
      return of(this.facilityList[facilityId]);
    }
    return this.http.get<FacilityData>('api/facility/' + facilityId)
      .pipe(
        map(response => {
          this.facilityList[facilityId] = response;
          return response;
        })
      );
  }

  saveFacilityData(facilityData: FacilityData): Observable<FacilityData> {
    return this.http.post<FacilityData>('api/facility', facilityData);
  }

  addFacilityData(facilityData: FacilityData): Observable<FacilityData> {
    return this.http.post<FacilityData>('api/facility/add', facilityData);
  }

  deleteFacilityData(facilityId: number): Observable<any> {
    return this.http.delete<FacilityData>('api/facility/delete/' + facilityId);
  }

}
