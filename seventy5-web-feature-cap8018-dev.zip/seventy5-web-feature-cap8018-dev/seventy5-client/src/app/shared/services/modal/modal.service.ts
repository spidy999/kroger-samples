import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class ModalService {

  private _hasUnsavedEdits: boolean;
  private _eventType: any;
  private _displayModal: boolean;
  private _tempStore: any;

  constructor() { }

  get hasUnsavedEdits(): boolean {
    return this._hasUnsavedEdits;
  }

  set hasUnsavedEdits(value: boolean) {
    this._hasUnsavedEdits = value;
  }

  get eventType(): any {
    return this._eventType;
  }

  set eventType(value: any) {
    this._eventType = value;
  }

  get displayModal(): boolean {
    return this._displayModal;
  }

  set displayModal(value: boolean) {
    this._displayModal = value;
  }

  get tempStore(): any {
    return this._tempStore;
  }

  set tempStore(value: any) {
    this._tempStore = value;
  }

}
