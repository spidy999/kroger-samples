import { NgModule } from '@angular/core';
import {
  CheckboxModule,
  DialogModule,
  DropdownModule,
  MultiSelectModule,
  InputSwitchModule,
  InputTextModule,
  KeyFilterModule,
  MenuModule,
  PaginatorModule,
  SelectButtonModule,
  SharedModule,
  TooltipModule,
  OverlayPanelModule,
  TreeTableModule,
  PanelModule,
  SpinnerModule,
  MessageService,
  TreeModule, FileUploadModule, ChartModule
} from 'primeng';

import {MenubarModule} from 'primeng/menubar';
import { CalendarModule } from 'primeng/calendar';
import { CardModule } from 'primeng/card';
import {TableModule} from 'primeng/table';
import {MessageModule} from 'primeng/message';
import {SidebarModule} from 'primeng/sidebar';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {ButtonModule} from 'primeng/button';
import {TabMenuModule} from 'primeng/tabmenu';
import {CommonModule} from '@angular/common';
import {AccordionModule} from 'primeng/accordion';
import {TabViewModule} from 'primeng/tabview';
import {ToastModule} from 'primeng/toast';
import {ToggleButtonModule} from 'primeng/togglebutton';
import {SlideMenuModule} from 'primeng/slidemenu';
import {TieredMenuModule} from 'primeng/tieredmenu';
import {RadioButtonModule} from 'primeng/radiobutton';


@NgModule({
    imports: [
    CommonModule,
    ToastModule,
    SharedModule,
    ChartModule,
    MenuModule,
    MenubarModule,
    SlideMenuModule,
    TieredMenuModule,
    FileUploadModule,
    CheckboxModule,
    DialogModule,
    RadioButtonModule,
    CalendarModule,
    TooltipModule,
    PaginatorModule,
    ButtonModule,
    InputTextModule,
    InputSwitchModule,
    SelectButtonModule,
    TableModule,
    TreeTableModule,
    KeyFilterModule,
    MessageModule,
    SidebarModule,
    DropdownModule,
    MultiSelectModule,
    TabMenuModule,
    AutoCompleteModule,
    CardModule,
    PanelModule,
    AccordionModule,
    OverlayPanelModule,
    SpinnerModule,
    TabViewModule,
    TreeModule,
    ToggleButtonModule
  ],
  declarations: [],
  exports: [
    CommonModule,
    ToastModule,
    MenuModule,
    MenubarModule,
    SharedModule,
    ChartModule,
    CheckboxModule,
    DialogModule,
    CalendarModule,
    TooltipModule,
    PaginatorModule,
    RadioButtonModule,
    ButtonModule,
    InputTextModule,
    InputSwitchModule,
    SelectButtonModule,
    TableModule,
    TreeTableModule,
    KeyFilterModule,
    MessageModule,
    SidebarModule,
    SlideMenuModule,
    TieredMenuModule,
    FileUploadModule,
    DropdownModule,
    MultiSelectModule,
    TabMenuModule,
    AutoCompleteModule,
    CardModule,
    PanelModule,
    AccordionModule,
    OverlayPanelModule,
    SpinnerModule,
    TabViewModule,
    TreeModule,
    ToggleButtonModule
  ],
  providers: [
    MessageService
  ]
})
export class PrimengModule { }
