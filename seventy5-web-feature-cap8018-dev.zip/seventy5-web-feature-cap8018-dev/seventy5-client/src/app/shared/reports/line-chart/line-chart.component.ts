import {Router} from '@angular/router';
import {UtilService} from '@shared/services/util/util.service';
import {ChartData, ChartDetails} from '@shared/models/reportData';
import {DomSanitizer, SafeHtml} from '@angular/platform-browser';
import {Component, Input, OnChanges, ViewChild} from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.less']
})
export class LineChartComponent implements OnChanges {
  @ViewChild('chart', {static: false}) chart;
  @ViewChild('legend', {static: false}) legend;
  @Input() public customOptions = {};
  @Input() public htmlLegends = false;
  @Input() public chartOptionsName: string;
  @Input() public lineChartDetails: ChartDetails;
  public chartOptions: any;
  public title: string;
  public height: string;
  public helpText: string;
  public detailUrl: string;
  public legends: SafeHtml;
  public lineChart: ChartData;
  public chartData: ChartData;

  constructor(private router: Router,
              private util: UtilService,
              private sanitizer: DomSanitizer) { }
  ngOnChanges() {
    this.setUpChartData();
    if (this.htmlLegends) {
      const component = this;
      setTimeout(() => {
        this.legends = this.sanitizer.bypassSecurityTrustHtml(this.chart.chart.generateLegend());
        setTimeout(() => {
          $(this.legend.nativeElement).find('ul > li').on('click', function() {
            try {
              const index = $(this).index();
              $(this).toggleClass('strike');
              const lineChart = component.chart;
              const list = lineChart.data.datasets[index]._meta;
              const current = list[Object.keys(list)[0]];
              current.hidden = !current.hidden;
              lineChart.chart.update();
            } catch (e) { }
          });
        });
      });
    }
  }

  setUpChartData() {
    this.setChartOptions();
    if (this.lineChartDetails) {
      this.title = this.lineChartDetails.title;
      this.height = this.lineChartDetails.height;
      this.lineChart = this.lineChartDetails.data;
      this.helpText = this.lineChartDetails.helpText;
      this.detailUrl = this.lineChartDetails.detailUrl;
      if (this.lineChart && this.lineChart.datasets) {
        this.chartData = {
          labels: this.lineChart.labels,
          datasets: this.lineChart.datasets
        };
      } else {
        this.chartData = null;
      }
    }
  }

  gotoDetailUrl() {
    if (this.detailUrl) {
      this.router.navigateByUrl(this.detailUrl);
    }
  }

  setChartOptions() {
    if (this.chartOptionsName === 'percentChartOptions') {
      this.setPercentChartOptions();
    } else {
      this.setDefaultChartOptions();
    }
  }

  setDefaultChartOptions() {
        this.chartOptions = {
          responsive: true,
          tooltips: {
            mode: 'point',
            callbacks: {
              label: function(tooltipItem, data) {
                let label = data.datasets[tooltipItem.datasetIndex].label || '';
                let dataValue = tooltipItem.yLabel;
                if (label) {
                  label += ': ';
                }
                if (dataValue && dataValue.toString().length >= 4) {
                  dataValue = dataValue.toLocaleString('en');
                }
                label += dataValue;
                return label;
              }
            }
          },
          scales: {
            xAxes: [{ticks: {
              maxRotation: 90,
              minRotation: 45,
            }}],
            yAxes: [{
              type: 'linear',
              ticks: {
                beginAtZero: true,
                callback: function (value) {
                  if (value && value.toString().length >= 4) {
                    return value.toLocaleString('en');
                  } else {
                    return value;
                  }
                }
              }
            }
            ]
          },
          legend: {
            fontSize: 2,
            position: 'bottom',
            display: !this.htmlLegends
          }
        };
        this.chartOptions = {...this.chartOptions, ...this.customOptions};
      }

  setPercentChartOptions() {
    this.chartOptions = {
      responsive: true,
      tooltips: {
        mode: 'point',
        callbacks: {
          label: function(tooltipItem, data) {
            let label = data.datasets[tooltipItem.datasetIndex].label || '';
            const dataValue = tooltipItem.yLabel;
            if (label) {
              label += ': ';
            }
            label += dataValue + '%';
            return label;
          }
        }
      },
      scales: {
        xAxes: [{ticks: {
          maxRotation: 90,
          minRotation: 45,
        }}],
        yAxes: [{
          ticks: {
            type: 'linear',
            beginAtZero: false,
            callback: function(value) {
              return value + '%';
            }
          }
          }
        ]
      },
      legend: {
        fontSize: 10,
        position: 'bottom'
      }
    };
    this.chartOptions = {...this.chartOptions, ...this.customOptions};
  }
}
