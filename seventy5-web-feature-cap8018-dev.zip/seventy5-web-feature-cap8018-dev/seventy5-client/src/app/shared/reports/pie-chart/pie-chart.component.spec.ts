import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { PieChartComponent } from './pie-chart.component';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('PieChartComponent', () => {
  let component: PieChartComponent;
  let fixture: ComponentFixture<PieChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ PrimengModule, RouterTestingModule ],
      declarations: [ PieChartComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PieChartComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
