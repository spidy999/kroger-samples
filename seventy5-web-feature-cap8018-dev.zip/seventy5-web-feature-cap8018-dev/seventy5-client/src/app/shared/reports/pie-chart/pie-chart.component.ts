import {Router} from '@angular/router';
import {Component, Input, OnChanges} from '@angular/core';
import {ChartData, ChartDetails} from '@shared/models/reportData';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.less']
})
export class PieChartComponent implements OnChanges {
  @Input() public pieChartDetails: ChartDetails;
  public chartOptions: any;
  public title: string;
  public helpText: string;
  public detailUrl: string;
  public router: Router;
  public pieChart: ChartData;
  public chartData: ChartData;

  constructor(router: Router) {
    this.router = router;
  }

  ngOnChanges() {
    this.setUpChartData();
  }

  setUpChartData() {
    if (this.pieChartDetails) {
      this.title = this.pieChartDetails.title;
      this.helpText = this.pieChartDetails.helpText;
      this.detailUrl = this.pieChartDetails.detailUrl;
      this.pieChart = this.pieChartDetails.data;
      if (this.pieChart && this.pieChart.datasets) {
        this.chartData = {
          labels: this.pieChart.labels,
          datasets: this.pieChart.datasets
        };
      } else {
        this.chartData = null;
      }
      this.chartOptions = {
        legend: {
          position: 'bottom'
        },
      startAngle:  90,
       pieceLabel: {
          mode: 'value',
          fontSize: 20,
          position: 'outside',
          fontStyle: 'bold',
          fontColor: '#000',
          fontFamily: 'Helvetica Neue, Helvetica, Arial, sans-serif',
        }
      };
    }
  }

  gotoDetailUrl() {
    if (this.detailUrl) {
      this.router.navigateByUrl(this.detailUrl).then();
    }
  }
}
