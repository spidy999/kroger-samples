import { CommonModule } from '@angular/common';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {BarChartComponent} from '@shared/reports/bar-chart/bar-chart.component';
import {PieChartComponent} from '@shared/reports/pie-chart/pie-chart.component';
import {LineChartComponent} from '@shared/reports/line-chart/line-chart.component';
import {TableChartComponent} from '@shared/reports/table-chart/table-chart.component';
import {DisplayCardComponent} from '@shared/reports/display-card/display-card.component';

@NgModule({
  imports: [
    CommonModule,
    PrimengModule
  ],
  declarations: [
    BarChartComponent,
    PieChartComponent,
    LineChartComponent,
    TableChartComponent,
    DisplayCardComponent
  ],
  exports: [
    BarChartComponent,
    PieChartComponent,
    LineChartComponent,
    TableChartComponent,
    DisplayCardComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ReportsModule { }
