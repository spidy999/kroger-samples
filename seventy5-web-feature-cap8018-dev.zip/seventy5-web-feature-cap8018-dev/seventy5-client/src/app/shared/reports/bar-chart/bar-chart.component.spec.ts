import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { BarChartComponent } from './bar-chart.component';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {UtilService} from '@shared/services/util/util.service';
import {RouterTestingModule} from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('BarChartComponent', () => {
  let component: BarChartComponent;
  let utilService: UtilService;
  let fixture: ComponentFixture<BarChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        PrimengModule,
        RouterTestingModule
      ],
      declarations: [ BarChartComponent ],
      providers: [ UtilService ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarChartComponent);
    utilService = TestBed.inject(UtilService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
