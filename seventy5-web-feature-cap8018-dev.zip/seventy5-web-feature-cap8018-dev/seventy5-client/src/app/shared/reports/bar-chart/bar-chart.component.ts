import {Router} from '@angular/router';
import {UtilService} from '@shared/services/util/util.service';
import {ChartData, ChartDetails} from '@shared/models/reportData';
import { SafeHtml, DomSanitizer } from '@angular/platform-browser';
import {Component, Input, OnChanges, ViewChild} from '@angular/core';

declare var $: any;
const ZERO_POINT_FIVE = .005;

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.less']
})
export class BarChartComponent implements OnChanges {
  @ViewChild('chart', {static: false}) chart;
  @ViewChild('legend', {static: false}) legend;
  @Input() public htmlLegends = false;
  @Input() public chartOptionsName: string;
  @Input() public barChartDetails: ChartDetails;
  public chartOptions: any;
  public title: string;
  public height: string;
  public helpText: string;
  public detailUrl: string;
  public dummyData: number;
  public legends: SafeHtml;
  public barChart: ChartData;
  public chartData: ChartData;
  public showChartLegend: boolean;

  constructor(private router: Router,
              private util: UtilService,
              private sanitizer: DomSanitizer) {}

  ngOnChanges() {
    this.setUpChartData();
    if (this.htmlLegends) {
      const component = this;
      setTimeout(() => {
        if (this.chart && this.chart.chart && this.chart.chart.generateLegend()) {
          this.legends = this.sanitizer.bypassSecurityTrustHtml(this.chart.chart.generateLegend());
        }
        setTimeout(() => {
          if (this.legend) {
            $(this.legend.nativeElement).find('ul > li').on('click', function() {
              try {
                const index = $(this).index();
                $(this).toggleClass('strike');
                const barChart = component.chart;
                const list = barChart.data.datasets[index]._meta;
                const current = list[Object.keys(list)[0]];
                current.hidden = !current.hidden;
                barChart.chart.update();
              } catch (e) { }
            });
          }
        });
      });
    }
  }

  setUpChartData() {
    this.setChartOptions();
      if (this.barChartDetails) {
      this.title = this.barChartDetails.title;
      this.helpText = this.barChartDetails.helpText;
      this.detailUrl = this.barChartDetails.detailUrl;
      this.barChart = this.barChartDetails.data;
      this.height = this.barChartDetails.height;

      if (this.barChart && this.barChart.datasets) {
        const maxValue = Math.max(...this.barChart.datasets[0].data);
        this.dummyData = maxValue * ZERO_POINT_FIVE;
          if (this.barChart.datasets.length > 1) {
            this.barChart.datasets[1].data = this.barChart.datasets[1].data.map(data => {
              return data < this.dummyData ? this.dummyData : data;
            });
          } else {
            this.barChart.datasets[0].data = this.barChart.datasets[0].data.map(data => {
              return data < this.dummyData ? this.dummyData : data;
            });
          }
        this.chartData = {
          labels: this.barChart.labels,
          datasets: this.barChart.datasets
        };
      } else {
        this.chartData = null;
      }
    }
  }

  setChartOptions() {
    this.showChartLegend = true;
    switch (this.chartOptionsName) {
      case 'overlapChartOptions' :
        this.setOverlapChartOptions();
        break;
      case 'percentChartOptions' :
        this.setPercentChartOptions();
        break;
      case 'enterpriseChartOptions':
        this.showChartLegend = false;
        this.setEnterpriseChartOptions();
        break;
      default :
        this.setDefaultChartOptions();
    }
  }

  gotoDetailUrl() {
    if (this.detailUrl) {
      this.router.navigateByUrl(this.detailUrl);
    }
  }

  setEnterpriseChartOptions() {
    const component = this;
    this.chartOptions = {
      responsive: true,
      tooltips: {
        mode: 'point',
        callbacks: {
          label: function(tooltipItem, data) {
            let value: number;
            let label: string;
            if (component.barChart.datasets.length > 1) {
               if (tooltipItem.datasetIndex === 0 ) {
                 value = data.datasets[0].data[tooltipItem.index];
                 label = data.datasets[0].label;
               }
              if (tooltipItem.datasetIndex === 1 ) {
                value = data.datasets[1].data[tooltipItem.index];
                label = data.datasets[1].label;
              }
            } else {
              value = data.datasets[0].data[tooltipItem.index];
              label = data.datasets[0].label;
            }
            if (value === component.dummyData) {
              value = 0;
            }
            return label + ': ' + value;
          }
        }
      },
      scales: {
        xAxes: [{
          ticks: {
            fontColor: UtilService.getColorForLabels(),
            maxRotation: 90,
            minRotation: 45,
            display: true
          }}],
        yAxes: [{
          ticks: {
            min: 0,
            beginAtZero: true,
            suggestedMin: 0,
            display: true
          },
        }]
      },
      legend: {
        fontSize: 10,
        position: 'bottom',
        display: !this.htmlLegends
      }
    };
  }

  setDefaultChartOptions() {
    this.chartOptions = {
      responsive: true,
      tooltips: {
        mode: 'point'
      },
      scales: {
        xAxes: [{
          ticks: {
          maxRotation: 90,
          minRotation: 45,
        }}],
        yAxes: [{
          ticks: {
            type: 'linear',
            beginAtZero: true
          }
        }
        ]
      },
      legend: {
        fontSize: 10,
        position: 'bottom',
        display: !this.htmlLegends
      }
    };
  }

  setOverlapChartOptions() {
    this.chartOptions = {
      responsive: true,
      stacked: true,
      tooltips: {
        mode: 'point'
      },
      scales: {
        xAxes: [{
          stacked: true,
          ticks: {
            fontSize: 13,
            fontStyle: 'bold',
            fontColor: '#000',
            fontFamily: 'Helvetica Neue, Helvetica, Arial, sans-serif'
          }
        }],
        yAxes: [{
          ticks: {
            type: 'linear',
            beginAtZero: false
          },
          stacked: false
        }]
      },
      legend: {
        fontSize: 10,
        position: 'bottom'
      },
      gridLines: {
        offsetGridLines: true
      }
    };
  }

  setPercentChartOptions() {
    this.chartOptions = {
      responsive: true,
      tooltips: {
        mode: 'point'
      },
      scales: {
        yAxes: [{
          id: 'left-y-axis',
          ticks: {
            type: 'linear',
            beginAtZero: false
          }
        },
          {
            id: 'right-y-axis',
            position: 'right',
            type: 'linear',
            ticks: {
              stepSize: 10,
              max: 110,
              callback: function(value) {
                return value + '%';
              }
            }
          }
        ]
      },
      legend: {
        fontSize: 10,
        position: 'bottom'
      }
    };
  }

}
