import {Paginator} from 'primeng';
import {Router} from '@angular/router';
import {UtilService} from '@shared/services/util/util.service';
import {ChartData, ChartDetails, Footer} from '@shared/models/reportData';
import {Component, Input, OnChanges, ViewChild} from '@angular/core';
const ROWS_PER_PAGE_LIMIT = 15;

@Component({
  selector: 'app-table-chart',
  templateUrl: './table-chart.component.html',
  styleUrls: ['./table-chart.component.less']
})
export class TableChartComponent implements OnChanges {
  @ViewChild('pageList', {static: false}) paginator: Paginator;
  public tableChart: any;
  public columnData: any;
  public limit: number;
  public title: string;
  public dataKey: string;
  public helpText: string;
  public detailUrl: string;
  public footer: Footer;
  public chartData: ChartData;
  @Input() public tableChartDetails: ChartDetails;

  constructor(private router: Router,
              public util: UtilService) { }

  ngOnChanges() {
    this.setUpTableData();
  }

  setUpTableData() {
    if (this.tableChartDetails) {
      this.title = this.tableChartDetails.title;
      this.helpText = this.tableChartDetails.helpText;
      this.tableChart = this.tableChartDetails.data;
      this.detailUrl = this.tableChartDetails.detailUrl;
      this.columnData = this.tableChartDetails.columns;
      this.dataKey = this.tableChartDetails.dataKey;
      this.footer = this.tableChartDetails.footer;
      this.limit = this.tableChartDetails.limit || ROWS_PER_PAGE_LIMIT;
      if (this.tableChart && this.tableChart.length > 0) {
        if (this.paginator) {
          this.paginator.first = 0;
        }
        this.chartData = this.tableChart;
      } else {
        this.chartData = null;
      }
    }
  }

  gotoDetailUrl() {
    if (this.detailUrl) {
      this.router.navigateByUrl(this.detailUrl);
    }
  }

  onSelectedRow(event) {
    if (event && event.data && event.originalEvent && event.originalEvent.isTrusted) {
      this.viewStore(event.data.store);
    }
  }
  // TODO: Needs work for Deep dive into table Data.
  viewStore(data) {
    console.log(data);
  }

}
