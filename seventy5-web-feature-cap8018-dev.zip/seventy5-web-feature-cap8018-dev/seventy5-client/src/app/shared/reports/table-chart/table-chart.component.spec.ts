import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import { TableChartComponent } from './table-chart.component';
import {RouterTestingModule} from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

describe('TableChartComponent', () => {
  let component: TableChartComponent;
  let fixture: ComponentFixture<TableChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ PrimengModule, RouterTestingModule ],
      declarations: [ TableChartComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableChartComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
