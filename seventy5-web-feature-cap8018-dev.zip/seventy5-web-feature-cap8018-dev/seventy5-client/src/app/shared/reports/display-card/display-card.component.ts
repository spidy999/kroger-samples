import {Router} from '@angular/router';
import {Component, Input, OnChanges} from '@angular/core';
import {PerformanceDisplay} from '@features/dashboard/models/dashboardData';

@Component({
  selector: 'app-display-card',
  templateUrl: './display-card.component.html',
  styleUrls: ['./display-card.component.less', './display-card-print.component.less']
})
export class DisplayCardComponent implements OnChanges {

  public title: any;
  public helpText: any;
  public detailUrl: any;
  public performance: any;
  public headingClass: any;
  public performanceText: any;
  private router: Router;
  @Input() public performanceDetails: PerformanceDisplay;

  constructor(router: Router) {
    this.router = router;
  }

  ngOnChanges() {
    this.setUpDisplayData();
  }

  private setUpDisplayData() {
    if (this.performanceDetails) {
      this.title = this.performanceDetails.title;
      this.helpText = this.performanceDetails.helpText;
      this.detailUrl = this.performanceDetails.detailUrl;
      this.performance = this.performanceDetails.performance;
      this.headingClass = this.performanceDetails.headingClass;
      this.performanceText = this.performanceDetails.performanceText;
    }
  }

  gotoDetailUrl() {
    if (this.detailUrl) {
      this.router.navigateByUrl(this.detailUrl).then();
    }
  }
}
