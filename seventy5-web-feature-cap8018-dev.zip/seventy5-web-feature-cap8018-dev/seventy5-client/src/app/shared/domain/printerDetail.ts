export class PrinterDetail {
  printerLocation: string;
  printerIpAddress: string;
}
