
export class Store {
  identifier: number;
  division: string;
  facility: string;
  zipCode: string;
  district: string;
  openDate: Date;
  closeDate: Date;
  lastUpdatedDateTime: Date;
  active: boolean;
  activeDc?: boolean;
  balerCount?: number;
}

export class StoreList {
  division: string;
  stores: Store[];
}


export class SelectorNode {
  constructor(public children: SelectorNode[],
              public label: string,
              public value: any,
              public selected: boolean,
              public partiallySelected: boolean) {
  }
}

export enum RenderType {
  PRIME_NG_TYPE = 'PRIMENG',
  KDS_TYPE = 'KDS'
}

export enum SelectionMode {
    MULTIPLE = 'MULTIPLE',
    SINGLE = 'SINGLE'
}
