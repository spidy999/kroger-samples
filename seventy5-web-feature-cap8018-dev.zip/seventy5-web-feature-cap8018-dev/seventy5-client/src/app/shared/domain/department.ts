export class Department {
    private _deptId?: string;
    private _deptDesc?: string;
    private _deptCode?: string;
    private _type?: string;
    private _parent_dept_code?: string;
    private _expanded?: boolean;
    private _selected?: boolean;
    private _partiallySelected?: boolean;

    get deptId(): string {
        return this._deptId;
    }

    set deptId(value: string) {
        this._deptId = value;
    }

    get deptDesc(): string {
        return this._deptDesc;
    }

    set deptDesc(value: string) {
        this._deptDesc = value;
    }

    get deptCode(): string {
        return this._deptCode;
    }

    set deptCode(value: string) {
        this._deptCode = value;
    }


    get type(): string {
        return this._type;
    }

    set type(value: string) {
        this._type = value;
    }

    get parent_dept_code(): string {
        return this._parent_dept_code;
    }

    set parent_dept_code(value: string) {
        this._parent_dept_code = value;
    }

    get expanded(): boolean {
        return this._expanded;
    }

    set expanded(value: boolean) {
        this._expanded = value;
    }

    get selected(): boolean {
        return this._selected;
    }

    set selected(value: boolean) {
        this._selected = value;
    }

    get partiallySelected(): boolean {
        return this._partiallySelected;
    }

    set partiallySelected(value: boolean) {
        this._partiallySelected = value;
    }
}

