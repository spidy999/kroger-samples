
export class MultipleStoresDto {
    divisionNo: string;
    locations: LocationInfo[];
    stores: string[];
    startDate: string;
    endDate: string;
    period?: number[];
}

export class StoresInfo {
  stores: LocationInfo[];
  startDate: string;
  endDate: string;
}

export class LocationInfo {
  divisionNo: string;
  district: string;
  store: string;
}
