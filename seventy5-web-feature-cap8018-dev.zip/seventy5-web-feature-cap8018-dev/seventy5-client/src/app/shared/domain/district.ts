import {Store} from './store';

export class District {
  constructor(public name: string, public storeDtos?: Store[]) {
  }
}
