export class SalvageMaterialType {
    materialTypeCd: string;
    materialTypeName: string;
}
