export enum DestinationType {
  ALL_DESTINATIONS = 'ALL',
  OUT_BOUND = 'Outbound',
  SHUTTLE = 'Shuttle',
  BUILDING_1 = 'Building 1',
  BUILDING_2 = 'Building 2',
  BUILDING_3 = 'Building 3'
}
