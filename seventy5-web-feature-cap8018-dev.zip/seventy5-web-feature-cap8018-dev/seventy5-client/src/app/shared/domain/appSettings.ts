
export class AppSettings {
  constructor(public  userId?: string,
              public  calendarStartDate?: string,
              public  calendarEndDate?: string,
              public chartLayoutOption?: ChartLayoutOption,
              public customCalendarOption?: CustomCalendarOption) {
  }
}

export enum SelectChartOptions {
  TABLE = 'TABLE',
  BAR_CHART = 'BAR_CHART',
  LINE_CHART = 'LINE_CHART',
  TREND_LINE = 'TREND_LINE'
}

export enum ChartLayoutOption  {
  TABLE = 'TABLE',
  BAR_CHART = 'BAR_CHART',
  LINE_CHART = 'LINE_CHART'
}

export enum CustomCalendarOption {
  CURRENT_WEEK = 'CURRENT_WEEK',
  LAST_WEEK = 'LAST_WEEK',
  CURRENT_MONTH = 'CURRENT_MONTH'
}
