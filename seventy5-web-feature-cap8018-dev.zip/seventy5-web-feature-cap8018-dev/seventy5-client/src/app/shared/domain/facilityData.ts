import { SalvageMaterialType } from './salvageMaterialType';
import {PrinterDetail} from '@app/shared/domain/printerDetail';

export class FacilityData {
  public facilityId: number;
  public facilityName: string;
  public facilityDesc: string;
  public streetAddress: string;
  public city: string;
  public stateCode: any;
  public zipCode: string;
  public printerIp?: string;
  public printerCopies: number;
  public minimumBales: number;
  public maximumBales: number;
  public balePrefix: string;
  public sessionTimeout: number;
  public timeZone: string;
  public vendorId: string;
  public salvageTracking: boolean;
  public doors?: string[];
  public destinations?: string[];
  public materialTypes?: SalvageMaterialType[];
  public printerDetails?: PrinterDetail[];
  public baledCardboardDestination?: string;
}

