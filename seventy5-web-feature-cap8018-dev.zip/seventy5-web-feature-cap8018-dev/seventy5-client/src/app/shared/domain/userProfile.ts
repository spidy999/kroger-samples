
export class UserProfile {
  constructor(  public userId?: string,
                public username?: string,
                public firstName?: string,
                public lastName?: string,
                public fullName?: string,
                public title?: string ) {
  }
}
