export class DcSalvageMaterial {
    salvageId ?: string;
    weight ?: number;
    doorNo ?: string;
    deviceId ?: string;
    insertedId ?: string;
    insertedTs ?: string;
    updatedId ?: string;
    updatedTs ?: string;
    bolId ?: number;
    facilityId ?: number;
  }

