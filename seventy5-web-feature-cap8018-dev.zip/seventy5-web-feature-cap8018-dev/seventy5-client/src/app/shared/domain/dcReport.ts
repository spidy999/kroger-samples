
export interface DcReport {
  baleCount?: number;
  facility?: number;
  insertedDt?: any;
  reportDayOfWeek?: string;
  facilityName?: string;
}
