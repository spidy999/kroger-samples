export enum SalvageBolStatus {
  ALL = 'ALL',
  OPEN = 'OPEN',
  CLOSED = 'CLOSED',
  CANCELED = 'CANCELED',
  TRANSFER = 'TRANSFER',
  RESTORE = 'RESTORE',
}
