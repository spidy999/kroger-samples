export class EquipmentStatus {
  facilityId?: string;
  equipmentType?: string;
  equipmentId?: string;
  insertedEuid?: string;
  insertedTs?: Date;
  status?: string;
  updatedEuid?: string;
  updatedTs?: Date;
}
