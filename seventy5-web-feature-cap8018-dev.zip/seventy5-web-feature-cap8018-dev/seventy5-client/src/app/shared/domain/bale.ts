export class Bale {
    divisionNo: string;
    storeNo: string;
    district: string;
    salvageId: string;
    typeCd: string;
    statusCd: string;
    insertedDt: any;
    baleCount: number;
    reportDate: any;
    reportDayOfWeek: string;
}


export class BaleList {
  storeBaleCount: number;
  sensorBaleCount: number;
  reportDate: any;
  reportDayOfWeek: string;
}
