export class BaleDetails {
    divisionNo: String;
    district: string;
    storeNo: string;
    salvageId: string;
    typeCd: string;
    statusCd: string;
    euid: string;
    deviceId: string;
    positionX: number;
    positionY: number;
    insertedDate: string;
}
