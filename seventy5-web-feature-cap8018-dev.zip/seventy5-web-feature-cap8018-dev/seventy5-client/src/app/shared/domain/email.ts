export class Email {
  public facilityId?: number;
  public emailGroup?: string;
  public emailAddress?: string;
}

export class DisplayEmail {
  public facility?: string;
  public emailGroup?: string;
  public emailAddress?: string;
}

