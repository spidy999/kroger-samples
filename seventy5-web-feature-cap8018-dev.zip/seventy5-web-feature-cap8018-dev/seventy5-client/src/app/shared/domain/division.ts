import {District} from './district';

export class Division {
  constructor(public divisionNumber: string, public divisionDesc: string,
              public includeDivision?: boolean, public districts?: District[]) {
  }
}

export class DivisionObject {
  constructor(public divisionNumber: string, public divisionDesc: string,
              public includeDivision?: boolean, public hostNamePrefix?: string) {
  }
}
