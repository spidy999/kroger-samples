import {Action} from '@ngrx/store';
import {AppSettings} from '@shared/domain/appSettings';

export const settingsKey = 'settings';
export const USER_SETTINGS_START = '[App Settings] User App Settings Start';
export const USER_SETTINGS_SUCCESS = '[App Settings] User App Settings Success';
export const USER_SETTINGS_UPDATE = '[App Settings] User App Settings Update';
export const USER_SETTINGS_FAIL = '[App Settings] User App Settings Fail';

export class UserAppSettingsStart implements Action {
  readonly type = USER_SETTINGS_START;
}

export class UserAppSettingsFail implements Action {
  readonly type = USER_SETTINGS_FAIL;
  constructor(public payload: string) {}
}

export class UserAppSettingsSuccess implements Action {
  readonly type = USER_SETTINGS_SUCCESS;
  constructor(public payload: {
    settings: AppSettings,
    isLoading: boolean
  }) {
  }
}

export class UserAppSettingsUpdate implements Action {
  readonly type = USER_SETTINGS_UPDATE;
  constructor(public payload: {
    settings: AppSettings,
    isLoading: boolean
  }) {}
}

export type UserAppSettingsAction =  UserAppSettingsStart
  | UserAppSettingsUpdate
  | UserAppSettingsSuccess
  | UserAppSettingsFail;
