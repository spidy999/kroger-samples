import {AppSettings} from '@shared/domain/appSettings';
import * as fromUserAppSettingsAction from '@app/root-store/user-settings/user-settings.action';

export interface UserAppSettingsState {
  settings: AppSettings;
  isLoading: boolean;
  error: string;
}

export const initialUserAppSettingsState: UserAppSettingsState  = {
  settings: null,
  isLoading: true,
  error: null
};

export function userAppSettingsReducer(state = initialUserAppSettingsState,
                                    action: fromUserAppSettingsAction.UserAppSettingsAction) {
  switch (action.type) {
    case fromUserAppSettingsAction.USER_SETTINGS_START:
      return {
        ...state,
        isLoading: true
      };
    case fromUserAppSettingsAction.USER_SETTINGS_SUCCESS:
      return {
        ...state,
        isLoading: action.payload.isLoading,
        settings: action.payload.settings
      };
    case fromUserAppSettingsAction.USER_SETTINGS_UPDATE:
      return {
        ...state,
        settings:  action.payload.settings,
        isLoading: action.payload.isLoading
      };
    case fromUserAppSettingsAction.USER_SETTINGS_FAIL:
      return {
        ...state,
        settings: null,
        isLoading: false,
        error: action.payload
      };
    default: return state;
  }
}

export const getUserAppSettings = (state: UserAppSettingsState) => state?.settings;
export const getUserAppSettingsLoadingStatus = (state: UserAppSettingsState) => state?.isLoading;
