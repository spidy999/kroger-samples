import {createFeatureSelector, createSelector} from '@ngrx/store';
import {settingsKey} from '@app/root-store/user-settings/user-settings.action';
import {UserAppSettingsState} from '@app/root-store/user-settings/user-settings.reducer';
import * as fromUserAppSettingsReducer from '@app/root-store/user-settings/user-settings.reducer';

export const getUserAppSettingsState = createFeatureSelector<UserAppSettingsState>(settingsKey);

export const getAppSettingsState = createSelector(getUserAppSettingsState,
  fromUserAppSettingsReducer.getUserAppSettings);

export const getAppSettingsLoadingStatus = createSelector(getUserAppSettingsState,
  fromUserAppSettingsReducer.getUserAppSettingsLoadingStatus);
