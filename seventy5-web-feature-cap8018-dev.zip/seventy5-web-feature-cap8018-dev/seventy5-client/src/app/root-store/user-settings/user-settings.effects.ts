import {Injectable} from '@angular/core';
import {of} from 'rxjs/internal/observable/of';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {AppSettings} from '@shared/domain/appSettings';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {UserService} from '@shared/services/user/user.service';
import * as fromUserAppSettings from '@app/root-store/user-settings/user-settings.action';

@Injectable()
export class UserAppSettingsEffects {
  constructor(private http: HttpClient,
              private actions$: Actions,
              private userService: UserService) {}

  @Effect()
  userAppSettings$ = this.actions$.pipe(
    ofType(fromUserAppSettings.USER_SETTINGS_START),
    mergeMap(() => {
      return this.userService.getUserAppSettingsFromServer()
        .pipe(
          map((settings: AppSettings) => {
              return new fromUserAppSettings.UserAppSettingsSuccess({
                settings: settings,
                isLoading: false
              });
            }
          ),
          catchError(() => {
            return of(new fromUserAppSettings.UserAppSettingsFail('not able to load settings data'));
          }));
    })
  );
}
