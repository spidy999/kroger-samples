import {createFeatureSelector, createSelector} from '@ngrx/store';
import {FacilityInfoState} from '@app/root-store/facility-info/facility-info.reducer';
import * as fromFacilityInfoReducer from '@app/root-store/facility-info/facility-info.reducer';

export const getFacilityInfoState = createFeatureSelector<FacilityInfoState>('facility');

export const getFacilitiesInfo = createSelector(getFacilityInfoState,
  fromFacilityInfoReducer.getFacilityInfo);

export const getFacilityItems = createSelector(getFacilityInfoState,
  fromFacilityInfoReducer.getFacilityItems);

export const getFacilityInfoLoadingStatus = createSelector(getFacilityInfoState,
  fromFacilityInfoReducer.getFacilityInfoLoadingStatus);
