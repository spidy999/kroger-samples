import {Action} from '@ngrx/store';
import {SelectItem} from 'primeng/api';
import {FacilityData} from '@shared/domain/facilityData';

export const facilityKey = 'facility';
export const FACILITY_INFO_START = '[Facility] Facility Info Start';
export const FACILITY_INFO_SUCCESS = '[Facility] Facility Info Success';
export const FACILITY_INFO_FAIL = '[Facility] Facility Info Fail';

export class FacilityInfoStart implements Action {
  readonly type = FACILITY_INFO_START;
}

export class FacilityInfoFail implements Action {
  readonly type = FACILITY_INFO_FAIL;
  constructor(public payload: string) {}
}

export class FacilityInfoSuccess implements Action {
  readonly type = FACILITY_INFO_SUCCESS;
  constructor(public payload: {
    facilities: FacilityData[],
    facilityItems: SelectItem[],
    isLoading: boolean
  }) {
  }
}

export type FacilityInfoAction =  FacilityInfoStart
  | FacilityInfoSuccess
  | FacilityInfoFail;
