import {Injectable} from '@angular/core';
import {of} from 'rxjs/internal/observable/of';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {FacilityData} from '@shared/domain/facilityData';
import {FacilityService} from '@shared/services/facility/facility.service';
import * as fromFacilityInfoActions from '@app/root-store/facility-info/facility-info.action';

@Injectable()
export class FacilityInfoEffects {
  constructor(private http: HttpClient,
              private actions$: Actions,
              private facilityService: FacilityService) {}

  @Effect()
  facilities$ = this.actions$.pipe(
    ofType(fromFacilityInfoActions.FACILITY_INFO_START),
    mergeMap(() => {
      return this.facilityService.getAllFacilities()
        .pipe(
          map((facilities: FacilityData[]) => {
            const facilityItems = facilities ? facilities.map(facilityData => ({
              label: facilityData.facilityName, value: facilityData.facilityId})) : [];
              return new fromFacilityInfoActions.FacilityInfoSuccess({
                facilities: facilities,
                facilityItems: facilityItems,
                isLoading: false
              });
            }
          ),
          catchError(() => {
            return of(new fromFacilityInfoActions.FacilityInfoFail('not able to load facility data'));
          }));
    })
  );

}
