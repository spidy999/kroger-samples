import {SelectItem} from 'primeng/api';
import {FacilityData} from '@shared/domain/facilityData';
import * as fromFacilityInfo from '@app/root-store/facility-info/facility-info.action';

export interface FacilityInfoState {
  facilities: FacilityData[];
  facilityItems: SelectItem[];
  isLoading: boolean;
  error: string;
}

export const initialFacilityInfoState: FacilityInfoState  = {
  facilities: null,
  facilityItems: null,
  isLoading: true,
  error: null
};

export function facilityInfoReducer(state = initialFacilityInfoState,
                                 action: fromFacilityInfo.FacilityInfoAction) {
  switch (action.type) {
    case fromFacilityInfo.FACILITY_INFO_START:
      return {
        ...state,
        isLoading: true
      };
    case fromFacilityInfo.FACILITY_INFO_SUCCESS:
      return {
        ...state,
        facilities: action.payload.facilities,
        facilityItems: action.payload.facilityItems,
        isLoading: action.payload.isLoading
      };
    case fromFacilityInfo.FACILITY_INFO_FAIL:
      return {
        ...state,
        facilities: null,
        facilityItems: null,
        isLoading: false,
        error: action.payload
      };
    default: return state;
  }
}

export const getFacilityInfo = (state: FacilityInfoState) => state?.facilities;
export const getFacilityItems = (state: FacilityInfoState) => state?.facilityItems;
export const getFacilityInfoLoadingStatus = (state: FacilityInfoState) => state?.isLoading;
