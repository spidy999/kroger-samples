import {ActionReducerMap} from '@ngrx/store';
import * as fromUserReducer from '@app/root-store/user-info/user-info.reducer';
import * as fromStoreReducer from '@app/root-store/store-node/store-node.reducer';
import * as fromDivisionReducer from '@app/root-store/divisions/divisions.reducer';
import * as fromFacilityReducer from '@app/root-store/facility-info/facility-info.reducer';
import * as fromUserSettingsReducer from '@app/root-store/user-settings/user-settings.reducer';

export interface AppState {
  user: fromUserReducer.UserState;
  store: fromStoreReducer.StoreState;
  divisions: fromDivisionReducer.DivisionState;
  facility: fromFacilityReducer.FacilityInfoState;
  settings: fromUserSettingsReducer.UserAppSettingsState;
}

export const appReducer: ActionReducerMap<AppState> = {
  user: fromUserReducer.userInfoReducer,
  store: fromStoreReducer.storeNodeReducer,
  divisions: fromDivisionReducer.divisionsReducer,
  facility: fromFacilityReducer.facilityInfoReducer,
  settings: fromUserSettingsReducer.userAppSettingsReducer
};

