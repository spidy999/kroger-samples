import {UserInfoEffects} from '@app/root-store/user-info/user-info.effects';
import {StoreNodeEffects} from '@app/root-store/store-node/store-node.effects';
import {DivisionsEffects} from '@app/root-store/divisions/divisions.effects';
import {FacilityInfoEffects} from '@app/root-store/facility-info/facility-info.effects';
import {UserAppSettingsEffects} from '@app/root-store/user-settings/user-settings.effects';

export const AppEffects = [
  UserInfoEffects,
  StoreNodeEffects,
  DivisionsEffects,
  FacilityInfoEffects,
  UserAppSettingsEffects
];
