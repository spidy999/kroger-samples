import {Injectable} from '@angular/core';
import {of} from 'rxjs/internal/observable/of';
import {HttpClient} from '@angular/common/http';
import {Division} from '@shared/domain/division';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {DivisionService} from '@shared/services/division/division.service';
import * as fromDivisionActions from '@app/root-store/divisions/divisions.action';

@Injectable()
export class DivisionsEffects {
  constructor(private http: HttpClient,
              private actions$: Actions,
              private divisionService: DivisionService) {}

  @Effect()
  divisions$ = this.actions$.pipe(
    ofType(fromDivisionActions.DIVISIONS_START),
    mergeMap(() => {
      return this.divisionService.getIncludedDivisions()
        .pipe(
          map((divisions: Division[]) => {
            const divisionList = divisions ? divisions.map(divisionData => ({
              label: `${divisionData.divisionDesc} - ${divisionData.divisionNumber}`,
              value: divisionData.divisionNumber})) : [];
              return new fromDivisionActions.DivisionsSuccess({
                divisions: divisions,
                divisionItems: divisionList,
                isLoading: false
              });
            }
          ),
          catchError(() => {
            return of(new fromDivisionActions.DivisionsFail('not able to load division data'));
          }));
    })
  );

}
