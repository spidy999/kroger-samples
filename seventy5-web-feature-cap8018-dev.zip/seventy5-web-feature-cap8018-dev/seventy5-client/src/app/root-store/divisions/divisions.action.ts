import {Action} from '@ngrx/store';
import {SelectItem} from 'primeng/api';
import {Division} from '@shared/domain/division';

export const divisionsKey = 'divisions';
export const DIVISIONS_START = '[Divisions] Divisions Start';
export const DIVISIONS_SUCCESS = '[Divisions] Divisions Success';
export const DIVISIONS_FAIL = '[Divisions] Divisions Fail';

export class DivisionsStart implements Action {
  readonly type = DIVISIONS_START;
}

export class DivisionsFail implements Action {
  readonly type = DIVISIONS_FAIL;
  constructor(public payload: string) {}
}

export class DivisionsSuccess implements Action {
  readonly type = DIVISIONS_SUCCESS;
  constructor(public payload: {
    divisions: Division[],
    divisionItems: SelectItem[],
    isLoading: boolean
  }) {
  }
}

export type DivisionsAction =  DivisionsStart
  | DivisionsSuccess
  | DivisionsFail;
