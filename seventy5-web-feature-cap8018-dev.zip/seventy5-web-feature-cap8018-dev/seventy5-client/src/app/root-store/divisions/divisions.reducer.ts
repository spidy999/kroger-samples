import {SelectItem} from 'primeng/api';
import {Division} from '@shared/domain/division';
import * as fromDivisionActions from '@app/root-store/divisions/divisions.action';

export interface DivisionState {
  divisions: Division[];
  divisionItems: SelectItem[];
  isLoading: boolean;
  error: string;
}

export const initialDivisionState: DivisionState  = {
  divisions: null,
  divisionItems: null,
  isLoading: true,
  error: null
};

export function divisionsReducer(state = initialDivisionState,
                                 action: fromDivisionActions.DivisionsAction) {
  switch (action.type) {
    case fromDivisionActions.DIVISIONS_START:
      return {
        ...state,
        isLoading: true
      };
    case fromDivisionActions.DIVISIONS_SUCCESS:
      return {
        ...state,
        divisions: action.payload.divisions,
        divisionItems: action.payload.divisionItems,
        isLoading: action.payload.isLoading
      };
    case fromDivisionActions.DIVISIONS_FAIL:
      return {
        ...state,
        divisions: null,
        divisionItems: null,
        isLoading: false,
        error: action.payload
      };
    default: return state;
  }
}

export const getDivisionsInfo = (state: DivisionState) => state?.divisions;
export const getDivisionItems = (state: DivisionState) => state?.divisionItems;
export const getDivisionLoadingStatus = (state: DivisionState) => state?.isLoading;
