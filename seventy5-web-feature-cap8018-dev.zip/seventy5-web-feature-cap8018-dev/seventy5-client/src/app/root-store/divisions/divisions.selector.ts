import {createFeatureSelector, createSelector} from '@ngrx/store';
import * as fromDivisionReducer from '@app/root-store/divisions/divisions.reducer';
import {DivisionState} from '@app/root-store/divisions/divisions.reducer';

export const getDivisionsState = createFeatureSelector<DivisionState>('divisions');

export const getDivisions = createSelector(getDivisionsState,
  fromDivisionReducer.getDivisionsInfo);

export const getDivisionItems = createSelector(getDivisionsState,
  fromDivisionReducer.getDivisionItems);

export const getDivisionsLoadingStatus = createSelector(getDivisionsState,
  fromDivisionReducer.getDivisionLoadingStatus);
