import {UserProfile} from '@shared/domain/userProfile';
import * as fromUserActions from '@app/root-store/user-info/user-info.action';

export interface UserState {
  user: UserProfile | null;
  isAuthenticated: boolean;
}

export const initialUserState: UserState  = {
  user: null,
  isAuthenticated: false
};

export function userInfoReducer(state = initialUserState, action: fromUserActions.UserActions) {
  switch (action.type) {
    case fromUserActions.LOGIN:
      const userInfo = action.payload;
      return {
        ...state,
        user: userInfo.user,
        isAuthenticated: userInfo.isAuthenticated
    };
    case fromUserActions.LOGOUT:
      return {
        user: null,
        isAuthenticated: false
      };
    default: return state;
  }
}

export const getUserInfo = (state: UserState) => state.user;
export const checkAuthentication = (state: UserState) => state.isAuthenticated;
