import {createFeatureSelector, createSelector} from '@ngrx/store';
import {userKey} from '@app/root-store/user-info/user-info.action';
import {UserState} from '@app/root-store/user-info/user-info.reducer';
import * as fromUserReducer from '@app/root-store/user-info/user-info.reducer';

export const userFeature = createFeatureSelector<UserState>(userKey);

export const getUserInfoState = createSelector(userFeature,
  fromUserReducer.getUserInfo
);

export const validateUser = createSelector(userFeature,
  fromUserReducer.checkAuthentication
);
