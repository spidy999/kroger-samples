import {Action} from '@ngrx/store';
import {UserProfile} from '@shared/domain/userProfile';

export const userKey = 'user';
export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';

export class Login implements Action {
  readonly type = LOGIN;
  constructor(public payload: {
    user: UserProfile,
    isAuthenticated: boolean
  }) {}
}

export class Logout implements Action {
  readonly type = LOGOUT;
}

export type UserActions = Login | Logout;

