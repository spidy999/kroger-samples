import {tap} from 'rxjs/operators';
import {Router} from '@angular/router';
import {Injectable} from '@angular/core';
import {AuthService} from 'kroger-ng-oauth2';
import {HttpClient} from '@angular/common/http';
import {Actions, Effect, ofType} from '@ngrx/effects';
import * as fromUserActions from '@app/root-store/user-info/user-info.action';
const TIMEOUT = 200;

@Injectable()
export class UserInfoEffects {
  constructor(private router: Router,
              private http: HttpClient,
              private actions$: Actions,
              private authService: AuthService) {
  }

  @Effect({dispatch: false})
  logout$ = this.actions$.pipe(
    ofType(fromUserActions.LOGOUT),
    tap(() => {
      this.authService.logout().subscribe(() => {
        setTimeout(() => {
          window.location.href = window.location.origin + '/';
        }, TIMEOUT);
      });
    })
  );
}
