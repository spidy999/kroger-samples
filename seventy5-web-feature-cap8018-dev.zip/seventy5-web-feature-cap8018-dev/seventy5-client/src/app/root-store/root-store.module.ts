import {StoreModule} from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';
import {CommonModule} from '@angular/common';
import {AppEffects} from '@app/root-store/app.effects';
import {userKey} from '@app/root-store/user-info/user-info.action';
import {storeKey} from '@app/root-store/store-node/store-node.action';
import {divisionsKey} from '@app/root-store/divisions/divisions.action';
import {facilityKey} from '@app/root-store/facility-info/facility-info.action';
import {settingsKey} from '@app/root-store/user-settings/user-settings.action';
import {FacilityService} from '@shared/services/facility/facility.service';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import * as fromUserReducer from '@app/root-store/user-info/user-info.reducer';
import * as fromDivisionReducer from '@app/root-store/divisions/divisions.reducer';
import * as fromStoreNodeReducer from '@app/root-store/store-node/store-node.reducer';
import * as fromFacilityInfoReducer from '@app/root-store/facility-info/facility-info.reducer';
import * as fromUserAppSettingsReducer from '@app/root-store/user-settings/user-settings.reducer';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature(userKey, fromUserReducer.userInfoReducer),
    StoreModule.forFeature(storeKey, fromStoreNodeReducer.storeNodeReducer),
    StoreModule.forFeature(divisionsKey, fromDivisionReducer.divisionsReducer),
    StoreModule.forFeature(facilityKey, fromFacilityInfoReducer.facilityInfoReducer),
    StoreModule.forFeature(settingsKey, fromUserAppSettingsReducer.userAppSettingsReducer),
    EffectsModule.forFeature(AppEffects)
  ],
  declarations: [],
  providers: [FacilityService],
  exports: [],
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class RootStoreModule { }
