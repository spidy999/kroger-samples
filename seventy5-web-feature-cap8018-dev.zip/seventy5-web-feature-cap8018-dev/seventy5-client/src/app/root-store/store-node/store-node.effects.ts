import {Injectable} from '@angular/core';
import {of} from 'rxjs/internal/observable/of';
import {HttpClient} from '@angular/common/http';
import {District} from '@shared/domain/district';
import {Division} from '@shared/domain/division';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {SelectorNode} from 'kroger-ng-store-selector';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {DivisionService} from '@shared/services/division/division.service';
import {DistrictService} from '@shared/services/district/district.service';
import * as fromStoreNodeActions from '@app/root-store/store-node/store-node.action';

@Injectable()
export class StoreNodeEffects {
  constructor(private http: HttpClient,
              private actions$: Actions,
              private districtService: DistrictService,
              private divisionService: DivisionService) {}

  @Effect()
  storeNode$ = this.actions$.pipe(
      ofType(fromStoreNodeActions.STORE_NODE_START),
      mergeMap(() => {
         return this.divisionService.getIncludedDivisions()
           .pipe(
             map((divisions: Division[]) => {
               const selector = new SelectorNode();
               const districts = this.getDistricts(divisions);
               const storeNode: SelectorNode = this.getStoreNode(divisions, districts, selector);
               return new fromStoreNodeActions.StoreNodeSuccess({
                 node: storeNode,
                 isLoading: false
               });
               }
             ),
             catchError(() => {
              return of(new fromStoreNodeActions.StoreNodeFail('not able to load data'));
            }));
      })
  );

  private getDistricts(divisions) {
    return divisions.map(division =>
      this.districtService.getDistrictsForDivision(division.divisionNumber, false)
    );
  }

  private getStoreNode(divisions, districts, selector): SelectorNode {
    forkJoin([...districts]).subscribe((districtResponses: District[]) => {
      for (let i = 0; i < districtResponses.length; i++) {
        divisions[i].districts = districtResponses[i];
      }
      const selectorNode =  {
        children: divisions.map(division => ({
          children: division.districts.map(district => ({
            children: district.storeDtos.map(store => ({
              children: [],
              label: store.facility,
              value: store,
              selected: false,
              partiallySelected: false
            })),
            label: `District ${district.name}`,
            value: district,
            selected: false,
            partiallySelected: false
          })),
          label: `${division.divisionDesc} - ${division.divisionNumber}`,
          value: division,
          selected: false,
          partiallySelected: false
        })),
        label: null,
        value: null,
        selected: false,
        partiallySelected: false
      };
      selector.value = selectorNode.value;
      selector.label = selectorNode.label;
      selector.partiallySelected = selectorNode.partiallySelected;
      selector.selected = selectorNode.selected;
      selector.children = selectorNode.children;
    });
    return selector;
  }

}
