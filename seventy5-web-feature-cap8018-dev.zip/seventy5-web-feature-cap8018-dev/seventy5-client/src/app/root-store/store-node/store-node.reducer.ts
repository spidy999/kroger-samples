import {SelectorNode} from '@shared/domain/store';
import * as fromStoreNodeActions from '@app/root-store/store-node/store-node.action';

export interface StoreState {
  node: SelectorNode;
  isLoading: boolean;
  error: string;
}

export const initialUserState: StoreState  = {
  node: null,
  isLoading: true,
  error: null
};

export function storeNodeReducer(state = initialUserState,
                                 action: fromStoreNodeActions.StoreNodeAction) {
  switch (action.type) {
    case fromStoreNodeActions.STORE_NODE_START:
      return {
        ...state,
        isLoading: true
      };
    case fromStoreNodeActions.STORE_NODE_SUCCESS:
      return {
        ...state,
        isLoading: action.payload.isLoading,
        node: action.payload.node
      };
    case fromStoreNodeActions.STORE_NODE_FAIL:
      return {
        ...state,
        node: null,
        isLoading: false,
        error: action.payload
      };
    default: return state;
  }
}

export const getStoreNode = (state: StoreState) => state.node;
export const getStoreNodeLoadingStatus = (state: StoreState) => state.isLoading;
