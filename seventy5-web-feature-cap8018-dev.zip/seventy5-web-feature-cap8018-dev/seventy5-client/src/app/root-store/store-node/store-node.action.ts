import {Action} from '@ngrx/store';
import {SelectorNode} from 'kroger-ng-store-selector';

export const storeKey = 'store';
export const STORE_NODE_START = '[Store] Store Node Start';
export const STORE_NODE_SUCCESS = '[Store] Store Node Success';
export const STORE_NODE_FAIL = '[Store] Store Node Fail';

export class StoreNodeStart implements Action {
  readonly type = STORE_NODE_START;
}

export class StoreNodeFail implements Action {
  readonly type = STORE_NODE_FAIL;
  constructor(public payload: string) {}
}

export class StoreNodeSuccess implements Action {
  readonly type = STORE_NODE_SUCCESS;
  constructor(public payload: {
    node: SelectorNode,
    isLoading: boolean
  }) {
  }
}

export type StoreNodeAction =  StoreNodeStart
  | StoreNodeSuccess
  | StoreNodeFail;

