import {createFeatureSelector, createSelector} from '@ngrx/store';
import {StoreState} from '@app/root-store/store-node/store-node.reducer';
import * as fromStoreNode from '@app/root-store/store-node/store-node.reducer';
import {storeKey} from '@app/root-store/store-node/store-node.action';

export const getStoreState = createFeatureSelector<StoreState>(storeKey);

export const getStoreNodeState = createSelector(getStoreState,
  fromStoreNode.getStoreNode);

export const getStoreLoadingStatus = createSelector(getStoreState,
  fromStoreNode.getStoreNodeLoadingStatus);
