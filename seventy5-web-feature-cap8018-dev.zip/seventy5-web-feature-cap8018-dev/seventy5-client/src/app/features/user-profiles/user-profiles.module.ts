import { CommonModule } from '@angular/common';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {TemplateModule} from '@app/templates/template.module';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { UserProfilesRoutingModule } from './user-profiles-routing.module';
import {AppSettingsComponent} from '@features/user-profiles/app-settings/app-settings.component';
import {UserProfileComponent} from '@features/user-profiles/user-profile/user-profile.component';
import {UserDetailsComponent} from '@features/user-profiles/user-details/user-details.component';

@NgModule({
  declarations: [
    AppSettingsComponent,
    UserProfileComponent,
    UserDetailsComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    PrimengModule,
    CalendarModule,
    TemplateModule,
    ReactiveFormsModule,
    KdsStencilAccessorsModule,
    UserProfilesRoutingModule
  ],
  exports: [
    AppSettingsComponent,
    UserProfileComponent,
    UserDetailsComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class UserProfilesModule { }
