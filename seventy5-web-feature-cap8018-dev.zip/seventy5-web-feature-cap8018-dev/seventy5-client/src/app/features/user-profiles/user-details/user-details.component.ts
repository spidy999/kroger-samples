import {select, Store} from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import {AppState} from '@app/root-store/app.reducer';
import {UserProfile} from '@shared/domain/userProfile';
import {getUserInfoState} from '@app/root-store/user-info/user-info.selector';

@Component({
  selector: 'user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.less']
})
export class UserDetailsComponent implements OnInit {

  public userInfo: UserProfile;
  constructor(private readonly store: Store<AppState>) {
    this.store.pipe(select(getUserInfoState)).subscribe(user => {
      this.userInfo = user;
    });
  }

  ngOnInit(): void {}

}
