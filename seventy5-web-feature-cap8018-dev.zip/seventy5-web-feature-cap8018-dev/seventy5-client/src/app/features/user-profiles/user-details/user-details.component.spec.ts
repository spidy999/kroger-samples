import {Store, StoreModule} from '@ngrx/store';
import {provideMockStore} from '@ngrx/store/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { UserDetailsComponent } from './user-details.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {userInfoReducer, UserState} from '@app/root-store/user-info/user-info.reducer';

describe('UserDetailsComponent', () => {
  let store: Store<UserState>;
  let component: UserDetailsComponent;
  let fixture: ComponentFixture<UserDetailsComponent>;
  const initialState = {
    user: {
      user: {
        username: 'SUPPORT',
        fullName: 'Application Support',
        firstName: 'Support',
        lastName: 'Support',
        title: 'Application Support'
      },
      isAuthenticated: true
    },
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        StoreModule.forRoot({
          user: userInfoReducer
        })
      ],
      declarations: [ UserDetailsComponent ],
      providers: [
        provideMockStore({ initialState }),
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDetailsComponent);
    store = TestBed.inject(Store);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
