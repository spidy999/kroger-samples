import {select, Store} from '@ngrx/store';
import {SelectItem} from 'primeng/api';
import {FormGroup} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {AuthService} from 'kroger-ng-oauth2';
import {Component, OnInit} from '@angular/core';
import {AppState} from '@app/root-store/app.reducer';
import {UserProfile} from '@shared/domain/userProfile';
import {AppSettings} from '@shared/domain/appSettings';
import {ToastDetails} from '@shared/models/Notification';
import {user_menu as constants} from '@core/models/user_menu';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {getUserInfoState} from '@app/root-store/user-info/user-info.selector';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {getAppSettingsState} from '@app/root-store/user-settings/user-settings.selector';
import * as fromAppSettingsAction from '@app/root-store/user-settings/user-settings.action';

@Component({
  selector: 'app-settings',
  templateUrl: './app-settings.component.html',
  styleUrls: ['./app-settings.component.less']
})
export class AppSettingsComponent implements OnInit {
  public dates: Date;
  public userInfo: UserProfile;
  public userAppData: AppSettings;
  public settingsForm: FormGroup = null;
  public chartOptions: SelectItem[];
  public calendarOptions: SelectItem[];
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor(private store: Store<AppState>,
              private userService: UserService,
              private utilService: UtilService,
              private authService: AuthService,
              private notificationService: NotificationsService) {
    this.store.pipe(select(getUserInfoState)).subscribe(user => this.userInfo = user);
    const {calendarOptions, chartOptions} = constants;
    this.calendarOptions = calendarOptions;
    this.chartOptions = chartOptions;
  }

  ngOnInit() {
    this.utilService.hideSpinner();
    this.loadUserSettings();
  }

  private loadUserSettings() {
    this.settingsForm = this.userService.userAppSettingsForm();
    this.store.pipe(select(getAppSettingsState)).subscribe(settings => {
      this.userAppData = settings;
      if (this.userAppData && this.userAppData.customCalendarOption && this.userAppData.chartLayoutOption) {
        const { customCalendarOption, chartLayoutOption} = this.userAppData;
        this.settingsForm.setValue({chartLayoutOption, customCalendarOption});
      }
    });
  }

  public submit() {
    this.updateUserAppSettings();
  }

  private updateUserAppSettings() {
    let toastDetails: ToastDetails;
    this.userService.updateUserAppSettings(this.settingsForm.value).subscribe( () => {
      const settings: AppSettings = {
        ...this.userAppData,
        chartLayoutOption: this.settingsForm.get('chartLayoutOption').value,
        customCalendarOption: this.settingsForm.get('customCalendarOption').value
      };
      this.store.dispatch(new fromAppSettingsAction.UserAppSettingsUpdate({
        settings: settings,
        isLoading: false
      }));
      toastDetails = {
        title: 'Success',
        message: 'Updated Successfully',
        toastType: 'success'
      };
      this.notificationService.emitMessage.next(toastDetails);
    }, () => {
      toastDetails = {
        title: 'Failure',
        message: 'Update incomplete, please try Again!.',
        toastType: 'error'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

}
