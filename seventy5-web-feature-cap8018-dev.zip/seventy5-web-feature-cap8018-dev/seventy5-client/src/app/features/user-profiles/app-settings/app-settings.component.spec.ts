import {Store, StoreModule} from '@ngrx/store';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppSettingsComponent } from './app-settings.component';
import {provideMockStore} from '@ngrx/store/testing';
import {RouterTestingModule} from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {userInfoReducer, UserState} from '@app/root-store/user-info/user-info.reducer';

describe('UserSettingsComponent', () => {
  let component: AppSettingsComponent;
  let store: Store<UserState>;
  let fixture: ComponentFixture<AppSettingsComponent>;
  let userService: UserService;
  let utilService: UtilService;
  let facilityService: FacilityService;
  const initialState = {
    user: {
      user: {
        username: 'SUPPORT',
        fullName: 'Application Support',
        firstName: 'Support',
        lastName: 'Support',
        title: 'Application Support'
      },
      isAuthenticated: true
    },
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        StoreModule.forRoot({
          user: userInfoReducer
        }),
        BrowserAnimationsModule,
      ],
      providers: [
        UserService,
        UtilService,
        FacilityService,
        provideMockStore({ initialState }),
      ],
      declarations: [ AppSettingsComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppSettingsComponent);
    store = TestBed.inject(Store);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    facilityService = TestBed.inject(FacilityService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
