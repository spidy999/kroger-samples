import {Observable} from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import {UtilService} from '@shared/services/util/util.service';

@Component({
  selector: 'user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.less']
})
export class UserProfileComponent implements OnInit {

  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor(private utilService: UtilService) {}

  ngOnInit() {
    this.utilService.showSpinner();
    this.buildTabs();
  }

  private buildTabs() {
    this.utilService.hideSpinner();
  }
}
