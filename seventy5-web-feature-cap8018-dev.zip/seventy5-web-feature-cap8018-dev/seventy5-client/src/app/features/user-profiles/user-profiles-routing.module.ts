import { NgModule } from '@angular/core';
import {AuthGuard} from '@app/auth-guard';
import {Permission} from '@shared/models/permissions';
import { Routes, RouterModule } from '@angular/router';
import {UserProfileComponent} from '@features/user-profiles/user-profile/user-profile.component';

const userProfileRoutes: Routes = [
  {
    path: '',
    component: UserProfileComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.USER_PROFILE.toString()
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(userProfileRoutes)],
  exports: [RouterModule]
})
export class UserProfilesRoutingModule { }
