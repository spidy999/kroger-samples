import {ChartDetails} from '@shared/models/reportData';

export class BaleProductionDetails {
  dcScansData: ChartDetails;
  avgWeightData: ChartDetails;
  storeScansData: ChartDetails;
  sensorsBaleData: ChartDetails;
  totalWeightData: ChartDetails;
  balesWithoutWeightData: ChartDetails;
  storeVsDcPercentageData: ChartDetails;
  storeVsSensorsPercentageData: ChartDetails;
}
