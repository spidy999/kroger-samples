
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import { SalvageMaterialType } from '@app/shared/domain/salvageMaterialType';

export interface BillOfLadingSearchTableData {
  bolId: number;
  dateCreated: string;
  destination: string;
  lastUpdatedDate: string;
  materialType: string;
  qty: any;
  status: string;
  totalWeight: any;
  dataKey?: string;
}

export interface SearchBOLResponseData {
  bolId?: number;
  destination?: string;
  deviceId?: string;
  doorNo?: string;
  facilityId?: number;
  insertedDate?: string;
  insertedEuid?: string;
  salvageMaterialType?: SalvageMaterialType;
  reprintBol?: boolean;
  salvageQty?: any;
  status?: SalvageBolStatus;
  totalWeight?: any;
  trailerNo?: string;
  updatedDate?: string;
  updatedEuid?: string;
}
