
export class DcDetails {
    endDate: any;
    startDate: any;
    facilityId: number;
    // add more props if you need
}
