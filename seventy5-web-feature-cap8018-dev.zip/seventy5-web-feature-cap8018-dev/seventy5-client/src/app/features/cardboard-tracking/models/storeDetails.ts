
export class StoreDetails {
    divisionNo: string;
    endDate: any;
    startDate: any;
    storeNo: string;
}
