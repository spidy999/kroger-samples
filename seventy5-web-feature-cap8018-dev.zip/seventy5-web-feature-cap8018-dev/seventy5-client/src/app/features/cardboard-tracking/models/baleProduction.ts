export enum BaleProductionFactors {
  STORE_SCANS = 'storeScans',
  STORE_VS_DC_PERCENT = 'storeVsDcPercent',
  DC_SCANS = 'dcScans',
  TOTAL_WEIGHT = 'actualWeight',
  AVG_WEIGHT = 'avgWeight',
  BALES_WITHOUT_WEIGHT = 'unWeighedBales',
  STORE_VS_SENSOR_PERCENT = 'sensorVariance',
  SENSORS_BALE = 'baleSensorCount'

}

export enum CardboardTrackingTab {
  BALE_PRODUCTION = 'BALE_PRODUCTION',
  STORE_ACTIVITY = 'STORE_ACTIVITY',
  DC_ACTIVITY = 'DC_ACTIVITY',
  BILL_OF_LADING = 'BILL_OF_LADING'
}

export enum BaleProductionType {
  ENTERPRISE_BALE_PRODUCTION = 'ENTERPRISE_BALE_PRODUCTION',
  CORPORATE_BALE_PRODUCTION = 'CORPORATE_BALE_PRODUCTION'
}

export class BaleProductionOptions {
  public storeScans?: string;
  public dcScans?: string;
  public district?: string;
  public actualWeight?: string;
  public avgWeight?: string;
  public variance?: string;
  public sensorVariance?: string;
  public unWeighedBales?: string;
  public baleSensorCount?: string;
}
