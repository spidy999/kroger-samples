import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {DestinationType} from '@shared/domain/DestinationType';
import {CardboardTrackingTab} from '@features/cardboard-tracking/models/baleProduction';

export const CardBoardTab = {
  corpAndSupportUserTabs: [
    {label: 'Bale Production', value: CardboardTrackingTab.BALE_PRODUCTION },
    {label: 'Store Activity', value: CardboardTrackingTab.STORE_ACTIVITY },
    {label: 'DC Activity', value: CardboardTrackingTab.DC_ACTIVITY },
    {label: 'Bill of Lading', value: CardboardTrackingTab.BILL_OF_LADING }
  ],
  otherUserTabs: [
    {label: 'Bale Production', value: CardboardTrackingTab.BALE_PRODUCTION },
    {label: 'Store Activity', value: CardboardTrackingTab.STORE_ACTIVITY }
  ],
};

export const BillOfLading = {
  cols : [
    {field: 'bolId', header: 'BOL#'},
    {field: 'lastUpdatedDate', header: 'Closed Date'},
    {field: 'salvageMaterialType', subfield: 'materialTypeName', header: 'Material Type'},
    {field: 'status', header: 'Status'},
    {field: 'destination', header: 'Destination'},
    {field: 'qty', header: 'Qty'},
    {field: 'totalWeight', header: 'Total Weight'}
  ],

  statusType: [
    {label: 'All', value: SalvageBolStatus.ALL },
    {label: 'Open', value: SalvageBolStatus.OPEN },
    {label: 'Closed', value: SalvageBolStatus.CLOSED },
    {label: 'Canceled', value: SalvageBolStatus.CANCELED }
  ],

  destinations: [
    {label: 'All', value: DestinationType.ALL_DESTINATIONS },
    {label: 'Outbound', value: DestinationType.OUT_BOUND },
    {label: 'Shuttle', value: DestinationType.SHUTTLE },
    {label: 'Building 1', value: DestinationType.BUILDING_1 },
    {label: 'Building 2', value: DestinationType.BUILDING_2 },
    {label: 'Building 3', value: DestinationType.BUILDING_3 }
  ]

};

export const BaleProduction = {
  types: [
    {label: 'Table', value: 'table', icon: 'fa fa-fw fa-table'},
    {label: 'Trend Line', value: 'lineChart', icon: 'fa fa-fw fa-line-chart'}
  ],

  withDcFilters: [
    {label: 'Store Bales', value: 'storeScans'},
    {label: 'Store % DC', value: 'storeVsDcPercent'},
    {label: 'DC Bales', value: 'dcScans'},
    {label: 'Store % Sensor', value: 'sensorVariance'},
    {label: 'Sensor Bales', value: 'baleSensorCount'},
    {label: 'Total Wt', value: 'actualWeight'},
    {label: 'Average Weight', value: 'avgWeight'},
    {label: 'Bales W/O Wt', value: 'unWeighedBales'}
  ],

  withoutDcFilters: [
    {label: 'Store Bales', value: 'storeScans'},
    {label: 'Store % DC', value: 'storeVsDcPercent'},
    {label: 'Sensor Bales', value: 'baleSensorCount'},
    {label: 'Store % Sensor', value: 'sensorVariance'}
  ],
  withDcColumns: [
    {field: 'district', header: 'District'},
    {field: 'storeScans', header: 'Store Bales'},
    {field: 'baleSensorCount', header: 'Sensor Bales'},
    {field: 'sensorVariance', header: 'Store % Sensor'},
    {field: 'dcScans', header: 'DC Bales'},
    {field: 'variance', header: 'Store % DC'},
    {field: 'actualWeight', header: 'Total Wt'},
    {field: 'avgWeight', header: 'Average Weight (Goal 750 lbs.)'},
    {field: 'unWeighedBales', header: 'Bales W/O Wt'}
  ],

  withoutDcColumns: [
    {field: 'district', header: 'District'},
    {field: 'storeScans', header: 'Store Bales'},
    {field: 'baleSensorCount', header: 'Sensor Bales'},
    {field: 'sensorVariance', header: 'Store % Sensor'}
  ]
};

export const BaleProductionDetails =  {
  withDcColumns: [
    {field: 'store', header: 'Store'},
    {field: 'storeScans', header: 'Store Bales'},
    {field: 'baleSensorCount', header: 'Sensor Bales'},
    {field: 'sensorVariance', header: 'Store % Sensor'},
    {field: 'dcScans', header: 'DC Bales'},
    {field: 'variance', header: 'Store % DC'},
    {field: 'actualWeight', header: 'Total Wt'},
    {field: 'avgWeight', header: 'Avg Wt'},
    {field: 'unWeighedBales', header: 'Bales W/O Wt'}
  ],

  withoutDcColumns: [
    {field: 'store', header: 'Store'},
    {field: 'storeScans', header: 'Store Bales'},
    {field: 'baleSensorCount', header: 'Sensor Bales'},
    {field: 'sensorVariance', header: 'Store % Sensor'}
  ]
};

export const DCActivity = {
  types: [
    {label: 'Table', value: 'table', icon: 'fa fa-fw fa-table'},
    {label: 'Bar', value: 'barChart', icon: 'fa fa-fw fa-bar-chart'},
    {label: 'Line', value: 'lineChart', icon: 'fa fa-fw fa-line-chart'}
  ],
   cols: [
    {field: 'sunday', header: 'SUN'},
    {field: 'monday', header: 'MON'},
    {field: 'tuesday', header: 'TUE'},
    {field: 'wednesday', header: 'WED'},
    {field: 'thursday', header: 'THU'},
    {field: 'friday', header: 'FRI'},
    {field: 'saturday', header: 'SAT'},
    {field: 'total', header: 'Total'},
    {field: 'average', header: 'AVG'}
   ]
};

export const StoreActivity = {
  types: [
    {label: 'Table', value: 'table', icon: 'fa fa-fw fa-table'},
    {label: 'Bar', value: 'barChart', icon: 'fa fa-fw fa-bar-chart'},
    {label: 'Line', value: 'lineChart', icon: 'fa fa-fw fa-line-chart'}
  ],

  cols: [
    {field: 'store', header: 'STORE', headerClass: 'text-center', class: 'text-center'},
    {field: 'sunday', header: 'SUN', headerClass: 'text-center', class: 'text-center'},
    {field: 'monday', header: 'MON', headerClass: 'text-center', class: 'text-center'},
    {field: 'tuesday', header: 'TUE', headerClass: 'text-center', class: 'text-center'},
    {field: 'wednesday', header: 'WED', headerClass: 'text-center', class: 'text-center'},
    {field: 'thursday', header: 'THU', headerClass: 'text-center', class: 'text-center'},
    {field: 'friday', header: 'FRI', headerClass: 'text-center', class: 'text-center'},
    {field: 'saturday', header: 'SAT', headerClass: 'text-center', class: 'text-center'},
    {field: 'total', header: 'TOTAL', headerClass: 'text-center' , class: 'text-center'},
    {field: 'average', header: 'AVG', headerClass: 'text-center', class: 'text-center'}
  ]
};

export const StoreDetails = {
  types: [
    {label: 'Bar', value: 'barChart', icon: 'fa fa-fw fa-bar-chart'},
    {label: 'Line', value: 'lineChart', icon: 'fa fa-fw fa-line-chart'}
  ],

  cols: [
    {field: 'week', header: 'WEEK', class: 'weekClass'},
    {field: 'sunday', header: 'SUN'},
    {field: 'monday', header: 'MON'},
    {field: 'tuesday', header: 'TUE'},
    {field: 'wednesday', header: 'WED'},
    {field: 'thursday', header: 'THU'},
    {field: 'friday', header: 'FRI'},
    {field: 'saturday', header: 'SAT'},
    {field: 'total', header: 'TOTAL'},
    {field: 'average', header: 'AVG'}
   ]
};
