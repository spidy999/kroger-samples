import {Component, Input, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Constants} from '@shared/models/constants';
import {SelectItem} from 'primeng/api';
import * as moment from 'moment';
import {Moment} from 'moment';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {BaleProductionService} from '@app/features/cardboard-tracking/services/bale-production/bale-production.service';
import {StoreActivityService} from '@app/features/cardboard-tracking/services/store-activity/store-activity.service';
import {StoreDetails as constants} from '@app/features/cardboard-tracking/models/cardboard-tracking';
import {ChartDetails, GetDcData, ReportDataSet, ReportType} from '@shared/models/reportData';
import {Bale} from '@shared/domain/bale';
import {StoreDetails} from '@features/cardboard-tracking/models/storeDetails';
import {DcActivityService} from '../services/dc-activity/dc-activity.service';
import {DcDetails} from '../models/dcDetails';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {SelectChartOptions} from '@shared/domain/appSettings';
import {DcReport} from '@app/shared/domain/dcReport';
import {MultipleStoresDto} from '@app/shared/domain/multipleStoresDto';

@Component({
  selector: 'app-store-details',
  templateUrl: './store-dc-details.component.html',
  styleUrls: ['./store-dc-details.component.less']
})
export class StoreDcDetailsComponent implements OnInit {

  constructor(public router: Router,
              public user: UserService,
              private util: UtilService,
              private dateService: DateService,
              public modalService: ModalService,
              private dcActivityService: DcActivityService,
              private fiscalDateService: FiscalDateService,
              private storeActivityService: StoreActivityService,
              private cardBoardTrackingReport: BaleProductionService) {
    const {types, cols} = constants;
    this.types = types;
    this.cols = cols;
  }

  public url: any;
  public cols: any;
  public traversedData: any;
  public baleResponse: any = [];
  public storeDetailData: any = [];
  public storeNo: string;
  public selectedType: string;
  public showChart: boolean;
  public disableLoader = false;
  public innerSpinner = false;
  public bales: Bale[];
  public types: SelectItem[];
  public reportData: ChartDetails;
  public sortedDates: Moment[] = [];
  public chartType = SelectChartOptions;
  public selectionItems: SelectChartOptions[];
  private getParams: MultipleStoresDto | GetDcData = new MultipleStoresDto();
  @Input() public graphColors: any;
  @Input() public reportType: ReportType;
  @Input() public tableDetails: StoreDetails | DcDetails;

  private static calculateTotal(data): number {
    return data.reduce((prev, curr) => prev + curr, 0);
  }

  private static calculateAvg(data, count): number {
    let avg;
    if (data && count) {
      avg = (data / count).toFixed(2) || 0;
    }
    return avg;
  }

  private static getSalvageID(id) {
    const startId = 12;
    const endId = 20;
    return id.substring(startId, endId);
  }

  ngOnInit() {
    this.selectionItems = [SelectChartOptions.BAR_CHART, SelectChartOptions.LINE_CHART];
    if (this.tableDetails) {
      switch (this.reportType) {
        case ReportType.STORE_ACTIVITY:
          this.getParams = new MultipleStoresDto();
          this.storeNo = (this.tableDetails as StoreDetails).storeNo;
          this.getParams.stores = [this.storeNo];
          this.getParams.divisionNo = (this.tableDetails as StoreDetails).divisionNo;
          break;
        case ReportType.DC_ACTIVITY:
          this.getParams = new GetDcData();
          this.getParams.facilityId = (this.tableDetails as DcDetails).facilityId;
          break;
      }
      this.runBaleReport();
    }
    this.showChart = false;
    this.disableLoader = false;
  }

  private runBaleReport() {
    this.buildReportData();
  }

  public onSelectionType(evt) {
    if (evt) {
      this.selectedType = evt;
    }
  }

  private buildReportData() {
    switch (this.reportType) {
        case ReportType.STORE_ACTIVITY:
          this.getParams = { ...this.getParams, ...(this.tableDetails as StoreDetails) };
          this.executeStoreActivityReport();
          break;
        case ReportType.DC_ACTIVITY:
          this.getParams = { ...this.getParams, ...(this.tableDetails as DcDetails) };
          this.executeDCActivityReport();
          break;
      }
    }

  private executeStoreActivityReport() {
    const formatter = 'YYYY-MM-DD';
    const dateRange = [
      DateService.getIsoString(this.getParams.startDate, formatter),
      DateService.getIsoString(this.getParams.endDate, formatter)
    ];
    this.innerSpinner = true;
    this.storeActivityService.getBaleCountForMultipleStores(this.getParams as MultipleStoresDto)
      .subscribe(result => {
        this.innerSpinner = false;
        const bales = result;
        this.sortedDates = this.cardBoardTrackingReport.calculateRangeDates(dateRange);
        this.buildData(this.sortedDates, bales);
        this.showChart = true;
        this.disableLoader = true;
      },
        () => {
          this.util.hideSpinner();
          this.disableLoader = true;
        }
      );
    this.getDetailReportOfBale();
  }

  private executeDCActivityReport() {
    const formatter = 'YYYY-MM-DD';
    const dateRange = [
      DateService.getIsoString(this.getParams.startDate, formatter),
      DateService.getIsoString(this.getParams.endDate, formatter)
    ];
    this.innerSpinner = true;
    this.dcActivityService.getBaleCountForDc(this.getParams as GetDcData)
      .subscribe(result => {
        this.innerSpinner = false;
        const dcActivity = result;
        this.sortedDates = this.cardBoardTrackingReport.calculateRangeDates(dateRange);
        this.buildData(this.sortedDates, dcActivity);
        this.showChart = true;
        this.disableLoader = true;
      },
        () => {
          this.util.hideSpinner();
          this.disableLoader = true;
        });
  }

  private getReportData(rangeDates: Moment[], response: Array<any>): ReportDataSet[] {
    const records: ReportDataSet[] = [];
    let colorIndex = 0;
    let index = 0;
    let dates: Moment[] = [];
    this.graphColors = UtilService.getRandomColors(rangeDates.length / Constants.DAYS_IN_WEEK);
    while (index <= rangeDates.length - 1) {
      const color = this.graphColors[colorIndex++];
      dates = rangeDates.slice( index, index + Constants.DAYS_IN_WEEK);
      index = index + Constants.DAYS_IN_WEEK;
      const weekData = response.filter((elem) => {
        let convertedDate: Moment;
        switch (this.reportType) {
          case ReportType.STORE_ACTIVITY:
            convertedDate = moment(elem.reportDate);
            break;
          case ReportType.DC_ACTIVITY:
            convertedDate = moment(elem.insertedDt);
            break;
        }
        return convertedDate.isSameOrAfter(dates[0]) && convertedDate.isSameOrBefore(dates[dates.length - 1]);
      });

      let count = dates.length;
      const krogerDate = this.fiscalDateService.getKrogerWeek(dates[0].toDate());
      records.push(new ReportDataSet(krogerDate, this.buildStoreCountByDay(weekData, count),
        false, color, color));
      count = 0;
    }
    return records;
  }

  private buildData(sortedDates: Moment[], response: Bale[]|DcReport[]): void {
    this.traversedData = this.getReportData(sortedDates, response);
    this.buildTableData(this.traversedData);
    this.reportData = this.buildChartData(this.traversedData);
  }

  private buildTableData(datasets: ReportDataSet[]): void {
    this.storeDetailData = [];
    datasets.forEach(storeDetail => {
      let i = 0;
      const { label, data, divisionNo, district } = storeDetail;
      const result = {
        week: label,
        data: data,
        sunday: data[i++],
        monday: data[i++],
        tuesday: data[i++],
        wednesday: data[i++],
        thursday: data[i++],
        friday: data[i++],
        saturday: data[i++],
        total: data[i++],
        average: data[i++],
        divisionNo: divisionNo,
        district: district
      };
      this.storeDetailData.push(result);
    });
  }

  private buildChartData(traversedData): ChartDetails {
    let data;
    const chartDatasets = traversedData.map(reportDataSet => {
      const dataset = reportDataSet.data;
      return { ...reportDataSet, data: dataset.slice(0, Constants.DAYS_IN_WEEK) };
    });
    data = {
      labels: Constants.DAYS_OF_WEEK,
      datasets: chartDatasets
    };

    return {
      data,
      height: '200px'
    };
  }

  private buildStoreCountByDay(weekData, count): number[] {
    let bales = [];
    let dayData;
    Constants.DAYS_OF_WEEK.forEach(day => {
      dayData = weekData.find(value => value.reportDayOfWeek === day);
      if (dayData) {
        bales.push(dayData.baleCount);
      } else {
        bales.push(0);
      }
    });
    const total = StoreDcDetailsComponent.calculateTotal(bales);
    const avg = StoreDcDetailsComponent.calculateAvg(total, count);
    bales = [...bales, total, avg];
    return bales;
  }

  private getDetailReportOfBale() {
    this.storeActivityService.getDetailReportOfBale(this.getParams as MultipleStoresDto)
      .subscribe(result => {
        this.baleResponse = result;
      },
        () => {});
  }
}
