import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormBuilder, FormsModule} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { StoreDcDetailsComponent } from './store-dc-details.component';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {DistrictService} from '@shared/services/district/district.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {DivisionService} from '@shared/services/division/division.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import { DcActivityService } from '../services/dc-activity/dc-activity.service';
import {StoreActivityService
} from '@features/cardboard-tracking/services/store-activity/store-activity.service';
import {BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {LineChartComponent} from '@app/shared/reports/line-chart/line-chart.component';
import {BarChartComponent} from '@app/shared/reports/bar-chart/bar-chart.component';
import {SelectionTypeComponent} from '@app/templates/selection-type/selection-type.component';

describe('StoreDcDetailsComponent', () => {
  let component: StoreDcDetailsComponent;
  let userService: UserService;
  let utilService: UtilService;
  let dateService: DateService;
  let modalService: ModalService;
  let districtService: DistrictService;
  let divisionService: DivisionService;
  let fiscalDateService: FiscalDateService;
  let storeActivityService: StoreActivityService;
  let cardboardTrackingReportService: BaleProductionService;
  let fixture: ComponentFixture<StoreDcDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        UserService,
        FormBuilder,
        UtilService,
        DateService,
        ModalService,
        FacilityService,
        DistrictService,
        DivisionService,
        DcActivityService,
        FiscalDateService,
        StoreActivityService,
        BaleProductionService
      ],
      declarations: [
        BarChartComponent,
        LineChartComponent,
        SelectionTypeComponent,
        StoreDcDetailsComponent
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreDcDetailsComponent);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    dateService = TestBed.inject(DateService);
    modalService = TestBed.inject(ModalService);
    districtService = TestBed.inject(DistrictService);
    divisionService = TestBed.inject(DivisionService);
    fiscalDateService = TestBed.inject(FiscalDateService);
    storeActivityService = TestBed.inject(StoreActivityService);
    cardboardTrackingReportService = TestBed.inject(BaleProductionService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
