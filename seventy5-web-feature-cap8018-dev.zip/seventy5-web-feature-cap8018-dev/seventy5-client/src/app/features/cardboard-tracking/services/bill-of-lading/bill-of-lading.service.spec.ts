import {skip} from 'rxjs/operators';
import {SelectItem} from 'primeng/api';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {TestBed, inject, async} from '@angular/core/testing';
import { BillOfLadingService } from './bill-of-lading.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';


describe('BillOfLadingService', () => {
  let billOfLadingService: BillOfLadingService;
  let validatorsService: ValidatorsService;
  const destinations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule
    ],
    providers: [
      FormBuilder,
      FacilityService,
      ValidatorsService,
      BillOfLadingService
    ]
    });
  });

  beforeEach(() => {
    billOfLadingService = TestBed.inject(BillOfLadingService);
    validatorsService = TestBed.inject(ValidatorsService);
    billOfLadingService.billOfLadingForm = new FormGroup({
      facilityId: new FormControl(),
      destination: new FormControl(),
      salvageMaterialType: new FormControl(),
      bolId: new FormControl()
    });
  });

  it('should be created', inject([BillOfLadingService], (service: BillOfLadingService) => {
    expect(service).toBeTruthy();
  }));

  it('should validate form', inject([BillOfLadingService],
  (service: BillOfLadingService) => {
    spyOnProperty(service.createForm(), 'valid', 'get').and.returnValue(false);
  }));

  it( 'should fetch salvage BOL report', inject( [ BillOfLadingService, HttpTestingController ],
  ( service: BillOfLadingService, httpMock: HttpTestingController ) => {
    const salvageData = {
      bolId: null,
      destination: null,
      endDate: '2021-04-08 12:00 AM',
      facilityId: 3,
      salvageMaterialType: null,
      startDate: '2018-11-25 12:00 AM',
      status: 'CLOSED'
    };

    const result = [
      {
        bolId: 19009,
        destination: 'Outbound',
        deviceId: 'WEB',
        doorNo: '204',
        facilityId: 3,
        insertedDate: '2019-09-16 03:26 PM',
        insertedEuid: 'ZEN2267',
        reprintBol: false,
        salvageMaterialType: {materialTypeCd: 'BC', materialTypeName: 'Baled Cardboard'},
        salvageQty: 48,
        status: 'CLOSED',
        totalWeight: '39,080',
        trailerNo: '655602',
        updatedDate: '2019-09-17 10:13:03.000',
        updatedEuid: 'ZEN7900'
      },
      {
        bolId: 17987,
        destination: 'Outbound',
        deviceId: 'WEB',
        doorNo: '211',
        facilityId: 4,
        insertedDate: '2019-09-13 01:58 AM',
        insertedEuid: 'ZEN6807',
        reprintBol: false,
        salvageMaterialType: {materialTypeCd: 'BC', materialTypeName: 'Baled Cardboard'},
        salvageQty: 48,
        status: 'CLOSED',
        totalWeight: '39,864',
        trailerNo: '584961',
        updatedDate: '2019-09-17 10:11:12.000',
        updatedEuid: 'ZEN7900'
      }
    ];

    service.salvageBolReport( salvageData ).subscribe( salvage => {
      expect( salvage ).toBeTruthy();
    });
    const req = httpMock.expectOne( `api/salvage/salvageBolReport`);
    expect( req.request.method ).toBe( 'POST' );
    req.flush(result);
  }) );

  it( 'should fetch excel salvage report', inject( [ BillOfLadingService, HttpTestingController ],
  ( service: BillOfLadingService, httpMock: HttpTestingController ) => {
    const salvageData = {
      bolId: null,
      destination: null,
      endDate: '2021-04-08 12:00 AM',
      facilityId: 3,
      salvageMaterialType: null,
      startDate: '2018-11-25 12:00 AM',
      status: 'CLOSED'
    };

    service.excelSalvageReport( salvageData ).subscribe( salvage => {
      expect( salvage ).toBeTruthy();
    });
    const req = httpMock.expectOne( `api/salvage/loadExcelSalvageBol`);
    expect( req.request.method ).toBe( 'POST' );
    req.flush({
      data: true
    });
  }));

  it( 'should fetch salvage Bol report page count', inject( [ BillOfLadingService, HttpTestingController ],
  ( service: BillOfLadingService, httpMock: HttpTestingController ) => {
    const salvageData = {
      bolId: null,
      destination: null,
      endDate: '2021-04-08 12:00 AM',
      facilityId: 3,
      salvageMaterialType: null,
      startDate: '2018-11-25 12:00 AM',
      status: 'CLOSED'
    };

    service.salvageBolReportPageCount( salvageData ).subscribe( salvage => {
      expect( salvage ).toBe(5);
    });
    const req = httpMock.expectOne( `api/salvage/getSalvageBolDataCount` );
    expect( req.request.method ).toBe( 'POST' );
    req.flush(5);
  }) );

  it( 'should fetch salvage Bol report with pagination', inject( [ BillOfLadingService, HttpTestingController ],
  ( service: BillOfLadingService, httpMock: HttpTestingController ) => {
    const salvageData = {
      bolId: null,
      destination: null,
      endDate: '2021-04-08 12:00 AM',
      facilityId: 3,
      salvageMaterialType: null,
      startDate: '2018-11-25 12:00 AM',
      status: 'CLOSED'
    };

    const result = [
      {
        bolId: 19009,
        destination: 'Outbound',
        deviceId: 'WEB',
        doorNo: '204',
        facilityId: 3,
        insertedDate: '2019-09-16 03:26 PM',
        insertedEuid: 'ZEN2267',
        reprintBol: false,
        salvageMaterialType: {materialTypeCd: 'BC', materialTypeName: 'Baled Cardboard'},
        salvageQty: 48,
        status: 'CLOSED',
        totalWeight: '39,080',
        trailerNo: '655602',
        updatedDate: '2019-09-17 10:13:03.000',
        updatedEuid: 'ZEN7900'
      },
      {
        bolId: 17987,
        destination: 'Outbound',
        deviceId: 'WEB',
        doorNo: '211',
        facilityId: 4,
        insertedDate: '2019-09-13 01:58 AM',
        insertedEuid: 'ZEN6807',
        reprintBol: false,
        salvageMaterialType: {materialTypeCd: 'BC', materialTypeName: 'Baled Cardboard'},
        salvageQty: 48,
        status: 'CLOSED',
        totalWeight: '39,864',
        trailerNo: '584961',
        updatedDate: '2019-09-17 10:11:12.000',
        updatedEuid: 'ZEN7900'
      }
    ];
    const pageIndex = 3;
    const pageOffset = 15;

    service.salvageBolReportWithPagination( salvageData, pageIndex, pageOffset ).subscribe( salvage => {
      expect( salvage[0].facilityId ).toEqual(3);
      expect( salvage[0].insertedEuid ).toEqual('ZEN2267');
    });
    const req = httpMock.expectOne( `api/salvage/getSalvageBolData/${pageIndex}/${pageOffset}` );
    expect( req.request.method ).toBe( 'POST' );
    req.flush(result);
  }) );

  it('should test destination$ Subject', async(() => {
  inject([BillOfLadingService], (service: BillOfLadingService) => {

    const destinations = [
      { label: 'ALL', value: '' },
      { label: 'ANEX1', value: 'ANEX1' },
      { label: 'ANEX2', value: 'ANEX2' },
      { label: 'SCRAP YARD-1', value: 'SCRAP YARD-1' },
      { label: 'SCRAP YARD-2 (SALVAGE)', value: 'SCRAP YARD-2 (SALVAGE)' }
    ];

    destinations$.next(destinations);

    spyOn(billOfLadingService, 'getDestinations')
      .and.returnValue(destinations$);

    service.getDestinations().pipe(skip(1))
      .subscribe((o) => {
        expect(o).toBe(destinations);
      });
    });
  }));

});
