import { TestBed, inject } from '@angular/core/testing';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import { BaleProductionService } from './bale-production.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';


describe('BaleProductionService', () => {
  let reportService: BaleProductionService;
  let utilService: UtilService;
  const REPORTDATA = {
    'divisionNo': '014',
    'endDate': '2019-02-09 11:12 AM',
    'startDate': '2019-02-03 11:12 AM'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BaleProductionService, UtilService, DateService, FiscalDateService]
    });
  });

  beforeEach(() => {
    utilService = TestBed.inject(UtilService);
    reportService = TestBed.inject(BaleProductionService);
  });

  it('should be created', inject([BaleProductionService], (service: BaleProductionService) => {
    expect(service).toBeTruthy();
  }));

  it('should get detail report of bale for division', inject([BaleProductionService, HttpTestingController],
    (service: BaleProductionService, httpMock: HttpTestingController) => {
      service.getDetailReportOfBaleForDivision(REPORTDATA)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/report/BaleProduction/baleReport/`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [
        {statusInfo: {exitStatus: 'SUCCESS', messages: []},
          hasDataPayload: true, data: ''}]});
      httpMock.verify();
    }));

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));
});
