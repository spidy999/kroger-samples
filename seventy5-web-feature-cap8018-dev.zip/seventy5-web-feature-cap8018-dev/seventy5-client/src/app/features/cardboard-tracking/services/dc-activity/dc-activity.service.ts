import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import { DcReport } from '@app/shared/domain/dcReport';

@Injectable()
export class DcActivityService {

  constructor(private http: HttpClient) { }

  getBaleCountForDc(getValues: {
    startDate: string,
    endDate: string,
    facilityId: number
  }): Observable<DcReport[]> {
    return this.http.get<DcReport[]>(`api/report/balesCreatedAtDC/${getValues.startDate}/
      ${getValues.endDate}/${getValues.facilityId}`);
  }
}
