import {SelectItem} from 'primeng/api';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {map, share} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FacilityData} from '@shared/domain/facilityData';
import {SearchBolData} from '@shared/models/searchBolData';
import { SalvageBol } from '@features/salvage/domain/salvageBol';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {DateService} from '@shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';

@Injectable()
export class BillOfLadingService {
  public billOfLadingForm: FormGroup;
  private materialTypes$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private destinations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private facility$: BehaviorSubject<FacilityData> = new BehaviorSubject<FacilityData>(null);

  constructor(private fb: FormBuilder,
              private http: HttpClient,
              private dateService: DateService,
              private validator: ValidatorsService,
              private facilityService: FacilityService) { }

  /*Salvage Bill of Lading Report service calls*/
  salvageBolReport(getValues: SearchBolData): Observable<SalvageBol[]> {
    return this.http.post<SalvageBol[]>('api/salvage/salvageBolReport', getValues )
    .pipe(share());
  }

  /*Salvage Bill of Lading Report service calls for cache*/
  excelSalvageReport(getValues: SearchBolData): Observable<boolean> {
    return this.http.post<boolean>('api/salvage/loadExcelSalvageBol', getValues )
      .pipe(share());
  }

  /*Salvage Bill of Lading Report service calls to get the page count */
  salvageBolReportPageCount(getValues: SearchBolData): Observable<number> {
    return this.http.post<number>('api/salvage/getSalvageBolDataCount', getValues );
  }

  /*Salvage Bill of Lading Report service calls with pagination */
  salvageBolReportWithPagination(getValues: SearchBolData, pageIndex, pageOffset): Observable<SalvageBol[]> {
    return this.http.post<SalvageBol[]>(`api/salvage/getSalvageBolData/${pageIndex}/${pageOffset}`, getValues)
      .pipe(share());
  }

  createForm(): FormGroup {
    this.billOfLadingForm = this.fb.group({
      facilityId: [null, [Validators.required], [this.validateFacilityId.bind(this)]],
      destination: [''],
      salvageMaterialType: [''],
      bolId: [null,  ValidatorsService.bolIdValidations],
    });
    return this.billOfLadingForm;
  }

  private validateFacilityId(control: AbstractControl) {
    return this.facilityService.getFacilityDataById(control.value).pipe(
      map((facility: FacilityData) => {
        this.facility$.next(facility);
        const destinations = [{label: 'ALL', value: ''}];
        const materialTypes = [{ label: 'ALL', value: ''}];

        if (facility && facility.destinations) {
          this.destinations$.next([...destinations, ...facility.destinations.map( dest => ({
            label: dest, value: dest
          }))]);
        }

        if (facility && facility.materialTypes) {
          this.materialTypes$.next([ ...materialTypes, ...facility.materialTypes.map( type => ({
            label: type.materialTypeName, value: type
          }))]);
        }
        this.billOfLadingForm.get('destination').patchValue('');
        this.billOfLadingForm.get('salvageMaterialType').patchValue('');
        this.billOfLadingForm.updateValueAndValidity();
        return null;
      })
    );
  }

  getDestinations(): BehaviorSubject<SelectItem[]> {
    return this.destinations$;
  }

  getMaterialTypes(): BehaviorSubject<SelectItem[]> {
    return this.materialTypes$;
  }
}
