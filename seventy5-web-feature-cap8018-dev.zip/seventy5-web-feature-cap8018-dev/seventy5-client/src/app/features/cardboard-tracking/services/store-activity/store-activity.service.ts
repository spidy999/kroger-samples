import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { Bale } from '@shared/domain/bale';
import { BaleDetails } from '@shared/domain/baleDetails';
import { MultipleStoresDto } from '@app/shared/domain/multipleStoresDto';

@Injectable()
export class StoreActivityService {

  constructor(private http: HttpClient) { }

  getBaleCountForMultipleStores(multipleStore: MultipleStoresDto): Observable<Bale[]> {
    return this.http.post<Bale[]>
    ('api/report/baleReportForMultipleStores', multipleStore);
  }

  getDetailReportOfBale(multipleStore: MultipleStoresDto): Observable<BaleDetails[]> {
    return this.http.post<BaleDetails[]>('api/report/getDetailReportOfBale/', multipleStore);
  }

}
