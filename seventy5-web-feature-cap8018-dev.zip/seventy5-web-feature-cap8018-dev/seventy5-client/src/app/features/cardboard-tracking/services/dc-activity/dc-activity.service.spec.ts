import {DcReport} from '@shared/domain/dcReport';
import { TestBed, inject } from '@angular/core/testing';
import { DcActivityService } from './dc-activity.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {HttpClient} from '@angular/common/http';

describe('DcActivityService', () => {
  let dcActivityService: DcActivityService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpClient,
        DcActivityService
      ]
    });
  });

  beforeEach(() => {
    dcActivityService = TestBed.inject(DcActivityService);
  });

  it('should be created', inject([DcActivityService], (service: DcActivityService) => {
    expect(service).toBeTruthy();
  }));

  it( 'should fetch DC reports', inject( [ DcActivityService, HttpTestingController ],
    ( service: DcActivityService, httpMock: HttpTestingController ) => {
      const dcData = {
        startDate: '2019-02-24 12:00 AM',
        endDate: '2021-04-12 12:00 AM',
        facilityId:  2
      };
      const result: DcReport[] = [
        {
          baleCount: 1,
          facility: 2,
          facilityName: 'Second DC',
          insertedDt: '2019-11-16T00:00:00',
          reportDayOfWeek: 'SATURDAY'
        }
      ];

      service.getBaleCountForDc(dcData).subscribe( salvage => {
        expect( salvage[0].facility ).toEqual(2);
        expect( salvage ).toBeTruthy();
      });
      const req = httpMock.expectOne(() => {
        return true;
      });
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));
});
