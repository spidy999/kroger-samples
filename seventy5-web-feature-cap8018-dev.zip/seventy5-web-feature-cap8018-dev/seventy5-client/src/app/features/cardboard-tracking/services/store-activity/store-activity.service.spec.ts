import { TestBed, inject } from '@angular/core/testing';
import { StoreActivityService } from './store-activity.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('StoreActivityService', () => {

  let storeActivityService: StoreActivityService;

  const REPORT_DATA = {
    'divisionNo': '014',
    'stores': ['00441', '00430'],
    'startDate': '2018-08-03',
    'endDate': '2018-08-012',
    locations: [ {
      divisionNo: '014',
      district: '015',
      store: '00441'
    }, {
      divisionNo: '014',
      district: '015',
      store: '00430'
    }]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [StoreActivityService]
    });
  });

  beforeEach(() => {
    storeActivityService = TestBed.inject(StoreActivityService);
  });


  it('should be created', inject([StoreActivityService], (service: StoreActivityService) => {
    expect(service).toBeTruthy();
  }));

  it('should get bale count for multiple stores', inject([StoreActivityService, HttpTestingController],
    (service: StoreActivityService, httpMock: HttpTestingController) => {
      service.getBaleCountForMultipleStores(REPORT_DATA)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/report/baleReportForMultipleStores`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': true, 'data': ''}]});
      httpMock.verify();
    }));

  it('should get detail report of bale', inject([StoreActivityService, HttpTestingController],
    (service: StoreActivityService, httpMock: HttpTestingController) => {
      service.getDetailReportOfBale(REPORT_DATA)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/report/getDetailReportOfBale/`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': true, 'data': ''}]});
      httpMock.verify();
    }));

  afterEach(inject([HttpTestingController], (httpMock: HttpTestingController) => {
    httpMock.verify();
  }));
});
