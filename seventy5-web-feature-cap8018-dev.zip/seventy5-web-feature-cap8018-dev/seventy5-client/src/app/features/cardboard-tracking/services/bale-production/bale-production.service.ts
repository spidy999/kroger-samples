import * as moment from 'moment';
import { Moment } from 'moment';
import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import {ChartDetails, Dataset, GetDistrictData, GetDistrictDetailData} from '@shared/models/reportData';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {
  DivisionTrendLineResponse
} from '@features/cardboard-tracking/domain/divisionTrendLineResponse';
import { DivisionTrendLine } from '@features/cardboard-tracking/domain/divisionTrendLine';
import {BaleReport} from '@features/cardboard-tracking/domain/baleReport';
import { DcDetailedTrendLine } from '@features/cardboard-tracking/domain/dcDetailedTrendLine';
import {BaleProductionDetails} from '@features/cardboard-tracking/models/baleProductionDetails';
import {BaleProductionOptions} from '@features/cardboard-tracking/models/baleProduction';

const LINE_TENSION = 0.0;
const CINCINNATI_DIVISION = '014';

@Injectable()
export class BaleProductionService {

  constructor(
    private http: HttpClient,
    private util: UtilService,
    private dateService: DateService,
    private fiscalDateService: FiscalDateService) {}

  private static calculateStoreVsDcPercentageDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let storeVsDcPercentage;
    if (data && data.variance) {
      storeVsDcPercentage = data.variance;
    }
    return Math.round(storeVsDcPercentage);
  }

  private static calculateStoreVsSensorPercentageDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let storeVsSensorPercentage;
    if (data && data.sensorVariance) {
      storeVsSensorPercentage = data.sensorVariance;
    }
    return Math.round(storeVsSensorPercentage);
  }

  private static calculateTrendLineRangeValues(data: number[]): {maxRange: number, minRange: number} {
    return {
      minRange: Math.min(...data),
      maxRange: Math.max(...data)
    };
  }

  private static calculateDcScanCountDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let dcScanCount = 0;
    if (data && data.dcScanCount) {
      dcScanCount =  data.dcScanCount;
    }
    return dcScanCount;
  }

  private static calculateTotalWeightDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let totalWeightCount = 0;
    if (data && data.actualWeight) {
      totalWeightCount = data.actualWeight;
    }
    return totalWeightCount;
  }

  private static calculateStoreScanCountDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let storeScanCount = 0;
    if (data && data.storeScanCount) {
      storeScanCount = data.storeScanCount;
    }
    return storeScanCount;
  }

  private static calculateSensorBalesDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let sensorBales = 0;
    if (data && data.baleSensorCount) {
      sensorBales = data.baleSensorCount;
    }
    return sensorBales;
  }

  /*calculateKrogerWeekWiseUnWeighedBales helps to calculate the unWeighed Bales and use it for Average Weight Calculation */
  private static calculateKrogerWeekWiseUnWeighedBales(label: string, date: string, dataset: number):
    Array<{label: string, krogerDate: string, data: number}> {
    const unWeighedData = [];
    unWeighedData.push( {
      label: label,
      krogerDate: date,
      data: dataset
    });
    return unWeighedData;
  }

  private static calculateAvgWeightDataset(data: DivisionTrendLine| DcDetailedTrendLine): number {
    let averageWeight = 0;
    if (data && data.averageWeight) {
      averageWeight = data.averageWeight;
    }
    return averageWeight;
  }

  /*Bale Production service calls*/
  getDetailReportOfBaleForDivision(data: GetDistrictData): Observable<BaleReport> {

    /*Bale Production Trend line for Each Division */
    return this.http.post<BaleReport>('api/report/BaleProduction/baleReport/', data);
  }

  getBaleProductionAllDivisionTrendLine(data: GetDistrictData): Observable<DivisionTrendLineResponse> {
    /*Bale Production Trend line for All Division */
    return this.http.post<DivisionTrendLineResponse>('api/report/BaleProduction/DivisionTrendLine/', data);
  }

  /*Bale Production Details Service calls*/
  getDetailReportOfBaleForDistrict(data: GetDistrictDetailData): Observable<any> {
    return this.http.post<any>('api/report/BaleProduction/baleReportForDistrict/', data);
  }

  calculateRangeDates(givenDates: string []): Moment[] {
    const dates: Moment[] = [];
    const momentStart = moment(givenDates[0]);
    const momentEnd = moment(givenDates[1]);
    if (givenDates && momentStart.isSameOrBefore(momentEnd)) {
      while (momentStart.isSameOrBefore(momentEnd)) {
        dates.push(moment(momentStart));
        momentStart.add(1, 'd');
      }
    }
    return dates;
  }

  getBaleReportForEachDivisionTrendLineData(response: BaleReport, randomColor) {
    let label: string;
    let labels = [];
    const dcScans = [];
    const storeScans = [];
    const totalWeight = [];
    const storeVsDcPercentage = [];

    if (response) {
      if (response.baleReportTrendLines) {
        response.baleReportTrendLines.forEach( (data) => {
          if (data.districtCode) {
            label = data.districtCode;
            const dcScanDataset = [];
            const storeScanDataset = [];
            const totalWeightDataset = [];
            const storeVsDcPercentageDataset = [];

            data.detailTrendLine.forEach( (eachItem) => {
              const krogerDate = this.fiscalDateService.getKrogerWeek(eachItem.insertedDate);
              labels.push(krogerDate);
              dcScanDataset.push(BaleProductionService.calculateDcScanCountDataset(eachItem));
              storeScanDataset.push(BaleProductionService.calculateStoreScanCountDataset(eachItem));
              totalWeightDataset.push(BaleProductionService.calculateTotalWeightDataset(eachItem));
              storeVsDcPercentageDataset.push(BaleProductionService.calculateStoreVsDcPercentageDataset(eachItem));
            });

            labels = labels.filter( (x, i, a) => a.indexOf(x) === i);
            dcScans.push({ label: 'District ' + label, dataset: dcScanDataset});
            storeScans.push({ label: 'District ' + label, dataset: storeScanDataset});
            totalWeight.push({ label: 'District ' + label, dataset: totalWeightDataset});
            storeVsDcPercentage.push({ label: 'District ' + label, dataset: storeVsDcPercentageDataset});
          }
        });
      }
    }

    labels = labels.filter( (x, i, a) => a.indexOf(x) === i);

    const dcScanData = this.calculateTrendLineChart(dcScans, randomColor);
    const storeScanData = this.calculateTrendLineChart(storeScans, randomColor);
    const totalWeightData = this.calculateTrendLineChart(totalWeight, randomColor);
    const storeVsDcPercentageData = this.calculateTrendLineChart(storeVsDcPercentage, randomColor);

    return {
      labels: labels,
      dcScanCount: dcScanData,
      storeScanCount: storeScanData,
      totalWeightCount: totalWeightData,
      storeVsDcPercentage: storeVsDcPercentageData
    };
  }

  getBaleReportForAllDivisionsTrendLineData(response: DivisionTrendLineResponse, randomColor) {
    let label: string;
    let dateArray = [];
    let labels = [];
    const dcScans = [];
    const storeScans = [];
    const totalWeight = [];
    const storeVsDcPercentage = [];

    if (response) {
       if (response.divisionTrendLineDto) {

         dateArray = response.divisionTrendLineDto
           .reduce((prev, curr) => [...prev, ...curr.divisionTrendLineList], [])
           .map(trend => trend.weeklyDate)
           .filter((x, i, a) => a.indexOf(x) === i)
           .sort((a, b) => {
             if (moment(a).isBefore(b)) {
               return -1;
             } else if (moment(a).isSame(b)) {
               return 0;
             } else { return 1; }
           });

         labels = dateArray.map( date => {
           return this.fiscalDateService.getKrogerWeek(date);
         });

        response.divisionTrendLineDto.forEach( (data) => {
          if (data.divisionName) {
            label = data.divisionName;

            const dcScanDataset = dateArray.map(date =>
              data.divisionTrendLineList.find(trendLineData => trendLineData.weeklyDate === date))
              .map(result => result ? result.dcScanCount : 0);

            const storeScanDataset = dateArray.map(date =>
              data.divisionTrendLineList.find(trendLineData => trendLineData.weeklyDate === date))
              .map(result => result ? result.storeScanCount : 0);

            const totalWeightDataset = dateArray.map(date =>
              data.divisionTrendLineList.find(trendLineData => trendLineData.weeklyDate === date))
              .map(result => result ? result.actualWeight : 0);

            const storeVsDcPercentageDataset = dateArray.map(date =>
              data.divisionTrendLineList.find(trendLineData => trendLineData.weeklyDate === date))
              .map(result => result ? result.variance : 0);

            dcScans.push({ label: label, dataset: dcScanDataset});
            storeScans.push({ label: label, dataset: storeScanDataset});
            totalWeight.push({ label: label, dataset: totalWeightDataset});
            storeVsDcPercentage.push({ label: label, dataset: storeVsDcPercentageDataset});
          }
        });
      }
    }

    const dcScanData = this.calculateTrendLineChart(dcScans, randomColor);
    const storeScanData = this.calculateTrendLineChart(storeScans, randomColor);
    const totalWeightData = this.calculateTrendLineChart(totalWeight, randomColor);
    const storeVsDcPercentageData = this.calculateTrendLineChart(storeVsDcPercentage, randomColor);

    return {
      labels: labels,
      dcScanCount: dcScanData,
      storeScanCount: storeScanData,
      totalWeightCount: totalWeightData,
      storeVsDcPercentage: storeVsDcPercentageData
    };
  }

  getSensorBaleReportForEachDivisionTrendLineData(response: BaleReport, randomColor) {
    let label: string;
    let labels = [];
    let dateArray = [];
    const storeVsSensorPercentage = [];
    const sensorBaleCount = [];

    if (response) {
      if (response.sensorBaleReportTrendLines) {
        dateArray = response.sensorBaleReportTrendLines
          .reduce((prev, curr) => [...prev, ...curr.sensorDetailedTrendLine], [])
          .map(trend => trend.insertedDate)
          .filter((x, i, a) => a.indexOf(x) === i)
          .sort((a, b) => {
            if (moment(a).isBefore(b)) {
              return -1;
            } else if (moment(a).isSame(b)) {
              return 0;
            } else {
              return 1;
            }
          });
        labels = dateArray.map( date => {
          return this.fiscalDateService.getKrogerWeek(date);
        });

        response.sensorBaleReportTrendLines.forEach((data) => {
          if (data.districtCode) {
            label = data.districtCode;

            const sensorBaleCountWithDistrictDataset = dateArray.map(date =>
              data.sensorDetailedTrendLine.find(trendLineData => trendLineData.insertedDate === date))
              .map(result => result ? result.sensorBaleCount : 0);

            sensorBaleCount.push({label: 'District ' + label, dataset: sensorBaleCountWithDistrictDataset});
          }
        });
      }

      if (response.baleReportTrendLines) {
        response.baleReportTrendLines.forEach( (data) => {
          label = data.districtCode;
          const storeVsSensorPercentageWithDistrictDataset = [];
          data.detailTrendLine.forEach( (eachItem) => {
            storeVsSensorPercentageWithDistrictDataset.push(
              this.calculateStoreVsSensorPercentageForEachDivisionDataset(eachItem, sensorBaleCount));
          });
          storeVsSensorPercentage.push({ label: 'District ' + label, dataset: storeVsSensorPercentageWithDistrictDataset});
        });

      }
    }

    const sensorBaleCountData = this.calculateTrendLineChart(sensorBaleCount, randomColor);
    const storeVsSensorPercentageData = this.calculateTrendLineChart(storeVsSensorPercentage, randomColor);

    return {
      labels: labels,
      sensorBaleCount: sensorBaleCountData,
      storeVsSensorPercentage: storeVsSensorPercentageData,
    };
  }

  getUnWeighedBaleReportForEachDivisionTrendLineData(response: BaleReport, randomColor) {
    let label: string;
    let labels = [];
    let dateArray = [];
    const avgWeight = [];
    const balesWithoutWeight = [];

    if (response) {
      if (response.baleReportUnWeighTrendLines) {
        dateArray = response.baleReportUnWeighTrendLines
          .reduce((prev, curr) => [...prev, ...curr.dcUnWeighTrendLines], [])
          .map(trend => trend.insertedDate)
          .filter((x, i, a) => a.indexOf(x) === i)
          .sort((a, b) => {
            if (moment(a).isBefore(b)) {
              return -1;
            } else if (moment(a).isSame(b)) {
              return 0;
            } else {
              return 1;
            }
          });

        labels = dateArray.map( date => {
          return this.fiscalDateService.getKrogerWeek(date);
        });

        response.baleReportUnWeighTrendLines.forEach((data) => {
          if (data.districtCode) {
            label = data.districtCode;

            const balesWithoutWeightWithDistrictDataset = dateArray.map(date =>
              data.dcUnWeighTrendLines.find(trendLineData => trendLineData.insertedDate === date))
              .map(result => result ? result.notWeighedCount : 0);

            balesWithoutWeight.push({label: 'District ' + label, dataset: balesWithoutWeightWithDistrictDataset});
          }
        });
      }

      if (response.baleReportTrendLines) {
        response.baleReportTrendLines.forEach( (data) => {
          label = data.districtCode;
          const avgWeightWithDistrictDataset = [];
          data.detailTrendLine.forEach( (eachItem) => {
            avgWeightWithDistrictDataset.push(BaleProductionService.calculateAvgWeightDataset(eachItem));
          });
          avgWeight.push({ label: 'District ' + label, dataset: avgWeightWithDistrictDataset});
        });

      }
    }

    const balesWithoutWeightData = this.calculateTrendLineChart(balesWithoutWeight, randomColor);
    const avgWeightData = this.calculateTrendLineChart(avgWeight, randomColor);

    return {
      labels: labels,
      balesWithoutWeightCount: balesWithoutWeightData,
      avgWeightCount: avgWeightData,
   };
  }

  getSensorBaleReportForAllDivisionsTrendLineData(response: DivisionTrendLineResponse, randomColor) {
    let label: string;
    let labels = [];
    let dateArray = [];
    const storeVsSensorPercentage = [];
    const sensorBaleCount = [];

    if (response) {
      if (response.divisionBaleSensorDto) {
        dateArray = response.divisionBaleSensorDto
          .reduce((prev, curr) => [...prev, ...curr.divisionBaleSensorTrendLines], [])
          .map(trend => trend.weeklyDate)
          .filter((x, i, a) => a.indexOf(x) === i)
          .sort((a, b) => {
            if (moment(a).isBefore(b)) {
              return -1;
            } else if (moment(a).isSame(b)) {
              return 0;
            } else { return 1; }
          });

        labels = dateArray.map( date => {
          return this.fiscalDateService.getKrogerWeek(date);
        });
        response.divisionBaleSensorDto.forEach( (data) => {
          if (data.divisionName) {
            label = data.divisionName;
            const sensorBaleCountDataset = dateArray.map(date =>
              data.divisionBaleSensorTrendLines.find(trendLineData => trendLineData.weeklyDate === date))
              .map(result => result ? result.sensorBaleCount : 0);
            sensorBaleCount.push({ label: label, dataset: sensorBaleCountDataset});
          }
        });
      }
      if (response.divisionTrendLineDto) {
        response.divisionTrendLineDto.forEach( (data) => {
          label = data.divisionName;
          const storeVsSensorPercentageDataset = [];

          data.divisionTrendLineList.forEach( (eachItem) => {
            storeVsSensorPercentageDataset.push(this.calculateStoreVsSensorPercentageForAllDivisionDataset(eachItem, sensorBaleCount));
          });
          storeVsSensorPercentage.push({ label: label, dataset: storeVsSensorPercentageDataset});
        });
      }
    }

    const sensorBaleCountData = this.calculateTrendLineChart(sensorBaleCount, randomColor);
    const storeVsSensorPercentageData = this.calculateTrendLineChart(storeVsSensorPercentage, randomColor);

    return {
      labels: labels,
      sensorBaleCount: sensorBaleCountData,
      storeVsSensorPercentage: storeVsSensorPercentageData,
    };
  }

  getUnWeighedBaleReportForAllDivisionsTrendLineData(response: DivisionTrendLineResponse, randomColor) {
    let label: string;
    let labels = [];
    let dateArray = [];
    const avgWeight = [];
    const balesWithoutWeight = [];

    if (response) {

      if (response.divisionUnWeightDto) {
        dateArray = response.divisionUnWeightDto
          .reduce((prev, curr) => [...prev, ...curr.divisionUnWeightTrendlines], [])
          .map(trend => trend.weeklyDate)
          .filter((x, i, a) => a.indexOf(x) === i)
          .sort((a, b) => {
            if (moment(a).isBefore(b)) {
              return -1;
            } else if (moment(a).isSame(b)) {
              return 0;
            } else { return 1; }
          });

        labels = dateArray.map( date => {
          return this.fiscalDateService.getKrogerWeek(date);
        });

        response.divisionUnWeightDto.forEach( (data) => {
           if (data.divisionName) {
            label = data.divisionName;
             const balesWithoutWeightWithDivisionDataset = dateArray.map(date =>
               data.divisionUnWeightTrendlines.find(trendLineData => trendLineData.weeklyDate === date))
               .map(result => result ? result.unWeightBaleCount : 0);

             balesWithoutWeight.push({ label: label, dataset: balesWithoutWeightWithDivisionDataset});
          }
        });
      }

      if (response.divisionTrendLineDto) {
        response.divisionTrendLineDto.forEach( (data) => {
          label = data.divisionName;
          const avgWeightWithDivisionDataset = [];
          data.divisionTrendLineList.forEach( (eachItem) => {
            avgWeightWithDivisionDataset.push(BaleProductionService.calculateAvgWeightDataset(eachItem));
          });
          avgWeight.push({ label: label, dataset: avgWeightWithDivisionDataset});
        });
      }
    }

    const balesWithoutWeightData = this.calculateTrendLineChart(balesWithoutWeight, randomColor);
    const avgWeightData = this.calculateTrendLineChart(avgWeight, randomColor);

    return {
      labels: labels,
      balesWithoutWeightCount: balesWithoutWeightData,
      avgWeightCount: avgWeightData,
      };
  }

  calculateRandomColors(response): string[] {
    let randomColor = [];
    if (response.unWeighTrendLines) {
     randomColor = UtilService.getRandomColors(response.unWeighTrendLines.length);
    } else if (response.baleReportTrendLines) {
     randomColor = UtilService.getRandomColors(response.baleReportTrendLines.length);
    } else if (response.divisionTrendLineDto) {
     randomColor = UtilService.getRandomColors(response.divisionTrendLineDto.length);
    }
    return randomColor;
  }

  private calculateStoreVsSensorPercentageForEachDivisionDataset(data: DcDetailedTrendLine, sensors): number {
    let storeVsSensorPercentage;
    let sensorObj = <{label: string, dataset: []}>{};
    let sensorCount = 0;
    if (data && data.storeScanCount && sensors && sensors.length > 0) {
      sensorObj = sensors.find(s => {
        const district = 'District ' + data.district;
        if (s.label === district) {
          return s;
        }});
      if (sensorObj && sensorObj.dataset) {
        sensorCount = sensorObj.dataset[sensorCount];
      }
    }
    storeVsSensorPercentage = (sensorCount * 100) / data.storeScanCount;
    return Math.round(storeVsSensorPercentage);
  }

  private calculateStoreVsSensorPercentageForAllDivisionDataset(data: DivisionTrendLine, sensors): number {
    let storeVsSensorPercentage;
    let sensorObj = <{label: string, dataset: []}>{};
    let sensorCount = 0;
    if (data && data.storeScanCount && sensors && sensors.length > 0) {
       sensorObj = sensors.find(s => {
        if (s.label === data.divisionName) {
          return s;
        }});
      if (sensorObj && sensorObj.dataset) {
        sensorCount = sensorObj.dataset[sensorCount];
      }
    }
    storeVsSensorPercentage = (sensorCount * 100) / data.storeScanCount;
    return Math.round(storeVsSensorPercentage);
  }

  private calculateTrendLineChart(givenData, randomColor): Dataset[] {
    let chartData;
    chartData =  givenData.map((data, index) => {
      const color = randomColor[index];
      const label = data.label;
      const dataset = data.dataset;
      return new Dataset(dataset,
        false,
        label,
        color,
        color,
        color,
        'line', null,
        [],
        null,
        LINE_TENSION
        );
    });
    return chartData;
  }

  public calculateTrendLineDataset(dataset: Dataset[], labels: any): ChartDetails {
    let data;
    data = {
      labels: labels,
      datasets: dataset
    };

    return  {
      data,
      height: '400px'
    };
  }

  calculateBaleProductionTrendLineChart(baleReportData, sensorBaleReportData, unWeighedBaleReportData): BaleProductionDetails {
    const { labels, storeVsDcPercentage, dcScanCount,
      storeScanCount, totalWeightCount} = baleReportData;

    const { sensorBaleCount, storeVsSensorPercentage } = sensorBaleReportData;

    const { balesWithoutWeightCount, avgWeightCount} = unWeighedBaleReportData;

    const dcScansData = this.calculateTrendLineDataset(dcScanCount, labels);
    const avgWeightData = this.calculateTrendLineDataset(avgWeightCount, labels);
    const storeScansData = this.calculateTrendLineDataset(storeScanCount, labels);
    const totalWeightData = this.calculateTrendLineDataset(totalWeightCount, labels);
    const sensorsBaleData = this.calculateTrendLineDataset(sensorBaleCount, labels);
    const storeVsDcPercentageData = this.calculateTrendLineDataset(storeVsDcPercentage, labels);
    const balesWithoutWeightData = this.calculateTrendLineDataset(balesWithoutWeightCount, labels);
    const storeVsSensorsPercentageData = this.calculateTrendLineDataset(storeVsSensorPercentage, labels);

    return {
      dcScansData,
      avgWeightData,
      storeScansData,
      totalWeightData,
      sensorsBaleData,
      balesWithoutWeightData,
      storeVsDcPercentageData,
      storeVsSensorsPercentageData
    };
  }

  calculateBaleProductionDistrictTableData(response: BaleReport, division: string): BaleProductionOptions[] {
    const tableData = [];
    let districtDetails;
    if (response) {
      const districts = response.districtDetails;
      districts.forEach( baleProductionData => {
        const {districtCode, storeScanCount, baleSensorCount, sensorVariance, actualWeight,
               dcScanCount, variance, averageWeight, notWeighedCount} = baleProductionData;
        if (division === CINCINNATI_DIVISION) {
          districtDetails = {
            district:       districtCode,
            storeScans:     storeScanCount.toLocaleString('en'),
            dcScans:        dcScanCount.toLocaleString('en'),
            actualWeight:   actualWeight.toLocaleString('en'),
            avgWeight:      averageWeight.toLocaleString('en'),
            unWeighedBales: notWeighedCount.toLocaleString('en'),
            baleSensorCount: baleSensorCount.toLocaleString('en'),
            variance:       variance,
            sensorVariance:  sensorVariance,
          };
        } else {
          districtDetails = {
            district:       districtCode,
            storeScans:     storeScanCount.toLocaleString('en'),
            baleSensorCount: baleSensorCount.toLocaleString('en'),
            sensorVariance:  sensorVariance
          };
        }
        tableData.push(districtDetails);
      });
    }
    return tableData;
  }
}
