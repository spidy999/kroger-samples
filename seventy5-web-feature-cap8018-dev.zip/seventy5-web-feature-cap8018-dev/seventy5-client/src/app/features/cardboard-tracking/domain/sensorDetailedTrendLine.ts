export class SensorDetailedTrendLine {
  districtCode: string;
  insertedDate: string;
  sensorBaleCount: number;
}
