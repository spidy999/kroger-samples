import {DivisionBaleSensorTrendLine} from '@features/cardboard-tracking/domain/divisionBaleSensorTrendLine';

export class DivisionBaleSensorDto {
  divisionName: string;
  divisionBaleSensorTrendLines: DivisionBaleSensorTrendLine[];
}
