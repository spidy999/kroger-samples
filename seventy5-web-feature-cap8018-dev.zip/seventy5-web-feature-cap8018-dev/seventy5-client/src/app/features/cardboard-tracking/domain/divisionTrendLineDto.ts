import { DivisionTrendLine } from './divisionTrendLine';

export class DivisionTrendLineDto {
    divisionName: string;
    divisionTrendLineList: DivisionTrendLine[];
}
