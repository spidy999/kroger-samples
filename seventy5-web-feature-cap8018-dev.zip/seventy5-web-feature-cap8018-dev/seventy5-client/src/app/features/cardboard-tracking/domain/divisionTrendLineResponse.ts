import { DivisionUnWeightDto } from './divisionUnWeightDto';
import { DivisionTrendLineDto } from './divisionTrendLineDto';
import {DivisionBaleSensorDto} from './divisionBaleSensorDto';

export class DivisionTrendLineResponse {
    divisionTrendLineDto: DivisionTrendLineDto[];
    divisionBaleSensorDto: DivisionBaleSensorDto[];
    divisionUnWeightDto: DivisionUnWeightDto[];
}
