export class DivisionUnWeightTrendline {
    divisionName: string;
    weeklyDate: string;
    unWeightBaleCount: number;
}
