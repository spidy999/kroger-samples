export class DivisionTrendLine {
    divisionNo: string;
    divisionName: string;
    weeklyDate: string;
    storeScanCount: number;
    dcScanCount: number;
    actualWeight: number;
    averageWeight: number;
    variance: number;
    baleSensorCount?: number;
    sensorVariance?: string;
}
