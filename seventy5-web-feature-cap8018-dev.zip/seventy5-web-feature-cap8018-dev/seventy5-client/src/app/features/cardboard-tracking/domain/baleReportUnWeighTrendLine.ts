import { DcUnWeighTrendLine } from './dcUnWeighTrendLine';

export class BaleReportUnWeighTrendLine {
    districtCode: string;
    dcUnWeighTrendLines: DcUnWeighTrendLine[];
}
