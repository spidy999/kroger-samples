import { DcDetailedTrendLine } from './dcDetailedTrendLine';

export class BaleReportTrendLine {
    districtCode: string;
    detailTrendLine: DcDetailedTrendLine[];
}
