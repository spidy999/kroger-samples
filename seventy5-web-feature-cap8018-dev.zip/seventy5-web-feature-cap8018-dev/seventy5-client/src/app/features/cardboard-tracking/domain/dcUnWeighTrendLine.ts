export class DcUnWeighTrendLine {
    districtCode: string;
    insertedDate: string;
    notWeighedCount: number;
}
