import { Division } from '@shared/domain/division';
import { DistrictDetail } from './districtDetail';
import { BaleReportTrendLine } from './baleReportTrendLine';
import { BaleReportUnWeighTrendLine } from './baleReportUnWeighTrendLine';
import {SensorBaleReportTrendLine} from '@features/cardboard-tracking/domain/sensorBaleReportTrendLine';

export class BaleReport {
    division: Division;
    startDate: string;
    endDate: string;
    period?: number[];
    districtDetails: DistrictDetail[];
    baleReportTrendLines: BaleReportTrendLine[];
    sensorBaleReportTrendLines: SensorBaleReportTrendLine[];
    baleReportUnWeighTrendLines: BaleReportUnWeighTrendLine[];
}

export class EnterpriseDivisionReport {
  divNo: string;
  totalDivScan: number;
  districtExcelReportList: DistrictExcelReport[];
}

export class DistrictExcelReport {
  divisionNo: string;
  districtNO: string;
  districtScan: number;
}
