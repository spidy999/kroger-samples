export class DistrictDetail {
    districtCode: string;
    storeScanCount: number;
    dcScanCount: number;
    notWeighedCount: number;
    actualWeight: number;
    variance: number;
    averageWeight: number;
    sensorVariance: string;
    baleSensorCount: number;
}
