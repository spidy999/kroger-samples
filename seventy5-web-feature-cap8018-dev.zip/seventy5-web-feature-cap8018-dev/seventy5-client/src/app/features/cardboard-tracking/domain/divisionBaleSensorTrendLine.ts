export class DivisionBaleSensorTrendLine {
  divisionName: string;
  weeklyDate: string;
  sensorBaleCount: number;
}
