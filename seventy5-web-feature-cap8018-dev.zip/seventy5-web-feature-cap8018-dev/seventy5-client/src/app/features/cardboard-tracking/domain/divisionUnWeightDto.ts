import { DivisionUnWeightTrendline } from './divisionUnWeightTrendline';

export class DivisionUnWeightDto {
    divisionName: string;
    divisionUnWeightTrendlines: DivisionUnWeightTrendline[];
}
