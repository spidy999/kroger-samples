import {SensorDetailedTrendLine} from '@features/cardboard-tracking/domain/sensorDetailedTrendLine';

export class SensorBaleReportTrendLine {
  districtCode: string;
  sensorDetailedTrendLine: SensorDetailedTrendLine[];
}
