import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {RouterTestingModule} from '@angular/router/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormBuilder, FormsModule} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import { KrogerNgStoreSelectorModule } from 'kroger-ng-store-selector';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {StoreActivityService
} from '@features/cardboard-tracking/services/store-activity/store-activity.service';
import {BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import { DivisionService } from '@app/shared/services/division/division.service';
import { DistrictService } from '@app/shared/services/district/district.service';
import { StoreActivityComponent } from './store-activity.component';
import {LineChartComponent} from '@app/shared/reports/line-chart/line-chart.component';
import {BarChartComponent} from '@app/shared/reports/bar-chart/bar-chart.component';
import {StoreDcDetailsComponent} from '@features/cardboard-tracking/store-dc-details/store-dc-details.component';
import {SelectionTypeComponent} from '@app/templates/selection-type/selection-type.component';
import {ExcelService} from '@shared/services/excel/excel.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

describe('StoreActivityComponent', () => {
  let component: StoreActivityComponent;
  let userService: UserService;
  let utilService: UtilService;
  let dateService: DateService;
  let modalService: ModalService;
  let excelService: ExcelService;
  let notificationService: NotificationsService;
  let storeActivityService: StoreActivityService;
  let cardBoardTrackingService: BaleProductionService;
  let fixture: ComponentFixture<StoreActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        KrogerNgStoreSelectorModule
      ],
      providers: [
        UserService,
        DateService,
        FormBuilder,
        UtilService,
        ModalService,
        ExcelService,
        FacilityService,
        DivisionService,
        DistrictService,
        StoreActivityService,
        NotificationsService,
        BaleProductionService
      ],
      declarations: [
        BarChartComponent,
        LineChartComponent,
        StoreDcDetailsComponent,
        StoreActivityComponent,
        SelectionTypeComponent
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreActivityComponent);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    dateService = TestBed.inject(DateService);
    utilService = TestBed.inject(UtilService);
    excelService = TestBed.inject(ExcelService);
    modalService = TestBed.inject(ModalService);
    notificationService = TestBed.inject(NotificationsService);
    storeActivityService = TestBed.inject(StoreActivityService);
    cardBoardTrackingService = TestBed.inject(BaleProductionService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
