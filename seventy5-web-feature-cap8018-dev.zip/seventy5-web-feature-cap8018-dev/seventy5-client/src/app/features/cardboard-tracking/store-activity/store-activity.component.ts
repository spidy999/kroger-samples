import {Component, Input, OnChanges, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {SelectItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {timer} from 'rxjs/observable/timer';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {Constants} from '@shared/models/constants';
import {Store, StoreList} from '@shared/domain/store';
import {ToastDetails} from '@shared/models/Notification';
import {CalendarType} from '@shared/models/calendarType';
import {
  ChartDetails, DateRange, ReportDataSet, ReportType
} from '@shared/models/reportData';
import {StoreDetails} from '../models/storeDetails';
import {Bale} from '@shared/domain/bale';
import {BaleDetails} from '@shared/domain/baleDetails';
import {SelectChartOptions} from '@shared/domain/appSettings';
import {DateService} from '@shared/services/date/date.service';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {DivisionService} from '@app/shared/services/division/division.service';
import {DistrictService} from '@app/shared/services/district/district.service';
import {
  StoreActivityService
} from '@features/cardboard-tracking/services/store-activity/store-activity.service';
import {
  BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {LocationInfo, MultipleStoresDto} from '@app/shared/domain/multipleStoresDto';
import {StoreActivity as constants} from '@features/cardboard-tracking/models/cardboard-tracking';
const ARRAY_SIZE = 7;

@Component({
  selector: 'app-store-report',
  templateUrl: './store-activity.component.html',
  styleUrls: ['./store-activity.component.less']
})

export class StoreActivityComponent implements OnInit, OnChanges {
  public url: any;
  public cols: any;
  public paramData: any;
  public dateRange: any = [];
  public tableData: any = [];
  public storeTotal: any = [];
  public flip = true;
  public showChart: boolean;
  public disableExcel: boolean;
  public disableSubmit: boolean;
  public loadingDetails = false;
  public noStoreSelected: boolean;
  public dataNotAvailable: boolean;
  public divisions;
  public dates: string;
  public storeNo: string;
  public selectedType: string;
  public divisionNumber: string;
  public hoverToExpandText: string;
  public hoverToCollapseText: string;
  private bales: Bale[];
  public types: SelectItem[];
  public selectedStores: Store[];
  public storeData: StoreDetails;
  public chartData: ChartDetails;
  public baleDetails: BaleDetails[] = [];
  public chartType = SelectChartOptions;
  public selectionItems: SelectChartOptions[];
  public calendarType: CalendarType;
  public selectedCalendarType = CalendarType;
  public selectedReportType = ReportType;
  public multipleStoreDto: MultipleStoresDto = new MultipleStoresDto();
  public spinner$: Observable<boolean> = this.util.getSpinner();
  @Input() public widgetDetails: DateRange;
  @Input() public storeList: StoreList;

  constructor(public router: Router,
              public user: UserService,
              public util: UtilService,
              private dateService: DateService,
              private excelService: ExcelService,
              public modalService: ModalService,
              private divisionService: DivisionService,
              private districtService: DistrictService,
              private notificationService: NotificationsService,
              private storeActivityService: StoreActivityService,
              private cardBoardTrackingReport: BaleProductionService) {
    const {cols, types} = constants;
    this.types = types;
    this.cols = cols;
  }

  ngOnInit() {
    this.showChart = false;
    this.disableExcel = true;
    this.disableSubmit = true;
    this.noStoreSelected = true;
    this.dataNotAvailable = false;
    this.disableExcel = true;
    this.selectionItems = [
      SelectChartOptions.LINE_CHART,
      SelectChartOptions.TABLE,
      SelectChartOptions.BAR_CHART
    ];
    this.buildReports();
  }

  private buildReports() {
    this.showChart = false;
    this.disableExcel = true;
    const {startDate, endDate, period} = this.widgetDetails;
    this.dateRange = [startDate, endDate, period];
    const start = DateService.getMonthDayYearFormat(startDate);
    const end = DateService.getMonthDayYearFormat(endDate);
    this.dates = `${start} - ${end}`;
    if (this.storeList && this.storeList.division && this.storeList.stores) {
      this.noStoreSelected = false;
      this.runBaleReport();
    } else {
      this.showChart = true;
      this.noStoreSelected = true;
    }
  }

  ngOnChanges(): void {
    this.buildReports();
  }

  public onSelectionType(evt) {
    if (evt) {
      setTimeout(() => {
        this.selectedType = evt;
      });
    }
  }

  private runBaleReport() {
    this.divisionNumber = this.storeList.division;
    this.selectedStores = this.storeList.stores;
    this.buildReportData();
    this.buildStoreDetailReportData();
  }

  private buildReportData() {
    this.multipleStoreDto.divisionNo = this.divisionNumber;
    this.multipleStoreDto.stores = this.getStoreIdsForReport();
    this.multipleStoreDto.startDate = DateService.getDateForRequest(this.dateRange[0]);
    this.multipleStoreDto.endDate = DateService.getDateForRequest(this.dateRange[1]);
    this.paramData = {
      divisionNo: this.multipleStoreDto.divisionNo,
      startDate: this.multipleStoreDto.startDate,
      endDate: this.multipleStoreDto.endDate
    };
    this.showChart = true;
    this.util.showSpinner();
    forkJoin(
      [this.storeActivityService.getBaleCountForMultipleStores(this.multipleStoreDto),
      timer(Constants.SPINNER_TIMEOUT)]
    )
      .subscribe(([result]) => {
        this.util.hideSpinner();
        this.bales = result;
        this.dataNotAvailable = this.bales.length === 0;
        this.buildData(this.getReportData(this.bales));
      },
        () => {
          this.util.hideSpinner();
        }
      );
  }

  private buildStoreDetailReportData() {
    this.loadingDetails = true;
    forkJoin(
      [this.storeActivityService.getDetailReportOfBale(this.multipleStoreDto),
      timer(Constants.SPINNER_TIMEOUT)]
    )
      .subscribe(([result]) => {
        this.loadingDetails = false;
        this.baleDetails = result;
        this.disableExcel = !(this.bales && this.baleDetails && this.bales.length > 0);
      },
        () => {
          this.loadingDetails = false;
        });
  }

  private buildData(data: ReportDataSet[]) {
    this.chartData = this.buildChartData(data);
    this.buildTableData(data);
  }

  private buildTableData(datasets: ReportDataSet[]) {
    this.tableData = [];
    datasets.forEach(store => {
      let i = 0;
      const { label, data, divisionNo, district } = store;
      const result = {
        store: label,
        data,
        sunday: data[i++].toLocaleString('en'),
        monday: data[i++].toLocaleString('en'),
        tuesday: data[i++].toLocaleString('en'),
        wednesday: data[i++].toLocaleString('en'),
        thursday: data[i++].toLocaleString('en'),
        friday: data[i++].toLocaleString('en'),
        saturday: data[i++].toLocaleString('en'),
        total: data[i++].toLocaleString('en'),
        average: data[i++],
        divisionNo,
        district
      };
      this.tableData.push(result);
    });
  }

  private buildChartData(datasets: ReportDataSet[]): ChartDetails {
    const chartDatasets = datasets.map(reportDataSet => {
      return { ...reportDataSet, data: reportDataSet.data.slice(0, Constants.DAYS_IN_WEEK) };
    });
    let data;
    data = {
      labels: Constants.DAYS_OF_WEEK,
      datasets: chartDatasets
    };
    return {
      data,
      height: '500px'
    };
  }

  private getReportData(bales: Bale[]): ReportDataSet[] {
    const list: ReportDataSet[] = [];
    this.selectedStores.forEach((store, i) => {
      const color = UtilService.generateRandomColor(i);
      const storeData = bales.filter(r => store.facility === r.storeNo);
      list.push(new ReportDataSet(`${store.facility}`, this.buildStoreCountForDay(storeData),
        false, color, color, store.division , store.district));
    });
    return list.sort((a, b) => a.label.localeCompare(b.label));
  }

  private buildStoreCountForDay(storeData) {
    let bales = [];
    let dayData;
    Constants.DAYS_OF_WEEK.forEach( (d) => {
      dayData = storeData.filter (s => s.reportDayOfWeek === d);
      if (dayData) {
        bales.push(dayData.reduce((prev, curr) => prev + curr.baleCount, 0));
      } else {
        bales.push(0);
      }
    });
    const count = Constants.DAYS_IN_WEEK;
    const total = UtilService.calculateTotal(bales);
    const avg = UtilService.calculateAverage(total, count);
    bales = [...bales, total, avg];
    return bales;
  }

  private getAverageTotals(data: ReportDataSet[]) {
    let requiredData = [];
    const totals = [];
    let total = 0;
    data.forEach(d => {
      requiredData = d.data.slice(0, ARRAY_SIZE);
      total = UtilService.calculateTotal(requiredData);
      totals.push(total);
    });
    const resultantTotal = UtilService.calculateTotal(totals);
    const sortedDates = this.cardBoardTrackingReport.calculateRangeDates(this.dateRange).length;
    return UtilService.calculateAverage(resultantTotal, sortedDates);
  }

  // Building totals for Excel report
  private buildStoreTotalData(totals) {
    this.storeTotal.length = 0;
    let i = 0;
    const storeTotals = {
      store: 'Total',
      sunday: totals[i++].toLocaleString('en'),
      monday: totals[i++].toLocaleString('en'),
      tuesday: totals[i++].toLocaleString('en'),
      wednesday: totals[i++].toLocaleString('en'),
      thursday: totals[i++].toLocaleString('en'),
      friday: totals[i++].toLocaleString('en'),
      saturday: totals[i++].toLocaleString('en'),
      total: totals[i++].toLocaleString('en'),
      average: this.getAverageTotals(this.tableData.data.datasets).toLocaleString('en')
    };
    this.storeTotal.push(storeTotals);
  }

  private getStoreIdsForReport() {
    const storeIds = [];
    if (this.selectedStores) {
      this.selectedStores.forEach(s => {
        storeIds.push(s.facility);
      });
    }
    return storeIds.sort();
  }

  public exportToExcel(flip) {
    this.flip = !flip;
    this.buildExcelReport();
  }

  public buildExcelReport() {
    let toastDetails: ToastDetails;
    const storeList: MultipleStoresDto = {
      divisionNo: this.divisionNumber,
      stores: this.getStoreIdsForReport(),
      locations: this.buildStoreList(),
      startDate: DateService.getDateForRequest(this.dateRange[0]),
      endDate: DateService.getDateForRequest(this.dateRange[1]),
      period: this.dateRange[2]
    };
    this.excelService.downloadExcelReport(storeList
      , `api/report/store/excel/download`)
      .subscribe(response => {
        if (response && response.body && response.body.size > 0) {
            ExcelService.createExcelFile(response);
          }
         this.flip = true;
      }, (error) => {
        if (error && error.message) {
         toastDetails = ExcelService.displayToastMessage('error',  error);
        } else {
         toastDetails = ExcelService.displayToastMessage('error');
      }
      this.notificationService.emitMessage.next(toastDetails);
      this.flip = true;
    });
  }

  private viewStore(storeNo) {
    this.storeData = { ...this.paramData, storeNo };
  }

  public onSelectedRow(event) {
    if (event && event.data && event.originalEvent && event.originalEvent.isTrusted) {
      this.viewStore(event.data.store);
    }
  }

  public setHoverToCollapseText() {
    this.hoverToCollapseText = 'click to collapse';
    this.hoverToExpandText = 'click to expand';
  }

  public buildStoreList() {
    const storeList: LocationInfo[] = [];
    if (this.selectedStores) {
      this.selectedStores.forEach(store => {
        const location: LocationInfo = {
          divisionNo: store.division,
          district: store.district,
          store: store.facility
        };
        storeList.push(location);
      });
    }
    return storeList;
  }

}
