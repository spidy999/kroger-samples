import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { KrogerNgStoreSelectorModule } from 'kroger-ng-store-selector';
import {RouterTestingModule} from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@shared/calendar/calendar.module';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {DivisionService} from '@shared/services/division/division.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {DistrictService} from '@shared/services/district/district.service';
import { CardboardTrackingComponent } from './cardboard-tracking.component';
import {BarChartComponent} from '@shared/reports/bar-chart/bar-chart.component';
import {StoreActivityComponent} from './store-activity/store-activity.component';
import {LineChartComponent} from '@shared/reports/line-chart/line-chart.component';
import {StoreDcDetailsComponent} from './store-dc-details/store-dc-details.component';
import {TableChartComponent} from '@shared/reports/table-chart/table-chart.component';
import {SelectionTypeComponent} from '@app/templates/selection-type/selection-type.component';
import {DcActivityComponent} from '@features/cardboard-tracking/dc-activity/dc-activity.component';
import {BillOfLadingComponent} from '@features/cardboard-tracking/bill-of-lading/bill-of-lading.component';
import {BaleProductionComponent} from '@features/cardboard-tracking/bale-production/bale-production.component';
import {BaleProductionDetailsComponent
} from '@features/cardboard-tracking/bale-production/bale-production-details/bale-production-details.component';
import {CorporateBaleProductionComponent
} from '@features/cardboard-tracking/bale-production/corporate-bale-production/corporate-bale-production.component';
import {EnterpriseBaleProductionComponent
} from '@features/cardboard-tracking/bale-production/enterprise-bale-production/enterprise-bale-production.component';

describe('CardboardTrackingComponent', () => {
  let component: CardboardTrackingComponent;
  let utilService: UtilService;
  let userService: UserService;
  let modalService: ModalService;
  let districtService: DistrictService;
  let divisionService: DivisionService;
  let facilityService: FacilityService;
  let fixture: ComponentFixture<CardboardTrackingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        ReactiveFormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        KrogerNgStoreSelectorModule
      ],
      declarations: [
        BarChartComponent,
        LineChartComponent,
        TableChartComponent,
        DcActivityComponent,
        StoreDcDetailsComponent,
        BillOfLadingComponent,
        StoreActivityComponent,
        SelectionTypeComponent,
        BaleProductionComponent,
        CardboardTrackingComponent,
        BaleProductionDetailsComponent,
        CorporateBaleProductionComponent,
        EnterpriseBaleProductionComponent
      ],
      providers: [
        UtilService,
        UserService,
        ModalService,
        DistrictService,
        DivisionService,
        FacilityService,
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardboardTrackingComponent);
    utilService = TestBed.inject(UtilService);
    userService = TestBed.inject(UserService);
    modalService = TestBed.inject(ModalService);
    divisionService = TestBed.inject(DivisionService);
    districtService = TestBed.inject(DistrictService);
    facilityService = TestBed.inject(FacilityService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
