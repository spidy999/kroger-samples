import { CommonModule } from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {KrogerNgStoreSelectorModule} from 'kroger-ng-store-selector';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {ReportsModule} from '@shared/reports/reports.module';
import {TemplateModule} from '@app/templates/template.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { GlobalInterceptorModule } from '@app/httpInterceptor.module';
import { CardboardTrackingRoutingModule } from './cardboard-tracking-routing.module';
import {DivisionService} from '@shared/services/division/division.service';
import {DcActivityService
} from '@features/cardboard-tracking/services/dc-activity/dc-activity.service';
import {BillOfLadingService
} from '@features/cardboard-tracking/services/bill-of-lading/bill-of-lading.service';
import {StoreActivityService
} from '@features/cardboard-tracking/services/store-activity/store-activity.service';
import {BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {DcActivityComponent } from './dc-activity/dc-activity.component';
import {CardboardTrackingComponent} from './cardboard-tracking.component';
import {StoreActivityComponent
} from '@features/cardboard-tracking/store-activity/store-activity.component';
import {StoreDcDetailsComponent
} from '@features/cardboard-tracking/store-dc-details/store-dc-details.component';
import { BillOfLadingComponent } from './bill-of-lading/bill-of-lading.component';
import {BaleProductionComponent} from '@features/cardboard-tracking/bale-production/bale-production.component';
import {EnterpriseBaleProductionComponent
} from '@features/cardboard-tracking/bale-production/enterprise-bale-production/enterprise-bale-production.component';
import { BaleProductionDetailsComponent } from './bale-production/bale-production-details/bale-production-details.component';
import { CorporateBaleProductionComponent } from './bale-production/corporate-bale-production/corporate-bale-production.component';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    ReportsModule,
    PrimengModule,
    CalendarModule,
    TemplateModule,
    ReactiveFormsModule,
    KdsStencilAccessorsModule,
    KrogerNgStoreSelectorModule,
    CardboardTrackingRoutingModule
  ],
  declarations: [
    DcActivityComponent,
    BillOfLadingComponent,
    StoreActivityComponent,
    BaleProductionComponent,
    StoreDcDetailsComponent,
    CardboardTrackingComponent,
    BaleProductionDetailsComponent,
    CorporateBaleProductionComponent,
    EnterpriseBaleProductionComponent
  ],
  providers: [
    DivisionService,
    DcActivityService,
    BillOfLadingService,
    StoreActivityService,
    BaleProductionService,
    GlobalInterceptorModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class CardboardTrackingModule { }
