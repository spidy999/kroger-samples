import {FormGroup} from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import {map, mergeMap} from 'rxjs/operators';
import {DateRange} from '@shared/models/reportData';
import {LazyLoadEvent, SelectItem} from 'primeng/api';
import {CalendarType} from '@shared/models/calendarType';
import {ToastDetails} from '@shared/models/Notification';
import {
  BillOfLadingSearchTableData, SearchBOLResponseData
} from '@features/cardboard-tracking/models/billOfLading';
import {SearchBolData} from '@shared/models/searchBolData';
import {FacilityData} from '@app/shared/domain/facilityData';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {BillOfLading as constants} from '../models/cardboard-tracking';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import {UserService} from '@shared/services/user/user.service';
import { NotificationsService
} from '@shared/services/notifications/notifications.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import { BillOfLadingService
} from '@features/cardboard-tracking/services/bill-of-lading/bill-of-lading.service';
import {ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
const TIMEOUT = 100;

interface SalvageData {
  count: number;
  data: SalvageBol[];
}

@Component({
  selector: 'app-bill-of-lading',
  templateUrl: './bill-of-lading.component.html',
  styleUrls: ['./bill-of-lading.component.less'],
})
export class BillOfLadingComponent implements OnInit, OnChanges {

  @Input() facilityData: FacilityData[];
  @Input() facilityItems: SelectItem[];
  @Input() widgetDetails: DateRange;
  readonly OPEN = 'Open';
  readonly ALL = 'ALL';
  public flip = true;
  public loading: boolean;
  public showTable = false;
  public initialCheck = true;
  public innerSpinner = false;
  public excelResponse: boolean;
  public dates: string;
  public cols: any = [];
  public dateRange: any = [];
  public totalRecords: number;
  public loaderMessage: string;
  public bolChartData: any = [];
  public statusType: SelectItem[];
  public billOfLadingForm: FormGroup;
  public calendarType: CalendarType;
  public searchParams: SearchBolData;
  public selectedCalendarType = CalendarType;
  private response: SearchBOLResponseData[] = [];
  public bolTableData: BillOfLadingSearchTableData[] = [];
  public destinations$ = this.billOfLadingService.getDestinations();
  public materialTypes$ = this.billOfLadingService.getMaterialTypes();
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor( public utilService: UtilService,
               public userService: UserService,
               private dateService: DateService,
               public modalService: ModalService,
               public excelService: ExcelService,
               private changeDetect: ChangeDetectorRef,
               public facilityService: FacilityService,
               private notificationService: NotificationsService,
               private billOfLadingService: BillOfLadingService) {
    const {cols, statusType } = constants;
    this.cols = cols;
    this.statusType = statusType;
    this.billOfLadingForm = this.billOfLadingService.createForm();
  }

  ngOnInit() {
    this.loaderMessage = 'Loading...';
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.runSalvageReport(this.initialCheck);
  }

  private getBolData(data: SearchBOLResponseData[]):  SearchBOLResponseData[] {
    const processData = [];
    processData.length = 0;
    if (data) {
      data.forEach((item) => {
        if (item.salvageQty === 0) { item.salvageQty = 'NA'; }
        if (item.totalWeight === 0) { item.totalWeight = 'NA'; } else {
          item.totalWeight = item.totalWeight.toLocaleString('en');
        }
        item.insertedDate = DateService.getDateForRequest(item.insertedDate);
        processData.push(item);
      });
    }
    return processData;
  }

  private buildReportData(data: SearchBOLResponseData[]): void {
    this.bolChartData = this.buildTableData(data);
    this.showTable = this.bolChartData && this.bolChartData.length > 0;
  }

  private buildTableData(data) {
    this.bolTableData = data.map((billOfLadingData) => {
      const closedDate = ('CLOSED' === billOfLadingData.status) ?
                          DateService.getDateForRequest(billOfLadingData.updatedDate) : '';
      const { bolId, insertedDate: dateCreated, salvageMaterialType, status,
              destination, salvageQty: qty, totalWeight} = billOfLadingData;
      return {
        bolId,
        dateCreated,
        lastUpdatedDate: closedDate,
        salvageMaterialType,
        status,
        destination,
        qty,
        totalWeight
      };
    });
    return this.bolTableData;
  }

  public search() {
    this.loaderMessage = 'Updating...';
    this.runSalvageReport(this.initialCheck);
  }

  private extractCalendarDetails() {
    if (this.widgetDetails) {
      const {startDate, endDate, period} = this.widgetDetails;
      this.dateRange = [startDate, endDate, period];
      const start = DateService.getMonthDayYearFormat(startDate);
      const end = DateService.getMonthDayYearFormat(endDate);
      this.dates = `${start} - ${end}`;
    }
  }

  private runSalvageReport(flag: boolean) {
    this.extractCalendarDetails();
    this.calculateSearchParams(flag);
    this.buildSalvageReport();
    this.getExcelReportData();
  }

  private calculateSearchParams(flag: boolean) {
    if (flag) {
      if (this.facilityData) {
        this.billOfLadingForm.get('facilityId').setValue(this.facilityData[0].facilityId);
      }
      this.initialCheck = false;
    }
    this.searchParams = {
      facilityId: Number(this.billOfLadingForm.get('facilityId').value),
      status: SalvageBolStatus.CLOSED,
      startDate: DateService.getDateForRequest(this.dateRange[0]),
      endDate: DateService.getDateForRequest(this.dateRange[1])
    };
  }

  private getExcelReportData() {
    this.excelResponse = false;
    const searchBolParams = this.getInputParams();
    this.billOfLadingService.excelSalvageReport(searchBolParams)
      .subscribe(result => {
        this.excelResponse = result;
      }, () => {
        this.excelResponse = false;
      });
  }

  /* returns a list of salvageBale from backend */
  private buildSalvageReport() {
    this.utilService.showSpinner();
    const pageIndex = 0;
    const pageOffset = 15;
    const searchBolParams = this.getInputParams();
    const countObs: Observable<number> = this.billOfLadingService
      .salvageBolReportPageCount(searchBolParams);
    const salvageObs: Observable<SalvageBol[]> = this.billOfLadingService
      .salvageBolReportWithPagination(searchBolParams, pageIndex, pageOffset);

    const salvageDataObs: Observable<SalvageData> = countObs.pipe(
      mergeMap((value: number) => {
        let response: SalvageData;
        if (value > 0) {
          return salvageObs.pipe(
            map(bolData => {
              response = {
                count: value,
                data: bolData
              };
              return response;
            })
          );
        } else {
          return Observable.of(null);
        }
      })
    );
    salvageDataObs.subscribe(result => {
        if (result != null) {
          this.totalRecords = result.count;
          this.response = result.data;
          this.buildReportData(this.getBolData(this.response));
          this.utilService.hideSpinner();
        } else {
          this.showTable = false;
          this.utilService.hideSpinner();
        }
      },
      () => {
        this.showTable = false;
        this.utilService.hideSpinner();
      }
    );
  }

  public exportToExcel(flip) {
    this.flip = !flip;
    this.buildExcelReport();
  }

  private getInputParams() {
    const searchBolParams = {...this.billOfLadingForm.value, ...this.searchParams};
    if (searchBolParams.destination === '') {
      searchBolParams.destination = null;
    }
    if (searchBolParams.salvageMaterialType === '') {
      searchBolParams.salvageMaterialType = null;
    }
    return searchBolParams;
  }

  public buildExcelReport() {
    let toastDetails: ToastDetails;
    const searchBolParams = this.getInputParams();
    const excelParams = {...searchBolParams, period: this.dateRange[2]};
    const type = 'BillOfLading';
    this.excelService.downloadExcelReport(excelParams, `api/salvage/excel/download/${type}`)
      .subscribe(response => {
        if (response && response.body && response.body.size > 0) {
          ExcelService.createExcelFile(response);
        }
        this.flip = true;
      }, (error) => {
        if (error && error.message) {
          toastDetails = ExcelService.displayToastMessage('error', error);
        } else {
          toastDetails = ExcelService.displayToastMessage('error');
        }
        this.notificationService.emitMessage.next(toastDetails);
        this.flip = true;
      });
  }

  // Pagination for Bill of Lading table
  loadSalvageData(event: LazyLoadEvent) {
    this.loading = true;
    const pageIndex = event.first;
    const pageOffset = 15;
    const searchBolParams = this.getInputParams();
    setTimeout(() => {
      this.billOfLadingService.salvageBolReportWithPagination(searchBolParams, pageIndex, pageOffset)
        .subscribe(result => {
          this.response = result;
          this.buildReportData(this.getBolData(this.response));
          this.loading = false;
        });
    }, TIMEOUT);
    this.changeDetect.detectChanges();
  }

}
