import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BillOfLadingComponent } from './bill-of-lading.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {BillOfLadingService
} from '@features/cardboard-tracking/services/bill-of-lading/bill-of-lading.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {TableChartComponent} from '@app/shared/reports/table-chart/table-chart.component';

describe('BillOfLadingComponent', () => {
  let component: BillOfLadingComponent;
  let userService: UserService;
  let dateService: DateService;
  let modalService: ModalService;
  let facilityService: FacilityService;
  let validatorService: ValidatorsService;
  let billOfLadingService: BillOfLadingService;
  let notificationService: NotificationsService;
  let fixture: ComponentFixture<BillOfLadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        ReactiveFormsModule,
        BrowserAnimationsModule
      ],
      providers: [
        UserService,
        DateService,
        UtilService,
        ModalService,
        FacilityService,
        ValidatorsService,
        BillOfLadingService,
        NotificationsService
      ],
      declarations: [
        TableChartComponent,
        BillOfLadingComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillOfLadingComponent);
    userService = TestBed.inject(UserService);
    dateService = TestBed.inject(DateService);
    modalService = TestBed.inject(ModalService);
    facilityService = TestBed.inject(FacilityService);
    validatorService = TestBed.inject(ValidatorsService);
    notificationService = TestBed.inject(NotificationsService);
    billOfLadingService = TestBed.inject(BillOfLadingService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
