import {Router} from '@angular/router';
import {SelectItem} from 'primeng/api';
import { Observable } from 'rxjs/Observable';
import { timer } from 'rxjs/observable/timer';
import { DcDetails } from '../models/dcDetails';
import {Constants} from '@shared/models/constants';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { DcReport } from '@app/shared/domain/dcReport';
import {ToastDetails} from '@shared/models/Notification';
import {FacilityData} from '@shared/domain/facilityData';
import {SelectChartOptions} from '@shared/domain/appSettings';
import {CalendarType} from '@shared/models/calendarType';
import {Component, Input, OnChanges} from '@angular/core';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {DcActivityService} from '@features/cardboard-tracking/services/dc-activity/dc-activity.service';
import {DCActivity as constants } from '@features/cardboard-tracking/models/cardboard-tracking';
import {ChartDetails, DateRange, GetDcData, ReportDataSet, ReportType} from '@shared/models/reportData';

@Component({
  selector: 'app-dc-reports',
  templateUrl: './dc-activity.component.html',
  styleUrls: ['./dc-activity.component.less']
})

export class DcActivityComponent implements OnChanges {
  public cols: any;
  @Input() facility: number;
  @Input() facilityData: FacilityData[];
  @Input() public widgetDetails: DateRange;
  public flip = true;
  public showChart = false;
  public disableExcel = true;
  public dataAvailable = false;
  private response: DcReport[];
  public chartData: ChartDetails;
  public dcTotal: any = [];
  public dateRange: any = [];
  public types: SelectItem[];
  public dcActivityData: any;
  public dcTableData: any = [];
  public dates: string;
  public selectedType: string;
  public hoverToExpandText: string;
  public hoverToCollapseText: string;
  public tableDetails: DcDetails;
  public calendarType: CalendarType;
  public chartType = SelectChartOptions;
  public selectedReportType = ReportType;
  public selectedCalendarType = CalendarType;
  public selectionItems: SelectChartOptions[];
  public getParams: GetDcData = new GetDcData();
  public spinner$: Observable<boolean> = this.util.getSpinner();

  constructor(public router: Router,
              public user: UserService,
              private util: UtilService,
              private dateService: DateService,
              public modalService: ModalService,
              public excelService: ExcelService,
              private notificationService: NotificationsService,
              private dcActivityService: DcActivityService) {
    const {types, cols} = constants;
    this.types = types;
    this.cols = cols;
    this.selectionItems = [
      SelectChartOptions.LINE_CHART,
      SelectChartOptions.TABLE,
      SelectChartOptions.BAR_CHART
    ];
  }

  ngOnChanges( ): void {
    this.runBaleReport();
  }

  public getFacilityNameById(facilityId: number) {
    return this.facilityData.find(f => f.facilityId === facilityId).facilityName;
  }

  private runBaleReport() {
    if (this.widgetDetails) {
      const {startDate, endDate, period} = this.widgetDetails;
      this.dateRange = [startDate, endDate, period];
      const start = DateService.getMonthDayYearFormat(startDate);
      const end = DateService.getMonthDayYearFormat(endDate);
      this.dates = `${start} - ${end}`;
      this.buildDcReportData();
      this.showChart = true;
    }
  }

  public onSelectionType(evt) {
    if (evt) {
      setTimeout(() => {
        this.selectedType = evt;
      });
    }
  }

  private buildDcReportData() {
    this.getParams.startDate = DateService.getDateForRequest(this.dateRange[0]);
    this.getParams.endDate = DateService.getDateForRequest(this.dateRange[1]);
    this.getParams.facilityId = this.facility;
    this.util.showSpinner();
      forkJoin(
        [this.dcActivityService.getBaleCountForDc(this.getParams),
        timer(Constants.SPINNER_TIMEOUT)]
      )
      .subscribe(([result]) => {
        this.util.hideSpinner();
        this.response = result;
        this.dataAvailable = (this.response.length > 0);
        this.dcActivityData = this.buildDcData(this.getReportData(this.response));
        this.disableExcel = this.dataAvailable;
        }, () => {
          this.util.hideSpinner();
        }
      );
  }

  private getReportData(res: DcReport[]): ReportDataSet {
    const color = UtilService.generateRandomColor(0);
    const dcData = res.filter((r) => {
      return this.facility === r.facility;
    });
    return new ReportDataSet(this.getFacilityNameById(this.facility), this.buildDcCountForDay(dcData),
      false, color, color);
  }

  private buildDcData(data: ReportDataSet) {
    this.buildDcTableData(data);
    this.chartData = this.buildDcChartData(data);
    if (this.dcTableData && this.dcTableData.length > 0) {
      return  {
        data: this.dcTableData,
        columns: this.cols,
        dataKey: 'dc'
      };
    }
  }

  private buildDcTableData(dcActivity: ReportDataSet) {
    this.dcTableData = [];
    this.dcTableData.length = 0;
    let i = 0;
    const { label, data } = dcActivity;
    const result = {
      dc: label,
      data: data,
      sunday: data[i++].toLocaleString('en'),
      monday: data[i++].toLocaleString('en'),
      tuesday: data[i++].toLocaleString('en'),
      wednesday: data[i++].toLocaleString('en'),
      thursday: data[i++].toLocaleString('en'),
      friday: data[i++].toLocaleString('en'),
      saturday: data[i++].toLocaleString('en'),
      total: data[i++].toLocaleString('en'),
      average: data[i++].toLocaleString('en')
    };
    this.dcTableData.push(result);
  }

  private buildDcChartData(dcData: ReportDataSet): ChartDetails {
    let data;
    data = {
      labels: Constants.DAYS_OF_WEEK,
      datasets: [dcData],
    };
    this.showChart = true;
    this.disableExcel = false;
    return {
      data,
      height: '400px'
    };
  }

  private buildDcCountForDay(dcData): number[] {
    let bales = [];
    bales.length = 0;
    let dayData;
    Constants.DAYS_OF_WEEK.forEach(d => {
      dayData = dcData.filter ( s => s.reportDayOfWeek === d );
      if (dayData) {
        bales.push(dayData.reduce((prev, curr) => prev + curr.baleCount, 0));
      } else {
        bales.push(0);
      }
    });
    const count = Constants.DAYS_IN_WEEK;
    const total = UtilService.calculateTotal(bales);
    const avg = UtilService.calculateAverage(total, count);
    bales = [...bales, total, avg];
    return bales;
  }

  public setHoverToCollapseText() {
    this.hoverToCollapseText = 'click to collapse';
    this.hoverToExpandText = 'click to expand';
  }

  public onSelectedRow(event) {
    if (event && event.data && event.originalEvent && event.originalEvent.isTrusted) {
      this.tableDetails = {
        startDate : this.getParams.startDate,
        endDate : this.getParams.endDate,
        facilityId: this.getParams.facilityId
      };
    }
  }

  public exportToExcel(flip) {
    this.flip = !flip;
    this.buildExcelReport();
  }

  public buildExcelReport() {
    let toastDetails: ToastDetails;
    const params: GetDcData = {
      startDate: DateService.getDateForRequest(this.dateRange[0]),
      endDate: DateService.getDateForRequest(this.dateRange[1]),
      facilityId: this.facility,
      period: this.dateRange[2],
    };
    this.excelService.downloadExcelReport(params
      , `api/report/dc/excel/download`)
      .subscribe(response => {
        if (response && response.body && response.body.size > 0) {
          ExcelService.createExcelFile(response);
        }
        this.flip = true;
      }, (error) => {
        if (error && error.message) {
          toastDetails = ExcelService.displayToastMessage('error', error);
        } else {
          toastDetails = ExcelService.displayToastMessage('error');
        }
        this.notificationService.emitMessage.next(toastDetails);
        this.flip = true;
      });
  }
}
