import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormBuilder, FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {DcActivityService} from '@features/cardboard-tracking/services/dc-activity/dc-activity.service';
import { DcActivityComponent } from './dc-activity.component';
import {BarChartComponent} from '@app/shared/reports/bar-chart/bar-chart.component';
import {LineChartComponent} from '@app/shared/reports/line-chart/line-chart.component';
import { StoreDcDetailsComponent } from '../store-dc-details/store-dc-details.component';
import {TableChartComponent} from '@app/shared/reports/table-chart/table-chart.component';
import {SelectionTypeComponent} from '@app/templates/selection-type/selection-type.component';

describe('DcActivityComponent', () => {
  let component: DcActivityComponent;
  let userService: UserService;
  let utilService: UtilService;
  let dateService: DateService;
  let modalService: ModalService;
  let dcActivityService: DcActivityService;
  let notificationService: NotificationsService;
  let fixture: ComponentFixture<DcActivityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        UserService,
        UtilService,
        DateService,
        ModalService,
        FormBuilder,
        DcActivityService,
        NotificationsService
      ],
      declarations: [
        BarChartComponent,
        LineChartComponent,
        TableChartComponent,
        DcActivityComponent,
        SelectionTypeComponent,
        StoreDcDetailsComponent
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcActivityComponent);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    dateService = TestBed.inject(DateService);
    utilService = TestBed.inject(UtilService);
    modalService = TestBed.inject(ModalService);
    dcActivityService = TestBed.inject(DcActivityService);
    notificationService = TestBed.inject(NotificationsService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
