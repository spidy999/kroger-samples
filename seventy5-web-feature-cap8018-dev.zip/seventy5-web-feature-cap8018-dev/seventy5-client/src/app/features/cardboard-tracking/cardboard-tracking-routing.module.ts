import { NgModule } from '@angular/core';
import {Permission} from '@shared/models/permissions';
import {AuthGuard as AuthGuard} from '@app/auth-guard';
import { Routes, RouterModule } from '@angular/router';
import {CardboardTrackingComponent} from './cardboard-tracking.component';

const occRoutes: Routes = [
  {
    path: '',
    component: CardboardTrackingComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.OCC_REPORTS.toString()
    }
  }
  ];

@NgModule({
  imports: [RouterModule.forChild(occRoutes)],
  exports: [RouterModule]
})
export class CardboardTrackingRoutingModule { }
