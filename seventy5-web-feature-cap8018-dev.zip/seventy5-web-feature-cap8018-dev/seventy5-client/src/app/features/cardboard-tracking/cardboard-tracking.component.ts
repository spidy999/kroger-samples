import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {select, Store} from '@ngrx/store';
import {Dates} from '@shared/models/dateRange';
import {MenuItem, SelectItem} from 'primeng/api';
import {DateRange} from '@shared/models/reportData';
import {AppState} from '@app/root-store/app.reducer';
import {SelectorNode} from 'kroger-ng-store-selector';
import {Component, OnDestroy, OnInit} from '@angular/core';
import {FacilityData} from '@shared/domain/facilityData';
import {CalendarType} from '@shared/models/calendarType';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {DivisionService} from '@shared/services/division/division.service';
import {DistrictService} from '@shared/services/district/district.service';
import {getDivisionItems} from '@app/root-store/divisions/divisions.selector';
import {getStoreNodeState} from '@app/root-store/store-node/store-node.selector';
import {RenderType, SelectionMode, StoreList} from '@shared/domain/store';
import {CardboardTrackingTab} from '@features/cardboard-tracking/models/baleProduction';
import {CardBoardTab as constants} from '@features/cardboard-tracking/models/cardboard-tracking';
import {getFacilitiesInfo, getFacilityItems} from '@app/root-store/facility-info/facility-info.selector';
const ALL = 'ALL';

@Component({
  selector: 'app-occ-reports',
  templateUrl: './cardboard-tracking.component.html',
  styleUrls: ['./cardboard-tracking.component.less']
})
export class CardboardTrackingComponent implements OnInit, OnDestroy {
  public facility: number;
  public divisionNumber: string;
  public selector: SelectorNode;
  public storeList: StoreList;
  public renderType = RenderType;
  public dateRangeDisplay: DateRange;
  public availableOptions: MenuItem[];
  public selectionMode = SelectionMode;
  public divisionItems: SelectItem[] = [] = [];
  public facilityItems: SelectItem[] = [] = [];
  public facilityData: FacilityData[] = [] = [];
  public selectedCalendarType = CalendarType;
  public selectionType: CardboardTrackingTab;
  public selectedOptionType = CardboardTrackingTab;
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(public userService: UserService,
              public utilService: UtilService,
              private dateService: DateService,
              private districtService: DistrictService,
              private divisionService: DivisionService,
              private readonly store: Store<AppState>) {}

  ngOnInit() {
    this.store.pipe(select(getFacilitiesInfo), takeUntil(this.destroy)).subscribe(facilities => {
      this.facilityData = facilities;
      if (this.facilityData && this.facilityData.length > 0) {
        this.facility = this.facilityData[0].facilityId;
      }
    });
    this.store.pipe(select(getFacilityItems), takeUntil(this.destroy)).subscribe(items => {
      this.facilityItems = items;
    });
    this.store.pipe(select(getStoreNodeState), takeUntil(this.destroy)).subscribe(node => {
      this.selector = node;
    });
    this.store.pipe(select(getDivisionItems), takeUntil(this.destroy)).subscribe(divisions => {
      if (divisions && divisions.length > 0) {
        this.divisionItems.push({ label: ALL, value: ALL});
        divisions.forEach(division => {
          this.divisionItems.push({label: division.label, value: division.value});
        });
      } else {
        this.divisionItems = this.divisionItems || [];
      }
    });
    this.extractDates();
    this.buildSubTabs();
  }

  private extractDates() {
    this.dateService.getCalendar().pipe(takeUntil(this.destroy)).subscribe((response: Dates) => {
      const {startDate, stopDate, period} = response;
      this.dateRangeDisplay = {startDate, endDate: stopDate, period};
    });
  }

  private buildSubTabs() {
    this.divisionNumber = ALL;
    this.selectionType = this.selectedOptionType.BALE_PRODUCTION;
    const { otherUserTabs, corpAndSupportUserTabs } = constants;
    if (this.userService.isCorp() || this.userService.isSupport()) {
      this.availableOptions = corpAndSupportUserTabs;
    } else {
      this.availableOptions = otherUserTabs;
    }
  }

  public onSelectDivision(divisionNo: string) {
    this.divisionNumber = divisionNo;
  }

  public onStoresChange(stores) {
    if (stores) {
      const division = this.selector.children.find(node => (node.selected || node.partiallySelected));
      this.storeList = {
        division: division ? division.value.divisionNumber : null,
        stores: stores.map(store => store.value)
      };
    }
  }

  public onFacilityChange(facility: number) {
    this.facility = facility;
  }

  public tabChange(evt) {
    if (evt) {
      const detail = evt.detail;
      switch (detail) {
        case 0:
          this.selectionType = this.selectedOptionType.BALE_PRODUCTION;
          break;
        case 1:
          this.selectionType = this.selectedOptionType.STORE_ACTIVITY;
          this.storeList = {
            division: null,
            stores: null
          };
          break;
        case 2:
          this.selectionType = this.selectedOptionType.DC_ACTIVITY;
          break;
        case 3:
          this.selectionType = this.selectedOptionType.BILL_OF_LADING;
          break;
      }
    }
  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
