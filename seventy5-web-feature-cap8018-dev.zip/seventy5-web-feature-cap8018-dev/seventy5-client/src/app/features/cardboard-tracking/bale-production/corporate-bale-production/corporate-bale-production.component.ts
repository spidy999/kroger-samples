import {SelectItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import { BaleReport } from '../../domain/baleReport';
import {CalendarType} from '@shared/models/calendarType';
import {ToastDetails} from '@shared/models/Notification';
import {Component, Input, OnChanges} from '@angular/core';
import {SelectChartOptions} from '@shared/domain/appSettings';
import {DateRange, DistrictDetails, GetDistrictData} from '@shared/models/reportData';
import {BaleProductionFactors, BaleProductionOptions} from '../../models/baleProduction';
import {BaleProductionDetails} from '@features/cardboard-tracking/models/baleProductionDetails';
import {BaleProduction as constants} from '@features/cardboard-tracking/models/cardboard-tracking';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {BaleProductionService} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
const CINCINNATI_DIVISION = '014';

@Component({
  selector: 'corporate-bale-production',
  templateUrl: './corporate-bale-production.component.html',
  styleUrls: ['./corporate-bale-production.component.less']
})
export class CorporateBaleProductionComponent implements OnChanges {
  @Input() public division: string;
  @Input() public widgetDetails: DateRange;
  @Input() public baleProductionDetails: BaleReport;
  public cols: any;
  public labels: any;
  public reportData: any;
  public dateRange: any = [];
  public types: SelectItem[];
  public filters: SelectItem[];
  public exportParams: any;
  public flip = true;
  public showChart: boolean;
  public selectedType: string;
  public selectedFilter: string;
  public hoverToExpandText: string;
  public hoverToCollapseText: string;
  public divisions: SelectItem[];
  public calendarType: CalendarType;
  public districtData: DistrictDetails;
  public chartType = SelectChartOptions;
  public filterType = BaleProductionFactors;
  public selectedCalendarType = CalendarType;
  public selectionItems: SelectChartOptions[];
  public tableData: BaleProductionOptions[] = [];
  public baleProductionFactors: BaleProductionDetails;
  public getParams: GetDistrictData = new GetDistrictData();
  public spinner$: Observable<boolean> = this.util.getSpinner();

  constructor(public user: UserService,
              private util: UtilService,
              private dateService: DateService,
              private excelService: ExcelService,
              public modalService: ModalService,
              private notificationService: NotificationsService,
              private baleProductionService: BaleProductionService
  ) {}

  ngOnChanges() {
    const {types, withDcFilters, withDcColumns, withoutDcColumns} = constants;
    this.types = types;
    this.filters = withDcFilters;
    if (this.division && this.division === CINCINNATI_DIVISION) {
      this.cols = withDcColumns;
    } else {
      this.cols = withoutDcColumns;
    }
    this.initializeReport();
  }

  private initializeReport() {
    this.selectionItems = [SelectChartOptions.TABLE, SelectChartOptions.TREND_LINE];
    this.selectedFilter = this.filterType.STORE_SCANS;
    if (this.baleProductionDetails) {
      this.buildReportData();
    }
    this.exportParams = {
      divisionNo: this.baleProductionDetails.division.divisionNumber,
      startDate: DateService.getDateForRequest(this.widgetDetails.startDate),
      endDate: DateService.getDateForRequest(this.widgetDetails.endDate),
      period: this.widgetDetails.period
    };
    this.showChart = false;
  }

  private buildReportData() {
    this.calculateTableData(this.baleProductionDetails);
    this.calculateSingleDivisionTrendLineData(this.baleProductionDetails);
  }

  // To Manipulate the Single Division Bale production data into weeks
  private calculateSingleDivisionTrendLineData(response: BaleReport) {
    const randomColor = this.baleProductionService.calculateRandomColors(response);
    const baleReportData = this.baleProductionService
      .getBaleReportForEachDivisionTrendLineData(response, randomColor);
    const sensorBaleReportData = this.baleProductionService
      .getSensorBaleReportForEachDivisionTrendLineData(response, randomColor);
    const unWeighedBaleReportData = this.baleProductionService
      .getUnWeighedBaleReportForEachDivisionTrendLineData(response, randomColor);
    unWeighedBaleReportData.labels = baleReportData.labels;
    this.baleProductionFactors = this.baleProductionService
      .calculateBaleProductionTrendLineChart(baleReportData, sensorBaleReportData, unWeighedBaleReportData);
  }

  public onSelectionType(evt) {
    if (evt) {
      setTimeout(() => {
        this.selectedType = evt;
      });
    }
  }

  private calculateTableData(response: BaleReport): void {
    if (this.division) {
      this.tableData = this.baleProductionService.calculateBaleProductionDistrictTableData(response, this.division);
    }
  }

  public onSelectedRow(event): void {
    if (event && event.data && event.originalEvent && event.originalEvent.isTrusted) {
      this.viewDistrict(event.data.district);
    }
  }

  private viewDistrict(district): void {
    const ParamData = {
      divisionNo: this.baleProductionDetails.division.divisionNumber,
      startDate: DateService.getDateForRequest(this.widgetDetails.startDate),
      endDate: DateService.getDateForRequest(this.widgetDetails.endDate)
    };
    this.districtData = {...ParamData, district};
    this.getParams = ParamData;
  }

  public setHoverToCollapseText() {
    this.hoverToCollapseText = 'click to collapse';
    this.hoverToExpandText = 'click to expand';
  }

  public exportToExcel(flip) {
    this.flip = !flip;
    this.buildExcelReport();
  }

  buildExcelReport() {
    let toastDetails: ToastDetails;
    this.excelService.downloadExcelReport(this.exportParams
      , `api/CorporateExcelReport/corporate/download`)
      .subscribe(response => {
        if (response && response.body && response.body.size > 0) {
          ExcelService.createExcelFile(response);
        }
        this.flip = true;
      }, (error) => {
        if (error && error.message) {
          toastDetails = ExcelService.displayToastMessage('error',  error);
        } else {
          toastDetails = ExcelService.displayToastMessage('error');
        }
        this.notificationService.emitMessage.next(toastDetails);
        this.flip = true;
      });
  }
}
