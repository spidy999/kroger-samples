import {Router} from '@angular/router';
import {Component, Input, OnInit} from '@angular/core';
import {DistrictDetails, GetDistrictDetailData} from '@shared/models/reportData';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {BaleProductionDetails as constants} from '@features/cardboard-tracking/models/cardboard-tracking';
const CINCINNATI_DIVISION = '014';

@Component({
  selector: 'app-bale-production-details',
  templateUrl: './bale-production-details.component.html',
  styleUrls: ['./bale-production-details.component.less']
})
export class BaleProductionDetailsComponent implements OnInit {

  @Input() public districtDetails: DistrictDetails;
  public cols: any;
  public response: any;
  public tableData: any;
  public district: string;
  public showChart: boolean;
  public disableLoader = false;
  private storesData: any = [];
  private getParams: GetDistrictDetailData = new GetDistrictDetailData();

  constructor(public router: Router,
              public user: UserService,
              private util: UtilService,
              public modalService: ModalService,
              private cardboardTrackingService: BaleProductionService) {
  }

  ngOnInit() {
    if (this.districtDetails) {
      const {district, divisionNo, startDate, endDate} = this.districtDetails;
      const {withDcColumns, withoutDcColumns} = constants;
      if (divisionNo === CINCINNATI_DIVISION) {
        this.cols = withDcColumns;
      } else {
        this.cols = withoutDcColumns;
      }
      this.district = district;
      this.getParams.divisionNo = divisionNo;
      this.getParams.districtCode = district;
      this.getParams.startDate = startDate;
      this.getParams.endDate = endDate;
      this.runDistrictDetailedReport();
    } else {
      this.showChart = false;
      this.disableLoader = false;
    }
  }

  private runDistrictDetailedReport() {
    this.buildReport();
  }

  private buildReport() {
    this.cardboardTrackingService.getDetailReportOfBaleForDistrict(this.getParams)
      .subscribe(res => {
        this.response = res;
        this.buildData(this.response);
        this.showChart = true;
        this.disableLoader = true;
        },
        error => error
      );
  }

  private buildData(data) {
    this.buildDetailedData(data);
  }

  private buildDetailedData(data) {
    this.storesData = data.storeDetails;
    this.tableData = [];
    let result;
    this.storesData.forEach( baleData => {
      const {facilityNumber: store, storeScanCount, baleSensorCount, dcScanCount,
        sensorVariance, variance, actualWeight, averageWeight, notWeighedCount} = baleData;
      if (this.districtDetails.divisionNo === CINCINNATI_DIVISION) {
        result = {
          store,
          storeScans:      storeScanCount.toLocaleString('en'),
          dcScans:        dcScanCount.toLocaleString('en'),
          variance:       variance.toLocaleString('en'),
          actualWeight:   actualWeight.toLocaleString('en'),
          avgWeight:      averageWeight.toLocaleString('en'),
          unWeighedBales: notWeighedCount.toLocaleString('en'),
          baleSensorCount: baleSensorCount.toLocaleString('en'),
          sensorVariance:  sensorVariance
        };
      } else {
        result = {
          store,
          storeScans:      storeScanCount.toLocaleString('en'),
          baleSensorCount: baleSensorCount.toLocaleString('en'),
          sensorVariance:  sensorVariance
        };
      }
      this.tableData.push(result);
    });
  }
}
