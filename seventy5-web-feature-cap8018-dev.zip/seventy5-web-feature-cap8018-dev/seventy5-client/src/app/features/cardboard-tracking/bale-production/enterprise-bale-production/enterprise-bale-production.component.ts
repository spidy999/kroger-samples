import {SelectItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {ToastDetails} from '@shared/models/Notification';
import {Component, Input, OnChanges} from '@angular/core';
import {SelectChartOptions} from '@shared/domain/appSettings';
import {BaleProductionFactors} from '@features/cardboard-tracking/models/baleProduction';
import {BaleProductionDetails} from '@features/cardboard-tracking/models/baleProductionDetails';
import {BaleProduction as constants} from '@features/cardboard-tracking/models/cardboard-tracking';
import {DivisionTrendLineResponse} from '@features/cardboard-tracking/domain/divisionTrendLineResponse';
import {UtilService} from '@shared/services/util/util.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {BaleProductionService} from '@features/cardboard-tracking/services/bale-production/bale-production.service';

@Component({
  selector: 'enterprise-bale-production',
  templateUrl: './enterprise-bale-production.component.html',
  styleUrls: ['./enterprise-bale-production.component.less']
})
export class EnterpriseBaleProductionComponent implements OnChanges {

  public flip = true;
  public selectedType: string;
  public selectedFilter: string;
  public types: SelectItem[];
  public filters: SelectItem[];
  public selectionItems: SelectChartOptions[];
  public filterType = BaleProductionFactors;
  public baleProductionFactors: BaleProductionDetails;
  public spinner$: Observable<boolean> = this.util.getSpinner();
  @Input() public enterpriseReport: any;
  @Input() public enterpriseDetails: DivisionTrendLineResponse;

  constructor(private util: UtilService,
              private excelService: ExcelService,
              private notificationService: NotificationsService,
              private baleProductionService: BaleProductionService) {
    const {types, withDcFilters} = constants;
    this.types = types;
    this.filters = withDcFilters;
  }

  ngOnChanges() {
    this.initializeReport();
  }

  private initializeReport() {
    this.selectionItems = [SelectChartOptions.BAR_CHART, SelectChartOptions.LINE_CHART];
    this.selectedFilter = this.filterType.STORE_SCANS;
    if (this.enterpriseDetails) {
      this.buildReportData();
    }
  }

  private buildReportData() {
    this.calculateAllDivisionsTrendLineData(this.enterpriseDetails);
  }

  public exportToExcel(flip) {
    this.flip = !flip;
    this.buildExcelReport();
  }

  /* To Manipulate the All Divisions Bale production data into weeks */
  private calculateAllDivisionsTrendLineData(response: DivisionTrendLineResponse ) {
    const randomColor = this.baleProductionService.calculateRandomColors(response);
    const baleReportData = this.baleProductionService
      .getBaleReportForAllDivisionsTrendLineData(response, randomColor);
    const sensorBaleReportData = this.baleProductionService
      .getSensorBaleReportForAllDivisionsTrendLineData(response, randomColor);
    const unWeighedBaleReportData = this.baleProductionService
      .getUnWeighedBaleReportForAllDivisionsTrendLineData(response, randomColor);
    unWeighedBaleReportData.labels = baleReportData.labels;
    this.baleProductionFactors = this.baleProductionService.
    calculateBaleProductionTrendLineChart(baleReportData, sensorBaleReportData, unWeighedBaleReportData);
  }

  buildExcelReport() {
    let toastDetails: ToastDetails;
    this.excelService.downloadExcelReport(this.enterpriseReport
      , `api/EnterpriseExcelReport/enterprise/download`)
      .subscribe(response => {
        if (response && response.body && response.body.size > 0) {
          ExcelService.createExcelFile(response);
        }
        this.flip = true;
      }, (error) => {
        if (error && error.message) {
          toastDetails = ExcelService.displayToastMessage('error',  error);
        } else {
          toastDetails = ExcelService.displayToastMessage('error');
        }
        this.notificationService.emitMessage.next(toastDetails);
        this.flip = true;
      });
  }
}
