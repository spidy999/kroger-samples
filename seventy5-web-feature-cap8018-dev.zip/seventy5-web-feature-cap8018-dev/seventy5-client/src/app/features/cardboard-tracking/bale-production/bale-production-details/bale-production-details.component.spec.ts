import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormBuilder, FormsModule} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { BaleProductionDetailsComponent } from './bale-production-details.component';

describe('BaleProductionDetailsComponent', () => {
  let component: BaleProductionDetailsComponent;
  let userService: UserService;
  let modalService: ModalService;
  let cardboardTrackingService: BaleProductionService;
  let fixture: ComponentFixture<BaleProductionDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        UserService,
        UtilService,
        DateService,
        FormBuilder,
        FacilityService,
        ModalService,
        FiscalDateService,
        BaleProductionService
      ],
      declarations: [ BaleProductionDetailsComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaleProductionDetailsComponent);
    userService = TestBed.inject(UserService);
    modalService = TestBed.inject(ModalService);
    cardboardTrackingService = TestBed.inject(BaleProductionService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
