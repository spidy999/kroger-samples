import {SelectItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {SelectChartOptions} from '@shared/domain/appSettings';
import {CalendarType} from '@shared/models/calendarType';
import {Component, Input, OnChanges, OnInit} from '@angular/core';
import {DateRange, GetDistrictData} from '@shared/models/reportData';
import {BaleReport} from '@features/cardboard-tracking/domain/baleReport';
import {DateService} from '@shared/services/date/date.service';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {
  BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import { BaleProductionType} from '@features/cardboard-tracking/models/baleProduction';
import {BaleProduction as constants} from '@features/cardboard-tracking/models/cardboard-tracking';
import {DivisionTrendLineResponse} from '@features/cardboard-tracking/domain/divisionTrendLineResponse';
const ALL = 'ALL';

@Component({
  selector: 'bale-production',
  templateUrl: './bale-production.component.html',
  styleUrls: ['./bale-production.component.less']
})
export class BaleProductionComponent implements OnInit, OnChanges {

  constructor(public user: UserService,
              private util: UtilService,
              private dateService: DateService,
              public modalService: ModalService,
              private baleProductionService: BaleProductionService) {
    const {types, withDcColumns} = constants;
    this.cols = withDcColumns;
    this.types = types;
    this.baleProductionType = BaleProductionType.ENTERPRISE_BALE_PRODUCTION;
    this.selectionItems = [SelectChartOptions.TREND_LINE, SelectChartOptions.TABLE];
  }

  @Input() public widgetDetails: DateRange;
  @Input() public divisionNumber: string;
  public cols: any;
  public labels: any;
  public dates: string;
  public reportData: any;
  public showTable: boolean;
  public types: SelectItem[];
  public dateRange: any = [];
  public selectedType: string;
  public sortedDates: any = [];
  public enterpriseReport: any;
  public divisions: SelectItem[];
  public randomColor: string[] = [];
  public corporateDetails: BaleReport;
  public corporateDataNotAvailable = false;
  public enterpriseDataNotAvailable = false;
  public selectionItems: SelectChartOptions[];
  public calendarType: CalendarType;
  public selectedCalendarType = CalendarType;
  public baleProductionType: BaleProductionType;
  public enterpriseDetails: DivisionTrendLineResponse;
  public selectedBaleProductionType = BaleProductionType;
  public getParams: GetDistrictData = new GetDistrictData();
  public spinner$: Observable<boolean> = this.util.getSpinner();

  ngOnInit() {}

  private buildReports() {
    if (this.widgetDetails) {
      const {startDate, endDate, period} = this.widgetDetails;
      this.dateRange = [startDate, endDate, period];
      const start = DateService.getMonthDayYearFormat(startDate);
      const end = DateService.getMonthDayYearFormat(endDate);
      this.dates = `${start} - ${end}`;
      this.runBaleProductionReport();
    }
  }

  ngOnChanges(): void {
    this.buildReports();
  }

  private buildReport() {
    this.util.showSpinner();
    const divisionNo = this.getParams.divisionNo;
    if (divisionNo === ALL) {
        this.baleProductionService.getBaleProductionAllDivisionTrendLine(this.getParams)
        .subscribe((allDivisionData) => {
          this.util.hideSpinner();
          this.randomColor = this.baleProductionService.calculateRandomColors(allDivisionData);
          this.sortedDates = this.baleProductionService.calculateRangeDates(this.dateRange);
          this.enterpriseDataNotAvailable = (
             UtilService.isNullOrEmpty((allDivisionData as DivisionTrendLineResponse).divisionTrendLineDto)
             && UtilService.isNullOrEmpty((allDivisionData as DivisionTrendLineResponse).divisionUnWeightDto)
          );
          this.baleProductionType = BaleProductionType.ENTERPRISE_BALE_PRODUCTION;
          this.enterpriseDetails = allDivisionData as DivisionTrendLineResponse;
          this.enterpriseReport = {
            divisionNo: null,
            startDate: DateService.getDateForRequest(this.getParams.startDate),
            endDate: DateService.getDateForRequest(this.getParams.endDate),
            period: this.widgetDetails.period
          };
        }, () => this.util.hideSpinner());
    } else {
        this.baleProductionService.getDetailReportOfBaleForDivision(this.getParams)
          .subscribe((corporateData: BaleReport | number) => {
        this.util.hideSpinner();
        this.randomColor = this.baleProductionService.calculateRandomColors(corporateData);
        this.sortedDates = this.baleProductionService.calculateRangeDates(this.dateRange);
        this.corporateDataNotAvailable = (
          UtilService.isNullOrEmpty((corporateData as BaleReport).baleReportTrendLines)
          && UtilService.isNullOrEmpty((corporateData as BaleReport).baleReportUnWeighTrendLines)
          && UtilService.isNullOrEmpty((corporateData as BaleReport).districtDetails)
        );
        this.baleProductionType = BaleProductionType.CORPORATE_BALE_PRODUCTION;
        this.corporateDetails = corporateData as BaleReport;
        this.corporateDetails.period = this.widgetDetails.period;
      }, () => this.util.hideSpinner());
    }
  }

  private runBaleProductionReport() {
    this.getParams.divisionNo = this.divisionNumber;
    this.getParams.startDate = DateService.getDateForRequest(this.dateRange[0]);
    this.getParams.endDate = DateService.getDateForRequest(this.dateRange[1]);
    this.buildReport();
    this.showTable = true;
  }
}
