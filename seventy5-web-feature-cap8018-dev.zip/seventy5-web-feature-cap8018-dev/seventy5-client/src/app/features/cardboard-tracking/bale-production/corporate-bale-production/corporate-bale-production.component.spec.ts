import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {FormBuilder, FormsModule} from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {DivisionService} from '@shared/services/division/division.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {BaleProductionService
} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LineChartComponent} from '@app/shared/reports/line-chart/line-chart.component';
import { CorporateBaleProductionComponent } from './corporate-bale-production.component';
import {SelectionTypeComponent} from '@app/templates/selection-type/selection-type.component';
import {BaleProductionDetailsComponent
} from '@features/cardboard-tracking/bale-production/bale-production-details/bale-production-details.component';

describe('CorporateBaleProductionComponent', () => {
  let component: CorporateBaleProductionComponent;
  let userService: UserService;
  let modalService: ModalService;
  let dateService: DateService;
  let notificationService: NotificationsService;
  let baleProductionService: BaleProductionService;
  let fixture: ComponentFixture<CorporateBaleProductionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        BrowserAnimationsModule
      ],
      providers: [
        UserService,
        FormBuilder,
        DateService,
        FacilityService,
        ModalService,
        UtilService,
        DivisionService,
        NotificationsService,
        BaleProductionService
      ],
      declarations: [
        LineChartComponent,
        SelectionTypeComponent,
        BaleProductionDetailsComponent,
        CorporateBaleProductionComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateBaleProductionComponent);
    userService = TestBed.inject(UserService);
    dateService = TestBed.inject(DateService);
    modalService = TestBed.inject(ModalService);
    modalService = TestBed.inject(ModalService);
    notificationService = TestBed.inject(NotificationsService);
    baleProductionService = TestBed.inject(BaleProductionService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
