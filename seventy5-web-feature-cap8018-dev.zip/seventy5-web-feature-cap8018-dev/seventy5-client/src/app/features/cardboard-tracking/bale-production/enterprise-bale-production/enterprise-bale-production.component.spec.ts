import {FormsModule} from '@angular/forms';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {LineChartComponent} from '@app/shared/reports/line-chart/line-chart.component';
import { EnterpriseBaleProductionComponent } from './enterprise-bale-production.component';
import {UtilService} from '@shared/services/util/util.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {BaleProductionService} from '@features/cardboard-tracking/services/bale-production/bale-production.service';

describe('EnterpriseBaleProductionComponent', () => {
  let component: EnterpriseBaleProductionComponent;
  let utilService: UtilService;
  let notificationService: NotificationsService;
  let baleProductionService: BaleProductionService;

  let fixture: ComponentFixture<EnterpriseBaleProductionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        BrowserAnimationsModule
      ],
      providers: [
        UtilService,
        NotificationsService,
        BaleProductionService
      ],
      declarations: [
        LineChartComponent,
        EnterpriseBaleProductionComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterpriseBaleProductionComponent);
    utilService = TestBed.inject(UtilService);
    notificationService = TestBed.inject(NotificationsService);
    baleProductionService = TestBed.inject(BaleProductionService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
