import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {FormBuilder, FormsModule} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import { BaleProductionComponent } from './bale-production.component';
import {BaleProductionService} from '@features/cardboard-tracking/services/bale-production/bale-production.service';
import {LineChartComponent} from '@app/shared/reports/line-chart/line-chart.component';
import {SelectionTypeComponent} from '@app/templates/selection-type/selection-type.component';
import {
  BaleProductionDetailsComponent
} from '@features/cardboard-tracking/bale-production/bale-production-details/bale-production-details.component';
import {CorporateBaleProductionComponent
} from '@features/cardboard-tracking/bale-production/corporate-bale-production/corporate-bale-production.component';
import {EnterpriseBaleProductionComponent
} from '@features/cardboard-tracking/bale-production/enterprise-bale-production/enterprise-bale-production.component';

describe('BaleProductionComponent', () => {
  let component: BaleProductionComponent;
  let userService: UserService;
  let utilService: UtilService;
  let dateService: DateService;
  let modalService: ModalService;
  let baleProductionService: BaleProductionService;
  let fixture: ComponentFixture<BaleProductionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        BrowserAnimationsModule
      ],
      providers: [
        UserService,
        FormBuilder,
        FacilityService,
        DateService,
        UtilService,
        ModalService,
        BaleProductionService
      ],

      declarations: [
        LineChartComponent,
        SelectionTypeComponent,
        BaleProductionComponent,
        BaleProductionDetailsComponent,
        CorporateBaleProductionComponent,
        EnterpriseBaleProductionComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaleProductionComponent);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    dateService = TestBed.inject(DateService);
    modalService = TestBed.inject(ModalService);
    baleProductionService = TestBed.inject(BaleProductionService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
