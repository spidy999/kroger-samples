import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {select, Store} from '@ngrx/store';
import {OverlayPanel} from 'primeng/primeng';
import {MenuItem, SelectItem} from 'primeng/api';
import {AppState} from '@app/root-store/app.reducer';
import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {level} from '@features/email-configuration/models/emailConfig';
import {getDivisionItems} from '@app/root-store/divisions/divisions.selector';
import {
  EditDivisionEmailComponent
} from '@features/email-configuration/dialogs/edit-division-email/edit-division-email.component';
import {DisplayDivisionEmail, DivisionEmail} from '@features/email-configuration/models/divisionEmail';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DivisionService} from '@shared/services/division/division.service';
import {
  DivisionEmailService
} from '@features/email-configuration/services/division-email/division-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';

@Component({
  selector: 'division-email',
  templateUrl: './division-email.component.html',
  styleUrls: ['./division-email.component.less']
})

export class DivisionEmailComponent implements OnInit, OnDestroy {

  @ViewChild('actionMenu', {static: false}) actionMenu: any;
  @ViewChild(EditDivisionEmailComponent, {static: false}) editEmailDivision: EditDivisionEmailComponent;
  public innerSpinner: boolean;
  public selectedDivision: string;
  public selectedEmailGroup: number;
  public menuItems: MenuItem[];
  public emailList: DivisionEmail[] = [];
  public emailGroups: SelectItem[] = [];
  public divisionItems: SelectItem[] = [];
  public selectedEmail: DisplayDivisionEmail;
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private userService: UserService,
              private utilService: UtilService,
              private readonly store: Store<AppState>,
              private divisionService: DivisionService,
              private emailGroupService: EmailGroupService,
              private divisionEmailService: DivisionEmailService) {
  }

  ngOnInit() {
    this.utilService.hideSpinner();
    this.divisionItems = [];
    this.store.pipe(select(getDivisionItems), takeUntil(this.destroy)).subscribe(divisions => {
      if (divisions && divisions.length > 0) {
        this.divisionItems.push({label: 'Select Division', value: null});
        divisions.forEach(division => {
          this.divisionItems.push({label: division.label, value: division.value});
        });
        this.selectedDivision = this.divisionItems[0].value;
      } else {
        this.divisionItems = this.divisionItems || [];
      }
    });
    this.checkGroupNotification();
    this.loadData();
  }

  private loadData() {
    this.emailGroupService.findEmailGroupByLevel(level.DIVISION).subscribe((groups) => {
      this.emailGroups = [];
      this.emailGroups.push({label: 'Select Email Group', value: null});
      groups.forEach(group => {
        this.emailGroups.push({
          label: `${group.emailGroup}`,
          value: group.groupId
        });
      });
      this.selectedEmailGroup = this.emailGroups[0].value;
    });
  }

  public processData() {
    if (this.selectedDivision && this.selectedEmailGroup) {
      this.emailList = [];
      this.innerSpinner = true;
      this.divisionEmailService.divisionEmailList(this.selectedEmailGroup, this.selectedDivision).subscribe(group => {
        group.forEach(emailGroup => {
          this.emailList.push({
            divisionNo: emailGroup.divisionNo,
            divisionName: emailGroup.divisionName,
            groupId: emailGroup.groupId,
            groupName: emailGroup.groupName,
            emailAddress: emailGroup.emailAddress
          });
        });
        this.innerSpinner = false;
      });
    }
  }

  public showDetails(event, email: DivisionEmail, overlaypanel: OverlayPanel) {
    this.selectedEmail = email;
    overlaypanel.toggle(event);
  }

  public addNew() {
    this.editEmailDivision.showAddEmailDialog(this.selectedEmailGroup, this.selectedDivision);
  }

  public deleteEmail(email: DivisionEmail) {
   this.editEmailDivision.showDeleteEmailDialog(email);
  }

  public editEmail(email: DivisionEmail) {
    this.editEmailDivision.showEditEmailDialog(this.selectedEmailGroup, this.selectedDivision, email);
  }

  public onEditDialogSaved() {
    this.processData();
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadData();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
