import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DivisionEmailComponent } from './division-email.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {async, ComponentFixture, inject, TestBed} from '@angular/core/testing';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DivisionService} from '@shared/services/division/division.service';
import {EditDivisionEmailComponent} from '@features/email-configuration/dialogs/edit-division-email/edit-division-email.component';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {DivisionEmailService} from '@features/email-configuration/services/division-email/division-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';
import {DivisionEmail} from '@features/email-configuration/models/divisionEmail';

describe('EmailDivisionComponent', () => {
  let component: DivisionEmailComponent;
  let fixture: ComponentFixture<DivisionEmailComponent>;
  let userService: UserService;
  let utilService: UtilService;
  let divisionService: DivisionService;
  let emailGroupService: EmailGroupService;
  let divisionEmailService: DivisionEmailService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [
        DivisionEmailComponent,
        EditDivisionEmailComponent
      ],
      providers: [
        UserService,
        UtilService,
        DivisionService,
        EmailGroupService,
        DivisionEmailService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DivisionEmailComponent);
    component = fixture.componentInstance;
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    divisionService = TestBed.inject(DivisionService);
    emailGroupService = TestBed.inject(EmailGroupService);
    divisionEmailService = TestBed.inject(DivisionEmailService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it( 'should fetch division email list', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const groupId = 2;
      const division = '014';
      const result: DivisionEmail[] = [
        {
          divisionNo: '014',
          divisionName: 'Cincinnati',
          groupId: 2,
          groupName: 'DIV_EMAIL_LIST',
          emailAddress: 'div.support@gmail.com'
        }
      ];
      service.divisionEmailList(groupId, division).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/divisionEmailList/${groupId}/${division}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch insert division email', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const email: DivisionEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'DIV_EMAIL_LIST',
        emailAddress: 'div.support@gmail.com'
      };
      service.insertDivisionEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/insertDivisionEmail`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should fetch edit division email', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const old_email = 'DIV_EMAIL_LIST';
      const email: DivisionEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'DIV_EMAIL_REPORT',
        emailAddress: 'div.support@gmail.com'
      };
      service.editDivisionEmail(email, old_email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/editDivisionEmail/${old_email}`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should delete division email', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const email: DivisionEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'DIV_EMAIL_LIST',
        emailAddress: 'div.support@gmail.com'
      };
      service.deleteDivisionEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/deleteDivisionEmail`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  afterEach(() => {
    fixture.destroy();
  });
});

