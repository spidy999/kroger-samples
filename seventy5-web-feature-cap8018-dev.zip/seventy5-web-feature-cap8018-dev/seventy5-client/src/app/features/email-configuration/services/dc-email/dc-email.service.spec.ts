import {HttpClient} from '@angular/common/http';
import { DcEmailService } from './dc-email.service';
import {inject, TestBed} from '@angular/core/testing';
import {DcEmail} from '@features/email-configuration/models/dcEmail';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('DcEmailService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ HttpClient]
  }));

  it('should be created', () => {
    const service: DcEmailService = TestBed.get(DcEmailService);
    expect(service).toBeTruthy();
  });

  it( 'should fetch DC email list', inject( [ DcEmailService, HttpTestingController ],
    ( service: DcEmailService, httpMock: HttpTestingController ) => {
      const groupId = 2;
      const facility = 3;
      const result: DcEmail[] = [
        {
          facilityName: 'Woodlawn',
          facilityId: 3,
          groupId: 2,
          groupName: 'DC_EMAIL_LIST',
          emailAddress: 'dc.support@gmail.com'
        }
      ];
      service.dcEmailList(groupId, facility).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDC/emailDCList/${facility}/${groupId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch insert DC email', inject( [ DcEmailService, HttpTestingController ],
    ( service: DcEmailService, httpMock: HttpTestingController ) => {
      const email: DcEmail = {
        facilityName: 'Woodlawn',
        facilityId: 3,
        groupId: 2,
        groupName: 'DC_REPORT_EMAIL',
        emailAddress: 'dc.support@gmail.com'
      };
      service.insertDcEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDC/insertEmailDC`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should fetch edit DC email', inject( [ DcEmailService, HttpTestingController ],
    ( service: DcEmailService, httpMock: HttpTestingController ) => {
      const old_email = 'DC_REPORT_EMAIL';
      const email: DcEmail = {
        facilityName: 'Woodlawn',
        facilityId: 3,
        groupId: 2,
        groupName: 'DC_EMAIL_LIST',
        emailAddress: 'dc.support@gmail.com'
      };
      service.editDcEmail(email, old_email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDC/editEmailDC/${old_email}`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should delete DC email', inject( [ DcEmailService, HttpTestingController ],
    ( service: DcEmailService, httpMock: HttpTestingController ) => {
      const email: DcEmail = {
        facilityName: 'Woodlawn',
        facilityId: 3,
        groupId: 2,
        groupName: 'DC_EMAIL_LIST',
        emailAddress: 'dc.support@gmail.com'
      };
      service.deleteDcEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDC/deleteEmailDC`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

});
