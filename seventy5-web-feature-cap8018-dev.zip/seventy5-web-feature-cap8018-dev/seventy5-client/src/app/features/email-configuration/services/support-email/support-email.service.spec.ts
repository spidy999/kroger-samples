import {HttpClient} from '@angular/common/http';
import {inject, TestBed} from '@angular/core/testing';
import { SupportEmailService } from './support-email.service';
import {SupportEmail} from '@features/email-configuration/models/supportEmail';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('SupportEmailService', () => {
  let supportEmailService: SupportEmailService;
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ HttpClient]
  }));

  it('should be created', () => {
    supportEmailService = TestBed.inject(SupportEmailService);
    expect(supportEmailService).toBeTruthy();
  });

  it( 'should fetch support email list', inject( [ SupportEmailService, HttpTestingController ],
    ( service: SupportEmailService, httpMock: HttpTestingController ) => {
      const groupId = 2;
      const result: SupportEmail[] = [
        {
          groupId: 2,
          groupName: 'SUPP_EMAIL_LIST',
          emailAddress: 'supp.support@gmail.com'
        }
      ];
      service.supportEmailList(groupId).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( 'api/emailSupport/emailSupportList/2');
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should insert support email', inject( [ SupportEmailService, HttpTestingController ],
    ( service: SupportEmailService, httpMock: HttpTestingController ) => {
      const email: SupportEmail = {
        groupId: 2,
        groupName: 'SUPP_EMAIL_LIST',
        emailAddress: 'supp.support@gmail.com'
      };
      service.insertSupportEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailSupport/insertEmailSupport`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should edit support email', inject( [ SupportEmailService, HttpTestingController ],
    ( service: SupportEmailService, httpMock: HttpTestingController ) => {
      const old_email = 'SUPP_EMAIL_LIST';
      const email: SupportEmail = {
        groupId: 2,
        groupName: 'SUPP_EMAIL_REPORT',
        emailAddress: 'supp.support@gmail.com'
      };
      service.editSupportEmail(email, old_email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailSupport/editEmailSupport/${old_email}`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should delete support email', inject( [ SupportEmailService, HttpTestingController ],
    ( service: SupportEmailService, httpMock: HttpTestingController ) => {
      const email: SupportEmail = {
        groupId: 2,
        groupName: 'SUPP_EMAIL_LIST',
        emailAddress: 'supp.support@gmail.com'
      };
      service.deleteSupportEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( 'api/emailSupport/deleteEmailSupport');
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

});
