import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {EventEmitter, Injectable} from '@angular/core';
import {EmailGroup} from '@features/email-configuration/models/emailGroup';

@Injectable({
  providedIn: 'root'
})
export class EmailGroupService {

  constructor(private http: HttpClient) {}

  addNewGroupNotification = new EventEmitter<boolean>();

  // drop downs in Select Email Group and add new email
  findEmailGroupByLevel(level: string): Observable<EmailGroup[]> {
    return this.http.get<EmailGroup[]>('api/emailGroups/getGroupByLvl/' + level);
  }

  // insert email group: needs level and group name
  insertEmailGroup(emailGroup: EmailGroup): Observable<any> {
    return this.http.post<EmailGroup>('api/emailGroups/insertEmailGroup', emailGroup);
  }

  notifyEmailGroup(notification: boolean): void {
    this.addNewGroupNotification.next(notification);
  }

  getEmailGroupNotification(): Observable<boolean> {
    return this.addNewGroupNotification;
  }

}
