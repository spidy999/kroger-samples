import {HttpClient} from '@angular/common/http';
import {inject, TestBed} from '@angular/core/testing';
import { StoreEmailService } from './store-email.service';
import {StoreEmail} from '@features/email-configuration/models/emailStore';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('StoreEmailService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ HttpClient]
  }));

  it('should be created', () => {
    const service: StoreEmailService = TestBed.inject(StoreEmailService);
    expect(service).toBeTruthy();
  });

  it( 'should fetch store email list', inject( [ StoreEmailService, HttpTestingController ],
    ( service: StoreEmailService, httpMock: HttpTestingController ) => {
      const groupId = 2;
      const storeId = 3;
      const result: StoreEmail[] = [
        {
          groupId: 2,
          storeNo: '0456',
          divisionNo: '014',
          divisionName: 'Cincinnati',
          groupName: 'STORE_EMAIL_LIST',
          emailAddress: 'store.support@gmail.com'
        }
      ];
      service.storeEmailList(groupId, storeId).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailStore/storeEmailList/${storeId}/${groupId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should insert store email', inject( [ StoreEmailService, HttpTestingController ],
    ( service: StoreEmailService, httpMock: HttpTestingController ) => {
      const email: StoreEmail = {
        groupId: 2,
        storeNo: '0456',
        divisionNo: '014',
        groupName: 'STORE_EMAIL_LIST',
        emailAddress: 'store.support@gmail.com'
      };
      service.insertStoreEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailStore/insertStoreEmail`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should edit store email', inject( [ StoreEmailService, HttpTestingController ],
    ( service: StoreEmailService, httpMock: HttpTestingController ) => {
      const old_email = 'STORE_EMAIL_LIST';
      const email: StoreEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'STORE_EMAIL_REPORT',
        emailAddress: 'store.support@gmail.com'
      };
      service.editStoreEmail(email, old_email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailStore/editStoreEmail/${old_email}`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should delete store email', inject( [ StoreEmailService, HttpTestingController ],
    ( service: StoreEmailService, httpMock: HttpTestingController ) => {
      const email: StoreEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'STORE_EMAIL_LIST',
        emailAddress: 'store.support@gmail.com'
      };
      service.deleteStoreEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailStore/deleteStoreEmail`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

});
