import {HttpClient} from '@angular/common/http';
import {inject, TestBed} from '@angular/core/testing';
import { DivisionEmailService } from './division-email.service';
import {DivisionEmail} from '@features/email-configuration/models/divisionEmail';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('DivisionEmailService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ HttpClient]
  }));

  it('should be created', () => {
    const service: DivisionEmailService = TestBed.get(DivisionEmailService);
    expect(service).toBeTruthy();
  });

  it( 'should fetch division email list', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const groupId = 2;
      const division = '014';
      const result: DivisionEmail[] = [
        {
          divisionNo: '014',
          divisionName: 'Cincinnati',
          groupId: 2,
          groupName: 'DIV_EMAIL_LIST',
          emailAddress: 'div.support@gmail.com'
        }
      ];
      service.divisionEmailList(groupId, division).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/divisionEmailList/${groupId}/${division}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch insert division email', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const email: DivisionEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'DIV_EMAIL_LIST',
        emailAddress: 'div.support@gmail.com'
      };
      service.insertDivisionEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/insertDivisionEmail`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should fetch edit division email', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const old_email = 'DIV_EMAIL_LIST';
      const email: DivisionEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'DIV_EMAIL_REPORT',
        emailAddress: 'div.support@gmail.com'
      };
      service.editDivisionEmail(email, old_email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/editDivisionEmail/${old_email}`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));

  it( 'should delete division email', inject( [ DivisionEmailService, HttpTestingController ],
    ( service: DivisionEmailService, httpMock: HttpTestingController ) => {
      const email: DivisionEmail = {
        divisionNo: '014',
        divisionName: 'Cincinnati',
        groupId: 2,
        groupName: 'DIV_EMAIL_LIST',
        emailAddress: 'div.support@gmail.com'
      };
      service.deleteDivisionEmail(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailDivision/deleteDivisionEmail`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));
});
