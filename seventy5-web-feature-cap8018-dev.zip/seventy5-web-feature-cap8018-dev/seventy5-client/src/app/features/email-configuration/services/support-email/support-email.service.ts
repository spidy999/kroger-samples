import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Email} from '@shared/domain/email';
import {HttpClient} from '@angular/common/http';
import {SupportEmail} from '@features/email-configuration/models/supportEmail';

@Injectable({
  providedIn: 'root'
})
export class SupportEmailService {

  constructor(private http: HttpClient) {}

  supportEmailList(groupId: number): Observable<SupportEmail[]> {
    return this.http.get<SupportEmail[]>(`api/emailSupport/emailSupportList/${groupId}`);
  }

  insertSupportEmail(email: SupportEmail): Observable<any> {
    return this.http.post<Email>('api/emailSupport/insertEmailSupport', email);
  }

  editSupportEmail(email: SupportEmail, oldEmail: string): Observable<any> {
    return this.http.post<Email>( `api/emailSupport/editEmailSupport/${oldEmail}`, email);
  }

  deleteSupportEmail(email: SupportEmail): Observable<any> {
    return this.http.post<Email>('api/emailSupport/deleteEmailSupport', email);
  }

}
