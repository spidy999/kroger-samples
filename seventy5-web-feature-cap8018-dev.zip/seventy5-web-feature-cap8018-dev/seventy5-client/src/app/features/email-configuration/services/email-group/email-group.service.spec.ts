import {HttpClient} from '@angular/common/http';
import {inject, TestBed} from '@angular/core/testing';
import { EmailGroupService } from './email-group.service';
import {EmailGroup} from '@features/email-configuration/models/emailGroup';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('EmailGroupService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ HttpClient]
  }));

  it('should be created', () => {
    const service: EmailGroupService = TestBed.get(EmailGroupService);
    expect(service).toBeTruthy();
  });

  it( 'should fetch email group by level', inject( [ EmailGroupService, HttpTestingController ],
    ( service: EmailGroupService, httpMock: HttpTestingController ) => {
      const level = 'SUPP';
      const result: EmailGroup[] = [
        {
          level: 'SUPP',
          emailGroup: 'DIV_GROUP',
          groupId: 2
        }
      ];
      service.findEmailGroupByLevel(level).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailGroups/getGroupByLvl/${level}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch insert email group', inject( [ EmailGroupService, HttpTestingController ],
    ( service: EmailGroupService, httpMock: HttpTestingController ) => {
      const email: EmailGroup = {
        level: 'SUPP',
        emailGroup: 'DIV_GROUP',
        groupId: 2
      };
      service.insertEmailGroup(email).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/emailGroups/insertEmailGroup`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({});
    }));
});
