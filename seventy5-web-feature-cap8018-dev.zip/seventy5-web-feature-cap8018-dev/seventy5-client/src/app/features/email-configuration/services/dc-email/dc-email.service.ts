import { Injectable } from '@angular/core';
import {Email} from '@shared/domain/email';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {DcEmail} from '@features/email-configuration/models/dcEmail';

@Injectable({
  providedIn: 'root'
})
export class DcEmailService {

  constructor(private http: HttpClient) { }

  // when user selects specific facility required fields are groupId, facility
  dcEmailList(groupId: number, facility: number): Observable<DcEmail[]> {
    return this.http.get<DcEmail[]>(`api/emailDC/emailDCList/${facility}/${groupId}`);
  }

  insertDcEmail(email: DcEmail): Observable<any> {
    return this.http.post<DcEmail>('api/emailDC/insertEmailDC', email);
  }

  editDcEmail(email: DcEmail, oldEmail: string): Observable<any> {
    return this.http.post<Email>(`api/emailDC/editEmailDC/${oldEmail}`, email);
  }

  deleteDcEmail(email: DcEmail): Observable<any> {
    return this.http.post<DcEmail>('api/emailDC/deleteEmailDC', email);
  }
}
