import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Email} from '@shared/domain/email';
import {HttpClient} from '@angular/common/http';
import {DivisionEmail} from '@features/email-configuration/models/divisionEmail';

@Injectable({
  providedIn: 'root'
})
export class DivisionEmailService {

  constructor(private http: HttpClient) {}

  // when division is All and when user selects specific division no: required field is groupId, ?divisionNo
  divisionEmailList(groupId: number, division: string): Observable<DivisionEmail[]> {
    return this.http.get<DivisionEmail[]>(`api/emailDivision/divisionEmailList/${groupId}/${division}`);
  }

  insertDivisionEmail(email: DivisionEmail): Observable<any> {
    return this.http.post<Email>('api/emailDivision/insertDivisionEmail', email);
  }

  editDivisionEmail(email: DivisionEmail, oldEmail: string): Observable<any> {
    return this.http.post<Email>(`api/emailDivision/editDivisionEmail/${oldEmail}`, email);
  }

  deleteDivisionEmail(email: DivisionEmail): Observable<any> {
    return this.http.post<Email>('api/emailDivision/deleteDivisionEmail', email);
  }

}
