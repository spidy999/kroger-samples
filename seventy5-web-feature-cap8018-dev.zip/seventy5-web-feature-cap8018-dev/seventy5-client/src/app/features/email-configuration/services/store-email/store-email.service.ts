import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Email} from '@shared/domain/email';
import {HttpClient} from '@angular/common/http';
import {StoreEmail} from '@features/email-configuration/models/emailStore';

@Injectable({
  providedIn: 'root'
})
export class StoreEmailService {

  constructor(private http: HttpClient) {}

  storeEmailList(groupId: number, storeId: number): Observable<StoreEmail[]> {
    return this.http.get<StoreEmail[]>(`api/emailStore/storeEmailList/${storeId}/${groupId}`);
  }

  insertStoreEmail(email: StoreEmail): Observable<any> {
    return this.http.post<Email>('api/emailStore/insertStoreEmail', email);
  }

  editStoreEmail(email: StoreEmail, oldEmail: string): Observable<any> {
    return this.http.post<Email>(`api/emailStore/editStoreEmail/${oldEmail}`, email);
  }

  deleteStoreEmail(email: StoreEmail): Observable<any> {
    return this.http.post<Email>('api/emailStore/deleteStoreEmail', email);
  }
}
