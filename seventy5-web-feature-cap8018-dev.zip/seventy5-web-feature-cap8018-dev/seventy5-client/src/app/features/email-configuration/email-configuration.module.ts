import {CommonModule} from '@angular/common';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {TemplateModule} from '@app/templates/template.module';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {KrogerNgStoreSelectorModule} from 'kroger-ng-store-selector';
import {
  EmailConfigurationRoutingModule
} from '@features/email-configuration/email-configuration-routing.module';
import {GlobalInterceptorModule} from '@app/httpInterceptor.module';
import {
  EmailConfigurationComponent
} from '@features/email-configuration/email-configuration.component';
import {
  EditDcEmailComponent
} from '@features/email-configuration/dialogs/edit-dc-email/edit-dc-email.component';
import {DcEmailComponent} from '@features/email-configuration/dc-email/dc-email.component';
import {
  EditEmailGroupComponent
} from '@features/email-configuration/dialogs/edit-email-group/edit-email-group.component';
import {
  EditStoreEmailComponent
} from '@features/email-configuration/dialogs/edit-store-email/edit-store-email.component';
import {
  EditSupportEmailComponent
} from '@features/email-configuration/dialogs/edit-support-email/edit-support-email.component';
import {
  EditDivisionEmailComponent
} from '@features/email-configuration/dialogs/edit-division-email/edit-division-email.component';
import {StoreEmailComponent} from '@features/email-configuration/store-email/store-email.component';
import {SupportEmailComponent} from '@features/email-configuration/support-email/support-email.component';
import {DivisionEmailComponent} from '@features/email-configuration/division-email/division-email.component';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    PrimengModule,
    TemplateModule,
    ReactiveFormsModule,
    KdsStencilAccessorsModule,
    KrogerNgStoreSelectorModule,
    EmailConfigurationRoutingModule,
  ],
  declarations: [
    DcEmailComponent,
    StoreEmailComponent,
    SupportEmailComponent,
    DivisionEmailComponent,
    EditDcEmailComponent,
    EditEmailGroupComponent,
    EditStoreEmailComponent,
    EditSupportEmailComponent,
    EditDivisionEmailComponent,
    EmailConfigurationComponent
  ],
  providers: [
    GlobalInterceptorModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class EmailConfigurationModule { }
