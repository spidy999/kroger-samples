import {select, Store} from '@ngrx/store';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {AppState} from '@app/root-store/app.reducer';
import {Menu, MenuItem, OverlayPanel, SelectItem} from 'primeng';
import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {level} from '@features/email-configuration/models/emailConfig';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {DcEmailService} from '@features/email-configuration/services/dc-email/dc-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';
import {getFacilityItems} from '@app/root-store/facility-info/facility-info.selector';
import {DisplayDcEmail, DcEmail} from '@features/email-configuration/models/dcEmail';
import {
  EditDcEmailComponent
} from '@features/email-configuration/dialogs/edit-dc-email/edit-dc-email.component';

@Component({
  selector: 'dc-email',
  templateUrl: './dc-email.component.html',
  styleUrls: ['./dc-email.component.less']
})
export class DcEmailComponent implements OnInit, OnDestroy {

  @ViewChild('actionMenu', {static: false}) actionMenu: any;
  @ViewChild(EditDcEmailComponent, {static: false}) editEmailDC: EditDcEmailComponent;
  public innerSpinner: boolean;
  public selectedDc: number;
  public selectedEmailGroup: number;
  public selectedEmail: DisplayDcEmail;
  public menuItems: MenuItem[];
  public emailList: DcEmail[] = [];
  public emailGroups: SelectItem[] = [];
  public facilityItems: SelectItem[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private userService: UserService,
              private utilService: UtilService,
              private dcEmailService: DcEmailService,
              public facilityService: FacilityService,
              public readonly store: Store<AppState>,
              private emailGroupService: EmailGroupService) {
  }

  ngOnInit() {
    this.facilityItems = [];
    this.store.pipe(select(getFacilityItems), takeUntil(this.destroy)).subscribe(facilities => {
      if (facilities && facilities.length > 0) {
        this.facilityItems.push({label: 'Select Facility', value: null});
        facilities.forEach(facility => {
          this.facilityItems.push({label: facility.label, value: facility.value});
        });
        this.selectedDc = this.facilityItems[0].value;
      }
    });
    this.utilService.hideSpinner();
    this.checkGroupNotification();
    this.loadData();
  }

  private loadData() {
    this.emailGroupService.findEmailGroupByLevel(level.DISTRIBUTION_CENTER).subscribe((groups) => {
      this.emailGroups = [];
      this.emailGroups.push({label: 'Select Email Group', value: null});
      groups.forEach(group => {
        this.emailGroups.push({ label: `${group.emailGroup}`, value: group.groupId });
      });
      this.selectedEmailGroup = this.emailGroups[0].value;
    });
  }

  public processData() {
    if (this.selectedDc && this.selectedEmailGroup) {
      this.emailList = [];
      this.innerSpinner = true;
      this.dcEmailService.dcEmailList(this.selectedEmailGroup, this.selectedDc).subscribe(group => {
        if (group && group.length > 0) {
          group.forEach(emailGroup => {
            this.emailList.push({
              facilityId: emailGroup.facilityId,
              facilityName: emailGroup.facilityName,
              groupId: emailGroup.groupId,
              groupName: emailGroup.groupName,
              emailAddress: emailGroup.emailAddress
            });
          });
        }
        this.innerSpinner = false;
      });
    }
  }

  /* Action Menu toggles */
  public emailToggleMenu(event, email, menuItem: Menu) {
    this.menuItems = this.getActionsMenu(email);
    menuItem.toggle(event);
  }

  public getActionsMenu(item: any): MenuItem[] {
    const context = item;
    return [
      {
        label: 'Actions',
        items: [
          {label: 'Delete', icon: 'fa fa-fw fa-close', command: () => this.deleteEmail(context)}
        ]
      }
    ];
  }

  public showDetails(event, email: DcEmail, overlaypanel: OverlayPanel) {
    this.selectedEmail = email;
    overlaypanel.toggle(event);
  }

  public addNew() {
    this.editEmailDC.showAddEmailDialog(this.selectedDc, this.selectedEmailGroup);
  }

  public editEmail(email: DcEmail) {
    this.editEmailDC.showEditEmailDialog(this.selectedDc, this.selectedEmailGroup, email);
  }

  public deleteEmail(email: DcEmail) {
    this.editEmailDC.showDeleteEmailDialog(email);
  }

  public onEditDialogSaved() {
    this.processData();
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadData();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }

}
