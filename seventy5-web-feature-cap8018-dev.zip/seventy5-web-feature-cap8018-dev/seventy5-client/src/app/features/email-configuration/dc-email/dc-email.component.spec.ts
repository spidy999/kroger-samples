import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {DcEmailService} from '@features/email-configuration/services/dc-email/dc-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';
import { DcEmailComponent } from './dc-email.component';
import {EditDcEmailComponent} from '@features/email-configuration/dialogs/edit-dc-email/edit-dc-email.component';

describe('DcEmailComponent', () => {
  let component: DcEmailComponent;
  let fixture: ComponentFixture<DcEmailComponent>;
  let userService: UserService;
  let utilService: UtilService;
  let dcEmailService: DcEmailService;
  let facilityService: FacilityService;
  let emailGroupService: EmailGroupService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [ DcEmailComponent, EditDcEmailComponent ],
      providers: [
        UserService,
        UtilService,
        DcEmailService,
        FacilityService,
        EmailGroupService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DcEmailComponent);
    component = fixture.componentInstance;
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    dcEmailService = TestBed.inject(DcEmailService);
    facilityService = TestBed.inject(FacilityService);
    emailGroupService = TestBed.inject(EmailGroupService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
