
export enum EmailConfigurationTab {
  DIVISION = 'DIVISION',
  STORE = 'STORE',
  DISTRIBUTION_CENTER = 'DISTRIBUTION_CENTER',
  SUPPORT = 'SUPPORT'
}

export const EmailConfigurationTabs = {
  emailTabs: [
    {label: 'Division', value: EmailConfigurationTab.DIVISION },
    {label: 'Store', value: EmailConfigurationTab.STORE },
    {label: 'Distribution Center', value: EmailConfigurationTab.DISTRIBUTION_CENTER },
    {label: 'Support', value: EmailConfigurationTab.SUPPORT }
  ],
};

export const Options = {
 yesNoOptions: [
    {label: 'Yes', value: true},
    {label:  'No', value: false}
  ]
};

// use this value based on specific tab, this would help to get email groups based on level
export enum level {
  DIVISION = 'DIV',
  DISTRIBUTION_CENTER = 'DC',
  STORE = 'STO',
  SUPPORT = 'SUPP'
}
