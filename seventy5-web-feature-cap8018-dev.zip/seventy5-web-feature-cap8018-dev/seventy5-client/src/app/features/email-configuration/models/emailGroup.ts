export class EmailGroup {
  public groupId?: number;
  public level?: string;
  public emailGroup?: string;
}
