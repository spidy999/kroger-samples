export class SupportEmail {
  public groupId?: number;
  public groupName?: string;
  public emailAddress?: string;
}
