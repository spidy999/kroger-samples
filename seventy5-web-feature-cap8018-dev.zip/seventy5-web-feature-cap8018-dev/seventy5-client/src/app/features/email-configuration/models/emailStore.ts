export class StoreEmail {
  public identifier?: number;
  public storeNo?: string;
  public divisionNo?: string;
  public divisionName?: string;
  public groupId?: number;
  public groupName?: string;
  public emailAddress?: string;
}
