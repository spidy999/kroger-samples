
export class DivisionEmail {
  public divisionNo?: string;
  public divisionName?: string;
  public groupId?: number;
  public groupName?: string;
  public emailAddress?: string;
}

export class DisplayDivisionEmail {
  public divisionName?: string;
  public groupName?: string;
  public emailAddress?: string;
}

export class DivisionEmails {
  public division?: string;
  public emailGroup?: string;
  public emailAddress?: string;
}
