
export class DcEmail {
  public facilityName?: string;
  public facilityId?: number;
  public groupId?: number;
  public groupName?: string;
  public emailAddress?: string;

}

export class DisplayDcEmail {
  public facilityName?: string;
  public groupName?: string;
  public emailAddress?: string;
}

export class DcEmails {
  public facility?: string;
  public emailGroup?: string;
  public emailAddress?: string;
}
