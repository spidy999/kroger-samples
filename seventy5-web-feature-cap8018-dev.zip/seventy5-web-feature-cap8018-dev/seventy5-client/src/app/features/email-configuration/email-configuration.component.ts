import {MenuItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {Component, OnInit, ViewChild} from '@angular/core';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {EmailConfigurationTab} from '@features/email-configuration/models/emailConfig';
import {EmailConfigurationTabs as constants} from '@features/email-configuration/models/emailConfig';
import {EditEmailGroupComponent} from '@features/email-configuration/dialogs/edit-email-group/edit-email-group.component';

@Component({
  selector: 'app-email-configuration',
  templateUrl: './email-configuration.component.html',
  styleUrls: ['./email-configuration.component.less']
})
export class EmailConfigurationComponent implements OnInit {

  @ViewChild(EditEmailGroupComponent, {static: false}) editEmailGroup: EditEmailGroupComponent;
  public selectionType: EmailConfigurationTab;
  public selectedType = EmailConfigurationTab;
  public availableOptions: MenuItem[];
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor(private userService: UserService,
              private utilService: UtilService) {}

  ngOnInit(): void {
    this.selectionType = this.selectedType.DIVISION;
    this.buildTabs();
  }

  private buildTabs() {
    this.availableOptions = [];
    const { emailTabs } = constants;
    if (this.userService.getUser()) {
      if (this.userService.isSupport() || this.userService.isCorp()) {
        this.availableOptions = emailTabs;
      }
    }
  }

  public addNew() {
    this.editEmailGroup.showAddDialog();
  }

  public tabChange(evt) {
    if (evt) {
      const detail = evt.detail;
      switch (detail) {
        case 0:
          this.selectionType = this.selectedType.DIVISION;
          break;
        case 1:
          this.selectionType = this.selectedType.STORE;
          break;
        case 2:
          this.selectionType = this.selectedType.DISTRIBUTION_CENTER;
          break;
        case 3:
          this.selectionType = this.selectedType.SUPPORT;
          break;
      }
    }
  }
}
