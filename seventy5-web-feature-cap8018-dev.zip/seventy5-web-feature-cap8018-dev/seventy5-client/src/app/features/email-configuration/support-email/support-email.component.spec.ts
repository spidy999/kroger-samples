import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { SupportEmailComponent } from './support-email.component';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { EmailGroupService
} from '@features/email-configuration/services/email-group/email-group.service';
import {
  SupportEmailService
} from '@features/email-configuration/services/support-email/support-email.service';
import {
  EditSupportEmailComponent
} from '@features/email-configuration/dialogs/edit-support-email/edit-support-email.component';

describe('EmailSupportComponent', () => {
  let component: SupportEmailComponent;
  let fixture: ComponentFixture<SupportEmailComponent>;
  let userService: UserService;
  let utilService: UtilService;
  let emailGroupService: EmailGroupService;
  let supportEmailService: SupportEmailService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [
        SupportEmailComponent,
        EditSupportEmailComponent
      ],
      providers: [
        UserService,
        UtilService,
        EmailGroupService,
        SupportEmailService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportEmailComponent);
    component = fixture.componentInstance;
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    emailGroupService = TestBed.inject(EmailGroupService);
    supportEmailService = TestBed.inject(SupportEmailService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
