import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {MenuItem, OverlayPanel, SelectItem} from 'primeng';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {level} from '@features/email-configuration/models/emailConfig';
import {SupportEmail} from '@features/email-configuration/models/supportEmail';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';
import {SupportEmailService} from '@features/email-configuration/services/support-email/support-email.service';
import {EditSupportEmailComponent} from '@features/email-configuration/dialogs/edit-support-email/edit-support-email.component';

@Component({
  selector: 'support-email',
  templateUrl: './support-email.component.html',
  styleUrls: ['./support-email.component.less']
})
export class SupportEmailComponent implements OnInit, OnDestroy {

  @ViewChild('actionMenu', {static: false}) actionMenu: any;
  @ViewChild(EditSupportEmailComponent, {static: false}) editEmailSupport: EditSupportEmailComponent;
  public selectedEmailGroup: number;
  public innerSpinner: boolean;
  public selectedEmail: SupportEmail;
  public menuItems: MenuItem[];
  public divisions: SelectItem[] = [];
  public emailGroups: SelectItem[] = [];
  public emailList: SupportEmail[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private userService: UserService,
              private utilService: UtilService,
              private emailGroupService: EmailGroupService,
              private supportEmailService: SupportEmailService) {
  }

  ngOnInit() {
    this.utilService.hideSpinner();
    this.checkGroupNotification();
    this.loadData();
  }

  private loadData() {
    this.emailGroupService.findEmailGroupByLevel(level.SUPPORT).subscribe(groups => {
      this.emailGroups = [];
      this.emailGroups.push({label: 'Select Email Group', value: null});
      groups.forEach(group => {
        this.emailGroups.push({
          label: `${group.emailGroup}`,
          value: group.groupId
        });
      });
      this.selectedEmailGroup = this.emailGroups[0].value;
    });
  }

  public processData() {
    if (this.selectedEmailGroup) {
      this.innerSpinner = true;
      this.emailList = [];
      this.supportEmailService.supportEmailList(this.selectedEmailGroup).subscribe(group => {
        group.forEach(emailGroup => {
          this.emailList.push({
            groupId: emailGroup.groupId,
            groupName: emailGroup.groupName,
            emailAddress: emailGroup.emailAddress
          });
        });
        this.innerSpinner = false;
      });
    }
  }

  public showDetails(event, email: SupportEmail, overlaypanel: OverlayPanel) {
    this.selectedEmail = email;
    overlaypanel.toggle(event);
  }

  public addNew() {
    this.editEmailSupport.showAddEmailDialog(this.selectedEmailGroup);
  }

  public editEmail(email: SupportEmail) {
    this.editEmailSupport.showEditEmailDialog(this.selectedEmailGroup, email);
  }

  public deleteEmail(email: SupportEmail) {
    this.editEmailSupport.showDeleteEmailDialog(email);
  }

  public onEditDialogSaved() {
    this.processData();
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadData();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }

}
