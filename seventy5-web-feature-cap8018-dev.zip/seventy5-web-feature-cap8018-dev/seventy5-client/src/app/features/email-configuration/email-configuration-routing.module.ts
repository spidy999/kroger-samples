import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AuthGuard} from '@app/auth-guard';
import {Permission} from '@shared/models/permissions';
import {EmailConfigurationComponent} from '@features/email-configuration/email-configuration.component';

const adminRoutes: Routes = [
  {
    path: '',
    component: EmailConfigurationComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.EMAIL_CONFIGURATION.toString()
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class EmailConfigurationRoutingModule { }
