import {select, Store} from '@ngrx/store';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {RenderType, StoreList} from '@shared/domain/store';
import {Division} from '@shared/domain/division';
import {AppState} from '@app/root-store/app.reducer';
import {SelectorNode} from 'kroger-ng-store-selector';
import {MenuItem, OverlayPanel, SelectItem} from 'primeng';
import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {level} from '@features/email-configuration/models/emailConfig';
import {DivisionEmail} from '@features/email-configuration/models/divisionEmail';
import {getStoreNodeState} from '@app/root-store/store-node/store-node.selector';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DistrictService} from '@shared/services/district/district.service';
import {DivisionService} from '@shared/services/division/division.service';
import {
  EmailGroupService
} from '@features/email-configuration/services/email-group/email-group.service';
import {
  StoreEmailService
} from '@features/email-configuration/services/store-email/store-email.service';
import {getDivisions} from '@app/root-store/divisions/divisions.selector';
import {StoreEmail} from '@features/email-configuration/models/emailStore';
import {
  EditStoreEmailComponent
} from '@features/email-configuration/dialogs/edit-store-email/edit-store-email.component';

@Component({
  selector: 'store-email',
  templateUrl: './store-email.component.html',
  styleUrls: ['./store-email.component.less']
})
export class StoreEmailComponent implements OnInit, OnDestroy {

  @ViewChild('actionMenu', {static: false}) actionMenu: any;
  @ViewChild(EditStoreEmailComponent, {static: false}) editEmailStore: EditStoreEmailComponent;
  public innerSpinner: boolean;
  public outerSpinner: boolean;
  public storeId: number;
  public storeNo: string;
  public selectionMode: any;
  public renderType = RenderType;
  public selectedEmailGroup: number;
  public menuItems: MenuItem[];
  public storeList: StoreList;
  public selector: SelectorNode;
  public selectedEmail: StoreEmail;
  public divisions: Division[];
  public emailList: StoreEmail[] = [];
  public emailGroups: SelectItem[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private userService: UserService,
              private utilService: UtilService,
              private readonly store: Store<AppState>,
              private divisionService: DivisionService,
              private districtService: DistrictService,
              private storeEmailService: StoreEmailService,
              private emailGroupService: EmailGroupService) {
  }

  ngOnInit() {
    this.outerSpinner = true;
    this.selectionMode = 'SINGLE';
    this.store.pipe(select(getStoreNodeState), takeUntil(this.destroy)).subscribe(node => {
      this.selector = node;
    });
    this.store.pipe(select(getDivisions), takeUntil(this.destroy)).subscribe(divisions => {
      this.divisions = divisions;
    });
    this.utilService.hideSpinner();
    this.checkGroupNotification();
    this.loadData();
  }

  private loadData() {
      this.emailGroupService.findEmailGroupByLevel(level.STORE)
      .subscribe((groups) => {
        this.emailGroups = [];
        this.emailGroups.push({label: 'Select Email Group', value: null});
        groups.forEach(group => {
        this.emailGroups.push({
          label: `${group.emailGroup}`,
          value: group.groupId
        });
      });
      this.selectedEmailGroup = this.emailGroups[0].value;
      this.outerSpinner = false;
    });
  }

  public onStoreChange(store) {
    if (store && store.length > 0) {
      const storeNode = store[0].value;
      this.storeNo = storeNode ? storeNode.facility : null;
      this.storeId = storeNode ? storeNode.identifier : null;
      this.processData();
    }
  }

  public processData() {
    if (this.storeId && this.selectedEmailGroup) {
      this.innerSpinner = true;
      this.emailList = [];
      this.storeEmailService.storeEmailList(this.selectedEmailGroup, this.storeId)
        .subscribe(group => {
          group.forEach(emailGroup => {
            this.emailList.push({
              identifier: emailGroup.identifier,
              divisionNo: emailGroup.divisionNo,
              storeNo: emailGroup.storeNo,
              groupId: emailGroup.groupId,
              groupName: emailGroup.groupName,
              emailAddress: emailGroup.emailAddress
            });
          });
          this.innerSpinner = false;
        });
    }
  }

  public showDetails(event, email: DivisionEmail, overlayPanel: OverlayPanel) {
    this.selectedEmail = email;
    overlayPanel.toggle(event);
  }

  public addNew() {
    const storeDetails = { label: this.storeNo, value: this.storeId};
    if (this.storeNo) {
      this.editEmailStore.showAddEmailDialog(storeDetails, this.selectedEmailGroup);
    }
  }

  public editEmail(email: StoreEmail) {
    const storeDetails = { label: this.storeNo, value: this.storeId};
    if (this.storeNo) {
      email.divisionName = this.getDivisionName(email.divisionNo);
      this.editEmailStore.showEditEmailDialog(storeDetails, this.selectedEmailGroup, email);
    }
  }

  public deleteEmail(email: StoreEmail) {
    email.divisionName = this.getDivisionName(email.divisionNo);
    this.editEmailStore.showDeleteEmailDialog(email);
  }

  public onEditDialogSaved() {
    this.processData();
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadData();
      }
    });
  }

  getDivisionName(divisionNo) {
    const divisionObj = this.divisions.find(division => division.divisionNumber === divisionNo);
    return divisionObj.divisionDesc;
  }

  ngOnDestroy(): void {
      this.destroy.next(true);
      this.destroy.unsubscribe();
  }

}
