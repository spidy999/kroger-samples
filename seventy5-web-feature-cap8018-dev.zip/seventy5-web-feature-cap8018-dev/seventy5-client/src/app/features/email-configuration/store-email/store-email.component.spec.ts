import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreEmailComponent } from './store-email.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {DistrictService} from '@shared/services/district/district.service';
import {DivisionService} from '@shared/services/division/division.service';
import {
  StoreEmailService
} from '@features/email-configuration/services/store-email/store-email.service';
import {
  EmailGroupService
} from '@features/email-configuration/services/email-group/email-group.service';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {
  EditStoreEmailComponent
} from '@features/email-configuration/dialogs/edit-store-email/edit-store-email.component';

describe('EmailStoreComponent', () => {
  let component: StoreEmailComponent;
  let fixture: ComponentFixture<StoreEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [
        StoreEmailComponent,
        EditStoreEmailComponent
      ],
      providers: [
        UserService,
        UtilService,
        DistrictService,
        DivisionService,
        StoreEmailService,
        EmailGroupService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreEmailComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
