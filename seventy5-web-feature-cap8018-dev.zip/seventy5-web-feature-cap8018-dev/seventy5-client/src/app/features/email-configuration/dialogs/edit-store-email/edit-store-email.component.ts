import {SelectItem} from 'primeng';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {ToastDetails} from '@shared/models/Notification';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {level} from '@features/email-configuration/models/emailConfig';
import {StoreEmail} from '@features/email-configuration/models/emailStore';
import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import {
  NotificationsService
} from '@shared/services/notifications/notifications.service';
import {
  EmailGroupService
} from '@features/email-configuration/services/email-group/email-group.service';
import {
  StoreEmailService
} from '@features/email-configuration/services/store-email/store-email.service';

@Component({
  selector: 'edit-store-email',
  templateUrl: './edit-store-email.component.html',
  styleUrls: ['./edit-store-email.component.less']
})
export class EditStoreEmailComponent implements OnInit, OnDestroy {

  @Output() action = new EventEmitter<string>();
  public emailFlag = false;
  public doingAddNew = false;
  public showDialogFlag = false;
  public emailForm: FormGroup;
  public oldEmailAddress: string;
  public selectedEmail: StoreEmail;
  public divisions: SelectItem[] = [];
  public emailGroups: SelectItem[] = [];
  public storeDetails: SelectItem[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private storeEmailService: StoreEmailService,
              private emailGroupService: EmailGroupService,
              private notificationService: NotificationsService) { }

  ngOnInit() {
    this.createFormGroup();
    this.checkGroupNotification();
    this.loadEmailGroups();
  }

  private createFormGroup() {
    const EMAIL_ADDRESS_LENGTH = 50;
    const EMAIL_GROUP_LENGTH = 25;
    this.emailForm = new FormGroup({
      store: new FormControl({value: null, disabled: true}, [Validators.required]),
      emailGroup: new FormControl({value: null, disabled: true}, [Validators.required, Validators.maxLength(EMAIL_GROUP_LENGTH)]),
      emailAddress: new FormControl(null, [Validators.required, Validators.maxLength(EMAIL_ADDRESS_LENGTH), Validators.email]),
    });
  }

  private loadEmailGroups() {
    this.emailGroupService.findEmailGroupByLevel(level.STORE).subscribe(groups => {
      groups.forEach(group => {
        this.emailGroups.push({'label' : group.emailGroup, 'value': group.groupId});
      });
    });
  }

  public showAddEmailDialog(storeData, emailGroup) {
    if (storeData && emailGroup) {
      this.storeDetails = [];
      this.storeDetails.push(storeData);
      this.emailForm.get('store').setValue(storeData.value);
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.doingAddNew = true;
      this.showDialogFlag = true;
    }
  }

  public showEditEmailDialog(storeData, emailGroup, email) {
    if (storeData && emailGroup) {
      this.storeDetails = [];
      this.oldEmailAddress = email.emailAddress;
      this.storeDetails.push(storeData);
      this.emailForm.get('store').setValue(storeData.value);
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.emailForm.get('emailAddress').setValue(email.emailAddress);
      this.doingAddNew = false;
      this.showDialogFlag = true;
    }
  }

  public showDeleteEmailDialog(email: StoreEmail) {
    const deleteEmail = new StoreEmail();
    deleteEmail.identifier = email.identifier;
    deleteEmail.groupId = email.groupId;
    deleteEmail.divisionName = email.divisionName;
    deleteEmail.groupName = email.groupName;
    deleteEmail.emailAddress = email.emailAddress;
    this.selectedEmail = deleteEmail;
    this.emailFlag = true;
  }

  private getEmail(): StoreEmail {
    const email: StoreEmail = {};
    const controls = this.emailForm.controls;
    email.identifier = controls.store.value;
    email.groupId = controls.emailGroup.value;
    email.emailAddress = controls.emailAddress.value;
    return email;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    if (flag) {
      const email = this.getEmail();
      if (this.doingAddNew) {
        this.storeEmailService.insertStoreEmail(email).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record created successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.storeEmailService.editStoreEmail(email, this.oldEmailAddress).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record updated successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.emailForm.reset();
    this.emailForm.markAsPristine();
    this.showDialogFlag = false;
  }

  public deleteSelectedEmail(flag: boolean) {
    let toastDetails: ToastDetails = {};
    if (flag) {
      this.storeEmailService.deleteStoreEmail(this.selectedEmail).subscribe(() => {
        this.action.emit('deleted');
        toastDetails = {
          title: 'Success',
          message: 'Record deleted successfully.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record not deleted.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.emailFlag = false;
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadEmailGroups();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
