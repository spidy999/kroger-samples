import {SelectItem} from 'primeng';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {ToastDetails} from '@shared/models/Notification';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {DcEmail} from '@features/email-configuration/models/dcEmail';
import {level} from '@features/email-configuration/models/emailConfig';
import {FacilityService} from '@shared/services/facility/facility.service';
import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {DcEmailService} from '@features/email-configuration/services/dc-email/dc-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';

@Component({
  selector: 'edit-dc-email',
  templateUrl: './edit-dc-email.component.html',
  styleUrls: ['./edit-dc-email.component.less']
})
export class EditDcEmailComponent implements OnInit, OnDestroy {

  @Output() action = new EventEmitter<string>();
  public doingAddNew = false;
  public emailFlag = false;
  public showDialogFlag = false;
  public emailForm: FormGroup;
  public selectedEmail: DcEmail;
  public oldEmailAddress: string;
  public facilities: SelectItem[] = [];
  public emailGroups: SelectItem[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private dcEmailService: DcEmailService,
              private facilityService: FacilityService,
              private emailGroupService: EmailGroupService,
              private notificationService: NotificationsService) { }

  ngOnInit() {
    this.createFormGroup();
    this.checkGroupNotification();
    this.loadDivisionsAndEmailGroups();
  }

  private createFormGroup() {
    const EMAIL_ADDRESS_LENGTH = 50;
    const EMAIL_GROUP_LENGTH = 25;
    this.emailForm = new FormGroup({
      facility: new FormControl({value: null, disabled: true}, [Validators.required]),
      emailGroup: new FormControl({value: null, disabled: true}, [Validators.required, Validators.maxLength(EMAIL_GROUP_LENGTH)]),
      emailAddress: new FormControl(null, [Validators.required, Validators.maxLength(EMAIL_ADDRESS_LENGTH), Validators.email]),
    });
  }

  private loadDivisionsAndEmailGroups() {
    this.facilityService.getAllFacilities().subscribe(facilities => {
      this.facilities = [];
      facilities.forEach(facility => {
        this.facilities.push({
          label: `${facility.facilityName}`,
          value: facility.facilityId
        });
      });
    });

    this.emailGroupService.findEmailGroupByLevel(level.DISTRIBUTION_CENTER).subscribe(groups => {
      groups.forEach(group => {
        this.emailGroups.push({'label': group.emailGroup, 'value': group.groupId});
      });
    });
  }

  public showAddEmailDialog(facility, emailGroup) {
    if (facility && emailGroup) {
      this.emailForm.get('facility').setValue(facility);
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.doingAddNew = true;
      this.showDialogFlag = true;
    }
  }

  public showEditEmailDialog(facility, emailGroup, email) {
    if (facility && emailGroup) {
      this.oldEmailAddress = email.emailAddress;
      this.emailForm.get('facility').setValue(facility);
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.emailForm.get('emailAddress').setValue(email.emailAddress);
      this.doingAddNew = false;
      this.showDialogFlag = true;
    }
  }

  public showDeleteEmailDialog(email: DcEmail) {
    const deleteEmail = new DcEmail();
    deleteEmail.facilityId = email.facilityId;
    deleteEmail.groupId = email.groupId;
    deleteEmail.facilityName = email.facilityName;
    deleteEmail.groupName = email.groupName;
    deleteEmail.emailAddress = email.emailAddress;
    this.selectedEmail = deleteEmail;
    this.emailFlag = true;
  }

  private getEmail(): DcEmail {
    const email: DcEmail = {};
    const controls = this.emailForm.controls;
    email.facilityId = controls.facility.value;
    email.groupId = controls.emailGroup.value;
    email.emailAddress = controls.emailAddress.value;
    return email;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    if (flag) {
      const email = this.getEmail();
      if (this.doingAddNew) {
        this.dcEmailService.insertDcEmail(email).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record created successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.dcEmailService.editDcEmail(email, this.oldEmailAddress).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record updated successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.emailForm.reset();
    this.emailForm.markAsPristine();
    this.showDialogFlag = false;
  }

  public deleteSelectedEmail(flag: boolean) {
    let toastDetails: ToastDetails = {};
    if (flag) {
      this.dcEmailService.deleteDcEmail(this.selectedEmail).subscribe(() => {
        this.action.emit('deleted');
        toastDetails = {
          title: 'Success',
          message: 'Record deleted successfully.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record not deleted.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.emailFlag = false;
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadDivisionsAndEmailGroups();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }

}
