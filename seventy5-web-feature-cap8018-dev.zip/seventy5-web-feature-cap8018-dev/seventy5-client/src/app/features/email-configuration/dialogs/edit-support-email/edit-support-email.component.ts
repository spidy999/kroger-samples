import {SelectItem} from 'primeng';
import {Subject} from 'rxjs/Subject';
import {takeUntil} from 'rxjs/operators';
import {ToastDetails} from '@shared/models/Notification';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {level} from '@features/email-configuration/models/emailConfig';
import {SupportEmail} from '@features/email-configuration/models/supportEmail';
import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import {
  NotificationsService
} from '@shared/services/notifications/notifications.service';
import {
  EmailGroupService
} from '@features/email-configuration/services/email-group/email-group.service';
import {
  SupportEmailService
} from '@features/email-configuration/services/support-email/support-email.service';

@Component({
  selector: 'edit-support-email',
  templateUrl: './edit-support-email.component.html',
  styleUrls: ['./edit-support-email.component.less']
})
export class EditSupportEmailComponent implements OnInit, OnDestroy {

  @Output() action = new EventEmitter<string>();
  public emailFlag = false;
  public doingAddNew = false;
  public showDialogFlag = false;
  public emailForm: FormGroup;
  public oldEmailAddress: string;
  public selectedEmail: SupportEmail;
  public divisions: SelectItem[] = [];
  public storeDetails: SelectItem[] = [];
  public emailGroups: SelectItem[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private emailGroupService: EmailGroupService,
              private supportEmailService: SupportEmailService,
              private notificationService: NotificationsService) { }

  ngOnInit() {
    this.createFormGroup();
    this.checkGroupNotification();
    this.loadEmailGroups();
  }

  private createFormGroup() {
    const EMAIL_ADDRESS_LENGTH = 50;
    const EMAIL_GROUP_LENGTH = 25;
    this.emailForm = new FormGroup({
      emailGroup: new FormControl({value: null, disabled: true}, [Validators.required, Validators.maxLength(EMAIL_GROUP_LENGTH)]),
      emailAddress: new FormControl(null, [Validators.required, Validators.maxLength(EMAIL_ADDRESS_LENGTH), Validators.email]),
    });
  }

  private loadEmailGroups() {
    this.emailGroupService.findEmailGroupByLevel(level.SUPPORT).subscribe(groups => {
      groups.forEach(group => {
        this.emailGroups.push({'label' : group.emailGroup, 'value': group.groupId});
      });
    });
  }

  public showAddEmailDialog(emailGroup) {
    if (emailGroup) {
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.doingAddNew = true;
      this.showDialogFlag = true;
    }
  }

  public showEditEmailDialog(emailGroup, email) {
    if (emailGroup) {
      this.oldEmailAddress = email.emailAddress;
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.emailForm.get('emailAddress').setValue(email.emailAddress);
      this.doingAddNew = false;
      this.showDialogFlag = true;
    }
  }

  private getEmail(): SupportEmail {
    const email: SupportEmail = {};
    const controls = this.emailForm.controls;
    email.groupId = controls.emailGroup.value;
    email.emailAddress = controls.emailAddress.value;
    return email;
  }

  public showDeleteEmailDialog(email: SupportEmail) {
    const deleteEmail = new SupportEmail();
    deleteEmail.groupId = email.groupId;
    deleteEmail.groupName = email.groupName;
    deleteEmail.emailAddress = email.emailAddress;
    this.selectedEmail = deleteEmail;
    this.emailFlag = true;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    if (flag) {
      const email = this.getEmail();
      if (this.doingAddNew) {
        this.supportEmailService.insertSupportEmail(email).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record created successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.supportEmailService.editSupportEmail(email, this.oldEmailAddress).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record updated successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.emailForm.reset();
    this.emailForm.markAsPristine();
    this.showDialogFlag = false;
  }

  public deleteSelectedEmail(flag: boolean) {
    let toastDetails: ToastDetails = {};
    if (flag) {
      this.supportEmailService.deleteSupportEmail(this.selectedEmail).subscribe(() => {
        this.action.emit('deleted');
        toastDetails = {
          title: 'Success',
          message: 'Record deleted.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record not deleted.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.emailFlag = false;
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadEmailGroups();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
