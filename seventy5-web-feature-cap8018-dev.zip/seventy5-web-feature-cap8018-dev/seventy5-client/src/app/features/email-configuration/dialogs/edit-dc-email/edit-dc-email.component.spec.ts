import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { EditDcEmailComponent } from './edit-dc-email.component';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {FacilityService} from '@shared/services/facility/facility.service';
import {DcEmailService} from '@features/email-configuration/services/dc-email/dc-email.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';

describe('EditDcEmailComponent', () => {
  let component: EditDcEmailComponent;
  let fixture: ComponentFixture<EditDcEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ EditDcEmailComponent ],
      providers: [
        DcEmailService,
        FacilityService,
        EmailGroupService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDcEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
