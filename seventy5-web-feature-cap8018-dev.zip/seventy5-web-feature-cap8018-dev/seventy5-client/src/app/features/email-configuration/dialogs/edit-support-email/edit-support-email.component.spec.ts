import {PrimengModule} from '@shared/primeng/primeng.module';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditSupportEmailComponent } from './edit-support-email.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SupportEmailService} from '@features/email-configuration/services/support-email/support-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

describe('EditEmailSupportComponent', () => {
  let component: EditSupportEmailComponent;
  let fixture: ComponentFixture<EditSupportEmailComponent>;
  let emailGroupService: EmailGroupService;
  let supportEmailService: SupportEmailService;
  let notificationsService: NotificationsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [ EditSupportEmailComponent ],
      providers: [
        EmailGroupService,
        SupportEmailService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSupportEmailComponent);
    component = fixture.componentInstance;
    emailGroupService = TestBed.inject(EmailGroupService);
    notificationsService = TestBed.inject(NotificationsService);
    supportEmailService = TestBed.inject(SupportEmailService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
