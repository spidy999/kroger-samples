import {PrimengModule} from '@shared/primeng/primeng.module';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditStoreEmailComponent } from './edit-store-email.component';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {StoreEmailService} from '@features/email-configuration/services/store-email/store-email.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';

describe('EditEmailStoreComponent', () => {
  let component: EditStoreEmailComponent;
  let fixture: ComponentFixture<EditStoreEmailComponent>;
  let emailGroupService: EmailGroupService;
  let storeEmailService: StoreEmailService;
  let notificationsService: NotificationsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditStoreEmailComponent ],
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      providers: [
        StoreEmailService,
        EmailGroupService,
        NotificationsService
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditStoreEmailComponent);
    component = fixture.componentInstance;
    emailGroupService = TestBed.inject(EmailGroupService);
    notificationsService = TestBed.inject(NotificationsService);
    storeEmailService = TestBed.inject(StoreEmailService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
