import {Subject} from 'rxjs/Subject';
import {SelectItem} from 'primeng/api';
import {takeUntil} from 'rxjs/operators';
import {ToastDetails} from '@shared/models/Notification';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {level} from '@features/email-configuration/models/emailConfig';
import {DivisionService} from '@shared/services/division/division.service';
import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import {DivisionEmail} from '@features/email-configuration/models/divisionEmail';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';
import {DivisionEmailService} from '@features/email-configuration/services/division-email/division-email.service';

@Component({
  selector: 'edit-division-email',
  templateUrl: './edit-division-email.component.html',
  styleUrls: ['./edit-division-email.component.less']
})
export class EditDivisionEmailComponent implements OnInit, OnDestroy {

  @Output() action = new EventEmitter<string>();
  public emailFlag = false;
  public doingAddNew = false;
  public emailForm: FormGroup;
  public showDialogFlag = false;
  public oldEmailAddress: string;
  public selectedEmail: DivisionEmail;
  public divisions: SelectItem[] = [];
  public emailGroups: SelectItem[] = [];
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private divisionService: DivisionService,
              private emailGroupService: EmailGroupService,
              private notificationService: NotificationsService,
              private divisionEmailService: DivisionEmailService) { }

  ngOnInit() {
    this.createFormGroup();
    this.checkGroupNotification();
    this.loadDivisionsAndEmailGroups();
  }

  private createFormGroup() {
    const EMAIL_ADDRESS_LENGTH = 50;
    const EMAIL_GROUP_LENGTH = 25;
    this.emailForm = new FormGroup({
      division: new FormControl({value: null, disabled: true}, [Validators.required]),
      emailGroup: new FormControl({value: null, disabled: true}, [Validators.required, Validators.maxLength(EMAIL_GROUP_LENGTH)]),
      emailAddress: new FormControl(null, [Validators.required, Validators.maxLength(EMAIL_ADDRESS_LENGTH), Validators.email]),
    });
  }

  private loadDivisionsAndEmailGroups() {
    this.divisionService.getIncludedDivisions().subscribe(divisions => {
      for (const division of divisions) {
        this.divisions.push({
          label: `${division.divisionDesc} - ${division.divisionNumber}`,
          value: division.divisionNumber
        });
      }
    });

    this.emailGroupService.findEmailGroupByLevel(level.DIVISION).subscribe(groups => {
      groups.forEach(group => {
        this.emailGroups.push({'label' : group.emailGroup, 'value': group.groupId});
      });
    });
  }

  public showAddEmailDialog(emailGroup, division) {
    if (emailGroup && division) {
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.emailForm.get('division').setValue(division);
      this.doingAddNew = true;
      this.showDialogFlag = true;
    }
  }

  public showDeleteEmailDialog(email: DivisionEmail) {
    const deleteEmail = new DivisionEmail();
    deleteEmail.divisionNo = email.divisionNo;
    deleteEmail.groupId = email.groupId;
    deleteEmail.divisionName = email.divisionName;
    deleteEmail.groupName = email.groupName;
    deleteEmail.emailAddress = email.emailAddress;
    this.selectedEmail = deleteEmail;
    this.emailFlag = true;
  }

  public showEditEmailDialog(emailGroup, division, email) {
    if (emailGroup && division && email) {
      this.oldEmailAddress = email.emailAddress;
      this.emailForm.get('emailGroup').setValue(emailGroup);
      this.emailForm.get('division').setValue(division);
      this.emailForm.get('emailAddress').setValue(email.emailAddress);
      this.doingAddNew = false;
      this.showDialogFlag = true;
    }
  }

  private getEmail(): DivisionEmail {
    const email: DivisionEmail = {};
    const controls = this.emailForm.controls;
    email.divisionNo = controls.division.value;
    email.groupId = controls.emailGroup.value;
    email.emailAddress = controls.emailAddress.value;
    return email;
  }

  public saveEmail(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    if (flag) {
      const email = this.getEmail();
      if (this.doingAddNew) {
        this.divisionEmailService.insertDivisionEmail(email).subscribe(response => {
          if (response && response.statusInfo) {
              if (response.statusInfo.exitStatus === 'SUCCESS') {
                this.action.emit('saved');
                toastDetails = {
                  title: 'Success',
                  message: 'Record created successfully.',
                  toastType: 'success'
                };
              } else {
                toastDetails = {
                  title: 'Failure',
                  message: `Record ${response.data}.`,
                  toastType: 'error'
                };
              }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.divisionEmailService.editDivisionEmail(email, this.oldEmailAddress).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.action.emit('saved');
              toastDetails = {
                title: 'Success',
                message: 'Record updated successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.emailForm.reset();
    this.emailForm.markAsPristine();
    this.showDialogFlag = false;
  }

  public deleteSelectedEmail(flag: boolean) {
    let toastDetails: ToastDetails = {};
    if (flag) {
      this.divisionEmailService.deleteDivisionEmail(this.selectedEmail).subscribe(() => {
        this.action.emit('deleted');
        toastDetails = {
          title: 'Success',
          message: 'Record deleted successfully.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record not deleted.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.emailFlag = false;
  }

  public checkGroupNotification() {
    this.emailGroupService.getEmailGroupNotification().pipe(takeUntil(this.destroy)).subscribe(check => {
      if (check) {
        this.loadDivisionsAndEmailGroups();
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
