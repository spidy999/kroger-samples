import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditDivisionEmailComponent } from './edit-division-email.component';

describe('EditEmailDivisionComponent', () => {
  let component: EditDivisionEmailComponent;
  let fixture: ComponentFixture<EditDivisionEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDivisionEmailComponent ],
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDivisionEmailComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
