import {SelectItem} from 'primeng/api';
import {Component, OnInit} from '@angular/core';
import {ToastDetails} from '@shared/models/Notification';
import {UtilService} from '@shared/services/util/util.service';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {level} from '@features/email-configuration/models/emailConfig';
import {EmailGroup} from '@features/email-configuration/models/emailGroup';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {EmailGroupService} from '@features/email-configuration/services/email-group/email-group.service';

@Component({
  selector: 'edit-email-group',
  templateUrl: './edit-email-group.component.html',
  styleUrls: ['./edit-email-group.component.less']
})
export class EditEmailGroupComponent implements OnInit {

  public doingAddNew = false;
  public showDialogFlag = false;
  public emailGroupForm: FormGroup;
  public groupLevels: SelectItem[] = [];

  constructor(private utilService: UtilService,
              private emailGroupService: EmailGroupService,
              private notificationService: NotificationsService) {
  }

  ngOnInit(): void {
    this.createFormGroup();
  }

  private createFormGroup() {
    const GROUP_NAME_LENGTH = 25;
    this.emailGroupForm = new FormGroup({
      groupName: new FormControl(null, [Validators.required, Validators.maxLength(GROUP_NAME_LENGTH)]),
      groupLink: new FormControl(null, [Validators.required]),
    });

    this.groupLevels = [
      {label: 'Select Group Link', value: null},
      { label: 'DIVISION', value: level.DIVISION},
      { label: 'STORE', value: level.STORE},
      { label: 'DISTRIBUTION_CENTER', value: level.DISTRIBUTION_CENTER},
      { label: 'SUPPORT', value: level.SUPPORT}
    ];
  }

  private getEmail(): EmailGroup {
    const email: EmailGroup = {};
    const controls = this.emailGroupForm.controls;
    email.emailGroup = controls.groupName.value;
    email.level = controls.groupLink.value;
    return email;
  }

  public showAddDialog() {
    this.emailGroupForm.get('groupLink').setValue(this.groupLevels[0].value);
    this.doingAddNew = true;
    this.showDialogFlag = true;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    if (flag) {
      const email = this.getEmail();
      if (this.doingAddNew) {
        this.emailGroupService.insertEmailGroup(email).subscribe(response => {
          if (response && response.statusInfo) {
            if (response.statusInfo.exitStatus === 'SUCCESS') {
              this.emailGroupService.notifyEmailGroup(true);
              toastDetails = {
                title: 'Success',
                message: 'Record created successfully.',
                toastType: 'success'
              };
            } else {
              toastDetails = {
                title: 'Failure',
                message: `Record ${response.data}.`,
                toastType: 'error'
              };
            }
          }
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.emailGroupForm.reset();
    this.emailGroupForm.markAsPristine();
    this.showDialogFlag = false;
  }

}
