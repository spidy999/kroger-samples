import { EnterpriseTrendline } from './enterpriseTrendline';

export class EnterpriseTrendlineDto {
    divisionName: string;
    enterpriseTrendlineList: EnterpriseTrendline[];

}
