export class LabelButNotScanDto {
    totalStoreAndDcScan: number;
    totalDcScan: number;
    totalStoreScan: number;
    totalStoreCount: number;
    labelButNotScanPercent: number;
    labelButNotScanAtStore: number;
    totalBaleLabelledAtStore: number;

}
