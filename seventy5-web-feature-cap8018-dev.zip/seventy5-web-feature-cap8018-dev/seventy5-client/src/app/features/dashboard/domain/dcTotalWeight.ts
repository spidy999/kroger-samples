export class DcTotalWeight {
    totalWeight: number;
    totalWeightInTons: number;
}
