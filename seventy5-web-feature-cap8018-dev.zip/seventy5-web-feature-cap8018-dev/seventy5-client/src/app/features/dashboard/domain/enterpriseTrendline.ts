export class EnterpriseTrendline {
    divisionName: string;
    divisionNo: string;
    weeklyDate: string;
    baleCount: number;
    totalStore: number;
    avgBaleCount: number;
}
