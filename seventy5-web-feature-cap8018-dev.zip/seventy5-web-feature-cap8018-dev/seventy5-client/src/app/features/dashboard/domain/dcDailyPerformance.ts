import { DcShiftPerformance } from './dcShiftPerformance';

export class DcDailyPerformance {
    reportDate: string;
    scannedCount: number;
    weighedCount: number;
    labelledCount: number;
    shiftPerformance: DcShiftPerformance[];
    weighedPercent: number;
    scannedButNotWeighed: number;

}
