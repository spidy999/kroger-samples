import { EnterpriseBaleDto } from './enterpriseBaleDto';

export class EnterpriseCardboardDto {

    totalBaleCount: number;
    averageBalecount: number;
    totalZeroScan: number;
    enterpriseBaleDtoList: EnterpriseBaleDto[];
    enterpriseAverage: number;
}
