export class StoreVsDcDto {
    storeScan: number;
    dcScan: number;
    variance: number;

}
