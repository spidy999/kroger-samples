export class DailyStorePerformance {
    reportDate: string;
    scannedCount: number;
    storeCount: number;
    avgStoreCount: number;
}
