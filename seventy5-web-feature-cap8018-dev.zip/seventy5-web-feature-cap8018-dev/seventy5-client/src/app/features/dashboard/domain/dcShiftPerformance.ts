export class DcShiftPerformance {
    shift: number;
    scannedCount: number;
    weighedCount: number;
    labelledCount: number;
    notWeighedCount: number;
}

