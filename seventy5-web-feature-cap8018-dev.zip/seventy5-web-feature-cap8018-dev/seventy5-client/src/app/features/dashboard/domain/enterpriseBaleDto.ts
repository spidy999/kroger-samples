export class EnterpriseBaleDto {
    divisionName: string;
    divisionNo: string;
    baleCount: number;
    totalStore: number;
    avgBaleCount: number;

}
