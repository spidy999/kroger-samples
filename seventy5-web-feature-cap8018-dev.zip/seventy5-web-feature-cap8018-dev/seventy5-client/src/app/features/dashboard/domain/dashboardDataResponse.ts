import { DcDailyPerformance } from './dcDailyPerformance';

export class DashboardDataResponse {
    totalDcScanned: number;
    totalDcLabelled: number;
    dailyDcPerformances: DcDailyPerformance[];
    dcPerformancePercentage: number;
}
