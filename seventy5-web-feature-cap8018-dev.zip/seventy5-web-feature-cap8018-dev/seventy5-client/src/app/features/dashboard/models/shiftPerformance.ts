export class ShiftPerformance {
  public  shift: any;
  public  scannedCount: number;
  public  weighedCount: number;
  public  labelledCount: number;
  public  notWeighedCount: number;
}
