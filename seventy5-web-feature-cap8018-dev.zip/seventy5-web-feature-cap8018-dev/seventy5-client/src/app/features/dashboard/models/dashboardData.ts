import { DashboardDataResponse } from '../domain/dashboardDataResponse';
import { DcTotalWeight } from '../domain/dcTotalWeight';
import { DailyStorePerformance } from '../domain/dailyStorePerformance';
import { LabelButNotScanDto } from '../domain/labelButNotScanDto';
import { StoreVsDcDto } from '../domain/storeVsDcDto';

export type DashboardData = (
  DashboardDataResponse
  & DcTotalWeight
  & { storeBaleProduction: DailyStorePerformance[]}
  & { labelButNotScanDto: LabelButNotScanDto}
  & StoreVsDcDto
  & { totalStore: number}
  );

  export class PerformanceDisplay {
    public title: any;
    public helpText: any;
    public performance?: any;
    public performanceText?: string;
    public detailUrl?: any;
    public headingClass?: string;
  }


export enum DashboardTab {
  ENTERPRISE = 'ENTERPRISE',
  CORPORATE = 'CORPORATE'
}

export const DashBoardTabs = {
  corpUserTabs: [
    {label: 'Enterprise Dashboard', value: DashboardTab.ENTERPRISE }
  ],
  supportUserTabs: [
    {label: 'Enterprise Dashboard', value: DashboardTab.ENTERPRISE },
    {label: 'Corporate Dashboard', value: DashboardTab.CORPORATE },
  ]
};
