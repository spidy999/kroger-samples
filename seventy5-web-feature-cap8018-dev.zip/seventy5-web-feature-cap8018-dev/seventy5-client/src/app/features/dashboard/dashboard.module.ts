import { CommonModule } from '@angular/common';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {ReportsModule} from '@shared/reports/reports.module';
import {TemplateModule} from '@app/templates/template.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { GlobalInterceptorModule } from '@app/httpInterceptor.module';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {DashboardService} from '@features/dashboard/services/dashboard.service';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import {DashboardComponent} from '@features/dashboard/dashboard.component';
import {CorporateDashboardComponent} from '@features/dashboard/corporate-dashboard/corporate-dashboard.component';
import {EnterpriseDashboardComponent} from '@features/dashboard/enterprise-dashboard/enterprise-dashboard.component';

@NgModule({
  imports: [
    CommonModule,
    PrimengModule,
    ReportsModule,
    CalendarModule,
    TemplateModule,
    KdsStencilAccessorsModule,
    DashboardRoutingModule
  ],
  declarations: [
    DashboardComponent,
    CorporateDashboardComponent,
    EnterpriseDashboardComponent
  ],
  providers: [
    DashboardService,
    GlobalInterceptorModule
  ],
  schemas: [
    NO_ERRORS_SCHEMA,
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class DashboardModule {}
