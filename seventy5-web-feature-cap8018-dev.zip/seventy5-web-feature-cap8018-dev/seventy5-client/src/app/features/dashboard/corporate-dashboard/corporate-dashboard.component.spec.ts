import {FormBuilder} from '@angular/forms';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {ReportsModule} from '@shared/reports/reports.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { CorporateDashboardComponent } from './corporate-dashboard.component';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {DashboardService} from '@features/dashboard/services/dashboard.service';

describe('CorporateDashboardComponent', () => {
  let component: CorporateDashboardComponent;
  let fixture: ComponentFixture<CorporateDashboardComponent>;
  let dateService: DateService;
  let utilService: UtilService;
  let userService: UserService;
  let facilityService: FacilityService;
  let dashboardService: DashboardService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        PrimengModule,
        ReportsModule,
        CalendarModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        HttpClientTestingModule,
        BrowserAnimationsModule
      ],
      declarations: [
        CorporateDashboardComponent
      ],
      providers: [
        DateService,
        UserService,
        UtilService,
        FormBuilder,
        FacilityService,
        DashboardService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));


  beforeEach( ( ) => {
    fixture = TestBed.createComponent(CorporateDashboardComponent);
    component = fixture.componentInstance;
    dateService = TestBed.inject(DateService);
    utilService = TestBed.inject(UtilService);
    userService = TestBed.inject(UserService);
    facilityService = TestBed.inject(FacilityService);
    dashboardService = TestBed.inject(DashboardService);
  });

 it('should create', () => {
    expect(component).toBeTruthy();
  });
});
