import {Accordion} from 'primeng';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import {CalendarType} from '@shared/models/calendarType';
import {ChartDetails, DateRange} from '@shared/models/reportData';
import { LabelButNotScanDto } from '../domain/labelButNotScanDto';
import { DcDailyPerformance } from '../domain/dcDailyPerformance';
import { DailyStorePerformance } from '../domain/dailyStorePerformance';
import { DashboardData, PerformanceDisplay } from '../models/dashboardData';
import {ShiftPerformance} from '@features/dashboard/models/shiftPerformance';
import {Component, Input, OnChanges, ViewChild} from '@angular/core';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {DashboardService} from '@features/dashboard/services/dashboard.service';

@Component({
  selector: 'corporate-dashboard',
  templateUrl: './corporate-dashboard.component.html',
  styleUrls: ['./corporate-dashboard.component.less', '../dashboard-print.component.less']
})
export class CorporateDashboardComponent implements OnChanges {

  @Input() public widgetDetails: DateRange;
  @ViewChild('accordion', {static: false}) accordion: Accordion;
  public disableExcel = true;
  public dcPerformancePercentage: number;
  public dashBoardData: DashboardData;
  public storeData: LabelButNotScanDto ;
  public calendarType: CalendarType;
  public selectedCalendarType = CalendarType;
  public scans: PerformanceDisplay;
  public totalWeight: PerformanceDisplay;
  public totalStoreScans: PerformanceDisplay;
  public totalScansByShift: ChartDetails;
  public labelledAndScanned: ChartDetails;
  public balesLabelledByShift: ChartDetails;
  public balesNotWeighedByShift: ChartDetails;
  public baleProductionAtStores: ChartDetails;
  public scannedAtDcButNotWeighed: ChartDetails;
  public labelledAndNotScannedAtStore: ChartDetails;
  public dailyDcPerformances: DcDailyPerformance[];
  public storeBaleProductionData: DailyStorePerformance[];
  public spinner$: Observable<boolean> = this.util.getSpinner();

  constructor(private util: UtilService,
              private dateService: DateService,
              private dashBoardService: DashboardService) { }

  ngOnChanges() {
    this.loadDashboardData(this.widgetDetails);
  }

  private loadDashboardData(data: DateRange): void {
    this.storeBaleProductionData = [];
    this.util.showSpinner();
    forkJoin(
      {
        dcPerformance: this.dashBoardService.getDcPerformanceReport(data),
        baleProduction: this.dashBoardService.getDailyStorePerformance(data),
        labelledButNotScanned: this.dashBoardService.getLabelButNotScan(data),
        storeAndDcBaleCounts: this.dashBoardService.getStoreAndDcBaleCount(data),
        totalWeight: this.dashBoardService.getTotalWeight(data),
        totalStore: this.dashBoardService.getTotalStore(data),
        })
    .subscribe((result) => {
          const response = {
            ...result.dcPerformance,
            ...result.baleProduction,
            ...result.labelledButNotScanned,
            ...result.storeAndDcBaleCounts,
            ...result.totalWeight,
            ...result.totalStore
          };
      this.util.hideSpinner();
      this.dashBoardData = response;
      this.storeData = this.dashBoardData.labelButNotScanDto;
      this.dailyDcPerformances = this.dashBoardData.dailyDcPerformances;
      this.storeBaleProductionData = this.dashBoardData.storeBaleProduction;
      this.dcPerformancePercentage = this.dashBoardData.dcPerformancePercentage;
      this.calculateDailyDcPerformances();
      this.calculateCardBoardTrackingPerformance();
      this.calculateStoreExecution();
      this.calculateDCExecution();
      this.disableExcel = false;
      });
  }

  /* Manipulate the shift Data */
  private calculateDailyDcPerformances(): void {
    const shifts = [1, 2, 3];
    let givenShifts: number[] = [];
    let missedShiftsArray: number[] = [];
    const missingShift: ShiftPerformance = {
      scannedCount: 0,
      weighedCount: 0,
      labelledCount: 0,
      notWeighedCount: 0,
      shift: 0
    };

    if (this.dashBoardData.dailyDcPerformances && this.dashBoardData.dailyDcPerformances.length > 0) {
      this.dashBoardData.dailyDcPerformances.forEach((dailyDcPerformance) => {

        dailyDcPerformance.shiftPerformance.forEach((shiftData) => {
          givenShifts.push(shiftData.shift);
        });

        missedShiftsArray = shifts.filter((number) => {
          return !givenShifts.includes(number);
        });
        givenShifts = [];
        if (missedShiftsArray && missedShiftsArray.length > 0) {
          missedShiftsArray.forEach((shiftNumber) => {
            dailyDcPerformance.shiftPerformance.push({...missingShift, shift: shiftNumber });
          });
        }
      });
    }
  }

  /* calculates scan at Stores Vs scan at Dc's, Total No of Stores Recorded, Total Weight. */
  private calculateCardBoardTrackingPerformance(): void {
    const totalWeight = this.dashBoardData.totalWeight.toLocaleString('en');
    const totalWeightInTons = this.dashBoardData.totalWeightInTons.toLocaleString('en');
    this.scans = {
      title: 'Scan at Store and DC',
      helpText: ' Scan at Store and DC<br>' +
        'The Bale scanned at the Store and Distribution Center.',
      detailUrl: '/app-occ-reports-tab',
      performance: this.dashBoardData.variance,
      headingClass: 'text-positive-400'
    };
    this.totalStoreScans = {
      title: 'Stores Recording Bale',
      helpText: 'Displays the total # of stores who have recorded at least 1 bale scan in the time range selected. ',
      detailUrl: null,
      performance: this.dashBoardData.totalStore,
      headingClass: 'text-positive-400'
    };
    this.totalWeight = {
      title: 'Total Weight',
      helpText: 'Displays the total weight that the Distribution Center has recorded in the time range selected.',
      detailUrl: '/app-occ-reports-tab',
      performance: `${totalWeight} lbs`,
      performanceText: `${totalWeightInTons} Tons`,
      headingClass: 'text-positive-400 text-left'
    };
  }

  /* calculates Bale Production at Stores, Labelled at Store but Not scanned at Stores. */
  private calculateStoreExecution() {
    this.baleProductionAtStores = this.dashBoardService.getBaleProduction(this.storeBaleProductionData);
    this.labelledAndNotScannedAtStore = DashboardService.getLabelledAndNotScannedStoreData(this.storeData);
    this.labelledAndScanned = DashboardService.getLabelledAndScannedAtDCData(this.dashBoardData);
  }

  /* calculates Labelled and scanned at DC's. */
  private calculateDCExecution(): void {
    this.scannedAtDcButNotWeighed = this.dashBoardService.getScannedAtDcButNotWeighed(this.dashBoardData);
    this.totalScansByShift = this.dashBoardService.getTotalScansByShift(this.dashBoardData);
    this.balesLabelledByShift = this.dashBoardService.getBalesLabelledByShift(this.dashBoardData);
    this.balesNotWeighedByShift = this.dashBoardService.getBalesNotWeighedByShiftData(this.dashBoardData);
  }
}
