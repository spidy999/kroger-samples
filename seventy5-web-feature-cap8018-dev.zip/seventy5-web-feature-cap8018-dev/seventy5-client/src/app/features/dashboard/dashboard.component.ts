import {Subject} from 'rxjs/Subject';
import { MenuItem } from 'primeng/api';
import {takeUntil} from 'rxjs/operators';
import {Observable} from 'rxjs/Observable';
import {Dates} from '@shared/models/dateRange';
import {DateRange} from '@shared/models/reportData';
import {Component, OnDestroy, OnInit} from '@angular/core';
import {CalendarType} from '@shared/models/calendarType';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import { UserService } from '@shared/services/user/user.service';
import { DashboardTab } from '@features/dashboard/models/dashboardData';
import {DashBoardTabs as constants} from '@features/dashboard/models/dashboardData';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.less']
})
export class DashboardComponent implements OnInit, OnDestroy {
  public dateRangeDisplay: DateRange;
  public availableOptions: MenuItem[];
  public selectionType: DashboardTab;
  public showPDFInstructions: boolean;
  public selectedOptionType = DashboardTab;
  public selectedCalendarType = CalendarType;
  public hidePDFInstructionsForever: boolean;
  public spinner$: Observable<boolean> = this.util.getSpinner();
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private util: UtilService,
              private userService: UserService,
              private dateService: DateService) { }

  ngOnInit() {
    this.selectionType = this.selectedOptionType.ENTERPRISE;
    this.extractDates();
    this.buildSubTabs();
    if (window.localStorage.getItem('hidePDFInstructionsForever') === 'true') {
      this.hidePDFInstructionsForever = true;
    }
  }

  private extractDates() {
    this.dateService.getCalendar().pipe(takeUntil(this.destroy)).subscribe((response: Dates) => {
      const {startDate, stopDate} = response;
      this.dateRangeDisplay = {startDate, endDate: stopDate};
    });
  }

  private buildSubTabs() {
    this.availableOptions = [];
    const { corpUserTabs, supportUserTabs } = constants;
    if (this.userService.getUser()) {
      if (this.userService.isCorp()) {
        this.availableOptions = corpUserTabs;
      } else if (this.userService.isSupport()) {
        this.availableOptions = supportUserTabs;
      }
    }
  }

  public exportToExcel(): void {
    if (this.hidePDFInstructionsForever) {
      this.closePDFInstructions();
    } else {
      this.showPDFInstructions = true;
    }
  }

  public closePDFInstructions(): void {
    this.showPDFInstructions = false;
    if (this.hidePDFInstructionsForever) {
      window.localStorage.setItem('hidePDFInstructionsForever', 'true');
    }
    setTimeout(() => {
      window.print();
    });
  }

  public tabChange(evt) {
    if (evt) {
      const detail = evt.detail;
      switch (detail) {
        case 0:
          this.selectionType = this.selectedOptionType.ENTERPRISE;
          break;
        case 1:
          this.selectionType = this.selectedOptionType.CORPORATE;
          break;
      }
    }
  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
