import {inject, TestBed} from '@angular/core/testing';
import {DateRange} from '@shared/models/reportData';
import {DashboardService} from './dashboard.service';
import {UtilService} from '@shared/services/util/util.service';
import {StoreVsDcDto} from '@features/dashboard/domain/storeVsDcDto';
import {DcTotalWeight} from '@features/dashboard/domain/dcTotalWeight';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {EnterpriseBaleDto} from '@features/dashboard/domain/enterpriseBaleDto';
import {LabelButNotScanDto} from '@features/dashboard/domain/labelButNotScanDto';
import {EnterpriseTrendline} from '@features/dashboard/domain/enterpriseTrendline';
import {DailyStorePerformance} from '@features/dashboard/domain/dailyStorePerformance';
import {DashboardDataResponse} from '@features/dashboard/domain/dashboardDataResponse';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {EnterpriseCardboardDto} from '@features/dashboard/domain/enterpriseCardboardDto';
import {EnterpriseTrendlineDto} from '@features/dashboard/domain/enterpriseTrendlineDto';

describe('DashboardServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        UtilService,
        DashboardService,
        FiscalDateService
      ]
    });
  });

  it('should be created', inject([DashboardService], (service: DashboardService) => {
    expect(service).toBeTruthy();
  }));

  it( 'should fetch DC performance report', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const dcParams: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const dcShiftPerformance = [];
      const dcDailyPerformance = [{
        reportDate: '2018-11-25 12:00 AM',
        scannedCount: 3,
        weighedCount: 2,
        labelledCount: 2,
        shiftPerformance: dcShiftPerformance,
        weighedPercent: 5,
        scannedButNotWeighed: 1
      }];
      const dashboardData: DashboardDataResponse = {
        totalDcScanned: 3,
        totalDcLabelled: 5,
        dailyDcPerformances: dcDailyPerformance,
        dcPerformancePercentage: 5
      };
      service.getDcPerformanceReport( dcParams ).subscribe( data => {
        expect( data ).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/dashBoard/dcPerformance`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({
        data: dashboardData
      });
    })
  );

  it( 'should fetch total weight', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const dcParams: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const totalWeight: DcTotalWeight = {
        totalWeight: 340,
        totalWeightInTons: 3
      };
      service.getTotalWeight( dcParams ).subscribe( data => {
        expect( data ).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/dashBoard/getTotalWeight`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush({
        data: totalWeight
      });
    }));

  it( 'should fetch daily store performance', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const params: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const dailyStorePerformance: DailyStorePerformance[] = [
        {
          reportDate: '2018-11-25 12:00 AM',
          scannedCount: 3,
          storeCount: 3,
          avgStoreCount: 3
        },
        {
          reportDate: '2018-11-26 12:00 AM',
          scannedCount: 2,
          storeCount: 2,
          avgStoreCount: 2
        }
      ];
      service.getDailyStorePerformance( params ).subscribe( data => {
        expect( data ).toBeTruthy();
        expect(data.storeBaleProduction.length).toEqual(2);
      });
      const req = httpMock.expectOne( `api/dashBoard/getBaleProduction`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(dailyStorePerformance);
    }));

  it( 'should fetch labeled but not scanned bales', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const params: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const labelsButNotScannedBales: LabelButNotScanDto = {
        totalStoreAndDcScan: 5,
        totalDcScan: 3,
        totalStoreScan: 2,
        totalStoreCount: 2,
        labelButNotScanPercent: 2,
        labelButNotScanAtStore: 2,
        totalBaleLabelledAtStore: 3
      };

      service.getLabelButNotScan( params ).subscribe( data => {
        expect( data ).toBeTruthy();
        expect(data.labelButNotScanDto.labelButNotScanAtStore).toEqual(2);
      });
      const req = httpMock.expectOne( `api/dashBoard/getLabelButNotScan`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(labelsButNotScannedBales);
    }));

  it( 'should fetch store and DC bale count', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const params: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const storeAndDcBaleCounts: StoreVsDcDto = {
        storeScan: 3,
        dcScan: 3,
        variance: 3
      };

      service.getStoreAndDcBaleCount( params ).subscribe( data => {
        expect( data ).toBeTruthy();
        expect(data.storeScan).toEqual(3);
      });
      const req = httpMock.expectOne( `api/dashBoard/getStoreAndDcBaleCount`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(storeAndDcBaleCounts);
    }));

  it( 'should fetch total stores', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const params: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      service.getTotalStore( params ).subscribe( data => {
        expect( data.totalStore ).toEqual(5);
      });
      const req = httpMock.expectOne( `api/dashBoard/getTotalStore`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(5);
    }));

  it( 'should fetch enterprise bale data', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const params: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const enterpriseBaleDto: EnterpriseBaleDto[] = [
        {
          divisionName: 'Cincinnati',
          divisionNo: '014',
          baleCount: 5,
          totalStore: 4,
          avgBaleCount: 4
        },
        {
          divisionName: 'Atlanta',
          divisionNo: '011',
          baleCount: 6,
          totalStore: 5,
          avgBaleCount: 5
        }
      ];
      const enterpriseCardboardDto: EnterpriseCardboardDto = {
        totalBaleCount: 5,
        averageBalecount: 2,
        totalZeroScan: 1,
        enterpriseBaleDtoList: enterpriseBaleDto,
        enterpriseAverage: 3
      };
      service.getEnterpriseBaleData(params).subscribe( data => {
        expect( data ).toBeTruthy();
        expect(data.enterpriseAverage).toEqual(3);
      });
      const req = httpMock.expectOne( `api/enterprise/cardBoardBale`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(enterpriseCardboardDto);
    }));

  it( 'should fetch enterprise bale trendline data', inject( [ DashboardService, HttpTestingController ],
    ( service: DashboardService, httpMock: HttpTestingController ) => {
      const params: DateRange = {
        startDate: '2018-11-25 12:00 AM',
        endDate: '2021-04-08 12:00 AM',
        period: [1, 2]
      };

      const cincyTrendLine: EnterpriseTrendline[] = [
        {
          divisionName: 'Cincinnati',
          divisionNo: '014',
          weeklyDate: '2021-04-08',
          baleCount: 5,
          totalStore: 15,
          avgBaleCount: 3
        }
      ];

      const atlantaTrendLine: EnterpriseTrendline[] = [
        {
          divisionName: 'Atlanta',
          divisionNo: '011',
          weeklyDate: '2021-04-09',
          baleCount: 4,
          totalStore: 12,
          avgBaleCount: 3
        }
      ];
      const enterpriseTrendLineDto: EnterpriseTrendlineDto[] = [
        {
          divisionName: 'Cincinnati',
          enterpriseTrendlineList: cincyTrendLine
        },
        {
          divisionName: 'Atlanta',
          enterpriseTrendlineList: atlantaTrendLine
        }
      ];

      service.getEnterpriseBaleTrendLineData(params).subscribe( data => {
        expect( data ).toBeTruthy();
        expect(data[0].divisionName).toEqual('Cincinnati');
      });
      const req = httpMock.expectOne( `api/enterprise/trendline`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(enterpriseTrendLineDto);
    }));

});

