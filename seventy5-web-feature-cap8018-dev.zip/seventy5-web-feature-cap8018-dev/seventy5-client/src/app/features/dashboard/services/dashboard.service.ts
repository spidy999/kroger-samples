import * as moment from 'moment';
import { Injectable } from '@angular/core';
import {map, share} from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { StoreVsDcDto } from '../domain/storeVsDcDto';
import { DcTotalWeight } from '../domain/dcTotalWeight';
import { DashboardData } from '../models/dashboardData';
import { LabelButNotScanDto } from '../domain/labelButNotScanDto';
import { DashboardDataResponse } from '../domain/dashboardDataResponse';
import { DailyStorePerformance } from '../domain/dailyStorePerformance';
import {ChartDetails, Dataset, DateRange } from '@shared/models/reportData';
import { EnterpriseCardboardDto } from '../domain/enterpriseCardboardDto';
import { EnterpriseTrendlineDto } from '../domain/enterpriseTrendlineDto';
import {UtilService} from '@shared/services/util/util.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
const LINE_TENSION = 0.0;

@Injectable()
export class DashboardService {

  constructor(private http: HttpClient,
              private util: UtilService,
              private fiscalDateService: FiscalDateService) { }

  static calculateTrendLineDataset(dataset: Dataset[], labels: any, title, helpText): ChartDetails {
    let data;
    if (dataset && dataset.length > 0) {
      data = {
        labels: labels,
        datasets: dataset
      };
    }

    return  {
      title,
      helpText,
      data,
      height: '400px'
    };
  }

  static getLabelledAndScannedAtDCData(dashBoardData: DashboardData): ChartDetails {
    let data;
    if (dashBoardData.totalDcLabelled && dashBoardData.totalDcScanned &&
      dashBoardData.totalDcLabelled > 0 && dashBoardData.totalDcScanned > 0) {
      const scannedAtStore = dashBoardData.totalDcScanned - dashBoardData.totalDcLabelled;
      const percent = Math.round(dashBoardData.totalDcLabelled / dashBoardData.totalDcScanned * 100);
      const dataset = [{
        data: [dashBoardData.totalDcLabelled, scannedAtStore],
        backgroundColor: UtilService.getLabelButNotScannedDataColor(),
        hoverBackgroundColor: UtilService.getLabelButNotScannedDataColor()
      }];
      data = {
        labels: [`Bales Labeled at DC (${percent} %)`, 'Bales Labeled at Store'],
        datasets: dataset
      };
    }

    return {
      title: 'Bales Labeled by DC',
      helpText: `Displays the number of bales the DC has labeled versus
      the bales that were labeled by a store.`,
      detailUrl: null,
      data
    };
  }

  static getLabelledAndNotScannedStoreData(storeData: any): ChartDetails {
    let labelButNotScannedDataset = [];
    let data;
    if (storeData.labelButNotScanAtStore && storeData.totalStoreScan) {
      labelButNotScannedDataset = [
        {
          data: [storeData.labelButNotScanAtStore, storeData.totalStoreScan],
          backgroundColor: UtilService.getLabelButNotScannedDataColor(),
          hoverBackgroundColor: UtilService.getLabelButNotScannedDataColor()
        }
      ];
    }

    if (labelButNotScannedDataset.length > 0) {
      data = {
        labels: [storeData.labelButNotScanPercent + '% Bales not labeled at stores', 'Bales labeled at stores'],
        datasets: labelButNotScannedDataset
      };
    }

    return {
      title: 'Bales labeled but not scanned at Stores',
      helpText: `Displays the total # of bales that were labeled but were not scanned at the
        store.  This is recognized when the bale is scanned at the Distribution
        Center and recorded for the first time.`,
      detailUrl: null,
      data
    };
  }

  /*
  *
  * Labelled and scanned at DC pie chart
  *
  * All the bar graph for shift performances
  *
  * */
  getDcPerformanceReport(getValues: DateRange): Observable<DashboardDataResponse> {
    return this.http.post<DashboardDataResponse>('api/dashBoard/dcPerformance', getValues)
      .pipe(share());
  }

  /* Total Weight Recorded chart */
  getTotalWeight(getValues: DateRange): Observable<DcTotalWeight> {
    return this.http.post<DcTotalWeight>('api/dashBoard/getTotalWeight', getValues)
      .pipe(share());
  }

  /* Store Execution Chart */
  getDailyStorePerformance(getValues: DateRange): Observable<{ storeBaleProduction: DailyStorePerformance[]}>  {
    return this.http.post<DailyStorePerformance[]>('api/dashBoard/getBaleProduction', getValues)
      .pipe(map(response => ({storeBaleProduction: response})));
  }

  /*Labelled at the store but not scanned at the store pie chart*/
  getLabelButNotScan(getValues: DateRange): Observable<{labelButNotScanDto: LabelButNotScanDto}> {
    return this.http.post<LabelButNotScanDto>('api/dashBoard/getLabelButNotScan', getValues)
      .pipe(map(response => ({labelButNotScanDto: response})));
  }

  /*Scan at Sto scan at DC chart*/
  getStoreAndDcBaleCount(getValues: DateRange): Observable<StoreVsDcDto> {
    return this.http.post<StoreVsDcDto>('api/dashBoard/getStoreAndDcBaleCount', getValues)
      .pipe(share());
  }

  /* Total #of Stores Recording a Bale Scan chart */
  getTotalStore(getValues: DateRange): Observable<{totalStore: number}> {
    return this.http.post<number>('api/dashBoard/getTotalStore', getValues)
      .pipe(map(response => ({totalStore: response}) ));
  }

  /* Enterprise data*/
  getEnterpriseBaleData(getValues: DateRange): Observable<EnterpriseCardboardDto> {
    return this.http.post<EnterpriseCardboardDto>('api/enterprise/cardBoardBale', getValues)
      .pipe(share());
  }

  /*Enterprise TrendLine Data*/
  getEnterpriseBaleTrendLineData(getValues: DateRange): Observable<EnterpriseTrendlineDto[]> {
    return this.http.post<EnterpriseTrendlineDto[]>('api/enterprise/trendline', getValues)
      .pipe(share());
  }

  getBalesLabelledByShift(dashBoardData: DashboardData): ChartDetails {
    const labels = [];
    const totalLabelledCount: number[] = [];
    const labelledByShiftData: Dataset[] = [];
    const shiftWiseData = { 'Shift 1': [], 'Shift 2': [], 'Shift 3': [] };
    const totalColor = UtilService.getTotalColor();
    const colors = UtilService.getBalesNotWeighedByShiftsColor();

    let data;

    if (dashBoardData.dailyDcPerformances && dashBoardData.dailyDcPerformances.length > 0) {
      dashBoardData.dailyDcPerformances.forEach((dailyDcPerformance) => {
        labels.push(dailyDcPerformance.reportDate);

        dailyDcPerformance.shiftPerformance.forEach((shiftData) => {
          const value = shiftData.labelledCount;
          shiftWiseData['Shift ' + shiftData.shift].push(value);
        });
        totalLabelledCount.push(dailyDcPerformance.labelledCount);
      });

      const total = new Dataset(
        totalLabelledCount
        , false
        , 'Total'
        , totalColor.borderColor
        , totalColor.backgroundColor
        , totalColor.hoverBackgroundColor
        , 'line', true, [], null, LINE_TENSION);
      const labelledByShifts = Object.keys(shiftWiseData).map((key, index) => {
        return new Dataset(
          shiftWiseData[key]
          , false
          , key
          , colors[index].borderColor
          , colors[index].backgroundColor
          , colors[index].hoverBackgroundColor
          , 'bar', true, [], null, LINE_TENSION);
      });

      labelledByShiftData.push(total, ...labelledByShifts);

      data = {
        labels: labels,
        datasets: labelledByShiftData
      };
    }

    return {
      title: 'Bales Labeled by shift',
      helpText: `Displays total # of bales that the Distribution Center places a barcode
      on broken down by shift.`,
      detailUrl: null,
      data
    };
  }

  getTotalScansByShift(dashBoardData: DashboardData): ChartDetails {
    const labels = [];
    const totalScannedCount: number[] = [];
    const totalScansByShiftData = [];
    const totalColor = UtilService.getTotalColor();
    const colors = UtilService.getBalesNotWeighedByShiftsColor();
    const helpText = `Displays total # of scans recorded by each shift at the Distribution Center.
      Shifts are defined as:
      <br>
      <br>
      <ul>
        <li>1<sup>st</sup> Shift – 6AM-2PM EST</li>
        <li>2<sup>nd</sup> Shift – 2PM-10PM EST</li>
        <li>3<sup>rd</sup> Shift – 10PM-6AM EST</li>
      </ul>
      <br>
      The shifts are reflected in the same calendar day.  For example, the shift data displayed
      for 1/1/19 includes the 1<sup>st</sup> and 2<sup>nd</sup> shifts for that day. The
      3<sup>rd</sup> shift is reflected by the same calendar day but spread across 2 different
      shifts.  Work that began at 12:00AM on 1/1/19 as well as work between 10PM through 11:59PM
      are reflected on 1/1/19`;
    let data;

    if (dashBoardData.dailyDcPerformances && dashBoardData.dailyDcPerformances.length > 0) {
      const shiftWiseData = { 'Shift 1': [], 'Shift 2': [], 'Shift 3': [] };
      dashBoardData.dailyDcPerformances.forEach(dailyDcPerformance => {
        labels.push(dailyDcPerformance.reportDate);
        dailyDcPerformance.shiftPerformance.forEach(eachPerf => {
          shiftWiseData['Shift ' + eachPerf.shift].push(eachPerf.scannedCount);
        });
        totalScannedCount.push(dailyDcPerformance.scannedCount);
      });

      const total = new Dataset(
        totalScannedCount
        , false
        , 'Total'
        , totalColor.borderColor
        , totalColor.backgroundColor
        , totalColor.hoverBackgroundColor
        , 'line', true, [], null, LINE_TENSION);

      const totalScansByShift = Object.keys(shiftWiseData).map((key, index) => {
        return new Dataset(
          shiftWiseData[key]
          , false
          , key
          , colors[index].borderColor
          , colors[index].backgroundColor
          , colors[index].backgroundColor
          , 'bar', true, [], null, LINE_TENSION);
      });

      totalScansByShiftData.push(total, ...totalScansByShift);

      data = {
        labels: labels,
        datasets: totalScansByShiftData

      };
    }
    return {
      title: 'Scans By Shift',
      helpText,
      detailUrl: null,
      data
    };
  }

  getScannedAtDcButNotWeighed(dashBoardData: DashboardData): ChartDetails {
    const labels = [];
    const scannedData: number[] = [];
    const weighedData: number[] = [];
    const percentageData: number[] = [];
    const totalColor = UtilService.getTotalColor();
    const avgScanColor = UtilService.getAvgScansAtStoreColor();
    const noOfScansColor = UtilService.getNoOfScansAtStoreColor();
    let data;

    if (dashBoardData.dailyDcPerformances && dashBoardData.dailyDcPerformances.length > 0) {
      dashBoardData.dailyDcPerformances.forEach((dailyDcPerformance) => {
        labels.push(dailyDcPerformance.reportDate);
        scannedData.push(dailyDcPerformance.scannedCount);
        weighedData.push(dailyDcPerformance.weighedCount);
        percentageData.push(dailyDcPerformance.weighedPercent);
      });

      const scannedDataset = new Dataset(
        scannedData
        , false
        , '# of DC scans'
        , noOfScansColor
        , noOfScansColor
        , noOfScansColor
        , 'bar', true, [], 'left-y-axis');

      const weighedDataset = new Dataset(
        weighedData
        , false
        , '# Weighed'
        , avgScanColor
        , avgScanColor
        , avgScanColor
        , 'bar', true, [], 'left-y-axis');

      const percentageDataset = new Dataset(
        percentageData
        , false
        , '% Weighed'
        , totalColor.borderColor
        , totalColor.backgroundColor
        , totalColor.hoverBackgroundColor
        , 'line', true, [], 'right-y-axis', LINE_TENSION);

      data = {
        labels: labels,
        datasets: [percentageDataset, scannedDataset, weighedDataset]
      };
    }
    return {
      title: 'Bales Scanned and Weighed at DC',
      helpText: `Displays total # of bales scanned and weighed at the Distribution Center
      and calculates a percentage showing how many bales are being scanned and weighed.`,
      detailUrl: null,
      data
    };
  }

  getBalesNotWeighedByShiftData(dashBoardData: DashboardData): ChartDetails {
    const labels = [];
    const totalScannedButNotWeighedCount: number[] = [];
    const notWeighedBalesByShiftData: Dataset[] = [];
    const totalColor = UtilService.getTotalColor();
    const colors = UtilService.getBalesNotWeighedByShiftsColor();
    const shiftWiseData = { 'Shift 1': [], 'Shift 2': [], 'Shift 3': [] };
    let data;

    if (dashBoardData.dailyDcPerformances && dashBoardData.dailyDcPerformances.length > 0) {

      dashBoardData.dailyDcPerformances.forEach((dailyDcPerformance) => {
        labels.push(dailyDcPerformance.reportDate);

        dailyDcPerformance.shiftPerformance.forEach((shiftData) => {
          const value = shiftData.notWeighedCount;
          shiftWiseData[`Shift ${shiftData.shift}`].push(value);
        });
        totalScannedButNotWeighedCount.push(dailyDcPerformance.scannedButNotWeighed);
      });

      const total = new Dataset(
        totalScannedButNotWeighedCount
        , false
        , 'Total'
        , totalColor.borderColor
        , totalColor.backgroundColor
        , totalColor.hoverBackgroundColor
        , 'line', true, [], null, LINE_TENSION);

      const shifts: Dataset[] = Object.keys(shiftWiseData).map((key, index) => {
        return new Dataset(
          shiftWiseData[key]
          , false
          , key
          , colors[index].borderColor
          , colors[index].backgroundColor
          , colors[index].backgroundColor
          , 'bar', true, [], null, LINE_TENSION);
      });

      notWeighedBalesByShiftData.push(total, ...shifts);

      data = {
        labels: labels,
        datasets: notWeighedBalesByShiftData
      };
    }

    return {
      title: 'Bales Not Weighed By Shift',
      helpText: `Displays total # of bales not weighed broken down by shift at the
      Distribution Center.`,
      detailUrl: null,
      data
    };
  }

  getBaleProduction(storeBaleProductionData: DailyStorePerformance[]): ChartDetails {
    let data;

    const chartData: Dataset[] = [];
    const scans: number[] = [];
    const avgBale: number[] = [];
    const countColor = UtilService.getAvgScansAtStoreColor();
    const scanColor = UtilService.getNoOfScansAtStoreColor();

    storeBaleProductionData.forEach(date => {
      scans.push(date.scannedCount);
      avgBale.push(date.avgStoreCount);
    });
    const chartDataSet = [...scans, ...avgBale];
    chartData.push(new Dataset(avgBale, false, 'Bale Production at Stores Avg. bales/day',
      countColor, countColor, countColor, 'line', false, []));
    chartData.push(new Dataset(scans, false, 'Bale Production at Stores # of scans',
      scanColor, scanColor, scanColor, 'bar', false, []));

    const reportDates = [];
    storeBaleProductionData.forEach(date => {
      reportDates.push(date.reportDate);
    });

    if (chartDataSet.length > 0) {
      data = {
        labels: reportDates,
        datasets: chartData
      };
    }

    return {
      title: 'Bale Production At Stores',
      helpText: `Displays the total # of bales that have been scanned by all stores who have
        recorded scans.  The sum of all bales scanned by all stores is divided by
        all stores recording a scan produces the average bales being scanned
        per day metric.`,
      detailUrl: '/app-occ-reports-tab',
      data
    };
  }

  getEnterpriseTotalBales(enterpriseData: EnterpriseCardboardDto, title): ChartDetails {
    let data;
    const chartData: Dataset[] = [];
    const totalBaleCount: number[] = [];
    const divisions = [];

    /*dataset for all divisions*/
     if (enterpriseData.enterpriseBaleDtoList && enterpriseData.enterpriseBaleDtoList.length > 0) {
       const sortedData = enterpriseData.enterpriseBaleDtoList.sort((a, b) => (a.baleCount < b.baleCount) ? 1 : -1);
       sortedData.forEach(division => {
         const divisionName = division.divisionName.split('-').slice(0, 3);
         divisions.push(divisionName[0].trim());
         totalBaleCount.push(division.baleCount);
       });
       const chartDataSet = [...totalBaleCount];

       const enterpriseColor = UtilService.getColorForBaleTrendLine(totalBaleCount.length);

       chartData.push(new Dataset(totalBaleCount, false, 'Total # of Bales', enterpriseColor,
         enterpriseColor, enterpriseColor, 'bar', false, []));

       if (chartDataSet.length > 0) {
         data = {
           labels: divisions,
           datasets: chartData
         };

       }
     }

    return {
      title: title,
      helpText: `Total number of bales per division scanned the previous day,
      the three highest performing divisions are shown in green and the three lowest performing in red.`,
      data
    };
  }

  getEnterpriseAverageBales(enterpriseData: EnterpriseCardboardDto, title): ChartDetails {
    let data;
    const chartData: Dataset[] = [];
    const averageBaleCount: number[] = [];
    const divisions = [];

    /*dataset for all divisions*/
    if (enterpriseData.enterpriseBaleDtoList && enterpriseData.enterpriseBaleDtoList.length > 0) {
      const sortedData = enterpriseData.enterpriseBaleDtoList.sort((a, b) => (a.avgBaleCount < b.avgBaleCount) ? 1 : -1);
      sortedData.forEach(division => {
        const divisionName = division.divisionName.split('-').slice(0, 3);
        divisions.push(divisionName[0].trim());
        averageBaleCount.push(division.avgBaleCount);
      });
      const chartDataSet = [...averageBaleCount];

      const enterpriseColor = UtilService.getColorForBaleTrendLine(averageBaleCount.length);
      const enterpriseAvgColor = UtilService.getEnterpriseAvgColor();

      const enterpriseAverageBaleCount = averageBaleCount.map(() => enterpriseData.enterpriseAverage);

      chartData.push(new Dataset(enterpriseAverageBaleCount, false, 'Enterprise Average', enterpriseAvgColor,
        enterpriseAvgColor, enterpriseAvgColor, 'line', false, []));
      chartData.push(new Dataset(averageBaleCount, false, 'Average # of Bales', enterpriseColor,
        enterpriseColor, enterpriseColor, 'bar', false, []));

      if (chartDataSet.length > 0) {
        data = {
          labels: divisions,
          datasets: chartData
        };

      }
    }

    return {
      title: title,
      helpText: `Average number of bales per division scanned the previous day.
      The three highest performing divisions are shown in green and the three lowest performing in red.
      This is calcualted by dividing total bales scanned by total no of stores in that division.`,
      data
    };
  }

  getEnterpriseTrendLineData(response: EnterpriseTrendlineDto[], randomColor) {
    let label: string;
    let labels = [];
    const totalBaleCount = [];
    const averageBaleCount = [];
    let dateArray = [];

    if (response) {

      dateArray = response
        .reduce((prev, curr) => [...prev, ...curr.enterpriseTrendlineList], [])
        .map(trend => trend.weeklyDate)
        .filter((x, i, a) => a.indexOf(x) === i)
        .sort((a, b) => {
        if (moment(a).isBefore(b)) {
          return -1;
        } else if (moment(a).isSame(b)) {
          return 0;
        } else { return 1; }
      });

      labels = dateArray.map( date => {
        return this.fiscalDateService.getKrogerQuarterPeriodWeek(date);
      });

      response.forEach((trendData) => {

        label = trendData.divisionName.split('-')[0];

        const totalBaleCountSet = dateArray.map(date =>
           trendData.enterpriseTrendlineList.find(trendLineData => trendLineData.weeklyDate === date))
          .map(result => result ? result.baleCount : 0);

        const averageBaleCountSet = dateArray.map(date =>
          trendData.enterpriseTrendlineList.find(trendLineData => trendLineData.weeklyDate === date))
          .map(result => result ? result.avgBaleCount : 0);

        totalBaleCount.push({label: label, dataset: totalBaleCountSet});
        averageBaleCount.push({label: label, dataset: averageBaleCountSet});
      });
      const totalBaleData = this.calculateTrendLineChart(totalBaleCount, randomColor);
      const averageBaleData = this.calculateTrendLineChart(averageBaleCount, randomColor);

      return {
        labels: labels,
        totalBaleCount: totalBaleData,
        averageBaleCount: averageBaleData,
      };
    }
  }

  private calculateTrendLineChart(givenData, randomColor): Dataset[] {
    let chartData;
    chartData =  givenData.map((data, index) => {
      const color = randomColor[index];
      const label = data.label;
      const dataset = data.dataset;
      return new Dataset(dataset,
        false,
        label,
        color,
        color,
        color,
        'line', null,
        [],
        null,
        LINE_TENSION
      );
    });
    return chartData;
  }

}
