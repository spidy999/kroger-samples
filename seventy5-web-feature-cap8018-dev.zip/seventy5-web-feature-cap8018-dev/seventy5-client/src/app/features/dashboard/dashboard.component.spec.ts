import {FormBuilder} from '@angular/forms';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DashboardComponent} from './dashboard.component';
import {BarChartComponent} from '@shared/reports/bar-chart/bar-chart.component';
import {LineChartComponent} from '@shared/reports/line-chart/line-chart.component';
import {DisplayCardComponent} from '@shared/reports/display-card/display-card.component';
import {CorporateDashboardComponent} from '@features/dashboard/corporate-dashboard/corporate-dashboard.component';
import {EnterpriseDashboardComponent} from '@features/dashboard/enterprise-dashboard/enterprise-dashboard.component';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        HttpClientTestingModule,
        BrowserAnimationsModule
      ],
      declarations: [
        BarChartComponent,
        LineChartComponent,
        DashboardComponent,
        DisplayCardComponent,
        CorporateDashboardComponent,
        EnterpriseDashboardComponent
      ],
      providers: [
        DateService,
        UtilService,
        FormBuilder,
        UserService,
        FiscalDateService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
