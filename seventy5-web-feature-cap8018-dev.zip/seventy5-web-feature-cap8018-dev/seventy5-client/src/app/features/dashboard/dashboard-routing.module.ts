import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AuthGuard as AuthGuard} from '@app/auth-guard';
import {Permission} from '@shared/models/permissions';
import {DashboardComponent} from '@features/dashboard/dashboard.component';

const dashBoardRoutes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.DASHBOARD.toString()
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(dashBoardRoutes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
