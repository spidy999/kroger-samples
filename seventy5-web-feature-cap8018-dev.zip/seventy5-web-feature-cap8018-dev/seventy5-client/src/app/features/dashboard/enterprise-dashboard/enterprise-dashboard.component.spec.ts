import {PrimengModule} from '@shared/primeng/primeng.module';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {ReportsModule} from '@shared/reports/reports.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { EnterpriseDashboardComponent } from './enterprise-dashboard.component';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {DashboardService} from '@features/dashboard/services/dashboard.service';

describe('EnterpriseDashboardComponent', () => {
  let component: EnterpriseDashboardComponent;
  let fixture: ComponentFixture<EnterpriseDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        PrimengModule,
        ReportsModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      declarations: [ EnterpriseDashboardComponent ],
      providers: [
        DateService,
        UtilService,
        DashboardService,
        FiscalDateService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterpriseDashboardComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
