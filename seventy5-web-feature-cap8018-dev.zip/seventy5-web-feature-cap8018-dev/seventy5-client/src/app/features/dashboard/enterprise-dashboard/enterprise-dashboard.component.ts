import {Accordion} from 'primeng';
import {Observable} from 'rxjs/Observable';
import { timer } from 'rxjs/observable/timer';
import {Constants} from '@shared/models/constants';
import { forkJoin } from 'rxjs/observable/forkJoin';
import {Component, OnInit, ViewChild} from '@angular/core';
import {
  PerformanceDisplay,
} from '@features/dashboard/models/dashboardData';
import {ChartDetails, DateRange} from '@shared/models/reportData';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import {DashboardService} from '@features/dashboard/services/dashboard.service';
import { EnterpriseCardboardDto } from '../domain/enterpriseCardboardDto';
import { EnterpriseTrendlineDto } from '../domain/enterpriseTrendlineDto';

@Component({
  selector: 'enterprise-dashboard',
  templateUrl: './enterprise-dashboard.component.html',
  styleUrls: ['./enterprise-dashboard.component.less']
})
export class EnterpriseDashboardComponent implements OnInit {

  @ViewChild('accordion', {static: false}) accordion: Accordion;
  public labels: any;
  public today: string;
  public totalBaleCount: any;
  public averageBaleCount: any;
  public yesterday: string;
  public endDayOfWeek: string;
  public startDayOfWeek: string;
  public disableExcel = true;
  public randomColor: string[] = [];
  public showPDFInstructions: boolean;
  public hidePDFInstructionsForever: boolean;
  public displayDates: DateRange;
  public currentWeek: DateRange;
  public previousWeek: DateRange;
  public trendLineDates: DateRange;
  public totalBalesForCurrentDay: ChartDetails;
  public totalBalesForCurrentWeek: ChartDetails;
  public averageBalesForCurrentDay: ChartDetails;
  public averageBalesForCurrentWeek: ChartDetails;
  public totalBaleProductionChartData: ChartDetails;
  public averageBaleProductionChartData: ChartDetails;
  public totalZeroScans: PerformanceDisplay;
  public totalWeeklyBaleCount: PerformanceDisplay;
  public AverageBaleCountPerDay: PerformanceDisplay;
  public enterpriseDashBoardDayData: EnterpriseCardboardDto;
  public enterpriseDashBoardWeekData: EnterpriseCardboardDto;
  public enterpriseDashBoardTrendLineData: EnterpriseTrendlineDto[];
  public spinner$: Observable<boolean> = this.util.getSpinner();

  public totalBaleProductionChartCustomOptions = {
    tooltips: {
      mode: 'point',
      callbacks: {
        label: function(tooltipItem, data) {
          let label = data.datasets[tooltipItem.datasetIndex].label || '';
          let dataValue = tooltipItem.yLabel;
          if (label) {
            label += 'total Bale Production: ';
          }
          if (dataValue && dataValue.toString().length >= 4) {
            dataValue = dataValue.toLocaleString('en');
          }
          label += dataValue;
          return label ;
        }
      }
    }
  };

  public averageBaleProductionChartCustomOptions = {
    tooltips: {
      mode: 'point',
      callbacks: {
        label: function(tooltipItem, data) {
          let label = data.datasets[tooltipItem.datasetIndex].label || '';
          let dataValue = tooltipItem.yLabel;
          if (label) {
            label += 'avg. Bale Production: ';
          }
          if (dataValue && dataValue.toString().length >= 4) {
            dataValue = dataValue.toLocaleString('en');
          }
          label += dataValue;
          return label ;
        }
      }
    }
  };

  constructor(private util: UtilService,
              private dateService: DateService,
              private dashBoardService: DashboardService) { }

  ngOnInit() {
    this.calculateDates();
    if (window.localStorage.getItem('hidePDFInstructionsForever') === 'true') {
      this.hidePDFInstructionsForever = true;
    }
    this.loadEnterpriseDashboardData();
  }

  private calculateDates() {
    const {today, yesterday, startDayOfWeek, endDayOfWeek, currentWeek,
          previousWeek, trendLineDates, displayDates}
          = DateService.calculateReportDates();

    this.today = today;
    this.yesterday = yesterday;
    this.startDayOfWeek = startDayOfWeek;
    this.endDayOfWeek = endDayOfWeek;

    this.previousWeek = previousWeek;
    this.currentWeek = currentWeek;
    this.displayDates = displayDates;
    this.trendLineDates = trendLineDates;
  }

  private loadEnterpriseDashboardData(): void {
    this.util.showSpinner();
    forkJoin(
      [this.dashBoardService.getEnterpriseBaleData(this.previousWeek),
      this.dashBoardService.getEnterpriseBaleData(this.currentWeek),
      this.dashBoardService.getEnterpriseBaleTrendLineData(this.trendLineDates),
      timer(Constants.SPINNER_TIMEOUT)]
    )
      .subscribe(([dayResponse, weekResponse, trendLineResponse]) => {
        this.util.hideSpinner();
        this.enterpriseDashBoardWeekData = weekResponse;
        this.enterpriseDashBoardDayData = dayResponse;
        this.enterpriseDashBoardTrendLineData = trendLineResponse;
        this.randomColor = UtilService.getRandomColors(this.enterpriseDashBoardTrendLineData.length);
        this.calculateEnterpriseCardBoardPerformance();
        this.calculateEnterpriseBaleReport();
        this.calculateEnterpriseTrendLineReport();
        this.disableExcel = false;
      });
  }

  private calculateEnterpriseCardBoardPerformance() {
    this.totalWeeklyBaleCount = {
      title: 'Total Weekly Bale Count',
      helpText: `Total number of bales scanned for the current week.`,
      performance: this.enterpriseDashBoardWeekData.totalBaleCount,
      headingClass: 'text-positive-400',
    };
    this.AverageBaleCountPerDay = {
      title: 'Avg # of Bales / Store per Day',
      helpText: `Average number of bales scanned per store, per day for the current week.
      This is calculated by dividing the number of bales by the number of stores in enterprise by the number of days in the current week.`,
      detailUrl: null,
      performance: this.enterpriseDashBoardWeekData.averageBalecount,
      headingClass: 'text-positive-400',
    };
    this.totalZeroScans = {
      title: 'Total # of Zero Scans',
      helpText: `Total number zero scans during the current week, a store recording zero scans in a day adds 1 to the count.`,
      performance: this.enterpriseDashBoardWeekData.totalZeroScan,
      headingClass: 'text-negative-400',
    };
  }

  private calculateEnterpriseBaleReport() {
    this.calculateTotalBaleData();
    this.calculateAverageBaleData();
  }

  private calculateTotalBaleData() {
    const dayTitle = `Total # of Bales  ${this.yesterday}`;
    const weekTitle = `Total # of Bales  Week Of ${this.startDayOfWeek}`;
    this.totalBalesForCurrentDay =
      this.dashBoardService.getEnterpriseTotalBales(this.enterpriseDashBoardDayData, dayTitle);
    this.totalBalesForCurrentWeek =
      this.dashBoardService.getEnterpriseTotalBales(this.enterpriseDashBoardWeekData, weekTitle);
    this.totalBalesForCurrentWeek.helpText = `
    Total number of bales  per division scanned for the current week,
    the three highest performing divisions are shown in green and the three lowest performing in red.`;
  }

  private calculateAverageBaleData() {
    const dayTitle = `Average # of Bales  ${this.yesterday}`;
    const weekTitle = `Average # of Bales  Week Of ${this.startDayOfWeek}`;
    this.averageBalesForCurrentDay =
      this.dashBoardService.getEnterpriseAverageBales(this.enterpriseDashBoardDayData, dayTitle);
    this.averageBalesForCurrentWeek =
      this.dashBoardService.getEnterpriseAverageBales(this.enterpriseDashBoardWeekData, weekTitle);
    this.averageBalesForCurrentWeek.helpText = `
    Average number of bales per division scanned for the current week,
    the three highest performing divisions are shown in green and the three lowest performing in red.
    This is calculated by dividing total bales scanned by total no of stores in that division.`;
  }

  private calculateEnterpriseTrendLineReport() {
    const baleTrendLineData = this.dashBoardService
      .getEnterpriseTrendLineData(this.enterpriseDashBoardTrendLineData, this.randomColor);
    const { labels, totalBaleCount, averageBaleCount} = baleTrendLineData;
    this.labels = labels;
    this.totalBaleCount = totalBaleCount;
    this.averageBaleCount = averageBaleCount;
    this.calculateTotalBaleTrendLineData();
    this.calculateAverageBaleTrendLineData();
  }

  private calculateTotalBaleTrendLineData() {
    const title = `Total Bale Production Counts / Week By Division
                   Week of ${this.displayDates.startDate} Through Week of ${this.displayDates.endDate}`;
    const helpText = `Trendline for the total bale production per division for
    the current fiscal year until previous week.`;
    this.totalBaleProductionChartData =
      DashboardService.calculateTrendLineDataset(this.totalBaleCount, this.labels, title, helpText);
  }

  private calculateAverageBaleTrendLineData() {
    const title = `Average Bale Counts / Store / Day By Division
                   Week of ${this.displayDates.startDate} Through Week of ${this.displayDates.endDate}`;
    const helpText = `Trendline for the Average bale production per division
    for the current fiscal year until previous week.`;
    this.averageBaleProductionChartData =
      DashboardService.calculateTrendLineDataset(this.averageBaleCount, this.labels, title, helpText);
  }

  public closePDFInstructions(): void {
    this.showPDFInstructions = false;
    if (this.hidePDFInstructionsForever) {
      window.localStorage.setItem('hidePDFInstructionsForever', 'true');
    }
    setTimeout(() => {
      window.print();
    });
  }
}
