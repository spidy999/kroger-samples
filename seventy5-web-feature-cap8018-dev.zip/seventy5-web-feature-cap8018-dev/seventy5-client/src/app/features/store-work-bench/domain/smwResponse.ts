import {LabelButNotScanDto} from '@features/dashboard/domain/labelButNotScanDto';
import { StoreManagerWorkbenchDto } from './storeManagerWorkbenchDto';
import {BaleList} from '@app/shared/domain/bale';

export class SmwResponse {
    startDate: string;
    endDate: string;
    storeManagerWorkbenchDto: StoreManagerWorkbenchDto;
    labelButNotScanDto: LabelButNotScanDto;
    smwStoreActivityDtoList: BaleList[];
    dcActiveFlg: boolean;
    storeVsSensorBale: string;
}


