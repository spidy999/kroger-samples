export class StoreManagerWorkbenchDto {
    storeScan: number;
    dcScan: number;
    totalWeight: number;
    totalWeightInTons: number;
    storeVsDcPercent: number;
}
