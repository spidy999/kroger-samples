export class WeeklyYtdDto {
    weekStartDate: string;
    baleCount: number;
}
