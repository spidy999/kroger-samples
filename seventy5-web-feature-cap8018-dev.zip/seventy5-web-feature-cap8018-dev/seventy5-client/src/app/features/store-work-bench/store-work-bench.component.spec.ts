import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import {WorkBenchService} from '@features/store-work-bench/services/workBench.service';
import {StoreWorkBenchComponent} from '@features/store-work-bench/store-work-bench.component';

describe('StoreWorkBenchComponent', () => {
  let component: StoreWorkBenchComponent;
  let fixture: ComponentFixture<StoreWorkBenchComponent>;
  let dateService: DateService;
  let utilService: UtilService;
  let workBenchService: WorkBenchService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        ReactiveFormsModule,
        KrogerNgAuthModule,
        BrowserAnimationsModule,
        RouterTestingModule,
      ],
      declarations: [
        StoreWorkBenchComponent
      ],
      providers: [
        DateService,
        WorkBenchService,
        UtilService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreWorkBenchComponent);
    dateService = TestBed.inject(DateService);
    utilService = TestBed.inject(UtilService);
    workBenchService = TestBed.inject(WorkBenchService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
