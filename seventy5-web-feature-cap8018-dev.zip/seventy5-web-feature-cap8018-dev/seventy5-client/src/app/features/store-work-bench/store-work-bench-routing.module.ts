import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {StoreWorkBenchComponent} from '@features/store-work-bench/store-work-bench.component';
import {AuthGuard} from '@app/auth-guard';
import {Permission} from '@shared/models/permissions';

const storeWorkBenchRoutes: Routes = [
  {
    path: ':division/:store',
    component: StoreWorkBenchComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.SMW_DASHBOARD.toString()
    }
  },
  {
    path: ':division/:store/:days',
    component: StoreWorkBenchComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.SMW_DASHBOARD.toString()
    }
  },
  {
    path: '**',
    component: StoreWorkBenchComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.SMW_DASHBOARD.toString()
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(storeWorkBenchRoutes)],
  exports: [RouterModule]
})
export class StoreWorkBenchRoutingModule { }
