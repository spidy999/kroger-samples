import {SelectItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {timer} from 'rxjs/observable/timer';
import {forkJoin} from 'rxjs/observable/forkJoin';
import { SmwResponse } from './domain/smwResponse';
import {Constants} from '@shared/models/constants';
import { WeeklyYtdDto } from './domain/weeklyYtdDto';
import {ActivatedRoute, Router} from '@angular/router';
import {ChartDetails} from '@shared/models/reportData';
import {Component, NgZone, OnInit} from '@angular/core';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {PerformanceDisplay} from '@features/dashboard/models/dashboardData';
import {storeWorkBench, WorkBench} from '@features/store-work-bench/models/workBench';
import {WorkBenchService} from '@features/store-work-bench/services/workBench.service';

@Component({
  selector: 'app-store-work-bench',
  templateUrl: './store-work-bench.component.html',
  styleUrls: ['./store-work-bench.component.less']
})
export class StoreWorkBenchComponent implements OnInit {

  public selectedDay: any;
  public columns: any = [];
  public workBenchChartData: any = [];
  public checkDivision = false;
  public dates: string;
  public storeNo: string;
  public division: string;
  public customDays: number;
  public days: SelectItem[];
  private workBenchParams: WorkBench;
  private workBenchResponse: SmwResponse;
  private trendLineResponse: WeeklyYtdDto[];
  public totalWeight: PerformanceDisplay;
  public storeVsDcPercentScanned: PerformanceDisplay;
  public storeVsSensorPercentScanned: PerformanceDisplay;
  public trendChartData: ChartDetails;
  public labelledButNotScanned: ChartDetails;
  public spinner$: Observable<boolean> = this.util.getSpinner();

  constructor(private ngZone: NgZone,
              private router: Router,
              private util: UtilService,
              private route: ActivatedRoute,
              private dateService: DateService,
              private workBenchService: WorkBenchService) {
    const {columns, days} = storeWorkBench;
    this.days = days;
    this.columns = columns;
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      let data;
      if (params && params.division && params.storeNumber) {
        this.division = params['division'];
        this.storeNo = params['storeNumber'];
      } else {
        data = this.route.snapshot.paramMap;
        this.division = data.get('division');
        this.storeNo = data.get('store');
      }
      if (params && params.days) {
        const paramDays = +params.days;
        const days = storeWorkBench.days
                      .find(dayElement => dayElement.value === paramDays);
        if (!days) {
          this.selectedDay = null;
          this.customDays = paramDays;
        } else {
          this.customDays = null;
          this.selectedDay = paramDays;
        }
      } else if (data && data.params && data.params.days) {
        const paramDays = +data.params.days;
        const days = storeWorkBench.days
          .find(dayElement => dayElement.value === paramDays);
        if (!days) {
          this.selectedDay = null;
          this.customDays = paramDays;
        } else {
          this.customDays = null;
          this.selectedDay = paramDays;
        }
      } else {
        this.selectedDay = Constants.DAYS_IN_WEEK;
      }
     this.buildWidgets();
    });
  }

  public changeDays(evt) {
    if (evt !== null) {
      this.buildWidgets();
    }
  }

  public navigateToSpecificUrl() {
    this.ngZone.run(() => this.router
      .navigateByUrl(`/app-store-work-bench/${this.division}/${this.storeNo}/${this.selectedDay ? this.selectedDay : this.customDays}`))
      .then();
  }

  public submit() {
    this.buildWidgets();
  }

  private buildWidgets() {
    this.navigateToSpecificUrl();
    this.workBenchParams = {
      division: this.division,
      storeNumber: this.storeNo,
      days: this.selectedDay ? this.selectedDay : this.customDays
    };
    this.calculateWorkBenchData(this.workBenchParams);
  }

  private calculateWorkBenchData(data) {
    this.util.showSpinner();
      forkJoin(
        [this.workBenchService.getWorkBenchData(data),
        this.workBenchService.getStoreTrendData(data.division, data.storeNumber),
        timer(Constants.SPINNER_TIMEOUT)]
      )
      .subscribe(([workBenchData, trendLineData]) => {
      this.workBenchResponse = workBenchData;
      this.trendLineResponse = trendLineData;
      const startDate = DateService.getMonthDayYearFormat(this.workBenchResponse.startDate);
      const endDate = DateService.getMonthDayYearFormat(this.workBenchResponse.endDate);
      this.dates = `${startDate} - ${endDate}`;
      this.util.hideSpinner();
      if (this.workBenchResponse.dcActiveFlg) {
        this.checkDivision = true;
        this.calculateDashBoardData();
      } else {
        this.checkDivision = false;
      }
      this.calculateTableData();
      this.calculateStoreVsSensorData();
      this.calculateStoreTrendLineData();
    },
      () => {
        this.util.hideSpinner();
      }
    );
  }

  private calculateDashBoardData() {
    let headingColor: string;
    const { storeManagerWorkbenchDto, labelButNotScanDto} = this.workBenchResponse;
    const totalWeight = storeManagerWorkbenchDto.totalWeight.toLocaleString('en');
    const totalWeightInTons = storeManagerWorkbenchDto.totalWeightInTons.toLocaleString('en');
    if (storeManagerWorkbenchDto.totalWeight > 0 ||
        storeManagerWorkbenchDto.totalWeightInTons > 0 ||
        storeManagerWorkbenchDto.storeVsDcPercent > 0) {
      headingColor = 'text-positive-400';
    } else {
      headingColor = 'text-negative-400';
    }
    this.totalWeight = {
      title: 'Total weight',
      helpText: 'Displays the total weight that the Distribution Center has recorded in the time range selected.',
      performance:  `${totalWeight} lbs (${totalWeightInTons} Tons)`,
      headingClass: headingColor
    };
    this.storeVsDcPercentScanned = {
      title: 'Store vs DC Scans',
      helpText: ` Scan at Store and DC<br>
        The Bale scanned at the Store and Distribution Center.`,
      performance: storeManagerWorkbenchDto.storeVsDcPercent ? storeManagerWorkbenchDto.storeVsDcPercent : '0%',
      headingClass: headingColor
    };
    this.labelledButNotScanned = WorkBenchService.getLabelledAndNotScannedStoreData(labelButNotScanDto);
  }

  private calculateStoreVsSensorData() {
    let headingColor: string;
    const { storeVsSensorBale } = this.workBenchResponse;
    if (storeVsSensorBale != null) {
      headingColor = 'text-positive-400';
    } else {
      headingColor = 'text-negative-400';
    }
    this.storeVsSensorPercentScanned = {
      title: 'Store vs Sensor Scans',
      helpText: ` Scan at Store and Sensor<br>
        The Bale scanned at the store and the bale recorded by bale sensor`,
      performance: storeVsSensorBale ? storeVsSensorBale :  '0%',
      headingClass: headingColor
    };
  }

  private calculateTableData() {
    this.workBenchChartData = this.workBenchService.calculateTableData(this.workBenchResponse, this.columns);
  }

  private calculateStoreTrendLineData() {
    this.trendChartData = this.workBenchService.calculateTrendLineData(this.trendLineResponse);
  }

  public checkInputKey(event) {
    return UtilService.checkKey(event);
  }
}
