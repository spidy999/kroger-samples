export class WorkBench {
  public storeNumber: string;
  public division: string;
  public days?: number;
}

export const storeWorkBench = {
  columns: [
    {field: 'date', header: 'Date', class: 'text-center'},
    {field: 'storeBales', header: 'Store Bales', class: 'text-center'},
    {field: 'sensorBales', header: 'Sensor Bales', class: 'text-center'},
  ],

  days: [
    {label: 'last 7 days', value: 7 },
    {label: 'last 14 days', value: 14 },
    {label: 'last 21 days', value: 21 },
    {label: 'last 28 days', value: 28 },
    {label: 'Other', value: null }
  ]
};

export class StoreWorkBenchActivity {
  public date: string;
  public storeBales: number;
  public sensorBales: number;
}
