import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { SmwResponse } from '../domain/smwResponse';
import { WeeklyYtdDto } from '../domain/weeklyYtdDto';
import {UtilService} from '@shared/services/util/util.service';
import {ChartDetails, Dataset} from '@shared/models/reportData';
import {DateService} from '@shared/services/date/date.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import { LabelButNotScanDto } from '@features/dashboard/domain/labelButNotScanDto';
import {StoreWorkBenchActivity, WorkBench} from '@features/store-work-bench/models/workBench';
const LINE_TENSION = 0.5;
const ROWS_PER_PAGE_LIMIT = 7;

@Injectable()
export class WorkBenchService {

  constructor(private http: HttpClient,
              private util: UtilService,
              private dateService: DateService,
              private fiscalDateService: FiscalDateService) {}

  static getLabelledAndNotScannedStoreData(storeData: LabelButNotScanDto): ChartDetails {
    let labelButNotScannedDataset = [];
    let data;
    if (storeData.labelButNotScanAtStore && storeData.totalBaleLabelledAtStore) {
      labelButNotScannedDataset = [
        {
          data: [storeData.labelButNotScanAtStore, storeData.totalBaleLabelledAtStore],
          backgroundColor: UtilService.getLabelButNotScannedDataColor(),
          hoverBackgroundColor: UtilService.getLabelButNotScannedDataColor()
        }
      ];
    }

    if (labelButNotScannedDataset.length > 0) {
      data = {
        labels: [storeData.labelButNotScanPercent + '% Bales labeled but not scanned at Store', 'Bales labeled at stores'],
        datasets: labelButNotScannedDataset
      };
    }

    return {
      title: 'Bales labeled but not scanned at Store',
      helpText: `Displays the total # of bales that were labeled but were not scanned at the
        store.  This is recognized when the bale is scanned at the Distribution
        Center and recorded for the first time.`,
      data
    };
  }

  calculateTrendLineChart(givenData: number[], randomColor): ChartDetails[] {
    const chartData = [];
    chartData.push(new Dataset(givenData, false, 'Total Bales',
      randomColor, randomColor, randomColor, 'line', null,
      [], null, LINE_TENSION));
    return chartData;
  }

  calculateTrendLineData(res: WeeklyYtdDto[]): ChartDetails {
    const labels = [];
    const counts = [];
    let data;

    if (res && res.length > 0) {
      res.forEach((weeklyYtdDto) => {
        const krogerDate = this.fiscalDateService.getKrogerQuarterPeriodWeek(weeklyYtdDto.weekStartDate);
        labels.push(krogerDate);
        counts.push(weeklyYtdDto.baleCount);
      });
      const randomColor = UtilService.getAvgScansAtStoreColor();
      const storeDataset = this.calculateTrendLineChart(counts, randomColor);

      data = {
        labels: labels,
        datasets: storeDataset
      };
    }

    return {
      title: 'YTD Weekly Bale Production',
      helpText: `This chart represents the total number of cardboard bales
                produced per week since the beginning of the year.`,
      height: '350px',
      detailUrl: null,
      data
    };
  }

  getWorkBenchData(workBench: WorkBench): Observable<SmwResponse> {
    return this.http.get<SmwResponse> (`api/smw/bale/week/${workBench.division}/${workBench.storeNumber}/${workBench.days}`);
  }

  getStoreTrendData(divisionNumber: string, storeNumber: string): Observable<WeeklyYtdDto[]> {
    return this.http.get<WeeklyYtdDto[]> (`api/smw/store/trend/${divisionNumber}/${storeNumber}`);
  }

  calculateTableData(res: SmwResponse, cols) {
    const datesArray = DateService.getListOfDatesBetweenRange(res.startDate, res.endDate);
    const completeData = this.extractBaleData(res, datesArray);

    /* sort data according to dates */
    completeData.sort((a, b) => (a.date < b.date) ? 1 : -1);


    completeData.forEach(data => {
      const day = DateService.getDayName(new Date(data.date).toISOString());
      data.date = `${data.date} - ${day}`;
    });

    /* Finally add day for each date accordingly */
    const totalStoreBales = [];
    const totalSensorBales = [];
    completeData.forEach(item => {
      totalStoreBales.push(item.storeBales);
      totalSensorBales.push(item.sensorBales);
    });

    const calculateTotalBales = {
      header: 'TOTAL BALES',
      storeTotal: totalStoreBales.reduce((prev, current) => prev + current, 0),
      sensorTotal: totalSensorBales.reduce((prev, current) => prev + current, 0)
    };

    return {
      data: completeData,
      columns: cols,
      dataKey: 'date',
      title: 'Store Activity',
      footer: calculateTotalBales,
      limit: ROWS_PER_PAGE_LIMIT
    };
  }

  private extractBaleData(res: SmwResponse, datesArray) {
    let totalData = {};
    let baleInfo = {};

    const partialData = [];
    const sortedData = [];
    const baleData = [];
    const datesThatHasBales = [];

    /* Initialize the object with zero values */
    datesArray.forEach(date => {
      const dateObj = DateService.getMonthDayYearFormat(date.toISOString());
      totalData = {
        date: `${dateObj}`,
        storeBales: 0,
        sensorBales: 0
      };
      partialData.push(totalData);
    });

    if (res && res.smwStoreActivityDtoList && res.smwStoreActivityDtoList.length > 0) {
      res.smwStoreActivityDtoList.forEach(data => {
       data.reportDate = DateService.getMonthDayYearFormat(data.reportDate);
        baleInfo = {
            date: `${data.reportDate}`,
            storeBales: data.storeBaleCount,
            sensorBales: data.sensorBaleCount
          };
        baleData.push(baleInfo);
      });
    }

    baleData.forEach(st => datesThatHasBales.push(st.date));

    if (datesThatHasBales.length > 0) {
      partialData.forEach((data) => {
        if (datesThatHasBales.indexOf(data.date) === -1) {
          sortedData.push(data);
        }
      });
    } else {
      sortedData.push(...partialData);
    }

    const completeData: StoreWorkBenchActivity[] = [...sortedData, ...baleData ];
    return completeData;
  }

}
