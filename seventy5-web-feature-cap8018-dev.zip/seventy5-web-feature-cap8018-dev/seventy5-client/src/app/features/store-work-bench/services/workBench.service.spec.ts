import {inject, TestBed} from '@angular/core/testing';
import {WorkBench} from '@features/store-work-bench/models/workBench';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {FiscalDateService} from '@shared/services/date/fiscaldate.service';
import {WorkBenchService} from '@features/store-work-bench/services/workBench.service';
import {SmwResponse} from '@features/store-work-bench/domain/smwResponse';
import {WeeklyYtdDto} from '@features/store-work-bench/domain/weeklyYtdDto';
import {LabelButNotScanDto} from '@features/dashboard/domain/labelButNotScanDto';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {StoreManagerWorkbenchDto} from '@features/store-work-bench/domain/storeManagerWorkbenchDto';

describe('WorkBenchService', () => {
  let workBenchService: WorkBenchService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        UtilService,
        DateService,
        WorkBenchService,
        FiscalDateService
      ]
    });
  });

  beforeEach(() => {
    workBenchService = TestBed.inject(WorkBenchService);
  });

  it('should be created', inject([WorkBenchService], (service: WorkBenchService) => {
    expect(service).toBeTruthy();
  }));


  it( 'should fetch work bench data', inject( [ WorkBenchService, HttpTestingController ],
    ( service: WorkBenchService, httpMock: HttpTestingController ) => {
      const params: WorkBench = {
        storeNumber: '0254',
        division: '014',
        days: 50
      };
      const storeManager: StoreManagerWorkbenchDto = {
        storeScan: 3,
        dcScan: 2,
        totalWeight: 750,
        totalWeightInTons: 7,
        storeVsDcPercent: 70
      };
      const labelButNotScanDto: LabelButNotScanDto = {
        totalStoreAndDcScan: 5,
        totalDcScan: 4,
        totalStoreScan: 5,
        totalStoreCount: 5,
        labelButNotScanPercent: 70,
        labelButNotScanAtStore: 5,
        totalBaleLabelledAtStore: 10
      };
      const baleList = [
        {
          storeBaleCount: 4,
          sensorBaleCount: 5,
          reportDate: '',
          reportDayOfWeek: ''
        }
      ];
      const result: SmwResponse = {
        startDate: '',
        endDate: '',
        storeManagerWorkbenchDto: storeManager,
        labelButNotScanDto: labelButNotScanDto,
        smwStoreActivityDtoList: baleList,
        dcActiveFlg: true,
        storeVsSensorBale: ''
      };
      service.getWorkBenchData(params).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( 'api/smw/bale/week/014/0254/50');
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch store trend data', inject( [ WorkBenchService, HttpTestingController ],
    ( service: WorkBenchService, httpMock: HttpTestingController ) => {
      const division = '014';
      const store = '0254';
      const result: WeeklyYtdDto[] = [
        {
          weekStartDate: '',
          baleCount: 5,
        }
      ];
      service.getStoreTrendData(division, store).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/smw/store/trend/${division}/${store}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

});
