import {CommonModule} from '@angular/common';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {ReportsModule} from '@shared/reports/reports.module';
import {TemplateModule} from '@app/templates/template.module';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {WorkBenchService} from '@features/store-work-bench/services/workBench.service';
import {StoreWorkBenchComponent} from '@features/store-work-bench/store-work-bench.component';
import {StoreWorkBenchRoutingModule} from '@features/store-work-bench/store-work-bench-routing.module';

@NgModule({
  imports: [
    CommonModule,
    PrimengModule,
    ReportsModule,
    TemplateModule,
    KdsStencilAccessorsModule,
    StoreWorkBenchRoutingModule
  ],
  providers: [
    WorkBenchService
  ],
  exports: [StoreWorkBenchComponent],
  declarations: [StoreWorkBenchComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class StoreWorkBenchModule { }
