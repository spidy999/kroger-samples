import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {QuartzComponent} from '@features/admin/quartz/quartz.component';
import {QuartzService} from '@features/admin/quartz/quartz.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

describe('QuartzComponent', () => {
  let component: QuartzComponent;
  let quartzService: QuartzService;
  let fixture: ComponentFixture<QuartzComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        QuartzComponent
      ],
      providers: [
        QuartzService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuartzComponent);
    component = fixture.componentInstance;
    quartzService = TestBed.inject(QuartzService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
