export class QuartzJob {
  description: string;
  jobName: string;
  jobGroup: string;
  jobClass: string;
  paused: boolean;
  triggers: QuartzTrigger[] = [];
}

export class QuartzTrigger {
  keyName: string;
  keyGroup: string;
  description: string;
  nextFireTime: Date;
  previousFireTime: Date;
  triggerState: string;
}

