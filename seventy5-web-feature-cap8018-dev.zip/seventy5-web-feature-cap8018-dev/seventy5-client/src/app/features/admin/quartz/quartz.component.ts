import {Menu} from 'primeng/menu';
import {MenuItem} from 'primeng/api';
import {Component, OnInit} from '@angular/core';
import {ToastDetails} from '@shared/models/Notification';
import {QuartzJob} from '@features/admin/quartz/model/quartzjob.model';
import {QuartzService} from '@features/admin/quartz/quartz.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

@Component({
  selector: 'app-quartz',
  templateUrl: './quartz.component.html',
  styleUrls: ['./quartz.component.less']
})
export class QuartzComponent implements OnInit {

  public schedulerStatus = '';
  public innerSpinner: boolean;
  public isSchedulerStarted = false;
  public menuItems: MenuItem[];
  public allQuartzJobs: QuartzJob[];

  constructor(private quartzService: QuartzService,
              private notificationService: NotificationsService) {
  }

  ngOnInit(): void {
    this.innerSpinner = true;
    this.loadAllJobs(false);
    this.getSchedulerStatus();
  }

  public loadAllJobs(showStatus) {
    let toastDetails: ToastDetails = {};
    this.quartzService.allJobs().subscribe(res => {
      this.allQuartzJobs = res;

      if (showStatus) {
        toastDetails = {
          title: 'Success',
          message: 'Jobs Loaded.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }
      this.innerSpinner = false;
    }, () => {
      toastDetails = {
        title: 'Failure',
        message: 'Error in loading Jobs.',
        toastType: 'error'
      };
      this.innerSpinner = false;
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

  public jobActionToggle(event, job, menuItem: Menu) {
    this.menuItems = this.getJobActionsMenu(job);
    menuItem.toggle(event);
  }

  public getJobActionsMenu(quartzJob: QuartzJob): MenuItem[] {
    const menu = {label: 'Actions', items: []};
    if (quartzJob.paused) {
      menu.items.push({label: 'Resume', icon: 'fa fa-fw fa-play', command: () => this.resumeJob(quartzJob)});
    } else {
      menu.items.push({label: 'Pause', icon: 'fa fa-fw fa-pause', command: () => this.pauseJob(quartzJob) });
    }
    if (this.schedulerStatus === 'STARTED') {
      menu.items.push({label: 'Run Now', icon: 'fa fa-fw fa-play', command: () => this.runJobNow(quartzJob) });
    }
    menu.items.push({separator: true});
    menu.items.push({label: 'Delete...', icon: 'fa fa-fw fa-close', command: () => this.deleteJob(quartzJob)});
    return [ menu ];
  }

  private getSchedulerStatus() {
    this.quartzService.schedulerStatus().subscribe(res => {
      this.schedulerStatus = res;
      switch (this.schedulerStatus) {
        case 'STARTED':
          this.isSchedulerStarted = true;
          break;
        case 'STANDBY':
          this.isSchedulerStarted = false;
          break;
        case 'SHUTDOWN':
          this.isSchedulerStarted = false;
          break;
        default:
          break;
      }
    });
  }

  public schedulerControl($event, start: boolean) {
    let toastDetails: ToastDetails = {};
    this.quartzService.schedulerControl(start).subscribe(() => {
      this.getSchedulerStatus();
      if (start) {
        toastDetails = {
          title: 'Success',
          message: 'Scheduler Started.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      } else {
        toastDetails = {
          title: 'Success',
          message: 'Scheduler Paused.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }
    });
  }

  private pauseJob(quartzJob: QuartzJob) {
    this.quartzService.pauseJob(quartzJob).subscribe(() => {
      this.loadAllJobs(false);
      const toastDetails = {
        title: 'Success',
        message: `Paused Job: ${quartzJob.jobName}`,
        toastType: 'success'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

  private resumeJob(quartzJob: QuartzJob) {
    this.quartzService.resumeJob(quartzJob).subscribe(() => {
        this.loadAllJobs(false);
        const toastDetails = {
          title: 'Success',
          message: `Resumed Job: ${quartzJob.jobName}`,
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
    });
  }

  private runJobNow(quartzJob: QuartzJob) {
    this.quartzService.triggerJob(quartzJob).subscribe(() => {
      this.loadAllJobs(false);
      const toastDetails = {
        title: 'Success',
        message: `Triggered Job: ${quartzJob.jobName}`,
        toastType: 'success'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

  private deleteJob(quartzJob: QuartzJob) {
    const confirmation = 'Deleting a job will only apply until the application server is restarted' +
        ' when it will get re-created.  This can be helpful if the definition has changed in the' +
        ' code and you want the job to be created by that new code.' +
        '\nAre you sure you want to delete this job?';

    if (confirm(confirmation)) {
      this.quartzService.deleteJob(quartzJob).subscribe(() => {
        this.loadAllJobs(false);
        const toastDetails = {
          title: 'Success',
          message: `Deleted Job: ${quartzJob.jobName}`,
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
  }

}
