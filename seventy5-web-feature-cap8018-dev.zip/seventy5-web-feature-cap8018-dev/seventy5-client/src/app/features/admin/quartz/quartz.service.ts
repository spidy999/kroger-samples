import {Injectable} from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {QuartzJob} from '@features/admin/quartz/model/quartzjob.model';

@Injectable()
export class QuartzService {

  constructor(private http: HttpClient) {}

  allJobs(): Observable<QuartzJob[]> {
    return this.http.get<QuartzJob[]>('/api/quartz/job');
  }

  schedulerStatus(): Observable<string> {
    return this.http.get<string>(
      'api/quartz/scheduler/status', {responseType: 'text' as 'json'});
  }

  schedulerControl(start: boolean): Observable<void> {
    if (start) {
      return this.http.get<void>('api/quartz/scheduler/start');
    } else {
      return this.http.get<void>('api/quartz/scheduler/standby');
    }
  }

  jobStatus(quartzJob: QuartzJob): Observable<string> {
    return this.http.get<string>('api/quartz/job/status/' + quartzJob.jobGroup + '/' + quartzJob.jobName);
  }

  pauseJob(quartzJob: QuartzJob): Observable<void> {
    return this.http.get<void>('api/quartz/job/pause/' + quartzJob.jobGroup + '/' + quartzJob.jobName);
  }

  resumeJob(quartzJob: QuartzJob): Observable<void> {
    return this.http.get<void>('api/quartz/job/resume/' + quartzJob.jobGroup + '/' + quartzJob.jobName);
  }

  triggerJob(quartzJob: QuartzJob): Observable<void> {
    return this.http.get<void>('api/quartz/job/trigger/' + quartzJob.jobGroup + '/' + quartzJob.jobName);
  }

  deleteJob(quartzJob: QuartzJob): Observable<void> {
    return this.http.get<void>('api/quartz/job/delete/' + quartzJob.jobGroup + '/' + quartzJob.jobName);
  }

}
