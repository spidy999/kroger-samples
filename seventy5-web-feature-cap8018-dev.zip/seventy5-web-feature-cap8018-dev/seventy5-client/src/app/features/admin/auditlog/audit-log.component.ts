import {Subject} from 'rxjs/Subject';
import {SelectItem} from 'primeng/api';
import {takeUntil} from 'rxjs/operators';
import {timer} from 'rxjs/observable/timer';
import {Dates} from '@shared/models/dateRange';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {Constants} from '@shared/models/constants';
import {FormControl, FormGroup} from '@angular/forms';
import {CalendarType} from '@shared/models/calendarType';
import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuditLogEvent} from '@features/admin/models/domain/auditLogEvent';
import {AuditLogEventSearch} from '@features/admin/models/domain/auditLogEventSearch';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DropdownService} from '@shared/services/dropdown/dropdown.service';
import {AuditLogService} from '@features/admin/services/auditlog/audit-log.service';

@Component({
  selector: 'app-audit-log',
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.less']
})
export class AuditLogComponent implements OnInit, OnDestroy {

  public dateRange: any = [];
  public innerSpinner: boolean;
  public isSearchAuditSubmitted: boolean;
  public searchAuditForm: FormGroup;
  public levels: SelectItem[];
  public sources: SelectItem[];
  public logNames: SelectItem[];
  public categories: SelectItem[];
  public sourceEvents: SelectItem[];
  public auditLogEvents: AuditLogEvent[];
  public calendarType: CalendarType;
  public selectedCalendarType = CalendarType;
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(private util: UtilService,
              private user: UserService,
              private dateService: DateService,
              public dropdownService: DropdownService,
              public auditLogService: AuditLogService) {
  }

  ngOnInit() {
    this.calendarType = this.selectedCalendarType.PREVIOUS_WEEK_CALENDAR;
    this.loadDropDownData();
    this.createSearchAuditForm();
    this.extractedDates();
    this.runSearch();
  }

  private extractedDates() {
    this.dateService.getCalendar().pipe(takeUntil(this.destroy)).subscribe((response: Dates) => {
      const {startDate, stopDate} = response;
      this.dateRange = [startDate, stopDate];
    });
  }

  private createSearchAuditForm() {
    this.searchAuditForm = new FormGroup({
        selectedDescription: new FormControl()
      , selectedEuids: new FormControl()
      , selectedLogNames: new FormControl()
      , selectedLevels: new FormControl()
      , selectedCategories: new FormControl()
      , selectedSources: new FormControl()
      , selectedSourceEvents: new FormControl()
    });

  }

  public loadDropDownData() {
    forkJoin([
      this.dropdownService.loadByName('AuditLogNameEnum'),
      this.dropdownService.loadByName('AuditLogLevelEnum'),
      this.dropdownService.loadByName('AuditLogCategoryEnum'),
      this.dropdownService.loadByName('AuditLogSourceEnum'),
      this.dropdownService.loadByName('AuditLogSourceEventEnum'),
      timer(Constants.SPINNER_TIMEOUT)
      ]
    ).subscribe(([logNames, levels, categories, sources, sourceEvents]) => {
      this.logNames = logNames;
      this.levels = levels;
      this.categories = categories;
      this.sources = sources;
      this.sourceEvents = sourceEvents;
    });
  }

  public runSearch() {
    this.innerSpinner = true;
    this.isSearchAuditSubmitted = true;
    const auditLogEventSearch = new AuditLogEventSearch();
    auditLogEventSearch.logNames = this.searchAuditForm.value.selectedLogNames;
    auditLogEventSearch.levels = this.searchAuditForm.value.selectedLevels;
    auditLogEventSearch.categories = this.searchAuditForm.value.selectedCategories;
    auditLogEventSearch.sources = this.searchAuditForm.value.selectedSources;
    auditLogEventSearch.sourceEvents = this.searchAuditForm.value.selectedSourceEvents;
    auditLogEventSearch.description = this.searchAuditForm.value.selectedDescription;
    auditLogEventSearch.startDate = this.dateRange[0];
    auditLogEventSearch.endDate = this.dateRange[1];
    if (this.searchAuditForm.value.selectedEuids) {
      auditLogEventSearch.euids = this.searchAuditForm.value.selectedEuids.split(',');
    }
    this.auditLogService.search(auditLogEventSearch).subscribe(res => {
      this.auditLogEvents = res.map(resEvent => {
        const auditLogEvent = new AuditLogEvent();
        auditLogEvent.auditLogEventId = resEvent.auditLogEventId;
        auditLogEvent.logName = resEvent.logName;
        auditLogEvent.level = resEvent.level;
        auditLogEvent.category = resEvent.category;
        auditLogEvent.source = resEvent.source;
        auditLogEvent.sourceEvent = resEvent.sourceEvent;
        auditLogEvent.description = resEvent.description;
        auditLogEvent.insertedDate = (new Date(resEvent.insertedDate)).toString();
        auditLogEvent.createdByEuid = resEvent.createdByEuid;
        return auditLogEvent;
      });
      this.innerSpinner = false;
      this.isSearchAuditSubmitted = false;
    });

  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }

}
