import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {
  FormBuilder, FormControl, FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {AuditLogComponent} from './audit-log.component';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {DropdownService} from '@shared/services/dropdown/dropdown.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {AuditLogService} from '@features/admin/services/auditlog/audit-log.service';

describe('AuditLogComponent', () => {
  let component: AuditLogComponent;
  let fixture: ComponentFixture<AuditLogComponent>;
  let userService: UserService;
  let dateService: DateService;
  let auditLogService: AuditLogService;
  let dropdownService: DropdownService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        RouterTestingModule
      ],
      providers: [
        UserService,
        DateService,
        FormBuilder,
        UtilService,
        FacilityService,
        DropdownService,
        AuditLogService,
        ValidatorsService
      ],
      declarations: [ AuditLogComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuditLogComponent);
    userService = TestBed.inject(UserService);
    dateService = TestBed.inject(DateService);
    auditLogService = TestBed.inject(AuditLogService);
    dropdownService = TestBed.inject(DropdownService);
    component = fixture.componentInstance;

    component.searchAuditForm = new FormGroup({
      selectedDescription: new FormControl(),
      selectedEuids: new FormControl(),
      selectedLogNames: new FormControl(),
      selectedLevels: new FormControl(),
      selectedCategories: new FormControl(),
      selectedSources: new FormControl(),
      selectedSourceEvents: new FormControl()
    });

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
