import * as _ from 'lodash';
import {MenuItem} from 'primeng/api';
import {DivisionObject} from '@shared/domain/division';
import {ToastDetails} from '@shared/models/Notification';
import { OverlayPanel, SelectItem} from 'primeng/primeng';
import {Component, OnInit, ViewChild} from '@angular/core';
import {OptionData as constant} from '@features/admin/models/adminData';
import {DivisionService} from '@shared/services/division/division.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {DivisionEditDialogComponent} from '@features/admin/division/edit/division-edit-dialog.component';

@Component({
  selector: 'app-division',
  templateUrl: './division.component.html',
  styleUrls: ['./division.component.less']
})
export class DivisionComponent implements OnInit {

  @ViewChild(DivisionEditDialogComponent, {static: false}) editDialog: DivisionEditDialogComponent;

  public innerSpinner: boolean;
  public divisionFlag: boolean;
  public currentDivision: string;
  public menuItems: MenuItem[];
  public divisions: DivisionObject[];
  public yesNoOptions: SelectItem[] = [];
  public selectedDivision: DivisionObject;

  constructor(public divisionService: DivisionService,
              private notificationService: NotificationsService) {
    const { yesNoOptions } = constant;
    this.yesNoOptions = yesNoOptions;
  }

  ngOnInit() {
    this.divisionFlag = false;
    this.innerSpinner = true;
    this.runSearch();
  }

  private runSearch() {
    this.divisionService.getAllDivisions().subscribe(res => {
      this.divisions = res.map(resDivision => {
        return new DivisionObject(resDivision.divisionNumber, resDivision.divisionDesc,
          resDivision.includeDivision, resDivision.hostNamePrefix);
      });
      this.innerSpinner = false;
    });

  }

  private sortList() {
    this.divisions = _.sortBy(this.divisions, 'divisionNumber');
  }

  public showDetails(event, division: DivisionObject, overlaypanel: OverlayPanel) {
    this.selectedDivision = division;
    overlaypanel.toggle(event);
  }

  public openEditDialog(division: DivisionObject) {
    this.editDialog.showEditDialog(division);
  }

  public onEditDialogSaved(division: DivisionObject) {
    const itemIndex = this.divisions.findIndex(aDivision => aDivision.divisionNumber === division.divisionNumber );
    if (itemIndex >= 0) {
      this.divisions[itemIndex] = division;
    } else {
      this.divisions.push(division);
    }
    this.sortList();
  }

  public addNew() {
    const division: DivisionObject = {'divisionNumber': null, 'divisionDesc': null};
    division.includeDivision = true;
    this.editDialog.showAddDialog(division);
  }

  public deleteDivision(division: DivisionObject) {
    this.currentDivision = division.divisionNumber;
    this.divisionFlag = true;
  }

  public deleteSelectedDivision(flag: boolean) {
    let toastDetails: ToastDetails = {};
    if (flag) {
      this.divisionService.deleteDivision(this.currentDivision).subscribe(() => {
        const itemIndex = this.divisions.findIndex(aDivision => aDivision.divisionNumber === this.currentDivision);
        if (itemIndex >= 0) {
          this.divisions.splice(itemIndex, 1);
        }
        this.sortList();
        toastDetails = {
          title: 'Success',
          message: 'Record deleted.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record not deleted.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.divisionFlag = false;
  }
}
