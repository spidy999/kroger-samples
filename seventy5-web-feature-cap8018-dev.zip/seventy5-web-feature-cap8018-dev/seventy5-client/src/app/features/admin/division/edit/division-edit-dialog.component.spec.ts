import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UtilService} from '@shared/services/util/util.service';
import {DivisionService} from '@shared/services/division/division.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {DivisionEditDialogComponent} from '@features/admin/division/edit/division-edit-dialog.component';

describe('DivisionEditDialogComponent', () => {
  let component: DivisionEditDialogComponent;
  let fixture: ComponentFixture<DivisionEditDialogComponent>;
  let utilService: UtilService;
  let divisionService: DivisionService;
  let notificationsService: NotificationsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        DivisionEditDialogComponent
      ],
      providers: [
        UtilService,
        DivisionService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DivisionEditDialogComponent);
    component = fixture.componentInstance;
    utilService = TestBed.inject(UtilService);
    divisionService = TestBed.inject(DivisionService);
    notificationsService = TestBed.inject(NotificationsService);

    component.editDivisionFormGroup = new FormGroup({
      divisionNumber: new FormControl(),
      divisionName: new FormControl(),
      hostNamePrefix: new FormControl(),
      includeDivision: new FormControl()
    });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
