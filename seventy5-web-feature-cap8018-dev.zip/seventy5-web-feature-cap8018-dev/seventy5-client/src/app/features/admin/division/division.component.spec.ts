import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {DivisionService} from '@shared/services/division/division.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {DivisionComponent} from '@features/admin/division/division.component';

describe('DivisionComponent', () => {
  let component: DivisionComponent;
  let fixture: ComponentFixture<DivisionComponent>;
  let divisionService: DivisionService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        KrogerNgAuthModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        DivisionComponent
      ],
      providers: [
        DivisionService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DivisionComponent);
    component = fixture.componentInstance;
    divisionService = TestBed.inject(DivisionService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });

});
