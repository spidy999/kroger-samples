import {SelectItem} from 'primeng/api';
import {ToastDetails} from '@shared/models/Notification';
import {OptionData as constant} from '../../models/adminData';
import {Division, DivisionObject} from '@shared/domain/division';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {UtilService} from '@shared/services/util/util.service';
import {DivisionService} from '@shared/services/division/division.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

const NAME_LENGTH = 32;
const HOST_NAME_PREFIX = 2;
const DIVISION_NUMBER_LENGTH = 3;

@Component({
  selector: 'app-division-edit-dialog',
  templateUrl: './division-edit-dialog.component.html',
  styleUrls: ['./division-edit-dialog.component.less']
})
export class DivisionEditDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<DivisionObject>();
  public doingAddNew = false;
  public showDialogFlag = false;
  public yesNoOptions: SelectItem[];
  public editDivisionFormGroup: FormGroup;

  constructor(private utilService: UtilService,
              public divisionService: DivisionService,
              private notificationService: NotificationsService) {
    const { yesNoOptions } = constant;
    this.yesNoOptions = yesNoOptions;
  }

  ngOnInit(): void {
    this.createFormGroup();
    const controls = this.editDivisionFormGroup.controls;
    controls.includeDivision.setValue(true);
  }

  private createFormGroup() {
    this.editDivisionFormGroup = new FormGroup({
      divisionNumber: new FormControl(null, [Validators.required,  Validators.maxLength(DIVISION_NUMBER_LENGTH)]),
      divisionName: new FormControl(null, [Validators.required,  Validators.maxLength(NAME_LENGTH)]),
      hostNamePrefix: new FormControl(null, [Validators.maxLength(HOST_NAME_PREFIX)]),
      includeDivision: new FormControl(null, Validators.required),
    });
  }

  private setDivision(division: DivisionObject) {
    const controls = this.editDivisionFormGroup.controls;

    controls.divisionNumber.setValue(division.divisionNumber);
    controls.divisionName.setValue(division.divisionDesc);
    controls.hostNamePrefix.setValue(division.hostNamePrefix);
    controls.includeDivision.setValue(division.includeDivision);
  }

  private getDivision(): DivisionObject {
    const controls = this.editDivisionFormGroup.controls;

    const division: DivisionObject = {
        'divisionNumber': controls.divisionNumber.value,
        'divisionDesc': controls.divisionName.value
    };
    division.includeDivision = controls.includeDivision.value;
    return division;
  }

   public showEditDialog(division: Division) {
    this.setDivision(division);
    this.doingAddNew = false;
    this.editDivisionFormGroup.controls.divisionNumber.disable();
    this.showDialogFlag = true;
  }

   public showAddDialog(division: Division) {
    this.setDivision(division);
    this.editDivisionFormGroup.controls.divisionNumber.enable();
    this.doingAddNew = true;
    this.showDialogFlag = true;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    const division = this.getDivision();
    if (flag) {
      if (this.doingAddNew) {
        this.divisionService.addDivision(division).subscribe(res => {
          this.setDivision(res);
          this.saved.emit(this.getDivision());
          toastDetails = {
            title: 'Success',
            message: 'Record created',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        },  () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.divisionService.saveDivision(division).subscribe(res => {
          this.setDivision(res);
          this.saved.emit(this.getDivision());
          toastDetails = {
            title: 'Success',
            message: 'Record saved',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        },  () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not saved',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.editDivisionFormGroup.reset();
    this.editDivisionFormGroup.markAsPristine();
    this.showDialogFlag = false;
  }

}
