import {CacheService} from '@features/admin/services/cache/cache.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {inject, TestBed} from '@angular/core/testing';
import {CacheStatisticsModel} from '@features/admin/models/domain/cacheStatisticModel';

describe('CacheService', () => {
  let auditLogService: CacheService;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ CacheService ]
  }));

  beforeEach(() => {
    auditLogService = TestBed.inject(CacheService);
  });

  it('should be created', () => {
    const service: CacheService = TestBed.inject(CacheService);
    expect(service).toBeTruthy();
  });

  it( 'should fetch cache list', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      const result: CacheStatisticsModel[] = [
        {
          name: 'dashboard-BaleProduction',
          statistics: {
            AverageGetTime: '0.0',
            AveragePutTime: '0.0',
            AverageRemoveTime: '0.0',
            CacheEvictions: '0',
            CacheGets: '0',
            CacheHitPercentage: '0.0',
            CacheHits: '0',
            CacheMissPercentage: '0.0',
            CacheMisses: '0',
            CachePuts: '0',
            CacheRemovals: '0'
          }
        }
      ];
      service.list().subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/cache/`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should load cache', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      const cacheName = 'findAllEmail';
      const result: CacheStatisticsModel = {
        name: 'findAllEmail',
        statistics: {
          AverageGetTime: '0.0',
          AveragePutTime: '0.0',
          AverageRemoveTime: '0.0',
          CacheEvictions: '0',
          CacheGets: '0',
          CacheHitPercentage: '0.0',
          CacheHits: '0',
          CacheMissPercentage: '0.0',
          CacheMisses: '0',
          CachePuts: '0',
          CacheRemovals: '0',
        }
      };
      service.loadCache(cacheName).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/cache/${cacheName}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should clear cache', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      const cacheName = 'findAllSupplyItems';
      service.clear(cacheName).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/cache/clear/${cacheName}`);
      expect( req.request.method ).toBe( 'GET' );
    }));

  it( 'should clear all cache', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      const result = [
        'dashboard-TotalWeight',
        'supplyAuditChampions',
        'findAllDistricts',
        'dashboard-TotalStore',
        'findAllDivisions',
        'findEmailByFacility',
        'findAllEmail',
        'findAllFacilities'
      ];
      service.clearAll().subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/cache/clear/all`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should set logging enable', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      const logging = true;
      service.setLogging(logging).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/cache/log/enable`);
      expect( req.request.method ).toBe( 'GET' );
    }));

  it( 'should set logging disable', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      const logging = false;
      service.setLogging(logging).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/cache/log/disable`);
      expect( req.request.method ).toBe( 'GET' );
    }));

  it( 'should check is logging enabled', inject( [ CacheService, HttpTestingController ],
    ( service: CacheService, httpMock: HttpTestingController ) => {
      service.isLoggingEnabled().subscribe(data => {
        expect(data).toEqual(false);

        const req = httpMock.expectOne( `/api/cache/log/isenabled`);
        expect( req.request.method ).toBe( 'GET' );
        req.flush(false);
      });
    }));
});
