import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BaleSensorService {

  constructor(private http: HttpClient) { }

  uploadFile(file): Observable<any> {
    return this.http.post<any>('api/isilon/upload/file', file);
  }
}
