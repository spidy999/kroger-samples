import {inject, TestBed} from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {BaleSensorService} from '@features/admin/services/sensors/bale-sensor.service';

describe('BaleSensorService', () => {
  let baleSensorService: BaleSensorService;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ BaleSensorService ]
  }));

  beforeEach(() => {
    baleSensorService = TestBed.inject(BaleSensorService);
  });

  it('should be created', () => {
    const service: BaleSensorService = TestBed.inject(BaleSensorService);
    expect(service).toBeTruthy();
  });

  it( 'should upload file', inject( [ BaleSensorService, HttpTestingController ],
    ( service: BaleSensorService, httpMock: HttpTestingController ) => {
      const records = [
        {
          baleScanned: '1',
          createdDate: '9/17/2019',
          divisionNo: '14',
          index: '8',
          sensorEventStartTs: '9/17/2019 1:31',
          sensorId: '73029',
          storeNo: '454',
        },
        {
          baleScanned: '1',
          createdDate: '9/17/2019',
          divisionNo: '14',
          index: '38',
          sensorEventStartTs: '9/17/2019 7:08',
          sensorId: '73029',
          storeNo: '454'
        },
        {
          baleScanned: '1',
          createdDate: '9/17/2019',
          divisionNo: '14',
          index: '73',
          sensorEventStartTs: '9/17/2019 19:19',
          sensorId: '73029',
          storeNo: '454'
        }
      ];
      const result = [];
      service.uploadFile(records).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/isilon/upload/file`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(result);
    }));
});
