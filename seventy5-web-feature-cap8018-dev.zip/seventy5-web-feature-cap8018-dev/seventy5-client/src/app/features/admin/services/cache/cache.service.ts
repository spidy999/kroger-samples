import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { CacheStatisticsModel } from '../../models/domain/cacheStatisticModel';

@Injectable()
export class CacheService {

  constructor(private http: HttpClient) {}

  list(): Observable<CacheStatisticsModel[]> {
    return this.http.get<CacheStatisticsModel[]>('/api/cache/');
  }

  loadCache(cacheName): Observable<CacheStatisticsModel> {
    return this.http.get<CacheStatisticsModel>('/api/cache/' + cacheName);
  }

  clear(cacheName: string): Observable<void> {
    return this.http.get<void>('/api/cache/clear/' + cacheName);
  }

  clearAll(): Observable<string[]> {
    return this.http.get<string[]>('/api/cache/clear/all');
  }

  setLogging(enabledFlag): Observable<void> {
    if (enabledFlag) {
      return this.http.get<void>('/api/cache/log/enable');
    } else {
      return this.http.get<void>('/api/cache/log/disable');
    }
  }

  isLoggingEnabled(): Observable<boolean> {
    return this.http.get<boolean>('/api/cache/log/isenabled');
  }
}
