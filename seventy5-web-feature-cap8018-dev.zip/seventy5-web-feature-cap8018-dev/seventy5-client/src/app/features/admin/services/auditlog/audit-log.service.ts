import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import { AuditLogEvent } from '../../models/domain/auditLogEvent';
import {AuditLogEventSearch} from '@features/admin/models/domain/auditLogEventSearch';

@Injectable()
export class AuditLogService {

  constructor(private http: HttpClient) {}

  search(auditLogEventSearch: AuditLogEventSearch): Observable<AuditLogEvent[]> {
    return this.http.post<AuditLogEvent[]>('/api/auditlog/search', auditLogEventSearch );
  }

}
