import {inject, TestBed} from '@angular/core/testing';
import {AuditLogEvent} from '@features/admin/models/domain/auditLogEvent';
import {AuditLogService} from '@features/admin/services/auditlog/audit-log.service';
import {AuditLogEventSearch} from '@features/admin/models/domain/auditLogEventSearch';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('WorkBenchService', () => {
  let auditLogService: AuditLogService;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [ AuditLogService ]
  }));

  beforeEach(() => {
    auditLogService = TestBed.inject(AuditLogService);
  });

  it('should be created', () => {
    const service: AuditLogService = TestBed.inject(AuditLogService);
    expect(service).toBeTruthy();
  });

  it( 'should search audit log data', inject( [ AuditLogService, HttpTestingController ],
    ( service: AuditLogService, httpMock: HttpTestingController ) => {
      const params: AuditLogEventSearch = {
        logNames: ['SYSTEM'],
        levels: ['INFORMATION'],
        categories: ['LOGON'],
        sources: ['SYSTEM'],
        sourceEvents: [],
        description: 'SUPPORT was logged in from the web.',
        euids: ['SUPPORT'],
        startDate: 'Fri Apr 23 2021 16:03:08 GMT-0400 (Eastern Daylight Time)',
        endDate: 'Fri Apr 23 2021 16:03:08 GMT-0400 (Eastern Daylight Time)'
      };

      const result: AuditLogEvent[] = [
        {
          auditLogEventId: 140438,
          logName: {displayName: 'System', name: 'SYSTEM'},
          level: {displayName: 'Information', name: 'INFORMATION'},
          category: {displayName: 'Login', name: 'LOGON'},
          source: {displayName: 'System', name: 'SYSTEM'},
          sourceEvent: {displayName: 'Login', name: 'LOGIN'},
          description: 'SUPPORT was logged in from the web.',
          insertedDate: 'Fri Apr 23 2021 16:03:08 GMT-0400 (Eastern Daylight Time)',
          createdByEuid: 'SUPPORT',
        }
      ];
      service.search(params).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `/api/auditlog/search`);
      expect( req.request.method ).toBe( 'POST' );
      req.flush(result);
    }));

});
