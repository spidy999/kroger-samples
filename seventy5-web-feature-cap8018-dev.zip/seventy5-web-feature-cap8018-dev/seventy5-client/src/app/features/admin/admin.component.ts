import {Component, OnInit} from '@angular/core';
import {MenuItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {AdminTab} from '@features/admin/models/adminData';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {AdminTabs as constants} from '@features/admin/models/adminData';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.less']
})
export class AdminComponent implements OnInit {
  public selectionType: AdminTab;
  public selectedType = AdminTab;
  public availableOptions: MenuItem[];
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor(private userService: UserService,
              private utilService: UtilService) {}

  ngOnInit(): void {
    this.selectionType = this.selectedType.HOME;
    this.buildTabs();
  }

  private buildTabs() {
    this.availableOptions = [];
    const { supportUserTabs } = constants;
    if (this.userService.getUser()) {
      if (this.userService.isSupport()) {
        this.availableOptions = supportUserTabs;
      }
    }
  }

  public tabChange(evt) {
    if (evt) {
      const detail = evt.detail;
      switch (detail) {
        case 0:
          this.selectionType = this.selectedType.HOME;
          break;
        case 1:
          this.selectionType = this.selectedType.AUDIT_LOG;
          break;
        case 2:
          this.selectionType = this.selectedType.DC_FACILITIES;
          break;
        case 3:
          this.selectionType = this.selectedType.DIVISIONS;
          break;
        case 4:
          this.selectionType = this.selectedType.STORES;
          break;
        case 5:
          this.selectionType = this.selectedType.QUARTZ_MANAGER;
          break;
        case 6:
          this.selectionType = this.selectedType.CACHE_MANAGER;
          break;
        case 7:
          this.selectionType = this.selectedType.LOGGERS;
          break;
        case 8:
          this.selectionType = this.selectedType.ERROR_MESSAGES;
          break;
      }
    }
  }
}
