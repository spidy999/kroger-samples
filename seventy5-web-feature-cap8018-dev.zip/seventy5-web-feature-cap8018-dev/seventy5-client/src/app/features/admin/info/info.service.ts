import * as _ from 'lodash';
import {map} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ActuatorInfo} from '@features/admin/info/model/info.model';

@Injectable()
export class AppInformationService {

  private actuatorBaseUrl = '/manage/';

  private static buildEnvironmentTree(json) {
    const treeNodes = [];
    const profileNode = {label: 'Active Profiles', children: []};
    if (json && json.activeProfiles) {
      json.activeProfiles.forEach(data => {
        profileNode.children.push({label: json.activeProfiles[data]});
      });
      treeNodes.push(profileNode);
    }

   /* json.propertySources.forEach(prop => {
      const treeNode = {label: _.startCase(json.propertySources[prop].name), children: []};
      if (json.propertySources[prop].properties) {
        treeNode.children = AppInformationService.buildPropertyNode(json.propertySources[prop].properties);
      }
      treeNodes.push(treeNode);
    });*/

    for (let i = 0; i < json.propertySources.length; i++) {
      const treeNode = {label: _.startCase(json.propertySources[i].name), children: []};
      if (json.propertySources[i].properties) {
        treeNode.children = AppInformationService.buildPropertyNode(json.propertySources[i].properties);
      }
      treeNodes.push(treeNode);
    }
    return treeNodes;
  }

  private static buildPropertyNode(properties) {
    const children = [];
    for (const property in properties) {
      if (properties.hasOwnProperty(property)) {
        const propertyValue = {label: property, data: properties[property].value};
        children.push(propertyValue);
      }
    }
    return children;
  }

  constructor(private http: HttpClient) {}

  information() {
    return this.http.get<ActuatorInfo>(this.actuatorBaseUrl + 'info');
  }

  configprops() {
    return this.http.get<any>(
      this.actuatorBaseUrl + 'configprops'
    ).pipe(map(res => res.contexts['application-1'].beans));
  }

  flyway() {
    return this.http.get<any>(this.actuatorBaseUrl + 'flyway')
      .pipe(map(res => res.contexts['application-1'].flywayBeans.flyway));
  }

  environmentTree() {
    return this.http.get<any>(this.actuatorBaseUrl + 'env')
      .pipe(map(res => AppInformationService.buildEnvironmentTree(res)));
  }

}
