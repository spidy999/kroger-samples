import {Component, OnInit, ViewChild} from '@angular/core';
import {ActuatorInfo} from '@features/admin/info/model/info.model';
import {
  ActuatorConfigprops,
  ActuatorInfoConstants,
  ConfigPropsConstants,
  ServerInfoConstants
} from '@features/admin/info/model/configprops.model';
import {Observable} from 'rxjs/Observable';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {ToastDetails} from '@shared/models/Notification';
import {UtilService} from '@shared/services/util/util.service';
import {AppInformationService} from '@features/admin/info/info.service';
import {LoggersService} from '@features/admin/loggers/loggers.service';
import {BaleSensorService} from '@features/admin/services/sensors/bale-sensor.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {FileUploadService as upload} from '@shared/services/fileUpload/file-upload.service';
const TIMEOUT = 2000;

@Component({
  selector: 'app-information',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.less']
})
export class InformationComponent implements OnInit {

  @ViewChild('uploadCSVFile', {static: false}) fileInput;
  public count: number;
  public serverInfo: any;
  public progressColor: any;
  public fileName: string;
  public csvRecords = [];
  public showStatusBar: boolean;
  public systemProperties: any;
  public infoRows: {field: any, header: any}[] = [];
  public actuatorGitRows: {field: any, header: any}[] = [];
  public configPropsRows: {field: any, header: any}[] = [];
  public configPropsCols: {field: any, header: any}[] = [];
  public actuatorBuildRows: {field: any, header: any}[] = [];
  public actuatorInfo: ActuatorInfo;
  public actuatorConfigprops: ActuatorConfigprops;
  public spinner$: Observable<boolean> = this.util.getSpinner();

  constructor(public util: UtilService,
              private loggersService: LoggersService,
              private baleSensorService: BaleSensorService,
              private appInformationService: AppInformationService,
              private notificationService: NotificationsService) {
    const {propRows, propCols} = ConfigPropsConstants;
    this.configPropsRows = propRows;
    this.configPropsCols = propCols;

    const {infoRows} = ServerInfoConstants;
    this.infoRows = infoRows;

    const {buildRows, gitRows} = ActuatorInfoConstants;
    this.actuatorBuildRows = buildRows;
    this.actuatorGitRows = gitRows;
  }

  ngOnInit(): void {
    this.loadWidgets();
  }

  private loadWidgets() {
    this.showStatusBar = false;
    this.util.showSpinner();
    let toastDetails: ToastDetails = {};
    forkJoin(
      [this.loggersService.serverInfo(),
      this.appInformationService.information(),
      this.appInformationService.configprops(),
      this.appInformationService.environmentTree()]
    ).subscribe(([serverInfo, information, configprops, environmentTree]) => {
        this.util.hideSpinner();
        this.serverInfo = serverInfo;
        this.actuatorInfo = information;
        this.actuatorConfigprops = configprops;
        this.systemProperties = environmentTree;
      },
      () => {
      this.util.hideSpinner();
      toastDetails = {
          title: 'Error',
          message: 'Failed to load info',
          toastType: 'error'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

  fileChangeListener() {
    let toastDetails: ToastDetails = {};
    const file = this.fileInput.nativeElement.files[0];
    this.fileName = file.name;
    if (file && upload.isCSVFile(file)) {
      const reader = new FileReader();
      reader.readAsText(file);
      reader.onload = () => {
        const csvData = reader.result;
        const csvRecordsArray = (<string>csvData).split(/\r\n|\n/);
        const headersRow = upload.getHeaderArray(csvRecordsArray);
        if (upload.checkHeaders(headersRow)) {
          this.csvRecords = upload.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
          toastDetails = this.uploadData(toastDetails, csvRecordsArray);
        } else {
          toastDetails = {
            title: 'Error',
            message: 'File headers does not match',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        }
      };
      reader.onerror = () =>  {
        console.log('Unable to read ' , file);
      };
    } else {
      toastDetails = {
        title: 'Error',
        message: 'Please import valid .csv file',
        toastType: 'error'
      };
      this.showStatusBar = false;
      this.notificationService.emitMessage.next(toastDetails);
    }
    this.fileReset();
  }

  private uploadData(toastDetails: ToastDetails, uploadData) {
    this.count = 0;
    this.showStatusBar = true;
    const timeInterval = Math.floor(upload.calculateBarSpeed(uploadData));
    this.baleSensorService.uploadFile(this.csvRecords).subscribe(res => {
      this.showStatusBar = false;
      clearInterval(interval);
        if (res.statusInfo.exitStatus === 'SUCCESS') {
          toastDetails = {
            title: 'success',
            message: 'File uploaded successfully',
            toastType: 'success'
          };
        } else {
          toastDetails = {
            title: 'Error',
            message: 'Failed to uploaded file',
            toastType: 'error'
          };
        }
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
      toastDetails = {
        title: 'Error',
        message: 'Network is slow',
        toastType: 'error'
      };
      this.showStatusBar = false;
      this.notificationService.emitMessage.next(toastDetails);
  });
    const interval = setInterval(() => {
      this.count = this.count + timeInterval;
      this.progressColor = upload.setBarStyle(this.count);
      if (this.count >= 100) {
        this.count = 100;
        clearInterval(interval);
        }
      }, TIMEOUT);
    return toastDetails;
  }

  fileReset() {
    this.fileInput.nativeElement.value = '';
    this.csvRecords = [];
  }
}
