export class ActuatorInfo {
  public git: ActuatorGit;
  public build: ActuatorBuild;
}

export class ActuatorBuild {
  public version: string;
  public artifact: string;
  public name: string;
  public group: string;
  public time: Date;
  public continuousIntegration: ActuatorContinuousIntegration;
}

export class ActuatorContinuousIntegration {
  public buildNumber: string;
  public agent: string;
}

export class ActuatorGit {
  public commit: ActuatorGitCommit;
  public branch: string;
}

export class ActuatorGitCommit {
  public time: number;
  public id: string;
}
