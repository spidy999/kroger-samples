/*
  A pared down list of properties available from Spring Actuator /configprops.
 */
export class ActuatorConfigprops {
  public seventy5DataSource?: Seventy5DataSource;
}

export class Seventy5DataSource {
  public prefix?: string;
  public properties?: DatasourceProperties;
}

export class DatasourceProperties {
  public driverClassName: string;
  public jdbcUrl: string;
  public username: string;
  public maxLifetime: number;
  public minimumIdle: number;
  public autoCommit: boolean;
  public maximumPoolSize: number;
  public idleTimeout: string;
  public connectionTimeout: number;
}

export const ConfigPropsConstants = {
  propRows: [
    {field: 'Driver class name', header: 'driverClassName'},
    {field: 'URL', header: 'jdbcUrl'},
    {field: 'Username', header: 'username'},
    {field: 'Pool max size', header: 'maximumPoolSize'},
    {field: 'Pool min Idle', header: 'minimumIdle'},
    {field: 'Pool max lifetime', header: 'maxLifetime'},
    {field: 'Pool idle timeout', header: 'idleTimeout'},
    {field: 'Pool auto commit', header: 'autoCommit'}
  ],

  propCols: [
    {field: 'Prefix', header: 'prefix', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'Properties', header: 'properties', headerClass: 'centerAlignment', class: 'centerAlignment'},
  ]
};

export const ServerInfoConstants = {
  infoRows: [
    {field: 'Canonical Host Name', header: 'canonicalHostName'},
    {field: 'Host Address', header: 'hostAddress'},
    {field: 'Host Name', header: 'hostName'},
    {field: 'Server Port', header: 'serverPort'}
  ],
};

export const ActuatorInfoConstants = {
  buildRows: [
    {field: 'Name', header: 'name'},
    {field: 'Version', header: 'version'},
    {field: 'Time', header: 'time'}
  ],
  gitRows: [
    {field: 'Branch Name', header: 'branch'},
    {field: 'Commit Time', header: 'time'}
  ],
};

export const FlywayConstants = {
  flywayCols: [
    {field: 'Type', header: 'type', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'Checksum', header: 'checksum', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'Version', header: 'version', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'Description', header: 'description', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'Script', header: 'script', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'State', header: 'state', headerClass: 'centerAlignment', class: 'centerAlignment'},
    {field: 'Installed', header: 'installedOn', headerClass: 'centerAlignment', class: 'centerAlignment'}
  ]
};
