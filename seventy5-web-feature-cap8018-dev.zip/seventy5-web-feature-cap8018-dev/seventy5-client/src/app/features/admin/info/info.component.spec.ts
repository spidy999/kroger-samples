import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {InformationComponent} from '@features/admin/info/info.component';
import {UtilService} from '@shared/services/util/util.service';
import {LoggersService} from '@features/admin/loggers/loggers.service';
import {AppInformationService} from '@features/admin/info/info.service';
import {BaleSensorService} from '@features/admin/services/sensors/bale-sensor.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

describe('InformationComponent', () => {
  let component: InformationComponent;
  let fixture: ComponentFixture<InformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        InformationComponent
      ],
      providers: [
        UtilService,
        LoggersService,
        BaleSensorService,
        NotificationsService,
        AppInformationService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InformationComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
