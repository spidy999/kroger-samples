export class ActuatorFlyway {
  public migrations: FlywayMigration[];
}

export class FlywayMigration {
  public type: string;
  public checksum: number;
  public version: string;
  public description: string;
  public script: string;
  public state: string;
  public installedOn: Date;
  public executionTime: number;
}
