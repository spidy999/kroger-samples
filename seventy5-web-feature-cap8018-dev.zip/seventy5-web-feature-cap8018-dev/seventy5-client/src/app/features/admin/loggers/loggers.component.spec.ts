import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LoggersComponent} from '@features/admin/loggers/loggers.component';
import {LoggersService} from '@features/admin/loggers/loggers.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

describe('LoggersComponent', () => {
  let component: LoggersComponent;
  let fixture: ComponentFixture<LoggersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        LoggersComponent
      ],
      providers: [
        LoggersService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoggersComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
