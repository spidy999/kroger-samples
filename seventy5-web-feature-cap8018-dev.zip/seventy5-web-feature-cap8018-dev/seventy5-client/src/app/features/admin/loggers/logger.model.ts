export class Logger {
  public name: string;
  public configuredLevel: string;
  public effectiveLevel: string;
}
