import {Component, OnInit} from '@angular/core';
import {MenuItem, SelectItem} from 'primeng/api';
import {Menu, OverlayPanel} from 'primeng/primeng';
import {ToastDetails} from '@shared/models/Notification';
import {Logger} from '@features/admin/loggers/logger.model';
import {LoggersService} from '@features/admin/loggers/loggers.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

@Component({
  selector: 'app-loggers-manager',
  templateUrl: './loggers.component.html',
  styleUrls: ['./loggers.component.less']
})
export class LoggersComponent implements OnInit {

  public serverInfo: any;
  public loggerList: any[];
  public selectedLogger: any;
  public innerSpinner: boolean;
  public menuItems: MenuItem[];
  public loggerLevels: SelectItem[];

  constructor(private loggersService: LoggersService,
              private notificationService: NotificationsService) {
  }

  private static isProtectedLogger(logger) {
    const protectedLoggers = ['ROOT', 'com', 'org', 'com.kroger'];
    if (protectedLoggers.includes(logger.name)) {
      return true;
    }
    return !logger.name.startsWith('com.kroger.seventy5');
  }

  ngOnInit(): void {
    this.innerSpinner = true;
    this.loadServerInfo();
    this.loadLoggerList(false);
  }

  public loggerActionToggle(event, logger , menuItem: Menu ) {
    this.menuItems = this.getActionsMenu(logger);
    menuItem.toggle(event);
  }

  public getActionsMenu(logger: any): MenuItem[] {
    const menu = {label: 'Actions', items: []};

    if (logger) {
      this.loggerLevels.forEach((loggerLevel) => {
        if (logger.configuredLevel !== loggerLevel.value &&
             !(loggerLevel.value === '' && logger.configuredLevel === null)) {
          menu.items.push({
            label: loggerLevel.label,
            value: loggerLevel.value,
            command: () => this.setLevel(logger, loggerLevel.value)
          });
        }
      });
    }
    return [ menu ];
  }

  private setLevel(logger, level) {
    let toastDetails: ToastDetails = {};
    if (LoggersComponent.isProtectedLogger(logger)) {
      const message = 'This logger has been flagged as protected.  ' +
      'Are you sure you want to change it\'s level?' +
      ' (Click the help icon for more information.)';
      if (!confirm(message)) {
        return;
      }
    }

    this.loggersService.setLevel(logger.name, level).subscribe(() => {
      this.loadLoggerList(true);
      toastDetails = {
        title: 'Success',
        message: 'Logger level set.',
        toastType: 'success'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

  public loadLoggerList(showSuccess) {
    let toastDetails: ToastDetails = {};
    this.loggersService.list().subscribe(res => {
      this.loggerLevels = [{ 'label': '<none>', 'value': '' }];
      res.levels.forEach((level) => {
        const selectItem = { 'label': level, 'value': level };
        this.loggerLevels.push(selectItem);
      });

      const loggers = res.loggers;
      const loggerNames = Object.getOwnPropertyNames(loggers);

      this.loggerList = [];
      loggerNames.forEach((loggerName => {
        const aLogger = new Logger();
        aLogger.name = loggerName;
        aLogger.configuredLevel = loggers[loggerName].configuredLevel;
        aLogger.effectiveLevel = loggers[loggerName].effectiveLevel;
        this.loggerList.push(aLogger);
      }));

      if (showSuccess) {
        toastDetails = {
          title: 'Success',
          message: 'Logger list loaded.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }
      this.innerSpinner = false;
    }, () => {
      toastDetails = {
        title: 'Failure',
        message: 'Error in loading Logger List.',
        toastType: 'error'
      };
      this.notificationService.emitMessage.next(toastDetails);
      this.innerSpinner = false;
    });
  }

  private loadServerInfo() {
    this.loggersService.serverInfo().subscribe(res => {
      this.serverInfo = res;
    });
  }

  public showDetails(event, logger: any, overlaypanel: OverlayPanel) {
    this.selectedLogger = logger;
    overlaypanel.toggle(event);
  }

}
