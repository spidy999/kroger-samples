import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class LoggersService {

  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<any>('/api/loggers/');
  }

  setLevel(loggerName, level) {
    return this.http.post<any>('/api/loggers/level/' + loggerName, level);
  }

  serverInfo() {
    return this.http.get<any>('/api/loggers/server');
  }

}
