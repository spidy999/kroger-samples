import {OverlayPanel} from 'primeng/primeng';
import {ToastDetails} from '@shared/models/Notification';
import {Component, OnInit, ViewChild} from '@angular/core';
import {FacilityData} from '@app/shared/domain/facilityData';
import {FacilityService} from '@shared/services/facility/facility.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {FacilityEditDialogComponent} from '@features/admin/facility/edit/facility-edit-dialog.component';

const TIMEOUT = 900;
const MIN_BALES = 42;
const MAX_BALES = 48;
const PRINTER_COPIES = 3;

@Component({
  selector: 'app-facility',
  templateUrl: './facility.component.html',
  styleUrls: ['./facility.component.less']
})
export class FacilityComponent implements OnInit {

  @ViewChild(FacilityEditDialogComponent, {static: false}) editDialog: FacilityEditDialogComponent;
  public facilityFlag: boolean;
  public innerSpinner: boolean;
  public facilities: FacilityData[];
  public selectedFacility: FacilityData;
  public currentFacility: FacilityData;

  constructor(public facilityService: FacilityService,
              public notificationService: NotificationsService) {}

  ngOnInit() {
    this.facilityFlag = false;
    this.innerSpinner = true;
    this.runSearch();
  }


  runSearch() {
    this.facilityService.getAllFacilities().subscribe(res => {
      this.facilities = res.map(resFacility => {
        const facility = new FacilityData();
        facility.facilityId = resFacility.facilityId;
        facility.facilityName = resFacility.facilityName;
        facility.streetAddress = resFacility.streetAddress;
        facility.city = resFacility.city;
        facility.stateCode = resFacility.stateCode;
        facility.zipCode = resFacility.zipCode;
        facility.printerCopies = resFacility.printerCopies;
        facility.minimumBales = resFacility.minimumBales;
        facility.maximumBales = resFacility.maximumBales;
        facility.balePrefix = resFacility.balePrefix;
        facility.salvageTracking = resFacility.salvageTracking;
        facility.sessionTimeout = resFacility.sessionTimeout;
        facility.timeZone = resFacility.timeZone;
        return facility;
      });
      this.innerSpinner = false;
    });

  }

  private sortList() {
    this.facilities = this.facilities.sort((a, b) => (a.facilityId > b.facilityId) ? 1 : -1);
  }

  public showDetails(event, facility: FacilityData, overlaypanel: OverlayPanel) {
    this.selectedFacility = facility;
    overlaypanel.toggle(event);
  }

  public openEditDialog(facility: FacilityData) {
    this.editDialog.showEditDialog(facility);
  }

  public onEditDialogSaved(facility: FacilityData) {
    const itemIndex = this.facilities.findIndex(afacility => afacility.facilityId === facility.facilityId);
    if (itemIndex >= 0) {
      this.facilities[itemIndex] = facility;
    } else {
      this.facilities.push(facility);
    }
    this.sortList();
  }

  public addNew() {
    const facilityData = new FacilityData();
    facilityData.printerCopies = PRINTER_COPIES;
    facilityData.minimumBales = MIN_BALES;
    facilityData.maximumBales = MAX_BALES;
    facilityData.sessionTimeout = TIMEOUT;
    facilityData.salvageTracking = true;
    facilityData.timeZone = 'America/New_York';
    this.editDialog.showAddDialog(facilityData);
  }

  deleteFacility(facility: FacilityData) {
    this.currentFacility = facility;
    this.facilityFlag = true;
  }

  public doDeleteFacility(flag: boolean) {
    let toastDetails: ToastDetails;
    if (flag) {
      this.facilityService.deleteFacilityData(this.currentFacility.facilityId).subscribe(() => {
        const itemIndex = this.facilities.findIndex(afacility => afacility.facilityId === this.currentFacility.facilityId);
        if (itemIndex >= 0) {
          this.facilities.splice(itemIndex, 1);
        }
        this.sortList();
        toastDetails = {
          title: 'Success',
          message: 'Record Deleted.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record Not Deleted.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.facilityFlag = false;
  }
}
