import {SelectItem} from 'primeng/api';
import {ToastDetails} from '@shared/models/Notification';
import {FacilityData} from '@app/shared/domain/facilityData';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {OptionData as constant} from '@features/admin/models/adminData';
import {UtilService} from '@shared/services/util/util.service';
import {TimezoneService} from '@shared/services/timezone/timezone.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

const CITY_LENGTH = 35;
const ZIP_CODE_LENGTH = 10;
const STATE_CODE_LENGTH = 2;
const STREET_ADDRESS_LENGTH = 35;

@Component({
  selector: 'app-facility-edit-dialog',
  templateUrl: './facility-edit-dialog.component.html',
  styleUrls: ['./facility-edit-dialog.component.less']
})
export class FacilityEditDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<FacilityData>();
  public doingAddNew = false;
  public showDialogFlag = false;
  public timeZones: SelectItem[];
  public yesNoOptions: SelectItem[] = [];
  public editFacilityFormGroup: FormGroup;

  constructor(public utilService: UtilService,
              public facilityService: FacilityService,
              private timezoneService: TimezoneService,
              public notificationService: NotificationsService) {
    const { yesNoOptions } = constant;
    this.yesNoOptions = yesNoOptions;
  }

  ngOnInit(): void {
    this.createFormGroup();
    this.getJavaTimezones();
  }

  private createFormGroup() {
    this.editFacilityFormGroup = new FormGroup({
      facilityId: new FormControl(null),
      facilityName: new FormControl(null, Validators.required),
      streetAddress: new FormControl(null, Validators.maxLength(STREET_ADDRESS_LENGTH)),
      city: new FormControl(null, Validators.maxLength(CITY_LENGTH)),
      stateCode: new FormControl(null, [Validators.pattern(/^[a-zA-Z]+$/),
        Validators.maxLength(STATE_CODE_LENGTH)]),
      zipCode: new FormControl(null, Validators.maxLength(ZIP_CODE_LENGTH)),
      vendorId: new FormControl(),
      salvageTracking: new FormControl(null, Validators.required),
      printerCopies: new FormControl(),
      minimumBales: new FormControl(),
      maximumBales: new FormControl(),
      balePrefix: new FormControl(),
      sessionTimeout: new FormControl(),
      timeZone: new FormControl()
    });
  }

  private setFacilityData(facilityData: FacilityData) {
    const controls = this.editFacilityFormGroup.controls;

    controls.facilityId.setValue(facilityData.facilityId);
    controls.facilityName.setValue(facilityData.facilityName);
    controls.streetAddress.setValue(facilityData.streetAddress);
    controls.city.setValue(facilityData.city);
    controls.stateCode.setValue(facilityData.stateCode);
    controls.zipCode.setValue(facilityData.zipCode);
    controls.vendorId.setValue(facilityData.vendorId);
    controls.salvageTracking.setValue(facilityData.salvageTracking);
    controls.printerCopies.setValue(facilityData.printerCopies);
    controls.minimumBales.setValue(facilityData.minimumBales);
    controls.maximumBales.setValue(facilityData.maximumBales);
    controls.balePrefix.setValue(facilityData.balePrefix);
    controls.sessionTimeout.setValue(facilityData.sessionTimeout);
    controls.timeZone.setValue(facilityData.timeZone);
  }

  private getFacilityData(): FacilityData {
    const controls = this.editFacilityFormGroup.controls;
     return {
      facilityId: controls.facilityId.value,
      facilityDesc: controls.facilityName.value,
      vendorId: controls.vendorId.value,
      salvageTracking: controls.salvageTracking.value,
      facilityName: controls.facilityName.value,
      streetAddress: controls.streetAddress.value,
      city: controls.city.value,
      stateCode: controls.stateCode.value,
      zipCode: controls.zipCode.value,
      printerCopies: controls.printerCopies.value,
      minimumBales: controls.minimumBales.value,
      maximumBales: controls.maximumBales.value,
      balePrefix:  controls.balePrefix.value,
      sessionTimeout: controls.sessionTimeout.value,
      timeZone: controls.timeZone.value,
    };
  }

  public showEditDialog(facilityData: FacilityData) {
    this.setFacilityData(facilityData);
    this.doingAddNew = false;
    this.editFacilityFormGroup.controls.facilityId.disable();
    this.showDialogFlag = true;
  }

  public showAddDialog(facilityData: FacilityData) {
    this.setFacilityData(facilityData);
    this.doingAddNew = true;
    this.editFacilityFormGroup.controls.facilityId.enable();
    this.showDialogFlag = true;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails;
    event.preventDefault();
    const facilityData = this.getFacilityData();
    if (flag) {
      if (this.doingAddNew) {
        this.facilityService.addFacilityData(facilityData).subscribe(res => {
          this.setFacilityData(res);
          this.saved.emit(this.getFacilityData());
          toastDetails = {
            title: 'Success',
            message: 'Record Created.',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
            toastDetails = {
              title: 'Failure',
              message: 'Record Not Created.',
              toastType: 'error'
            };
            this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.facilityService.saveFacilityData(facilityData).subscribe(res => {
          this.setFacilityData(res);
          this.saved.emit(this.getFacilityData());
          toastDetails = {
            title: 'Success',
            message: 'Record Saved.',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record Not Saved.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.editFacilityFormGroup.reset();
    this.editFacilityFormGroup.markAsPristine();
    this.showDialogFlag = false;
  }

  private getJavaTimezones() {
    this.timezoneService.getTimeZones().subscribe(res => {
      this.timeZones = res;
    });
  }

  public checkInputKey(event) {
    return UtilService.checkKey(event);
  }

}
