import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {UtilService} from '@shared/services/util/util.service';
import {TimezoneService} from '@shared/services/timezone/timezone.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {FacilityEditDialogComponent} from '@features/admin/facility/edit/facility-edit-dialog.component';

describe('FacilityEditDialogComponent', () => {
  let component: FacilityEditDialogComponent;
  let fixture: ComponentFixture<FacilityEditDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        FacilityEditDialogComponent
      ],
      providers: [
        UtilService,
        FacilityService,
        TimezoneService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilityEditDialogComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });

});


