import { NgModule } from '@angular/core';
import {AuthGuard} from '@app/auth-guard';
import {Permission} from '@shared/models/permissions';
import { Routes, RouterModule } from '@angular/router';
import {AdminComponent} from '@features/admin/admin.component';

const adminRoutes: Routes = [
  {
    path: '',
    component: AdminComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.ADMINISTRATION.toString()
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
