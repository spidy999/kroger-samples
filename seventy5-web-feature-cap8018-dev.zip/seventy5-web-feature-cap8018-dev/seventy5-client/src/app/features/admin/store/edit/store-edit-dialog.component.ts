import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {SelectItem} from 'primeng/api';
import {Store} from '@shared/domain/store';
import {ToastDetails} from '@shared/models/Notification';
import {OptionData as constant} from '@features/admin/models/adminData';
import {UtilService} from '@shared/services/util/util.service';
import {StoreService} from '@shared/services/store/store.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

const MIN_BALE_COUNT = 0;
const MAX_BALE_COUNT = 48;

@Component({
  selector: 'app-store-edit-dialog',
  templateUrl: './store-edit-dialog.component.html',
  styleUrls: ['./store-edit-dialog.component.less']
})
export class StoreEditDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<Store>();
  public doingAddNew = false;
  public showDialogFlag = false;
  public yesNoOptions: SelectItem[] = [];
  public editStoreFormGroup: FormGroup;

  constructor(private util: UtilService,
              private storeService: StoreService,
              private notificationService: NotificationsService) {
    const { yesNoOptions } = constant;
    this.yesNoOptions = yesNoOptions;
  }

  ngOnInit(): void {
    this.createFormGroup();
    const controls = this.editStoreFormGroup.controls;
    controls.active.setValue(true);
  }

  private createFormGroup() {
    this.editStoreFormGroup = new FormGroup({
      division: new FormControl(null, [Validators.required, Validators.maxLength(3), Validators.minLength(3)]),
      facility: new FormControl(null, [Validators.required, Validators.maxLength(5), Validators.minLength(5)]),
      active: new FormControl(null, Validators.required),
      district: new FormControl(null, [Validators.required, Validators.maxLength(2), Validators.minLength(2)]),
      zipCode: new FormControl( null, Validators.required),
      openDate: new FormControl( null, null),
      closeDate: new FormControl( null, null),
      lastUpdatedDateTime: new FormControl(),
      identifier: new FormControl(),
      balerCount: new FormControl(null, [Validators.required, Validators.min(MIN_BALE_COUNT), Validators.max(MAX_BALE_COUNT)])
    });
  }

  private setStore(store: Store) {
    const controls = this.editStoreFormGroup.controls;

    controls.division.setValue(store.division);
    controls.facility.setValue(store.facility);
    controls.active.setValue(store.active);
    controls.district.setValue(store.district);
    controls.zipCode.setValue(store.zipCode);
    controls.openDate.setValue((store.openDate) ? new Date(store.openDate) : null);
    controls.closeDate.setValue((store.closeDate) ? new Date(store.closeDate) : null);
    controls.lastUpdatedDateTime.setValue((store.lastUpdatedDateTime) ? new Date(store.lastUpdatedDateTime) : null);
    controls.identifier.setValue(store.identifier);
    controls.balerCount.setValue(store.balerCount);
  }

  private getStore(): Store {
    const controls = this.editStoreFormGroup.controls;
    return  {
      'division': controls.division.value
      , 'facility': controls.facility.value
      , 'active': controls.active.value
      , 'zipCode': controls.zipCode.value
      , 'district': controls.district.value
      , 'openDate': controls.openDate.value
      , 'closeDate': controls.closeDate.value
      , 'lastUpdatedDateTime': controls.lastUpdatedDateTime.value
      , 'identifier': controls.identifier.value
      , 'balerCount': controls.balerCount.value
    };
  }

  public showEditDialog(store: Store) {
    this.setStore(store);
    this.doingAddNew = false;
    this.editStoreFormGroup.controls.division.disable();
    this.editStoreFormGroup.controls.facility.disable();
    this.editStoreFormGroup.controls.identifier.disable();
    this.editStoreFormGroup.controls.district.disable();
    this.editStoreFormGroup.controls.zipCode.disable();
    this.editStoreFormGroup.controls.openDate.disable();
    this.editStoreFormGroup.controls.closeDate.enable();
    this.editStoreFormGroup.controls.active.enable();

    this.showDialogFlag = true;
  }

  public showAddDialog(store: Store) {
    this.setStore(store);
    this.doingAddNew = true;
    this.editStoreFormGroup.controls.division.enable();
    this.editStoreFormGroup.controls.facility.enable();
    this.showDialogFlag = true;
  }

  public saveChanges(flag: boolean, event) {
    let toastDetails: ToastDetails = {};
    event.preventDefault();
    const store = this.getStore();
    if (flag) {
      if (this.doingAddNew) {
        this.storeService.addStore(store).subscribe(res => {
          this.setStore(res);
          this.saved.emit(this.getStore());
          toastDetails = {
            title: 'Success',
            message: 'Record created',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not created',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      } else {
        this.storeService.saveStore(store).subscribe(res => {
          this.setStore(res);
          this.saved.emit(this.getStore());
          toastDetails = {
            title: 'Success',
            message: 'Record saved',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Record not saved',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
    this.editStoreFormGroup.markAsPristine();
    this.showDialogFlag = false;
  }

  // To disable unwanted keys
  public checkInputKey(event) {
    return UtilService.checkKey(event);
  }
}
