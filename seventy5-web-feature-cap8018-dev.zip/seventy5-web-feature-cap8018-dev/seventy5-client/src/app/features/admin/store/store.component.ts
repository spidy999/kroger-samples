import {MenuItem} from 'primeng/api';
import {Store} from '@shared/domain/store';
import {Division} from '@shared/domain/division';
import {BooleanPipe} from '@shared/filters/boolean.pipe';
import {ToastDetails} from '@shared/models/Notification';
import {Component, OnInit, ViewChild} from '@angular/core';
import {Menu, OverlayPanel, SelectItem} from 'primeng/primeng';
import {OptionData as constant} from '@features/admin/models/adminData';
import {StoreService} from '@shared/services/store/store.service';
import {DivisionService} from '@shared/services/division/division.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {StoreEditDialogComponent} from '@features/admin/store/edit/store-edit-dialog.component';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.less']
})
export class StoreComponent implements OnInit {

  @ViewChild(StoreEditDialogComponent, {static: false}) editDialog: StoreEditDialogComponent;
  public currentFilters: any;
  public storeObj: Store;
  public storeFlag: boolean;
  public innerSpinner: boolean;
  public stores: Store[];
  public selectedStore: Store;
  public menuItems: MenuItem[];
  public filteredStores: Store[];
  public divisionItems: Division[];
  public yesNoOptions: SelectItem[];
  public selectedDivision: Division;

  constructor(private storeService: StoreService,
              private divisionService: DivisionService,
              private notificationService: NotificationsService) {
    const { yesNoOptions } = constant;
    this.yesNoOptions = yesNoOptions;
  }

  ngOnInit() {
    this.storeFlag = false;
    this.loadDivisions();
  }

  private loadDivisions() {
    this.divisionService.getAllDivisions().subscribe(res => {
      this.divisionItems = res;
    });
  }

  public runSearch() {
    this.innerSpinner = true;
    if (this.selectedDivision) {
      this.storeService.getAllStoresForDivision(this.selectedDivision.divisionNumber).subscribe(res => {
        this.stores = [];
        res.forEach(resStore => {
          const store = new Store();
          store.active = resStore.active;
          store.activeDc = resStore.activeDc;
          store.facility = resStore.facility;
          store.district = resStore.district;
          store.division = resStore.division;
          store.identifier = resStore.identifier;
          store.zipCode = resStore.zipCode;
          store.balerCount = (resStore.balerCount);
          store.lastUpdatedDateTime = (resStore.lastUpdatedDateTime) ? new Date(resStore.lastUpdatedDateTime) : null;
          store.openDate = (resStore.openDate) ? new Date(resStore.openDate) : null;
          store.closeDate = (resStore.closeDate) ? new Date(resStore.closeDate) : null;

          this.stores.push(store);
        });
        this.sortList();
        this.filteredStores = this.stores;
        this.innerSpinner = false;
      }, () => {
        this.innerSpinner = false;
      });
    }
  }

  public globalActionToggleMenu(event,  menuItem: Menu) {
    this.menuItems = this.getGlobalActionsMenu();
    menuItem.toggle(event);
  }

  public getGlobalActionsMenu(): MenuItem[] {
    return [
      {
        label: 'Actions',
        items: [
          {label: 'Active DC: Yes', icon: 'fa fa-toggle-on', command: () => this.setActiveDc(true)},
          {label: 'Active DC: No', icon: 'fa fa-toggle-off', command: () => this.setActiveDc(false)}
        ]
      }
    ];
  }

  private sortList() {
    this.stores = this.stores.sort((a, b) => (a.facility > b.facility) ? 1 : -1);
  }

  public showDetails(event, store: Store, overlaypanel: OverlayPanel) {
    this.selectedStore = store;
    overlaypanel.toggle(event);
  }

  public openEditDialog(store: Store) {
    this.editDialog.showEditDialog(store);
  }

  public onEditDialogSaved(store: Store) {
    const itemIndex = this.stores.findIndex(aStore => aStore.facility === store.facility && aStore.division === store.division );
    if (itemIndex >= 0) {
      this.stores[itemIndex] = store;
    } else {
      this.stores.push(store);
    }
    this.sortList();
  }

  public deleteStore(store: Store) {
    this.storeFlag = true;
    this.storeObj = store;
  }

  public deleteSelectedStore(flag: boolean) {
    let toastDetails: ToastDetails = {};
    if (flag) {
      this.storeService.deleteStore(this.storeObj.division, this.storeObj.facility).subscribe(() => {
        const itemIndex = this.stores.findIndex(aStore =>
          aStore.facility === this.storeObj.facility && aStore.division === this.storeObj.division);
        if (itemIndex >= 0) {
          this.stores.splice(itemIndex, 1);
        }
        this.sortList();
        toastDetails = {
          title: 'Success',
          message: 'Record deleted',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Record not deleted',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.storeFlag = false;
  }


  private setActiveDc(isActive) {
    const booleanPipe = new BooleanPipe();

    if (this.filteredStores.length <= 0) {
      alert('No stores have been selected. Adjust the filters and try again.');

    } else {

      let confirmationMessage =
         `This will set the Active DC flag to '${booleanPipe.transform(isActive, 'YES_NO')}'` +
         ` for the stores in division '${this.selectedDivision.divisionDesc}'.`;

      if (this.currentFilters && Object.keys(this.currentFilters).length > 0) {
        confirmationMessage += '\nSince you have filtered the list, only the selected stores will be included.';
      }

      confirmationMessage += '\n\nContinue setting the flag?';

      if (confirm(confirmationMessage)) {
        let toastDetails: ToastDetails = {};
        this.storeService.setActiveDcFlag(this.filteredStores, isActive).subscribe(() => {
          this.runSearch();
          toastDetails = {
            title: 'Success',
            message: 'Active DC flag was set.',
            toastType: 'success'
          };
          this.notificationService.emitMessage.next(toastDetails);
        }, () => {
          toastDetails = {
            title: 'Failure',
            message: 'Active DC flag was not set.',
            toastType: 'error'
          };
          this.notificationService.emitMessage.next(toastDetails);
        });
      }
    }
  }

  public onTtFilter(event) {
    this.filteredStores = event.filteredValue;
    this.currentFilters = event.filters;
  }
}
