import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {StoreEditDialogComponent} from '@features/admin/store/edit/store-edit-dialog.component';
import {StoreService} from '@shared/services/store/store.service';
import {UtilService} from '@shared/services/util/util.service';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

describe('StoreEditDialogComponent', () => {
  let component: StoreEditDialogComponent;
  let fixture: ComponentFixture<StoreEditDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        StoreEditDialogComponent
      ],
      providers: [
        UtilService,
        StoreService,
        NotificationsService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreEditDialogComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
