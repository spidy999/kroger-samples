import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HTTP_STATUS } from '@shared/models/shared';

@Component({
  selector: 'app-error-messages',
  templateUrl: './error-messages.component.html',
  styleUrls: ['./error-messages.component.less']
})
export class ErrorMessagesComponent implements OnInit {
  statuses = [
    HTTP_STATUS.SUCCESS,
    HTTP_STATUS.NOT_FOUND,
    HTTP_STATUS.UNAUTHORIZED,
    HTTP_STATUS.SERVER_ERROR,
    HTTP_STATUS.SERVICE_UNAVAILABLE,
    HTTP_STATUS.BAD_REQUEST,
    HTTP_STATUS.GATEWAY_TIMEOUT
  ];

  isPending = false;

  constructor(private http: HttpClient) { }

  ngOnInit() {}

  public getRequest(url) {
    this.isPending = true;
    this.http.get(url).subscribe(() => {
      this.isPending = false;
    }, () => {
      this.isPending = false;
    });
  }

}
