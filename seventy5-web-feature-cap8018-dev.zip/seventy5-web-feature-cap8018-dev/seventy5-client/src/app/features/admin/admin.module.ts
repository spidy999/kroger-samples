import {CommonModule} from '@angular/common';
import {BooleanPipe} from '@shared/filters/boolean.pipe';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {ReportsModule} from '@shared/reports/reports.module';
import {TemplateModule} from '@app/templates/template.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { GlobalInterceptorModule } from '@app/httpInterceptor.module';
import {AdminRoutingModule} from '@features/admin/admin-routing.module';
import {AdminComponent} from '@features/admin/admin.component';
import {StoreComponent} from '@features/admin/store/store.component';
import {CacheComponent} from '@features/admin/cache/cache.component';
import {QuartzComponent} from '@features/admin/quartz/quartz.component';
import {InformationComponent} from '@features/admin/info/info.component';
import {LoggersComponent} from '@features/admin/loggers/loggers.component';
import {DivisionComponent} from '@features/admin/division/division.component';
import {FacilityComponent} from '@features/admin/facility/facility.component';
import {AuditLogComponent} from '@features/admin/auditlog/audit-log.component';
import { ErrorMessagesComponent } from './error-messages/error-messages.component';
import {StoreEditDialogComponent} from '@features/admin/store/edit/store-edit-dialog.component';
import {FacilityEditDialogComponent} from '@features/admin/facility/edit/facility-edit-dialog.component';
import {DivisionEditDialogComponent} from '@features/admin/division/edit/division-edit-dialog.component';
import {QuartzService} from '@features/admin/quartz/quartz.service';
import {LoggersService} from '@features/admin/loggers/loggers.service';
import {AppInformationService} from '@features/admin/info/info.service';
import {CacheService} from '@features/admin/services/cache/cache.service';
import {DivisionService} from '@shared/services/division/division.service';
import {AuditLogService} from '@features/admin/services/auditlog/audit-log.service';
import {BaleSensorService} from '@features/admin/services/sensors/bale-sensor.service';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    PrimengModule,
    ReportsModule,
    CalendarModule,
    TemplateModule,
    ReactiveFormsModule,
    KdsStencilAccessorsModule,
    AdminRoutingModule,
  ],
  declarations: [
    BooleanPipe,
    AdminComponent,
    CacheComponent,
    StoreComponent,
    QuartzComponent,
    LoggersComponent,
    DivisionComponent,
    AuditLogComponent,
    FacilityComponent,
    InformationComponent,
    ErrorMessagesComponent,
    StoreEditDialogComponent,
    DivisionEditDialogComponent,
    FacilityEditDialogComponent
  ],
  providers: [
    CacheService,
    QuartzService,
    LoggersService,
    DivisionService,
    AuditLogService,
    BaleSensorService,
    AppInformationService,
    GlobalInterceptorModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AdminModule { }
