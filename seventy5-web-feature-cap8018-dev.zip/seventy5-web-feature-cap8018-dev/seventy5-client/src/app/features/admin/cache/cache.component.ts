import {ToastDetails} from '@shared/models/Notification';
import {Accordion, MenuItem, OverlayPanel} from 'primeng';
import {Component, OnInit, ViewChild} from '@angular/core';
import { CacheStatisticsModel } from '../models/domain/cacheStatisticModel';
import {CacheService} from '@features/admin/services/cache/cache.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';

@Component({
  selector: 'app-cache-manager',
  templateUrl: './cache.component.html',
  styleUrls: ['./cache.component.less']
})
export class CacheComponent implements OnInit {

  @ViewChild('mainAccordion', {static: false}) mainAccordion: Accordion;
  public cacheName: string;
  public selectedCache: any;
  public clearFlag: boolean;
  public clearAllFlag: boolean;
  public innerSpinner: boolean;
  public loggingEnabled: boolean;
  public menuItems: MenuItem[];
  public cacheList: CacheStatisticsModel[];

  constructor(private cacheService: CacheService,
              private notificationService: NotificationsService) {}

  ngOnInit(): void {
    this.clearFlag = false;
    this.innerSpinner = true;
    this.clearAllFlag = false;
    this.loadCacheList(false);
    this.getLoggingStatus();
  }

  public loadCacheList(showSuccess) {
    let toastDetails: ToastDetails = {};
    this.cacheService.list().subscribe(res => {
      this.cacheList = res;
      if (showSuccess) {
        toastDetails = {
          title: 'Success',
          message: 'Cache list loaded.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }
      this.innerSpinner = false;
    }, () => {
      toastDetails = {
        title: 'Failure',
        message: 'Error in loaded Cache list.',
        toastType: 'error'
      };
      this.innerSpinner = false;
      this.notificationService.emitMessage.next(toastDetails);
    });
  }

  private loadCache(cacheName) {
    this.cacheService.loadCache(cacheName).subscribe(res => {
      const itemIndex = this.cacheList.findIndex(cache => cache.name === cacheName);
      this.cacheList[itemIndex] = res;
    });
  }

  public showDetails(event, cache: any, overlaypanel: OverlayPanel) {
    this.selectedCache = cache;
    overlaypanel.toggle(event);
  }

  public clearAllCaches() {
    this.clearAllFlag = true;
  }

  public clearCache(cache) {
    console.log(cache);
    this.cacheName = cache.name;
    this.clearFlag = true;
  }

  public doClearCache(cache: boolean) {
    if (cache) {
      this.cacheService.clear(this.cacheName).subscribe(() => {
        this.loadCache(this.cacheName);
      });
    }
    this.clearFlag = false;
  }

  public doClearAllCache(cache: boolean) {
    if (cache) {
      this.cacheService.clearAll().subscribe(() => {
        this.loadCacheList(true);
      });
    }
    this.clearAllFlag = false;
  }

  private getLoggingStatus() {
    this.cacheService.isLoggingEnabled().subscribe(res => {
      this.loggingEnabled = res;
    });
  }

  public setLogging(enabledFlag) {
    this.cacheService.setLogging(enabledFlag).subscribe(() => {
      this.getLoggingStatus();
    });
  }
}
