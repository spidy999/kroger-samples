export class EquipmentSearch {
  startDate: Date;
  endDate: Date;
  facilityId: string;
  equipmentType: string;
}
