export class CacheStatisticsModel {
    name: string;
    statistics: any;
}
