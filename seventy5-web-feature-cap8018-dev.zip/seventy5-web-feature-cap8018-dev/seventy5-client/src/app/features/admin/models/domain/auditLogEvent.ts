export class AuditLogEvent {
  auditLogEventId: number;
  logName: any;
  level: any;
  category: any;
  source: any;
  sourceEvent: any;
  description: string;
  insertedDate: string;
  createdByEuid: string;
}
