export class BaleSensor {
  public divisionNo: string;
  public storeNo: string;
  public sensorId: string;
  public sensorEventStartTs: string;
  public index: string;
  public baleScanned: string;
  public createdDate: string;
}
