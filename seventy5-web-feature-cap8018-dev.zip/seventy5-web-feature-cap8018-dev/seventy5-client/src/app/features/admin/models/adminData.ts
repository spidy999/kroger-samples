
export enum AdminTab {
  HOME = 'HOME',
  AUDIT_LOG = 'AUDIT_LOG',
  DC_FACILITIES = 'DC_FACILITIES',
  DIVISIONS = 'DIVISIONS',
  STORES = 'STORES',
  QUARTZ_MANAGER = 'QUARTZ_MANAGER',
  CACHE_MANAGER = 'CACHE_MANAGER',
  LOGGERS = 'LOGGERS',
  ERROR_MESSAGES = 'ERROR_MESSAGES'
}

export const AdminTabs = {
  supportUserTabs: [
    {label: 'Home', value: AdminTab.HOME },
    {label: 'Audit Log', value: AdminTab.AUDIT_LOG },
    {label: 'DC Facilities', value: AdminTab.DC_FACILITIES },
    {label: 'Divisions', value: AdminTab.DIVISIONS },
    {label: 'Stores', value: AdminTab.STORES },
    {label: 'Quartz Manager', value: AdminTab.QUARTZ_MANAGER },
    {label: 'Cache Manager', value: AdminTab.CACHE_MANAGER },
    {label: 'Loggers', value: AdminTab.LOGGERS },
    {label: 'Error Messages', value: AdminTab.ERROR_MESSAGES },
  ],
};

export const OptionData = {

 yesNoOptions: [
    {label: 'Yes', value: true},
    {label:  'No', value: false}
  ]
};
