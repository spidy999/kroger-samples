export class AuditLogEventSearch {
  public logNames: any[];
  public levels: any[];
  public categories: any[];
  public sources: any[];
  public sourceEvents: any[];
  public description: string;
  public euids: string[];
  public startDate: any;
  public endDate: any;
}
