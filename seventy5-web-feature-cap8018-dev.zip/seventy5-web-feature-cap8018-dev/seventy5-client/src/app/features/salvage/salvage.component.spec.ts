import { MessageService } from 'primeng/api';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CalendarModule} from '@shared/calendar/calendar.module';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {UserService} from '@shared/services/user/user.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';
import {SalvageComponent} from './salvage.component';
import {CloseSalvageComponent} from './close-salvage/close-salvage.component';
import {CreateSalvageComponent} from './create-salvage/create-salvage.component';
import {SearchSalvageComponent} from './search-salvage/search-salvage.component';
import {InProgressSalvageComponent} from '@features/salvage/in-progress-salvage/in-progress-salvage.component';

describe('SalvageComponent', () => {
  let component: SalvageComponent;
  let userService: UserService;
  let modalService: ModalService;
  let facilityService: FacilityService;
  let printSalvageService: PrintSalvageService;
  let fixture: ComponentFixture<SalvageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule
      ],
      declarations: [
        SalvageComponent,
        CloseSalvageComponent,
        SearchSalvageComponent,
        CreateSalvageComponent,
        InProgressSalvageComponent
      ],
      providers: [
        UserService,
        ModalService,
        MessageService,
        FacilityService,
        PrintSalvageService,
        CreateSalvageService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalvageComponent);
    userService = TestBed.inject(UserService);
    modalService = TestBed.inject(ModalService);
    facilityService = TestBed.inject(FacilityService);
    printSalvageService = TestBed.inject(PrintSalvageService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
