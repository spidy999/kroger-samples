import {SelectItem} from 'primeng/api';
import { FormGroup } from '@angular/forms';
import { ReceiptData} from '../models/salvage';
import {FacilityData} from '@shared/domain/facilityData';
import {Component, Input, OnInit, ViewChild} from '@angular/core';
import { UserService } from '@shared/services/user/user.service';
import { UtilService } from '@shared/services/util/util.service';
import { DateService } from '@shared/services/date/date.service';
import { ModalService } from '@shared/services/modal/modal.service';
import {SalvageService} from '@features/salvage/services/salvage.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import { CreateSalvageService } from '@features/salvage/services/create-salvage/create-salvage.service';
import {PrintDialogComponent} from '@features/salvage/dialogs/print-dialog/print-dialog.component';

const RNS = 'RN';
const OTHERS = 'O';
const BALED_PLASTIC = 'BP';
const LOOSE_PLASTIC = 'LP';
const BALED_CARDBOARD = 'BC';
const LOOSE_CARDBOARD = 'LC';
const DONATIONS_RECLAIM = 'DC';

@Component({
  selector: 'app-create-salvage',
  templateUrl: './create-salvage.component.html',
  styleUrls: ['./create-salvage.component.less']
})

export class CreateSalvageComponent implements OnInit {

  @ViewChild(PrintDialogComponent, {static: false}) printDialog: PrintDialogComponent;
  @Input() facilityData: FacilityData[];
  @Input() facilityItems: SelectItem[];

  private bolId: number;
  public salvageQty: number;
  public facilityId: number;
  public submitPrintData: ReceiptData;
  public confirmationMsg: boolean;
  public salvageForm: FormGroup = null;
  public materialConst = {
    BALED_CARDBOARD,
    LOOSE_CARDBOARD,
    LOOSE_PLASTIC,
    BALED_PLASTIC,
    RNS,
    DONATIONS_RECLAIM,
    OTHERS
  };
  public maxBaleQty$ = this.createSalvageService.getMaximumBaleQty();
  public minBaleQty$ = this.createSalvageService.getMinimumBaleQty();
  public doors$ = this.createSalvageService.getDoors();
  public destinations$ = this.createSalvageService.getDestinations();
  public materialTypes$ = this.createSalvageService.getMaterialTypes();
  public printLocations$ = this.createSalvageService.getPrintLocations();
  public receiptData: ReceiptData = new ReceiptData();

  constructor(private util: UtilService,
              private userService: UserService,
              private dateService: DateService,
              public modalService: ModalService,
              private salvageService: SalvageService,
              private facilityService: FacilityService,
              private createSalvageService: CreateSalvageService) {
    this.confirmationMsg = false;
  }

  ngOnInit() {
    this.initializeForm();
  }

  public initializeForm() {
      this.salvageForm = this.createSalvageService.createForm();
      this.salvageForm.controls['facilityId'].setValue(this.facilityItems[0].value);
  }

   /* Submit salvage details */
  public submit(flag: boolean, event) {
    event.preventDefault();
    if (flag) {
      const salvageData = {
        insertedEuid: this.userService.getUserEuid(),
        updatedEuid: this.userService.getUserEuid(),
        facilityId: Number(this.salvageForm.value.facilityId)
      };
      this.facilityId = this.salvageForm.value.facilityId;
      const submitSalvageDetails = {
        ... this.salvageForm.getRawValue(),
        ... salvageData
      };
      this.createSalvageService.saveSalvageValues(submitSalvageDetails)
        .subscribe(res => {
          this.bolId = res.bolId;
          this.printReceiptData(submitSalvageDetails);
          this.confirmationMsg = true;
        });
    }
    this.initializeForm();
  }

  /* Print receipt data */
  private printReceiptData(submittedData) {
    const facilityData = this.facilityData.find(f => f.facilityId === submittedData.facilityId);
    this.submitPrintData = this.displayReceiptData(facilityData, submittedData);
    this.showPrintDialog();
  }

  /* print preview receipt data */
  public showPrintPreviewDialog() {
    this.printDialog.printPreviewDialog(this.submitPrintData, true);
  }

  /* print receipt data */
  public showPrintDialog() {
    this.printDialog.printDialog(this.submitPrintData);
  }

  // To disable unwanted keys
  public checkInputKey(event) {
    return UtilService.checkKey(event);
  }

  /* Set print receipt data details */
  private displayReceiptData(facility, submittedData): ReceiptData {
    this.receiptData = {
      ... submittedData,
      bolId: this.bolId,
      salvageMaterialType: submittedData.salvageMaterialType,
      facilityId: submittedData.facilityId,
      salvageQty: submittedData.salvageQty || 'N/A',
      gpsId: submittedData.gpsId || 'N/A',
      reprintBol: false
    };
    return SalvageService.getReceiptInfo(facility, this.receiptData);
  }
}
