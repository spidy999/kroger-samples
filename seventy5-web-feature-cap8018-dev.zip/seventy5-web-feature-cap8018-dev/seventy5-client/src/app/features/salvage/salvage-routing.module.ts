import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AuthGuard as AuthGuard} from '@app/auth-guard';
import {SalvageComponent} from '@features/salvage/salvage.component';
import {Permission} from '@shared/models/permissions';

const salvageRoutes: Routes = [
  {
    path: '',
    component: SalvageComponent,
    canActivate: [AuthGuard],
    data:   {
      expectedRole: Permission.SALVAGE.toString()
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(salvageRoutes)],
  exports: [RouterModule]
})
export class SalvageRoutingModule { }
