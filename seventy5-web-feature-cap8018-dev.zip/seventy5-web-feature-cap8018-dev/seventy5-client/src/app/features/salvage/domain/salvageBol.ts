
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import { SalvageMaterialType } from '@app/shared/domain/salvageMaterialType';

export class SalvageBol {
    bolId?: number;
    facilityId?: number;
    printLocation?: string;
    trailerNo?: string;
    searchType?: string;
    salvageMaterialType?: SalvageMaterialType;
    salvageQty?: number;
    insertedEuid?: string;
    updatedEuid?: string;
    referenceNo?: string;
    comments?: string;
    status?: SalvageBolStatus;
    gpsId?: string;
    destination?: string;
    doorNo?: string;
    deviceId?: string;
    insertedDate?: string;
    reprintBol?: boolean;
    totalWeight?: number;
    errorCategory?: string;
    closedDate?: string;
    updatedDate?: string;
}
