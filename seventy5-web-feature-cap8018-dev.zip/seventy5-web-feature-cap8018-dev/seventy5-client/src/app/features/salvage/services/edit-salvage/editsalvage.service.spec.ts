import {FormBuilder} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { EditSalvageService } from './edit-salvage.service';
import {DateService} from '@shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';

describe('EditSalvageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        DateService,
        HttpClient,
        FormBuilder,
        FacilityService
      ]
    });
  });

  it('should be created', () => {
    const service: EditSalvageService = TestBed.inject(EditSalvageService);
    expect(service).toBeTruthy();
  });
});
