import { Injectable } from '@angular/core';

/**
 * Barcode Scanner
 *
 * This class helps to process barcode scans.  It works by looking for a 'start code' and 'end code'
 * which must be programmed into the scanner. A scan is defined as the characters found between the
 * start and end codes.  The codes are compared to the KeyboardEvent.keyCode() value so they should
 * represent a single character each.
 *
 * To set things up, you need to provide a list of BarcodeTarget objects that represent an HTML
 * text input box (or other target) and an associated prefix.  The target will get an event if a
 * scan with that prefix is detected.
 *
 * A prefix is NOT the same thing as the start code.  For example the data coming from a
 * scanner might be:   '<02>bol1234<13>'  where <02> is ASCII code 2 and is the start code.  'bol'
 * is the prefix and indicates that this was a Bill of Lading scan. '1234' is the BOL number.
 * <13> is ASCII code 13 and is the end code.  The event that is fired contains '1234' in the detail
 * property.
 *
 * Once a scan is found, the list of BarcodeTarget objects will be searched looking for one which
 * has a prefix that matches the scan.  When one is found, a 'barcodeinput' event will be dispatched
 * to the target.  This event has a 'detail' property containing the text that was scanned. It
 * also had a 'target' property.  You can add a BarcodeTarget with an empty or null prefix.  In
 * this case, the target will be notified if no other targets match.
 * If multiple entries match, they will all get the notification event.
 *
 *
 * To use this helper your view component should look something like this:
 *
 *   @ViewChild('inputId') inputBox;
 *   ngAfterViewInit(): void {
 *     const barcodeScanner = BarcodeScannerService.create([{prefix: 'bol', inputBox: this.inputBox}]);
 *   }
 *
 *   @HostListener('document:keypress', ['$event'])
 *   onKeyPress(event) {
 *     if (this.barcodeScanner) {
 *      this.barcodeScanner.onKeyPress(event);
 *     }
 *   }
 *
 *
 * And the template should contain something on the order of:
 *   <input #inputId (barcodeinput)="gotBarcode($event)" />
 *
 */
export class BarcodeScanner {

  private static DEFAULT_START_CODE = 2;  // ASCII 02 ('Start of text')
  private static DEFAULT_END_CODE = 13;  // ASCII 13 ('Carriage Return')
  private static ABORT_TIMEOUT_MS = 200;
  public  static SCAN_DETECTED_EVENT = 'barcodeinput';

  private startScanCharCode: number = BarcodeScanner.DEFAULT_START_CODE;
  private endScanCharCode: number = BarcodeScanner.DEFAULT_END_CODE;
  private barcodeTargets: BarcodeTarget[] = [];

  private barcodeInputStarted: boolean;
  private barcodeInputString = '';
  private abortTimer: any;


  constructor(initialTargets: BarcodeTarget[]) {
    const thisComponent = this;

    if (initialTargets) {
      for (const target of initialTargets) {
        this.addTarget(target);
      }
    }
  }

  setStartCode(startScanCharCode: number) {
    this.startScanCharCode = startScanCharCode;
  }

  setEndCode(endScanCharCode: number) {
    this.endScanCharCode = endScanCharCode;
  }

  addTarget(barcodeTarget: BarcodeTarget) {
    this.barcodeTargets.push(barcodeTarget);
  }

  onKeyPress(event) {
    if (event.keyCode === this.startScanCharCode) {
      this.startScan();
      event.preventDefault();

    } else if (event.keyCode === this.endScanCharCode && this.barcodeInputStarted) {
      this.endScan();
      event.preventDefault();

    } else {

      if (this.barcodeInputStarted && event && event.key) {
        this.barcodeInputString += event.key;
        event.preventDefault();
      }

    }
  }

  private startScan() {
    const thisComponent = this;
    this.barcodeInputStarted = true;

    // If we don't get the stop char quickly, end the scan.
    this.abortTimer = setTimeout(function () {
      thisComponent.endScan();
    }, BarcodeScanner.ABORT_TIMEOUT_MS);
  }

  private endScan() {
    if (this.abortTimer > 0) {
      clearTimeout(this.abortTimer);
    }

    this.notifyTarget();

    this.barcodeInputStarted = false;
    this.barcodeInputString = '';
  }

  private notifyTarget() {
    let foundOne = false;
    for (const barcodeTarget of this.barcodeTargets) {
      if (this.barcodeInputString.toUpperCase().startsWith(barcodeTarget.prefix.toUpperCase()) &&
        (barcodeTarget.prefix !== null && barcodeTarget.prefix !== '') ) {
        foundOne = true;
        // Remove the prefix and trigger the event
        const inputString = this.barcodeInputString.substring(
          barcodeTarget.prefix.length, this.barcodeInputString.length);

        barcodeTarget.target.nativeElement.dispatchEvent(
          new CustomEvent(BarcodeScanner.SCAN_DETECTED_EVENT,
            {detail: inputString, bubbles: true})
        );
      }
    }

    // Look for a null-prefix match only if we didn't find a prefixed match
    if (!foundOne) {
      for (const barcodeTarget of this.barcodeTargets) {
        if (barcodeTarget.prefix === null || barcodeTarget.prefix === '') {
          barcodeTarget.target.nativeElement.dispatchEvent(
            new CustomEvent(BarcodeScanner.SCAN_DETECTED_EVENT,
              {detail: this.barcodeInputString, bubbles: true})
          );
        }
      }
    }

  }
}

/*
 * Represents a target (usually a text box) and it's associated prefix.  If a scan is detected
 * with the prefix, a 'barcodeinput' event will be triggered on the target.
 *
 * NOTE: the prefix is not the start char and can be null or empty.
 */
export class BarcodeTarget {
  public prefix: string;
  public target: any;

  constructor(prefix, target) {
    this.prefix = prefix;
    this.target = target;
  }
}

@Injectable()
export class BarcodeScannerService {

  constructor() { }

  public static createScanner(initialTargets: BarcodeTarget[]): BarcodeScanner {
    return new BarcodeScanner(initialTargets);
  }
}
