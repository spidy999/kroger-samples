import { TestBed } from '@angular/core/testing';
import { SalvageService } from './salvage.service';
import {DateService} from '@shared/services/date/date.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';

describe('SalvageService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [DateService]
  }));

  it('should be created', () => {
    const service: SalvageService = TestBed.inject(SalvageService);
    expect(service).toBeTruthy();
  });
});
