import {FormBuilder} from '@angular/forms';
import {DateRange} from '@shared/models/dateRange';
import {inject, TestBed} from '@angular/core/testing';
import {SearchBolData} from '@shared/models/searchBolData';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {SearchSalvageService} from './search-salvage.service';
import {DateService} from '@shared/services/date/date.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {CloseBolAutoComplete} from '@features/salvage/models/closeBolAutoComplete';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
const SALVAGE_QTY = 24;

describe('SearchSalvageService', () => {
  let searchSalvageService: SearchSalvageService;
  let validatorService: ValidatorsService;
  let dateService: DateService;

  const salvageData = new SalvageBol();
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        SearchSalvageService,
        ValidatorsService,
        DateService,
        FormBuilder,
        DateRange
      ]
    });
  });

  beforeEach(() => {
    dateService = TestBed.inject(DateService);
    validatorService = TestBed.inject(ValidatorsService);
    searchSalvageService = TestBed.inject(SearchSalvageService);

    salvageData.salvageQty = SALVAGE_QTY;
    salvageData.salvageMaterialType = {materialTypeCd: 'BC', materialTypeName: 'Baled Cardboard'};
    salvageData.trailerNo = '1234';
    salvageData.status = SalvageBolStatus.CANCELED;
  });

  it('should be created', inject([SearchSalvageService], (service: SearchSalvageService) => {
    expect(service).toBeTruthy();
  }));

  it('should update BolSalvage', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      service.updateBolSalvage(salvageData)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/updateSalvageData`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': false}]});
      httpMock.verify();
    }));

  it('should update salvage bolStatus', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      service.updateSalvageBolStatus(salvageData)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/updateSalvageBolStatus`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': false}]});
      httpMock.verify();
    }));

  it('should get gpsId and trailerId', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      const dates = {'facilityId': 2, 'startDate': '2018-08-05', 'endDate': '2018-08-06'};
      service.getGPSandTrailerId(dates)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/autoComplete/` + dates['facilityId']  + '/'
        + dates ['startDate'] + '/' + dates ['endDate']);
      expect(req.request.method).toEqual('GET');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': false}]});
      httpMock.verify();
    }));

  it('should transfer BOL', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      const params = {
        bolId: 3,
        euid: 'KON4444',
        doorNo: '201'
      };
      service.transferBOLData(params)
        .subscribe(data => expect(data).toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/transferBOLData/3/KON4444/201`);
      expect(req.request.method).toEqual('GET');
      req.flush(null);
      httpMock.verify();
    }));

  it('should auto complete search BOL options', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      const params: SearchBolData = {
        bolId: 3,
        facilityId: 3,
        status: null,
        trailerNo: null,
        destination: null,
        salvageMaterialType: null,
        gpsId: null,
        startDate: '2018-04-12 12:00 AM',
        endDate: '2021-04-12 12:00 AM',
        period: [1, 2]
      };

      const result: CloseBolAutoComplete[] = [
        {
          trailerNo: 'TR3526',
          gpsId: 'GP423632'
        },
        {
          trailerNo: 'TR3366',
          gpsId: 'GP424642'
        },
      ];
      service.autoCompleteForSearchBOL(params)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/autoCompleteSearchBOL`);
      expect(req.request.method).toEqual('POST');
      req.flush(result);
      httpMock.verify();
    }));

  it('should fetch salvage BOL report with pagination', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      const pageIndex = 3;
      const pageOffset = 15;
      const searchData = {
        facilityId: 3,
        status: null,
        trailerNo: 'TR12647',
        destination: null,
        salvageMaterialType: null,
        gpsId: null,
        startDate: '2018-04-12 12:00 AM',
        endDate: '2021-04-12 12:00 AM',
        period: [1, 2],
        bolId: 3
      };
      const result: SalvageBol[] = [
        {
          bolId: 3,
          facilityId: 3,
          printLocation: 'BUILDING 2',
          trailerNo: 'TR4355',
          salvageMaterialType: null,
          salvageQty: 2,
          destination: 'BUILDING 3',
          doorNo: '203',
          totalWeight: 5
        }
      ];
      service.getSalvageBolReportWithPagination(searchData, pageIndex, pageOffset)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/getSalvageBolData/3/15`);
      expect(req.request.method).toEqual('POST');
      req.flush(result);
      httpMock.verify();
    }));

  it('should fetch salvage report bale count', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      const searchData = {
        facilityId: 3,
        status: null,
        trailerNo: 'TR12647',
        destination: null,
        salvageMaterialType: null,
        gpsId: null,
        startDate: '2018-04-12 12:00 AM',
        endDate: '2021-04-12 12:00 AM',
        period: [1, 2],
        bolId: 3
      };
      const result = 5;
      service.getSalvageBolReportPageCount(searchData)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/getSalvageBolDataCount`);
      expect(req.request.method).toEqual('POST');
      req.flush(result);
      httpMock.verify();
    }));

  it('should fetch excel salvage report', inject([SearchSalvageService, HttpTestingController],
    (service: SearchSalvageService, httpMock: HttpTestingController) => {
      const searchData = {
        facilityId: 3,
        status: null,
        trailerNo: 'TR12647',
        destination: null,
        salvageMaterialType: null,
        gpsId: null,
        startDate: '2018-04-12 12:00 AM',
        endDate: '2021-04-12 12:00 AM',
        period: [1, 2],
        bolId: 3
      };
      service.excelSalvageReport(searchData)
        .subscribe(data => expect( data ).toBeTruthy());
      const req = httpMock.expectOne(`api/salvage/loadExcelSalvageBol`);
      expect(req.request.method).toEqual('POST');
      req.flush({ data: true });
      httpMock.verify();
    }));

});
