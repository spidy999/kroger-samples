import {FormBuilder} from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import { TestBed, inject } from '@angular/core/testing';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {SalvageMaterialType} from '@shared/domain/salvageMaterialType';
import { CloseSalvageService } from './close-salvage.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('CloseSalvageService', () => {
  let closeSalvageService: CloseSalvageService;
  let facilityService: FacilityService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpClient,
        FormBuilder,
        FacilityService,
        CloseSalvageService
      ]
    });
  });

  beforeEach(() => {
    facilityService = TestBed.inject(FacilityService);
    closeSalvageService = TestBed.inject(CloseSalvageService);
  });

  it('should be created', inject([CloseSalvageService], (service: CloseSalvageService) => {
    expect(service).toBeTruthy();
  }));

  it( 'should fetch open BOL`s', inject( [ CloseSalvageService, HttpTestingController ],
    ( service: CloseSalvageService, httpMock: HttpTestingController ) => {
      const facilityId = 3;
      const result: SalvageBol[] = [
        {
          bolId: 4,
          facilityId: 3,
          printLocation: 'BUILDING 2',
          trailerNo: 'TRL1276',
          salvageQty: 7,
          insertedEuid: 'KON4444',
          updatedEuid: 'KON4444',
          gpsId: 'GP243',
          destination: '',
          doorNo: '203',
          totalWeight: 123
        }
      ];
      service.closeBolSearchForOpen(facilityId).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/salvage/searchOpenBOL/${facilityId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should close open pull ticket', inject( [ CloseSalvageService, HttpTestingController ],
    ( service: CloseSalvageService, httpMock: HttpTestingController ) => {
      const facilityId = 3;
      const result: SalvageBol[] = [
        {
          bolId: 4,
          facilityId: 3,
          printLocation: 'BUILDING 2',
          trailerNo: 'TRL1276',
          salvageQty: 7,
          insertedEuid: 'KON4444',
          updatedEuid: 'KON4444',
          gpsId: 'GP243',
          destination: '',
          doorNo: '203',
          totalWeight: 123
        }
      ];
      service.closePullTicketSearchForOpen(facilityId).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/salvage/searchOpenPullTickets/${facilityId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should search for close pull ticket', inject( [ CloseSalvageService, HttpTestingController ],
    ( service: CloseSalvageService, httpMock: HttpTestingController ) => {
      const salvageMaterialType = new SalvageMaterialType();
      salvageMaterialType.materialTypeCd = 'BC';
      salvageMaterialType.materialTypeName = 'Bale Cardboard';
      const params = {
        bolId: 3,
        facilityId: 3,
        printLocation: 'BUILDING 2',
        trailerNo: 'TRL1276',
        salvageQty: 7,
        insertedEuid: 'KON5555',
        updatedEuid: 'KON5555',
        gpsId: 'GPS3242',
        destination: 'BUILDING 2',
        doorNo: '203',
        salvageMaterialType: salvageMaterialType,
        startDate: '',
        endDate: '',
        totalWeight: 786
      };
      const result: SalvageBol[] = [
        {
          bolId: 4,
          facilityId: 3,
          printLocation: 'BUILDING 2',
          trailerNo: 'TRL1276',
          salvageQty: 7,
          salvageMaterialType: salvageMaterialType,
          insertedEuid: 'KON4444',
          updatedEuid: 'KON4444',
          gpsId: 'GP243',
          destination: '',
          doorNo: '203',
          totalWeight: 123
        }
      ];
      service.closeBolPullTicketSearch(params).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne(`api/salvage/searchBOLPullTicket/3/3/BC/TRL1276//`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));
});
