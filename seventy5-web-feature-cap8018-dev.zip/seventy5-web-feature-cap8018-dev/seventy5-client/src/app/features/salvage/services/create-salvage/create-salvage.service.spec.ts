import { FormBuilder } from '@angular/forms';
import {HttpClient} from '@angular/common/http';
import {inject, TestBed} from '@angular/core/testing';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {CreateSalvageService} from './create-salvage.service';
import {DateService} from '@shared/services/date/date.service';
import { FacilityService } from '@app/shared/services/facility/facility.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('CreateSalvageService', () => {
  let salvageService: CreateSalvageService;
  let dateService: DateService;
  let facilityService: FacilityService;
  const SALVAGE_DATA: SalvageBol = {
                        facilityId: 1,
                        salvageMaterialType: {materialTypeCd: 'LC', materialTypeName: 'Loose Cardboard'},
                        trailerNo: '25',
                        referenceNo: '10',
                        salvageQty: null,
                        gpsId: '5',
                        bolId: 0,
                        totalWeight: 0,
                        comments: null,
                        destination: 'building2',
                        updatedDate: '2018-08-03'
                    };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpClient,
        FormBuilder,
        DateService,
        FacilityService,
        CreateSalvageService
      ]
    });
  });

  beforeEach(() => {
    dateService = TestBed.inject(DateService);
    facilityService = TestBed.inject(FacilityService);
    salvageService = TestBed.inject(CreateSalvageService);
  });

  it('should be created', inject([CreateSalvageService], (service: CreateSalvageService) => {
    expect(service).toBeTruthy();
  }));

  it('should save salvage values', inject([CreateSalvageService, HttpTestingController],
    (service: CreateSalvageService, httpMock: HttpTestingController) => {
      service.saveSalvageValues(SALVAGE_DATA)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/insert`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': true, 'data': ''}]});
      httpMock.verify();
    }));

  it( 'should fetch dock door qty', inject( [ CreateSalvageService, HttpTestingController ],
    ( service: CreateSalvageService, httpMock: HttpTestingController ) => {
      const facilityId = 3;
      const doorNo = '203';
      const result =  5;
      service.getDockDoorQty(doorNo, facilityId).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/salvage/dockDoorQty/${doorNo}/${facilityId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch salvage material and door by facilityId', inject( [ CreateSalvageService, HttpTestingController ],
    ( service: CreateSalvageService, httpMock: HttpTestingController ) => {
      const facilityId = 3;
      const result = 5;
      service.salvageMaterialAndDoorByFacilityId(facilityId).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/salvage/facility/${facilityId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));
});
