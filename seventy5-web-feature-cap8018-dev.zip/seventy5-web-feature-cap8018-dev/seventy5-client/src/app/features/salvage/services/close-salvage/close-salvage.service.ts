import {map} from 'rxjs/operators';
import {AutoComplete} from 'primeng';
import {SelectItem} from 'primeng/api';
import { Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FacilityData} from '@shared/domain/facilityData';
import { SalvageBol } from '@features/salvage/domain/salvageBol';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {FormGroup, Validators, FormBuilder, AbstractControl} from '@angular/forms';

@Injectable()
export class CloseSalvageService {
  private closeBolForm: FormGroup;
  private searchBolForm: FormGroup;
  private completeBolForm: FormGroup;
  private bolSearchBox: AutoComplete;
  private trailerSearchBox: AutoComplete;
  private facility$: BehaviorSubject<FacilityData> = new BehaviorSubject<FacilityData>(null);
  private materialTypes$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  constructor(private fb: FormBuilder,
              private http: HttpClient,
              private facilityService: FacilityService) { }

  searchForm(bol, trailer) {
    this.bolSearchBox = bol;
    this.trailerSearchBox = trailer;
    this.searchBolForm = this.fb.group({
        facilityId: [null, Validators.required, this.validateFacilityId.bind(this)],
        searchType: [null, this.validateSearchType.bind(this)],
        salvageMaterialType: [null],
        trailerNo:  [null, ValidatorsService.trailerValidations],
        bolId:      [null, ValidatorsService.bolIdValidations]
    });
    return this.searchBolForm;
  }

  closeForm() {
   this.closeBolForm = this.fb.group({
     status:     [null, [Validators.required, this.validateStatus.bind(this)]],
     category:   [''],
     gpsId:      [null],
     trailerNo:  [null]
   });
   return this.closeBolForm;
  }

  validateStatus(control: AbstractControl) {
    if (!control.value) { return; }
    if (!this.closeBolForm ) { return; }

    this.closeBolForm.get('trailerNo').patchValue(null);
    this.closeBolForm.get('gpsId').patchValue(null);
    switch (control.value) {
      case 'approved': {
        this.closeBolForm.get('category').setValidators(null);
        this.closeBolForm.get('trailerNo').setValidators(null);
        this.closeBolForm.get('gpsId').setValidators(null);
      }
      break;
      case 'approvedWithError': {
        this.closeBolForm.get('category').patchValue('');
        this.closeBolForm.get('category').setValidators([Validators.required, this.validateCategory.bind(this)]);
      }
      break;
    }
    this.closeBolForm.get('category').updateValueAndValidity();
    this.closeBolForm.get('trailerNo').updateValueAndValidity();
    this.closeBolForm.get('gpsId').updateValueAndValidity();
    return null;
  }

  validateCategory(control: AbstractControl) {
    if (!control.value) { return; }
    if (!this.closeBolForm ) { return; }

    switch (control.value) {
      case 'gpsId': {
        this.closeBolForm.get('gpsId').setValidators([Validators.required, ValidatorsService.gpsIdValidations]);
        this.closeBolForm.get('trailerNo').setValidators(null);
        this.closeBolForm.get('trailerNo').patchValue(null);
        this.closeBolForm.get('trailerNo').markAsPristine();
        this.closeBolForm.get('trailerNo').markAsUntouched();
      } break;
      case 'trailerNo': {
        this.closeBolForm.get('trailerNo').setValidators([Validators.required, ValidatorsService.trailerValidations]);
        this.closeBolForm.get('gpsId').setValidators(null);
        this.closeBolForm.get('gpsId').patchValue(null);
        this.closeBolForm.get('gpsId').markAsPristine();
        this.closeBolForm.get('gpsId').markAsUntouched();
      } break;
    }
    return null;
  }

  completeForm() {
    this.completeBolForm = this.fb.group({
      bolId:        [Validators.required],
      doorNo:       [Validators.required],
      facilityId:   [null, Validators.required],
      salvageMaterialType: ['', Validators.required],
      trailerNo:    [null, Validators.required],
      destination:  [null, Validators.required],
      referenceNo:  [null],
      salvageQty:   [null],
      gpsId:        [null],
      comments:     [null]
    });
    return this.completeBolForm;
  }

  private validateFacilityId(control: AbstractControl) {
    return this.facilityService.getFacilityDataById(control.value).pipe(
      map((facility: FacilityData) => {
        this.facility$.next(facility);
        if (facility && facility.materialTypes) {
          this.materialTypes$.next(facility.materialTypes.map( type => ({
            label: type.materialTypeName, value: type
          })));
        } else {
          this.materialTypes$.next([]);
        }
        this.searchBolForm.get('bolId').patchValue(null);
        this.searchBolForm.get('trailerNo').patchValue(null);
        this.searchBolForm.get('salvageMaterialType').patchValue('');
        return null;
      })
    );
  }

  private validateSearchType(control: AbstractControl) {
    if (!this.searchBolForm ) {
      return;
    }
    this.searchBolForm.get('bolId').enable();
    this.searchBolForm.get('salvageMaterialType').enable();
    this.searchBolForm.get('trailerNo').enable();

    switch (control.value) {
      case 'bolId': {
        this.searchBolForm.get('trailerNo').disable();
        this.searchBolForm.get('salvageMaterialType').disable();
        this.searchBolForm.get('trailerNo').setValue(null);
        this.searchBolForm.get('salvageMaterialType').setValue('');
        this.searchBolForm.get('bolId').markAsPristine();
        setTimeout(() => {
          if (this.bolSearchBox) { this.bolSearchBox.focusInput(); } }, 0);
      } break;
      case 'salvageMaterialType': {
        this.searchBolForm.get('bolId').disable();
        this.searchBolForm.get('trailerNo').disable();
        this.searchBolForm.get('bolId').setValue(null);
        this.searchBolForm.get('trailerNo').setValue(null);
        this.searchBolForm.get('salvageMaterialType').setValidators(Validators.required);
        this.searchBolForm.get('salvageMaterialType').markAsPristine();
      }  break;
      case 'trailerNo': {
        this.searchBolForm.get('bolId').disable();
        this.searchBolForm.get('salvageMaterialType').disable();
        this.searchBolForm.get('bolId').setValue(null);
        this.searchBolForm.get('salvageMaterialType').setValue('');
        this.searchBolForm.get('trailerNo').setValidators([Validators.required, ValidatorsService.trailerValidations]);
        this.searchBolForm.get('trailerNo').markAsPristine();
        setTimeout(() => { if (this.trailerSearchBox) { this.trailerSearchBox.focusInput(); } }, 0);
      }  break;
    }
    return null;
  }

  /* open BOL for closeBOL-tab*/
  closeBolSearchForOpen(facilityId: number): Observable<SalvageBol[]> {
    return this.http.get<SalvageBol[]>(`api/salvage/searchOpenBOL/${facilityId}`);
  }

  closePullTicketSearchForOpen(facilityId: number): Observable<SalvageBol[]> {
    return this.http.get<SalvageBol[]>(`api/salvage/searchOpenPullTickets/${facilityId}`);
  }

  closeBolPullTicketSearch(getValues: SalvageBol & { startDate: any, endDate: any}): Observable<SalvageBol[]> {
    const {facilityId, bolId, salvageMaterialType, trailerNo, startDate, endDate} = getValues;
    return this.http.get<SalvageBol[]>(
      `api/salvage/searchBOLPullTicket/${facilityId}/${bolId}/${salvageMaterialType.materialTypeCd}/${trailerNo}/${startDate}/${endDate}`
    );
  }

  getMaterialTypes(): BehaviorSubject<SelectItem[]> {
    return this.materialTypes$;
  }
}
