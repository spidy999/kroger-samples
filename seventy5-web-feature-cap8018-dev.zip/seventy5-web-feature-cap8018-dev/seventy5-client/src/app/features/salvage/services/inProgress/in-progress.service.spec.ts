import {HttpClient} from '@angular/common/http';
import {inject, TestBed} from '@angular/core/testing';
import { InProgressService } from './in-progress.service';
import {DateService} from '@app/shared/services/date/date.service';
import {DcSalvageMaterial} from '@shared/domain/dcSalvageMaterial';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('InProgressService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpClient,
        DateService,
        InProgressService
      ]
    });
  });

  it('should be created', () => {
    const service: InProgressService = TestBed.inject(InProgressService);
    expect(service).toBeTruthy();
  });

  it( 'should fetch DC salvage material data', inject( [ InProgressService, HttpTestingController ],
    ( service: InProgressService, httpMock: HttpTestingController ) => {
      const params = {
        facilityId: 3,
        doorNo: '203'
      };
      const result: DcSalvageMaterial[] = [
        {
          salvageId : 'hsuw324242',
          weight : 890,
          doorNo : '203',
          bolId : 3,
          facilityId : 3
        }
      ];
      service.getDcSalvageMaterialData(params).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/salvage/getDcSalvageMaterialData/3/203`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));

  it( 'should fetch doors in progress', inject( [ InProgressService, HttpTestingController ],
    ( service: InProgressService, httpMock: HttpTestingController ) => {
      const facilityId = 3;
      const result = ['203', '201'];
      service.getDoorsInProgress({facilityId}).subscribe( data => {
        expect(data).toBeTruthy();
      });
      const req = httpMock.expectOne( `api/salvage/getDoorsInProgress/${facilityId}`);
      expect( req.request.method ).toBe( 'GET' );
      req.flush(result);
    }));
});
