/*

condition#1
-When user selects material type as 'Bale cardboard',
qty should be disabled and destination should be selected as 'Outbound' and disabled.
-If the qty is less than the min value from facility data table, error message is displayed and submit button is disabled.

condition#2
- When user selects material type as baled plastic, loose plastic and others.
- qty field is hidden.

condition#3
- When user selects material types other than Bale cardboard, baled plastic, loose plastic and others.
- qty field is enabled. However, the user must enter positive value.
-  If the qty field is empty or if invalid value is entered, error message is displayed and submit button is disabled
*/

import { map } from 'rxjs/operators';
import { SelectItem } from 'primeng/api';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { FacilityData } from '@app/shared/domain/facilityData';
import { SalvageBol } from '@features/salvage/domain/salvageBol';
import { SalvageMaterialType } from '@app/shared/domain/salvageMaterialType';
import { FormGroup, Validators, FormBuilder, AbstractControl } from '@angular/forms';
import { CloseBolAutoComplete } from '@features/salvage/models/closeBolAutoComplete';
import {DateService} from '@shared/services/date/date.service';
import { FacilityService } from '@app/shared/services/facility/facility.service';
import {
  GPS_ID_MAX_LENGTH,
  GPS_ID_MIN_LENGTH,
  REFERENCE_NO_MAX_LENGTH,
  REFERENCE_NO_MIN_LENGTH,
  TRAILER_MAX_LENGTH
} from '@app/shared/models/constants';
const RNS = 'RN';
const OTHER = 'O';
const LOOSE_PLASTIC = 'LP';
const LOOSE_CARDBOARD = 'LC';
const BALED_CARDBOARD = 'BC';
const DONATIONS_RECLAIM = 'DC';

@Injectable()
export class CreateSalvageService {
  private salvageForm: FormGroup;
  private minBaleQty$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private maxBaleQty$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private doors$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private facility$: BehaviorSubject<FacilityData> = new BehaviorSubject<FacilityData>(null);
  private printLocations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private materialTypes$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private destinations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  constructor(
    private http: HttpClient,
    private fb: FormBuilder,
    private dateService: DateService,
    private facilityService: FacilityService
  ) { }

  static getAutoCompleteData(response: CloseBolAutoComplete[]): { trailerResult: string[], gpsResult: string[] } {
    return {
      trailerResult: Array.from(new Set(response.map(res => res.trailerNo))),
      gpsResult: Array.from(new Set(response.map(res => res.gpsId)))
    };
  }

  saveSalvageValues(salvage: SalvageBol): Observable<SalvageBol> {
    return this.http.post<SalvageBol>('api/salvage/insert', salvage);
  }

  /* check total bale at the door in searchBOL and CreateBOL*/
  getDockDoorQty(doorNo, facilityId): Observable<number> {
    return this.http.get<number>(`api/salvage/dockDoorQty/${doorNo}/${facilityId}`);
  }

  /* returns all doors and material type for selected facility id.*/
  salvageMaterialAndDoorByFacilityId(facilityId): Observable<number> {
    return this.http.get<any>(`api/salvage/facility/${facilityId}`);
  }

  createForm(): FormGroup {
    this.salvageForm = this.fb.group({
      facilityId: [null, [Validators.required], [this.validateFacilityId.bind(this)]],
      printLocation: ['', Validators.required],
      salvageMaterialType: ['', [this.validateMaterialType.bind(this), Validators.required]],
      destination: ['',  [Validators.required, this.validateDestination.bind(this)]],
      doorNo: ['', Validators.required, this.validateDoorNo.bind(this)],
      trailerNo: [null, [
        Validators.required,
        Validators.pattern(/^[0-9a-zA-Z]+$/),
        Validators.maxLength(TRAILER_MAX_LENGTH)
        ]
      ],
      salvageQty: [null, [Validators.required, Validators.min(0)]],
      referenceNo: [null,
        [
          Validators.minLength(REFERENCE_NO_MIN_LENGTH),
          Validators.maxLength(REFERENCE_NO_MAX_LENGTH),
          Validators.pattern(/^[0-9a-zA-Z]+$/)
        ]
      ],
      gpsId: [null,
        [
          Validators.minLength(GPS_ID_MIN_LENGTH),
          Validators.maxLength(GPS_ID_MAX_LENGTH),
          Validators.pattern(/^[0-9a-zA-Z]+$/)
        ]],
      comments: [null]
    });
    return this.salvageForm;
  }

  private validateFacilityId(control: AbstractControl) {
    return this.facilityService.getFacilityDataById(control.value)
      .pipe(
         map(facility => {
             this.facility$.next(facility);
              if (facility && facility.materialTypes) {
                this.materialTypes$.next(
                  facility.materialTypes.map(type => ({
                    label: type.materialTypeName, value: type
                  })));
              }

              if (facility && facility.printerDetails) {
                this.printLocations$.next(
                  facility.printerDetails.map(type => ({
                    label: type.printerLocation, value: type.printerIpAddress
                  })));
              }

              if (facility && facility.doors) {
                this.doors$.next(facility.doors.map(door => ({
                  label: door, value: door
                })));
              }

              if (facility && facility.destinations) {
                this.destinations$.next(facility.destinations.map(destination => ({
                  label: destination, value: destination
                })));
              }
              this.salvageForm.get('doorNo').patchValue('');
              this.salvageForm.get('destination').patchValue('');
              this.salvageForm.get('printLocation').patchValue('');
              this.salvageForm.get('salvageMaterialType').patchValue('');
              this.salvageForm.get('doorNo').markAsPristine();
              this.salvageForm.get('printLocation').markAsPristine();
              this.salvageForm.get('salvageMaterialType').markAsPristine();
              this.salvageForm.get('destination').markAsPristine();
              return null;
         })
      );
  }

  validateDoorNo(control: AbstractControl) {
    if (!this.facility$.value) { return new Observable(); }

    return this.getDockDoorQty(control.value, this.facility$.value.facilityId)
    .pipe(map( res => {
      const materialType: SalvageMaterialType = this.salvageForm.value.salvageMaterialType;
        if (BALED_CARDBOARD === materialType.materialTypeCd) {
          this.salvageForm.get('salvageQty').setValue(res);
          this.salvageForm.get('salvageQty').markAsTouched();
          this.minBaleQty$.next(this.facility$.value.minimumBales);
          this.maxBaleQty$.next(this.facility$.value.maximumBales);
          if (res < this.facility$.value.minimumBales) {
            this.salvageForm.get('salvageQty').setErrors({min: true});
            return {'min': true};
          } else if (res > this.facility$.value.maximumBales) {
            this.salvageForm.get('salvageQty').setErrors({max: true});
            return {'max': true};
          } else {
            this.salvageForm.get('salvageQty').setErrors(null);
            return;
          }
        }
        return null;
      }));
  }

  validateMaterialType(control: AbstractControl) {
    if (!this.facility$.value) { return new Observable(); }
    if (!this.salvageForm ) { return; }

    this.salvageForm.get('salvageQty').enable();
    this.salvageForm.get('destination').enable();

    if (!control.value) {
      return;
    }

    if (this.facility$.value) {
      switch (control.value.materialTypeCd) {
        case LOOSE_CARDBOARD:
        case LOOSE_PLASTIC:
        case RNS:
        case DONATIONS_RECLAIM:
        case OTHER:
          this.salvageForm.get('salvageQty').setValidators(null);
          this.salvageForm.get('salvageQty').setValue(0);
          break;
        case BALED_CARDBOARD:
          this.salvageForm.get('destination').setValue(this.facility$.value.baledCardboardDestination);
          this.salvageForm.get('destination').disable();
          this.salvageForm.get('salvageQty').disable();
          break;
        default:
          this.salvageForm.get('salvageQty').enable();
          this.salvageForm.get('salvageQty').setValidators([Validators.required, Validators.min(0)]);
          this.salvageForm.get('salvageQty').setValue(0);
          break;
      }
      this.salvageForm.get('doorNo').updateValueAndValidity();
      this.salvageForm.get('destination').updateValueAndValidity();
      this.salvageForm.get('salvageQty').updateValueAndValidity();
    }
    return null;
  }

  validateDestination(control: AbstractControl) {
    if (!this.salvageForm ) {
      return;
    }
    if (!control.value) {
      return;
    }
  }

  getFacilityData(): BehaviorSubject<FacilityData> {
    return this.facility$;
  }
  getPrintLocations(): BehaviorSubject<SelectItem[]> {
    return this.printLocations$;
  }

  getDoors(): BehaviorSubject<SelectItem[]> {
    return this.doors$;
  }

  getDestinations(): BehaviorSubject<SelectItem[]> {
    return this.destinations$;
  }

  getMaterialTypes(): BehaviorSubject<SelectItem[]> {
    return this.materialTypes$;
  }

  getMinimumBaleQty() {
    return this.minBaleQty$;
  }

  getMaximumBaleQty() {
    return this.maxBaleQty$;
  }
}
