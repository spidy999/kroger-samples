import { Injectable } from '@angular/core';
import {FacilityData} from '@shared/domain/facilityData';
import {ReceiptData} from '@features/salvage/models/salvage';
import {DateService} from '@shared/services/date/date.service';

@Injectable({
  providedIn: 'root'
})
export class SalvageService {

  constructor() { }

  static getReceiptInfo(facility: FacilityData, receiptData: ReceiptData): ReceiptData {
    const {facilityName, streetAddress, city, stateCode, zipCode} = facility;
    const {bolId, facilityId, doorNo, trailerNo, salvageMaterialType, salvageQty, referenceNo,
      gpsId, comments, destination, reprintBol, printLocation} = receiptData;
    return {
      facilityName,
      streetAddress,
      city,
      stateCode,
      zipCode,
      bolId,
      facilityId,
      doorNo,
      trailerNo,
      salvageMaterialType:   salvageMaterialType,
      salvageQty:     Math.trunc(salvageQty),
      referenceNo,
      printedDate:    DateService.getMonthDayYearFormat(new Date()),
      dateOfInvoice:  DateService.getMonthDayYearFormat(new Date()),
      gpsId:          gpsId === undefined ? 'N/A' : gpsId,
      comments,
      destination,
      reprintBol,
      printLocation
    };
  }
}
