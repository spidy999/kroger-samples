import {FormBuilder} from '@angular/forms';
import {inject, TestBed} from '@angular/core/testing';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {PrintSalvageService} from './print-salvage.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';

describe('PrintSalvageService', () => {
  let printService: PrintSalvageService;
  const SALVAGE_DATA: SalvageBol = {
                  facilityId: 1,
                  salvageMaterialType: {materialTypeCd: 'LC', materialTypeName: 'Loose Cardboard'},
                  trailerNo: '25',
                  referenceNo: '10',
                  salvageQty: null,
                  gpsId: '5',
                  bolId: 0,
                  totalWeight: 0,
                  comments: null,
                  destination: 'building2',
                  updatedDate: '2018-08-03'
            };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        FormBuilder,
        FacilityService,
        PrintSalvageService
      ]
    });
  });

  beforeEach(() => {
    printService = TestBed.inject(PrintSalvageService);
  });

  it('should be created', inject([PrintSalvageService], (service: PrintSalvageService) => {
    expect(service).toBeTruthy();
  }));

  it('should print salvage BOL receipt', inject([PrintSalvageService, HttpTestingController],
    (service: PrintSalvageService, httpMock: HttpTestingController) => {
      service.printSalvageBolReceipt(SALVAGE_DATA)
        .subscribe(data => expect(data).not.toBeNull(true));
      const req = httpMock.expectOne(`api/salvage/printSalvageBolReceipt`);
      expect(req.request.method).toEqual('POST');
      req.flush({data: [{'statusInfo': {'exitStatus': 'SUCCESS', 'messages': []},
          'hasDataPayload': true, 'data': ''}]});
      httpMock.verify();
    }));

});
