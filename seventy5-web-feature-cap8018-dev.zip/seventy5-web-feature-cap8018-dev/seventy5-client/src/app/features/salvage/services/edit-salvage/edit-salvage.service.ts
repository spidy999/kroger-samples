import { Injectable } from '@angular/core';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {
  GPS_ID_MAX_LENGTH,
  GPS_ID_MIN_LENGTH,
  REFERENCE_NO_MAX_LENGTH,
  REFERENCE_NO_MIN_LENGTH,
  TRAILER_MAX_LENGTH
} from '@shared/models/constants';
import {map} from 'rxjs/operators';
import {SelectItem} from 'primeng/api';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FacilityData} from '@shared/domain/facilityData';
import {DateService} from '@shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';
const BALED_CARDBOARD = 'BC';

@Injectable({
  providedIn: 'root'
})
export class EditSalvageService {
  private editSalvageForm: FormGroup;
  private bolData: SalvageBol = {};
  private doors$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private facility$: BehaviorSubject<FacilityData> = new BehaviorSubject<FacilityData>(null);
  private destinations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private printLocations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private materialTypes$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  constructor(private fb: FormBuilder,
              private dateService: DateService,
              private facilityService: FacilityService) {}

  editForm(salvageData): FormGroup {
    this.bolData = salvageData;
    this.editSalvageForm = this.fb.group({
      bolId: [{ value: salvageData.bolId, disabled: true }, Validators.required],
      printLocation: ['', Validators.required],
      doorNo: [salvageData.doorNo, Validators.required],
      trailerNo: [salvageData.trailerNo, [
            Validators.required,
            Validators.pattern(/^[0-9a-zA-Z]+$/),
            Validators.maxLength(TRAILER_MAX_LENGTH)
          ]
          ],
      referenceNo: [salvageData.referenceNo,
            [
              Validators.minLength(REFERENCE_NO_MIN_LENGTH),
              Validators.maxLength(REFERENCE_NO_MAX_LENGTH),
              Validators.pattern(/^[0-9a-zA-Z]+$/)
            ]
          ],
      gpsId: [salvageData.gpsId,
            [
              Validators.minLength(GPS_ID_MIN_LENGTH),
              Validators.maxLength(GPS_ID_MAX_LENGTH),
              Validators.pattern(/^[0-9a-zA-Z]+$/)
            ]],
      comments: [salvageData.comments],
      destination: [salvageData.destination, Validators.required],
      salvageMaterialType: [salvageData.salvageMaterialType.materialTypeCd, Validators.required ],
      salvageQty: [ salvageData.salvageQty, [Validators.required, Validators.min(0)] ],
      facilityId: [salvageData.facilityId, [Validators.required], [this.validateFacilityId.bind(this)] ]
    });
    return this.editSalvageForm;
  }

  private validateFacilityId(control: AbstractControl) {
    return this.facilityService.getFacilityDataById(control.value).pipe(
      map(facility => {
        this.facility$.next(facility);

        if (this.bolData.salvageMaterialType) {
          const {materialTypeName, materialTypeCd} = this.bolData.salvageMaterialType;
          this.materialTypes$.next([{ label: materialTypeName, value: materialTypeCd}]);
        }

        if (facility && facility.printerDetails) {
          this.printLocations$.next(
            facility.printerDetails.map(type => ({
              label: type.printerLocation, value: type.printerIpAddress
            })));
        }

        if (facility && facility.doors) {
          this.doors$.next(facility.doors.map(door => ({
            label: door, value: door
          })));
        }

        if (facility && facility.destinations) {
          this.destinations$.next(facility.destinations.map(destination => ({
            label: destination, value: destination
          })));
        }

        if (facility && this.materialTypes$ &&  this.destinations$ && this.editSalvageForm) {
          if (BALED_CARDBOARD === this.bolData.salvageMaterialType.materialTypeCd) {
            this.editSalvageForm.get('destination').setValidators(null);
            this.editSalvageForm.get('destination').disable();
            this.editSalvageForm.get('destination').patchValue(this.bolData.destination);
            this.editSalvageForm.get('salvageQty').setValidators(null);
            this.editSalvageForm.get('salvageQty').disable();
          } else {
            this.editSalvageForm.get('destination').enable();
            this.editSalvageForm.get('destination').setValidators([Validators.required]);
            this.editSalvageForm.get('salvageQty').enable();
            this.editSalvageForm.get('salvageQty').setValidators([Validators.required, Validators.min(0)]);
          }
          this.editSalvageForm.get('salvageMaterialType').disable();
          this.editSalvageForm.get('facilityId').disable();
        }
        return null;
      }));
  }

  getDoors(): BehaviorSubject<SelectItem[]> {
    return this.doors$;
  }

  getPrinterLocations(): BehaviorSubject<SelectItem[]> {
    return this.printLocations$;
  }

  getDestinations(): BehaviorSubject<SelectItem[]> {
    return this.destinations$;
  }

  getMaterialTypes(): BehaviorSubject<SelectItem[]> {
    return this.materialTypes$;
  }
}
