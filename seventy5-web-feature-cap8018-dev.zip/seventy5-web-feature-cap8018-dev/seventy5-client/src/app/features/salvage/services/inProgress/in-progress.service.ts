import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {DateService} from '@app/shared/services/date/date.service';
import { DcSalvageMaterial } from '@app/shared/domain/dcSalvageMaterial';

@Injectable()
export class InProgressService {

  constructor( private http: HttpClient) { }

  // conversion of given date into "2018-11-19 10:47 AM" Format
  conversionOfDateForInProgressBOL(listData: DcSalvageMaterial[]): DcSalvageMaterial[] {
    return listData.map(data => ({
      ...data,
      updatedTs:  DateService.getDateForRequest(data.updatedTs),
      insertedTs: DateService.getDateForRequest(data.insertedTs)
    }));
  }

  getDcSalvageMaterialData({doorNo, facilityId}): Observable<DcSalvageMaterial[]> {
    return this.http.get<DcSalvageMaterial[]>(`api/salvage/getDcSalvageMaterialData/${facilityId}/${doorNo}`);
  }


  getDoorsInProgress({facilityId}): Observable<string[]> {
    return this.http.get<string[]>(`api/salvage/getDoorsInProgress/${facilityId}`);
  }
}
