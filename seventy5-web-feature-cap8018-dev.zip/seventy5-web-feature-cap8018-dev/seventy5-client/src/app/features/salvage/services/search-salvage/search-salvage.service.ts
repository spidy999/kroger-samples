import {SelectItem} from 'primeng/api';
import {map, share} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FacilityData} from '@shared/domain/facilityData';
import {SearchBolData} from '@shared/models/searchBolData';
import { SalvageBol } from '@features/salvage/domain/salvageBol';
import {CloseBolAutoComplete} from '@features/salvage/models/closeBolAutoComplete';
import {FormGroup, Validators, AbstractControl, FormBuilder} from '@angular/forms';
import {DateService} from '@shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
const ALL = 'ALL';

@Injectable()
export class SearchSalvageService {
  private searchBOLForm: FormGroup;
  private facility$: BehaviorSubject<FacilityData> = new BehaviorSubject<FacilityData>(null);
  private doors$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private materialTypes$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  private destinations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  constructor(private http: HttpClient,
              private fb: FormBuilder,
              private dateService: DateService,
              private facilityService: FacilityService) { }

  createSearchForm(): FormGroup {
    this.searchBOLForm = this.fb.group({
      facilityId:     [null, [Validators.required], [this.validateFacilityId.bind(this)]],
      gpsId:          [null, ValidatorsService.gpsIdValidations],
      trailerNo:      [null,  ValidatorsService.trailerValidations],
      destination:    [''],
      salvageMaterialType:   [''],
      status:         [ALL, Validators.required],
      bolId:          [null, ValidatorsService.bolIdValidations]
    });
    return this.searchBOLForm;
  }

  private validateFacilityId(control: AbstractControl) {
    return this.facilityService.getFacilityDataById(control.value).pipe(
      map((facility: FacilityData) => {
        this.facility$.next(facility);
        const destinations = [{label: 'ALL', value: ''}];
        const materialTypes = [{ label: 'ALL', value: ''}];

        if (facility && facility.destinations) {
          this.destinations$.next([...destinations, ...facility.destinations.map( dest => ({
            label: dest, value: dest
          }))]);
        }

        if (facility && facility.materialTypes) {
          this.materialTypes$.next([...materialTypes, ...facility.materialTypes.map(type => ({
            label: type.materialTypeName, value: type
          }))]);
        }
        this.searchBOLForm.get('destination').patchValue('');
        this.searchBOLForm.get('salvageMaterialType').patchValue('');
        this.searchBOLForm.updateValueAndValidity();
        return null;
      })
    );
  }

    /* conversion of given date into '2018-11-19 10:47 AM' Format */
  conversionOfDateForSearchList(listData: SalvageBol[]): SalvageBol[] {
    return listData.map(data => ({
      ...data,
      updatedDate:  DateService.getDateForRequest(data.updatedDate),
      insertedDate: DateService.getDateForRequest(data.insertedDate),
      closedDate:   data.status === 'CLOSED' ? DateService.getDateForRequest(data.updatedDate) : 'NA'
    }));
  }

  /*Edit in searchBOL-tab, close with Error in CloseBol-tab*/
  updateBolSalvage(getValues: SalvageBol): Observable<void> {
    return this.http.post<void>('api/salvage/updateSalvageData', getValues );
  }

  /* close, restore BOL in closeBOL-tab and searchBOL-tab*/
  updateSalvageBolStatus(getValues: SalvageBol): Observable<void> {
    return this.http.post<void>('api/salvage/updateSalvageBolStatus', getValues );
  }

  /* search for closeBOL-tab*/
  // this method is receiving startDate and endDate additionally to the SalvageData type
  closeBolSearch (getValues: SalvageBol & { startDate: any, endDate: any}): Observable<SalvageBol[]> {
    const {facilityId, bolId, salvageMaterialType, trailerNo, startDate, endDate} = getValues;
    return this.http.get<SalvageBol[]>(
      `api/salvage/searchBOL/${facilityId}/${bolId}/${salvageMaterialType.materialTypeCd}/${trailerNo}/${startDate}/${endDate}`
    );
  }

  /* autocomplete closeBOL-tab*/
  getGPSandTrailerId({facilityId, startDate, endDate}: SearchBolData): Observable<CloseBolAutoComplete[]> {
    return this.http.get<CloseBolAutoComplete[]>(`api/salvage/autoComplete/${facilityId}/${startDate}/${endDate}`);
  }

  /* searchBOL*/
  excelSalvageReport(getValues: SearchBolData): Observable<boolean> {
    return this.http.post<boolean>('api/salvage/loadExcelSalvageBol', getValues )
      .pipe(share());
  }

  /*Salvage Bill of Lading Report service calls to get the page count */
  getSalvageBolReportPageCount(getValues: SearchBolData): Observable<number> {
    return this.http.post<number>('api/salvage/getSalvageBolDataCount', getValues );
  }

  /*SearchBol with Pagination*/
  getSalvageBolReportWithPagination(getValues: SearchBolData, pageIndex: number, pageOffset: number): Observable<SalvageBol[]> {
    return this.http.post<SalvageBol[]>
    (`api/salvage/getSalvageBolData/${pageIndex}/${pageOffset}`, getValues);
  }

  /* autocomplete advanced searchBOL*/
  autoCompleteForSearchBOL(getValues: SearchBolData): Observable<CloseBolAutoComplete[]> {
    return this.http.post<CloseBolAutoComplete[]>('api/salvage/autoCompleteSearchBOL', getValues);
  }

  /* transfer BOL Data in searchBOL*/
  transferBOLData({bolId, euid, doorNo}): Observable<void> {
    return this.http.get<void>(`api/salvage/transferBOLData/${bolId}/${euid}/${doorNo}`);
  }

  getDoors(): BehaviorSubject<SelectItem[]> {
    return this.doors$;
  }

  getDestinations(): BehaviorSubject<SelectItem[]> {
    return this.destinations$;
  }

  getMaterialTypes(): BehaviorSubject<SelectItem[]> {
    return this.materialTypes$;
  }
}
