import {FormBuilder} from '@angular/forms';
import { TestBed } from '@angular/core/testing';
import { TransferSalvageService } from './transfer-salvage.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {DateService} from '@shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';

describe('TransferSalvageService', () => {
  beforeEach(() => TestBed.configureTestingModule( {
      imports: [HttpClientTestingModule],
      providers: [
        CreateSalvageService,
        ValidatorsService,
        FacilityService,
        DateService,
        FormBuilder
      ]}
    ));

  it('should be created', () => {
    const service: TransferSalvageService = TestBed.inject(TransferSalvageService);
    expect(service).toBeTruthy();
  });
});
