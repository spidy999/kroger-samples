import {map} from 'rxjs/operators';
import {SelectItem} from 'primeng/api';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FacilityData} from '@shared/domain/facilityData';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {FacilityService} from '@shared/services/facility/facility.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';

@Injectable({
  providedIn: 'root'
})
export class TransferSalvageService {
  transferBolForm: FormGroup;
  salvageData: SalvageBol = {};
  private facilityData: FacilityData = new FacilityData();
  private totalQty$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private maxQty$: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  private doors$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);

  constructor(private fb: FormBuilder,
              private http: HttpClient,
              private createService: CreateSalvageService,
              private facilityService: FacilityService) { }

  transferForm(): FormGroup {
    this.transferBolForm = this.fb.group({
      doorNo: ['', Validators.required, this.validateDoorNo.bind(this)]
    });
    return this.transferBolForm;
  }

  private validateDoorNo(control: AbstractControl) {
    return  this.createService.getDockDoorQty(control.value, this.salvageData.facilityId)
        .pipe(map(salvageQty => {
          if (salvageQty !== null) {
            const currentQty: number = this.salvageData.salvageQty;
            const result: number =  salvageQty + currentQty;
            const maxLimit: number = this.facilityData.maximumBales;
            this.totalQty$.next(result);
            this.maxQty$.next(maxLimit);
            if (result > maxLimit) {
              this.transferBolForm.controls['doorNo'].setErrors({'max': true});
              return {'max': true};
            } else {
              this.transferBolForm.get('doorNo').setErrors(null);
              return;
            }
          }
          return null;
        }));
  }

  getDataPerFacility(salvageData: SalvageBol) {
    this.facilityService.getFacilityDataById(salvageData.facilityId).subscribe((fd: FacilityData) => {
      if (fd && fd.printerDetails) {
        this.salvageData = salvageData;
        this.facilityData = fd;
        this.doors$.next([ ...fd.doors.map( door => ({
          label: door, value: door
        }))]);
      }
    });
  }

  getTotalQty() {
    return this.totalQty$;
  }

  getMaxQty() {
    return this.maxQty$;
  }

  getDoors(): BehaviorSubject<SelectItem[]> {
    return this.doors$;
  }
}
