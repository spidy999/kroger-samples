import {SelectItem} from 'primeng/api';
import {Injectable} from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {FacilityData} from '@shared/domain/facilityData';
import { SalvageBol } from '@features/salvage/domain/salvageBol';
import {FacilityService} from '@shared/services/facility/facility.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';

@Injectable()
export class PrintSalvageService {

  private printerLocationForm: FormGroup;
  private printerLocations$: BehaviorSubject<SelectItem[]> = new BehaviorSubject<SelectItem[]>([]);
  constructor(private http: HttpClient,
              private fb: FormBuilder,
              private facilityService: FacilityService) { }

  printSalvageBolReceipt(getValues: SalvageBol): Observable<void> {
    return this.http.post<void>('api/salvage/printSalvageBolReceipt', getValues );
  }

  createForm(): FormGroup {
    this.printerLocationForm = this.fb.group({
      printLocation:     new FormControl('', Validators.required)
    });
    return this.printerLocationForm;
  }

  getLocationPerFacility(facility: number) {
    this.facilityService.getFacilityDataById(facility).subscribe((fd: FacilityData) => {
      if (fd && fd.printerDetails) {
        this.printerLocations$.next([ ...fd.printerDetails.map( pl => ({
          label: pl.printerLocation, value: pl.printerIpAddress
        }))]);
      }
    });
  }

  getPrinterLocations(): BehaviorSubject<SelectItem[]> {
    return this.printerLocations$;
  }
}
