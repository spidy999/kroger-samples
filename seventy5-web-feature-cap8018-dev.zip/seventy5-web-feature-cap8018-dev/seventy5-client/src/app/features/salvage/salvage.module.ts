import { CommonModule } from '@angular/common';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {KdsStencilAccessorsModule} from 'kds-stencil-accessors';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {ReportsModule} from '@shared/reports/reports.module';
import {TemplateModule} from '@app/templates/template.module';
import { SalvageRoutingModule } from './salvage-routing.module';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import { GlobalInterceptorModule } from '@app/httpInterceptor.module';
import {SalvageService} from '@features/salvage/services/salvage.service';
import { CloseSalvageService } from './services/close-salvage/close-salvage.service';
import { SearchSalvageService } from './services/search-salvage/search-salvage.service';
import {InProgressService} from '@app/features/salvage/services/inProgress/in-progress.service';
import {EditSalvageService} from '@features/salvage/services/edit-salvage/edit-salvage.service';
import {BarcodeScannerService} from '@app/features/salvage/services/barcode/barcode-scanner.service';
import {PrintSalvageService} from '@app/features/salvage/services/print-salvage/print-salvage.service';
import {CreateSalvageService} from '@app/features/salvage/services/create-salvage/create-salvage.service';
import {TransferSalvageService} from '@features/salvage/services/transfer-salvage/transfer-salvage.service';
import {SalvageComponent} from '@features/salvage/salvage.component';
import { InProgressSalvageComponent } from './in-progress-salvage/in-progress-salvage.component';
import {CloseSalvageComponent} from '@app/features/salvage/close-salvage/close-salvage.component';
import {PrintDialogComponent} from '@features/salvage/dialogs/print-dialog/print-dialog.component';
import {CloseDialogComponent} from '@features/salvage/dialogs/close-dialog/close-dialog.component';
import {SearchSalvageComponent} from '@app/features/salvage/search-salvage/search-salvage.component';
import {CreateSalvageComponent} from '@app/features/salvage/create-salvage/create-salvage.component';
import {EditSalvageDialogComponent} from '@features/salvage/dialogs/edit-salvage-dialog/edit-salvage-dialog.component';
import {PrintLocationDialogComponent} from '@features/salvage/dialogs/print-location-dialog/print-location-dialog.component';
import {DeleteSalvageDialogComponent} from '@features/salvage/dialogs/delete-salvage-dialog/delete-salvage-dialog.component';
import {RestoreSalvageDialogComponent} from '@features/salvage/dialogs/restore-salvage-dialog/restore-salvage-dialog.component';
import {TransferSalvageDialogComponent} from '@features/salvage/dialogs/transfer-salvage-dialog/transfer-salvage-dialog.component';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    PrimengModule,
    CalendarModule,
    ReportsModule,
    TemplateModule,
    ReactiveFormsModule,
    KdsStencilAccessorsModule,
    SalvageRoutingModule
  ],
  declarations: [
    SalvageComponent,
    PrintDialogComponent,
    CloseDialogComponent,
    CloseSalvageComponent,
    SearchSalvageComponent,
    CreateSalvageComponent,
    EditSalvageDialogComponent,
    InProgressSalvageComponent,
    PrintLocationDialogComponent,
    DeleteSalvageDialogComponent,
    RestoreSalvageDialogComponent,
    TransferSalvageDialogComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [
    SalvageService,
    InProgressService,
    EditSalvageService,
    PrintSalvageService,
    CloseSalvageService,
    CreateSalvageService,
    SearchSalvageService,
    BarcodeScannerService,
    TransferSalvageService,
    GlobalInterceptorModule
  ]

})
export class SalvageModule { }

