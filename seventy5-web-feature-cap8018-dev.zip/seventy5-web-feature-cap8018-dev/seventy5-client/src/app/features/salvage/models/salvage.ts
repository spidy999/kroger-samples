import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {DestinationType} from '@shared/domain/DestinationType';

export const closeSalvage = {

  options : [
    {label: 'GPS ID', value: 'gpsId' },
    {label: 'Trailer #', value: 'trailerNo' },
  ],

  cols : [
    { field: 'details', header: 'Details' },
    { field: 'bolId', header: 'BOL No' },
    { field: 'gpsId', header: 'GPS Id' },
    { field: 'salvageMaterialType', subfield: 'materialTypeName', header: 'Material Type' },
    { field: 'trailerNo', header: 'Trailer No' },
    { field: 'status', header: 'Status' },
    { field: 'actions', header: 'Action' }
  ],

  searchOptions : [
    {label: 'BOL #', value: 'bolId' },
    {label: 'Material Type', value: 'salvageMaterialType' },
    {label: 'Trailer #', value: 'trailerNo' }
  ]

};

export const inProgressBol = {

  cols : [
    { field: 'salvageId', header: 'Bale ID' },
    { field: 'weight', header: 'Weight' },
    { field: 'updatedId', header: 'EUID' },
    { field: 'updatedTs', header: 'Timestamp' }
  ]
};

export const createSalvage = {
  destinations: [
    {label: 'Outbound', value: DestinationType.OUT_BOUND },
    {label: 'Shuttle', value: DestinationType.SHUTTLE },
    {label: 'Building 1', value: DestinationType.BUILDING_1 },
    {label: 'Building 2', value: DestinationType.BUILDING_2 },
    {label: 'Building 3', value: DestinationType.BUILDING_3 },
  ]

};

export const searchSalvage = {
  cols : [
    { field: 'details', header: 'Details' },
    { field: 'bolId', header: 'BOL No' },
    { field: 'updatedEuid', header: 'EUID' },
    { field: 'salvageMaterialType', subfield: 'materialTypeName', header: 'Material Type' },
    { field: 'trailerNo', header: 'Trailer No' },
    { field: 'destination', header: 'Destination' },
    { field: 'status', header: 'Status' },
    { field: 'actions', header: 'Action' }
  ],

  statusType : [
    {label: 'ALL', value: SalvageBolStatus.ALL },
    {label: 'Open', value: SalvageBolStatus.OPEN },
    {label: 'Closed', value: SalvageBolStatus.CLOSED },
    {label: 'Transfer', value: SalvageBolStatus.TRANSFER },
    {label: 'Canceled', value: SalvageBolStatus.CANCELED }
  ]
};


export class CloseSalvageData {
  public  materialType: string;
  public  gpsId?: string;
  public  trailerNo: string;
  public  bolId: string;
}

export enum SalvageTab {
  SEARCH_BOL = 'SEARCH_BOL',
  CREATE_BOL = 'CREATE_BOL',
  CLOSE_BOL = 'CLOSE_BOL',
  CLOSE_PT = 'CLOSE_PT',
  IN_PROGRESS_BOL = 'IN_PROGRESS_BOL'
}

export const SalvageTabs = {
  guardUserTabs: [
    {label: 'Close BOL', value: SalvageTab.CLOSE_BOL }
  ],
  otherUserTabs: [
    {label: 'Search BOL', value: SalvageTab.SEARCH_BOL },
    {label: 'Create BOL', value: SalvageTab.CREATE_BOL },
    {label: 'Close BOL', value: SalvageTab.CLOSE_BOL },
    {label: 'Close Pull Ticket', value: SalvageTab.CLOSE_PT },
    {label: 'In-Progress BOL', value: SalvageTab.IN_PROGRESS_BOL }
  ]
};

export class ReceiptData {
  public bolId: string;
  public facilityId: string;
  public facilityName: string;
  public streetAddress: string;
  public city: string;
  public stateCode: string;
  public zipCode: string;
  public doorNo: string;
  public trailerNo: string;
  public salvageMaterialType: SalvageMaterialType;
  public salvageQty: number;
  public referenceNo: string;
  public gpsId: string;
  public dateOfInvoice?: string;
  public printedDate?: string;
  public comments: string;
  public destination: string;
  public reprintBol?: boolean;
  public printLocation?: string;
}

export class SalvageMaterialType {
  public materialTypeName: string;
  public materialTypeCd: string;
}
