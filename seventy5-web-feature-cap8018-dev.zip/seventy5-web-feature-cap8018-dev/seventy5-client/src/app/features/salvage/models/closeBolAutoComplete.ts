export class CloseBolAutoComplete {
  public  trailerNo: string;
  public  gpsId: string;
}
