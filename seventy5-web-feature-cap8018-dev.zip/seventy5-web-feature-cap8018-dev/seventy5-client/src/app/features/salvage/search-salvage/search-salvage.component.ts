import 'rxjs-compat/add/observable/of';
import {FormGroup} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {map, mergeMap} from 'rxjs/operators';
import {DateRange} from '@shared/models/reportData';
import {Menu, OverlayPanel, Paginator} from 'primeng';
import {ToastDetails} from '@shared/models/Notification';
import {SearchBolData} from '@shared/models/searchBolData';
import {FacilityData} from '@app/shared/domain/facilityData';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {LazyLoadEvent, MenuItem, SelectItem} from 'primeng/api';
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {ReceiptData, searchSalvage as constants} from '../models/salvage';
import {SalvageMaterialType} from '@app/shared/domain/salvageMaterialType';
import {ChangeDetectorRef, Component, Input, OnChanges, OnInit, ViewChild} from '@angular/core';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import {UserService} from '@shared/services/user/user.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {SalvageService} from '@features/salvage/services/salvage.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {SearchSalvageService} from '../services/search-salvage/search-salvage.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';
import {DeleteSalvageDialogComponent
} from '@features/salvage/dialogs/delete-salvage-dialog/delete-salvage-dialog.component';
import {RestoreSalvageDialogComponent
} from '@features/salvage/dialogs/restore-salvage-dialog/restore-salvage-dialog.component';
import {TransferSalvageDialogComponent
} from '@features/salvage/dialogs/transfer-salvage-dialog/transfer-salvage-dialog.component';
import {PrintDialogComponent} from '@features/salvage/dialogs/print-dialog/print-dialog.component';
import {EditSalvageDialogComponent} from '@features/salvage/dialogs/edit-salvage-dialog/edit-salvage-dialog.component';
import {PrintLocationDialogComponent} from '@features/salvage/dialogs/print-location-dialog/print-location-dialog.component';
const TIMEOUT = 100;
const BALED_CARDBOARD = 'BC';

interface SalvageData {
  count: number;
  data: SalvageBol[];
}

@Component({
  selector: 'app-search-salvage',
  templateUrl: './search-salvage.component.html',
  styleUrls: ['./search-salvage.component.less']
})
export class SearchSalvageComponent implements OnInit, OnChanges {
  readonly OPEN = 'Open';
  readonly ALL = 'ALL';
  @ViewChild('searchBolList', {static: false}) paginator: Paginator;
  @ViewChild(PrintDialogComponent, {static: false}) printDialog: PrintDialogComponent;
  @ViewChild(EditSalvageDialogComponent, {static: false}) editDialog: EditSalvageDialogComponent;
  @ViewChild(DeleteSalvageDialogComponent, {static: false}) deleteDialog: DeleteSalvageDialogComponent;
  @ViewChild(RestoreSalvageDialogComponent, {static: false}) restoreDialog: RestoreSalvageDialogComponent;
  @ViewChild(TransferSalvageDialogComponent, {static: false}) transferDialog: TransferSalvageDialogComponent;
  @ViewChild(PrintLocationDialogComponent, {static: false}) printLocationDialog: PrintLocationDialogComponent;

  @Input() facilityData: FacilityData[];
  @Input() facilityItems: SelectItem[];
  @Input() public widgetDetails: DateRange;

  public flip = true;
  public initialCheck = true;
  public loading: boolean;
  public showTable: boolean;
  public dates: string;
  public printLocation: string;
  public loaderMessage: string;
  public facilityId: number;
  public totalRecords: number;
  public gpsResult: any = [];
  public dateRange: any = [];
  public filterGps: any = [];
  public filterTrailer: any = [];
  public trailerResult: any = [];
  public searchBOLForm: FormGroup;
  public singleBol: SalvageBol;
  public menuItems: MenuItem[];
  public facility: FacilityData;
  public statusType: SelectItem[];
  public selectedRowData: SalvageBol;
  public searchParams: SearchBolData;
  public submitPrintData: ReceiptData;
  public listData: SalvageBol[] = [];
  public receiptData: ReceiptData = new ReceiptData();
  public cols: Array<{field: string, header: string}> = [];
  public destinations$ = this.searchSalvageService.getDestinations();
  public materialTypes$ = this.searchSalvageService.getMaterialTypes();
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor(public userService: UserService,
              public changeDetect: ChangeDetectorRef,
              private dateService: DateService,
              private utilService: UtilService,
              private excelService: ExcelService,
              private salvageService: SalvageService,
              private facilityService: FacilityService,
              public notificationService: NotificationsService,
              private printSalvageService: PrintSalvageService,
              private createSalvageService: CreateSalvageService,
              private searchSalvageService: SearchSalvageService) {
    const {cols, statusType} = constants;
    this.cols = cols;
    this.statusType = statusType;
    this.searchBOLForm = this.searchSalvageService.createSearchForm();
  }

  ngOnInit() {
    this.loaderMessage = 'Loading...';
  }

  ngOnChanges() {
    this.extractCalendarDetails();
    this.runSearchSalvage(this.initialCheck);
  }

  private extractCalendarDetails() {
    if (this.widgetDetails) {
      const {startDate, endDate, period} = this.widgetDetails;
      this.dateRange = [startDate, endDate, period];
      const start = DateService.getMonthDayYearFormat(startDate);
      const end = DateService.getMonthDayYearFormat(endDate);
      this.dates = `${start} - ${end}`;
    }
  }

  public checkInputKey(event) {
    return UtilService.checkKey(event);
  }

  public search() {
    this.loaderMessage = 'Updating...';
    this.runSearchSalvage(false);
  }

  /* Load list of Bill of ladings */
  private runSearchSalvage(flag: boolean) {
    this.calculateSearchParams(flag);
    this.searchData();
    this.autoSearch();
  }

  private calculateSearchParams(flag: boolean) {
    if (flag) {
      if (this.facilityData) {
        this.searchBOLForm.get('facilityId').setValue(this.facilityData[0].facilityId);
      }
      this.searchParams = {
        facilityId: Number(this.searchBOLForm.get('facilityId').value),
        salvageMaterialType: null,
        status: SalvageBolStatus.ALL,
        startDate: DateService.getDateForRequest(this.dateRange[0]),
        endDate: DateService.getDateForRequest(this.dateRange[1])
      };
      this.initialCheck = false;
    } else {
      this.searchParams = {
        facilityId: Number(this.searchBOLForm.get('facilityId').value),
        startDate: DateService.getDateForRequest(this.dateRange[0]),
        endDate: DateService.getDateForRequest(this.dateRange[1])
      };
    }
  }

  private searchData() {
    this.showTable = false;
    this.listData = [];
    const pageIndex = 0;
    const pageOffset = 15;
    this.utilService.showSpinner();
    const searchBolParams = this.getInputParams();
    const countObs: Observable<number> = this.searchSalvageService
      .getSalvageBolReportPageCount(searchBolParams);
    const salvageObs: Observable<SalvageBol[]> = this.searchSalvageService
      .getSalvageBolReportWithPagination(searchBolParams, pageIndex, pageOffset);

    const salvageDataObs: Observable<SalvageData> = countObs.pipe(
      mergeMap((value: number) => {
        let response: SalvageData;
        if (value > 0) {
          return salvageObs.pipe(
            map(bolData => {
              response = {
                count: value,
                data: bolData
              };
              return response;
            })
          );
        } else {
          return Observable.of(null);
        }
      })
    );
    salvageDataObs.subscribe(salvageResult => {
      if (salvageResult != null) {
        this.totalRecords = salvageResult.count;
        this.listData = this.searchSalvageService.conversionOfDateForSearchList(salvageResult.data);
        const dataLength: number = this.listData.length;
        this.showTable = dataLength > 0;
        this.utilService.hideSpinner();
      } else {
        this.showTable = false;
        this.utilService.hideSpinner();
      }
    }, () => {
      this.showTable = false;
      this.utilService.hideSpinner();
    });
  }

  private getInputParams() {
    const searchBolParams = {...this.searchBOLForm.value, ...this.searchParams};
    if (searchBolParams.destination === '') {
      searchBolParams.destination = null;
    }
    if (searchBolParams.salvageMaterialType === '') {
      searchBolParams.salvageMaterialType = null;
    }
    return searchBolParams;
  }

  /* Show print location popup */
  private showPrintLocationDialog(bolId: number) {
    this.singleBol = this.listData.find(data => data.bolId === bolId);
    this.printLocationDialog.printLocationDialog(this.singleBol);
  }

  /* Build print receipt data */
  private displayReceiptData(data): ReceiptData {
    this.receiptData = {...this.singleBol, ...data,  reprintBol: false};
    return SalvageService.getReceiptInfo(data, this.receiptData);
  }

  private displayReceiptDataWithPrintLocation(facility, printLocation): ReceiptData {
    this.receiptData = {...facility, ...this.singleBol, reprintBol: false, printLocation: printLocation};
    return SalvageService.getReceiptInfo(facility, this.receiptData);
  }

  /* Enable Restore Search Bill of Lading Popup*/
  private showRestoreDialog(bolId: number) {
    this.singleBol = this.listData.find(data => data.bolId === bolId);
    this.restoreDialog.showDialog(this.singleBol);
  }

  public onRestoreDialog() {
    this.searchData();
  }

 /*  Enable Delete Search Bill of Lading Popup*/
  private showDeleteDialog(bolId: number) {
    this.singleBol = this.listData.find(data => data.bolId === bolId);
    this.deleteDialog.showDialog(this.singleBol);
  }

  public onDeleteDialog() {
    this.searchData();
  }

  /* Transfer contents from one trailer to another */
  private showTransferDialog(bolId: number) {
    this.singleBol = this.listData.find(data => data.bolId === bolId);
    this.transferDialog.showDialog(this.singleBol, this.facilityData);
  }

  public onTransferDialog() {
    this.searchData();
  }

  /* Edit Popup for Search Bill of lading */
  private showEditDialog(bolId: number) {
    this.singleBol = this.listData.find(data => data.bolId === bolId);
    this.editDialog.showEditDialog(this.singleBol, this.facilityData);
  }

  /* After Edit dialog saved */
  public onEditDialogSaved(data) {
    this.submitPrintData = this.displayReceiptData(data);
    /* [this.reprintBol = false] creates multiple copies for outbound */
    this.showPrintAndPrintPreviewDialog(false);
    this.searchData();
    const toastDetails = {
      title: 'Success',
      message: 'Action has been successfully updated.',
      toastType: 'success'
    };
    this.notificationService.emitMessage.next(toastDetails);
  }

   /* Print Location Popup for Search Bill of lading */
  public onPrintLocationDialogSaved(printLocationData) {
    if (printLocationData && printLocationData.printLocation) {
      const {facility, printLocation} = printLocationData;
      this.submitPrintData = this.displayReceiptDataWithPrintLocation(facility, printLocation);
      this.showPrintAndPrintPreviewDialog(true);
    }
  }

  /* Print Search Bill of lading and show Print Preview */
  private showPrintAndPrintPreviewDialog(previewFlag: boolean) {
    this.printDialog.printDialog(this.submitPrintData);
    if (previewFlag) {
      this.showPrintPreviewDialog();
    }
  }

  /* Show Only Print Preview of Search Bill of lading */
  private showPrintPreviewDialog() {
    this.printDialog.printPreviewDialog(this.submitPrintData, false);
  }

 /* Autocomplete function */
  private autoSearch() {
    const searchBolParams = this.getInputParams();
    this.searchSalvageService.autoCompleteForSearchBOL(searchBolParams).subscribe(res => {
      const { trailerResult, gpsResult } = CreateSalvageService.getAutoCompleteData(res);
      this.trailerResult = trailerResult;
      this.gpsResult = gpsResult;
      });
  }

  public autoCompleteForTrailer(event) {
    const query = event.query;
    this.filterTrailer = UtilService.filterData(query, this.trailerResult);
  }

  public autoCompleteForGps(event) {
    const query = event.query;
    this.filterGps = UtilService.filterData(query, this.gpsResult);
  }

  /* Export to excel reports */
  public exportToExcel(flip) {
    this.flip = !flip;
    this.buildExcelDataReport();
  }

  buildExcelDataReport() {
    let toastDetails: ToastDetails;
    const searchParams = this.getInputParams();
    const excelParams = {...searchParams, period: this.dateRange[2]};
    const type = 'SearchBOL';
    this.excelService.downloadExcelReport(excelParams, `api/salvage/excel/download/${type}`)
      .subscribe(response => {
        if (response && response.body && response.body.size > 0) {
          ExcelService.createExcelFile(response);
        }
        this.flip = true;
      }, (error) => {
        if (error && error.message) {
          toastDetails = ExcelService.displayToastMessage('error',  error);
        } else {
          toastDetails = ExcelService.displayToastMessage('error');
        }
        this.notificationService.emitMessage.next(toastDetails);
        this.flip = true;
      });
  }

  public selectedRow(event, row: SalvageBol, overlayPanel: OverlayPanel ) {
    this.selectedRowData = row;
    overlayPanel.toggle(event);
  }

  /* Action Menu toggles */
  public openBolToggleMenu(event, row: SalvageBol, menuItem: Menu) {
    const item = row.bolId;
    const materialType = row.salvageMaterialType;
    this.menuItems = this.getMenuItemsForOpenBol(item, materialType);
    menuItem.toggle(event);
  }

  public getMenuItemsForOpenBol(item: number, materialType: SalvageMaterialType): MenuItem[] {
    const context = item;
    if (materialType.materialTypeCd === BALED_CARDBOARD) {
      return [
        {
          label: 'Actions',
          items: [
            {label: 'Edit', icon: 'fa fa-fw fa-edit', command: () => this.showEditDialog(context)},
            {label: 'Print', icon: 'fa fa-fw fa-print', command: () => this.showPrintLocationDialog(context)},
            {label: 'Cancel', icon: 'fa fa-fw fa-close', command: () => this.showDeleteDialog(context)},
            {label: 'Transfer', icon: 'fa fa-fw fa-exchange', command: () => this.showTransferDialog(context)}
          ]
        }
      ];
    } else {
      return [
        {
          label: 'Actions',
          items: [
            {label: 'Edit', icon: 'fa fa-fw fa-edit', command: () => this.showEditDialog(context)},
            {label: 'Print', icon: 'fa fa-fw fa-print', command: () => this.showPrintLocationDialog(context)},
            {label: 'Cancel', icon: 'fa fa-fw fa-close', command: () => this.showDeleteDialog(context)},
          ]
        }
      ];
    }
  }

  public closeBolToggleMenu(event, row: SalvageBol, menuItem: Menu) {
    const item = row.bolId;
    this.menuItems = this.getMenuItemsForCloseBol(item);
    menuItem.toggle(event);
  }

  public getMenuItemsForCloseBol(item: number): MenuItem[] {
    const context = item;
    if (this.userService.isCorp() || this.userService.isSupport()) {
      return [
        {
          label: 'Actions',
          items: [
            {label: 'Restore', icon: 'fa fa-fw fa-retweet', command: () => this.showRestoreDialog(context)},
            {label: 'Print', icon: 'fa fa-fw fa-print', command: () => this.showPrintLocationDialog(context)}
          ]
        }
      ];
    } else if (this.userService.isContributor()) {
      return [
        {
          label: 'Actions',
          items: [
            {label: 'Print', icon: 'fa fa-fw fa-print', command: () => this.showPrintLocationDialog(context)}
          ]
        }
      ];
    }
  }

 // Pagination for Bill of Lading table

  loadSalvageData(event: LazyLoadEvent) {
    this.loading = true;
    const pageIndex = event.first;
    const pageOffset = 15;
    const searchBolParams = this.getInputParams();
    setTimeout(() => {
      this.searchSalvageService.getSalvageBolReportWithPagination(searchBolParams, pageIndex, pageOffset).subscribe(result => {
        this.listData = this.searchSalvageService.conversionOfDateForSearchList(result);
        this.loading = false;
      });
    }, TIMEOUT);
    this.changeDetect.detectChanges();
  }

}
