import { MessageService } from 'primeng/api';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {SearchSalvageComponent} from './search-salvage.component';
import {CalendarModule} from '@app/shared/calendar/calendar.module';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { SearchSalvageService } from '../services/search-salvage/search-salvage.service';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {ExcelService} from '@shared/services/excel/excel.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';

describe('SearchSalvageComponent', () => {
  let component: SearchSalvageComponent;
  let fixture: ComponentFixture<SearchSalvageComponent>;
  let userService: UserService;
  let dateService: DateService;
  let excelService: ExcelService;
  let facilityService: FacilityService;
  let validatorService: ValidatorsService;
  let printSalvageService: PrintSalvageService;
  let notificationService: NotificationsService;
  let searchSalvageService: SearchSalvageService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        CalendarModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
      ],
      providers: [
        UserService,
        DateService,
        UtilService,
        ExcelService,
        MessageService,
        FacilityService,
        ValidatorsService,
        PrintSalvageService,
        CreateSalvageService,
        SearchSalvageService
    ],
      declarations: [
        SearchSalvageComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSalvageComponent);
    userService = TestBed.inject(UserService);
    dateService = TestBed.inject(DateService);
    excelService = TestBed.inject(ExcelService);
    facilityService = TestBed.inject(FacilityService);
    validatorService = TestBed.inject(ValidatorsService);
    printSalvageService = TestBed.inject(PrintSalvageService);
    notificationService = TestBed.inject(NotificationsService);
    searchSalvageService = TestBed.inject(SearchSalvageService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
