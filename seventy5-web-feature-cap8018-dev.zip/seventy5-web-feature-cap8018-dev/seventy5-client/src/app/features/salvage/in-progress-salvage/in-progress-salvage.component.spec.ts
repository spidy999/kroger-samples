import { MessageService } from 'primeng/api';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {ReportsModule} from '@shared/reports/reports.module';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { InProgressSalvageComponent } from './in-progress-salvage.component';
import {UtilService} from '@app/shared/services/util/util.service';
import {UserService} from '@app/shared/services/user/user.service';
import {DateService} from '@app/shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {InProgressService} from '@app/features/salvage/services/inProgress/in-progress.service';

describe('InProgressSalvageComponent', () => {
  let component: InProgressSalvageComponent;
  let fixture: ComponentFixture<InProgressSalvageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        ReportsModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [
        InProgressSalvageComponent
      ],
      providers: [
        UserService,
        UtilService,
        DateService,
        MessageService,
        FacilityService,
        InProgressService
      ],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InProgressSalvageComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
