import {Paginator} from 'primeng';
import {SelectItem} from 'primeng/api';
import {Observable} from 'rxjs/Observable';
import {timer} from 'rxjs/observable/timer';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {Constants} from '@app/shared/models/constants';
import {FacilityData} from '@app/shared/domain/facilityData';
import {inProgressBol as constants} from '../models/salvage';
import {Component, Input, OnInit, ViewChild} from '@angular/core';
import { DcSalvageMaterial } from '@app/shared/domain/dcSalvageMaterial';
import {PerformanceDisplay} from '@features/dashboard/models/dashboardData';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@app/shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {InProgressService} from '@app/features/salvage/services/inProgress/in-progress.service';

@Component({
  selector: 'in-progress-salvage',
  templateUrl: './in-progress-salvage.component.html',
  styleUrls: ['./in-progress-salvage.component.less']
})
export class InProgressSalvageComponent implements OnInit {

  @ViewChild('inProgressBolList', {static: false}) paginator: Paginator;
  @Input() facilityData: FacilityData[];
  @Input() facilityItems: SelectItem[];

  public doorsExist = false;
  public dataAvailable = false;
  public selectedDoor: string;
  public totalBale: number;
  public facilityId: number;
  public doorsInProgress: any;
  public baleWithoutWeight: number;
  public facility: FacilityData;
  public listData: DcSalvageMaterial[];
  public baleCount: PerformanceDisplay;
  public unWeighedBaleCount: PerformanceDisplay;
  public cols: Array<{field: string, header: string}> = [];
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor(public userService: UserService,
              private utilService: UtilService,
              private facilityService: FacilityService,
              private inProgressService: InProgressService) {
    const {cols} = constants;
    this.cols = cols;
  }

  ngOnInit() {
    if (this.facilityData) {
      this.facilityId = this.facilityData[0].facilityId;
      this.getDoorsInProgress(this.facilityId);
    }
    this.utilService.hideSpinner();
  }

 /* Load in-progress bol's */
  private searchInProgressBOL() {
    if (this.selectedDoor === undefined) { return; }
    const inProgressBolParams = {
      facilityId: this.facilityId,
      doorNo: this.selectedDoor
    };

    this.utilService.showSpinner();
    forkJoin(
      [this.inProgressService.getDcSalvageMaterialData(inProgressBolParams),
      timer(Constants.SPINNER_TIMEOUT)]
    )
      .subscribe(([res]) => {
          this.utilService.hideSpinner();
          this.listData = this.inProgressService.conversionOfDateForInProgressBOL(res);
          const dataLength: any = this.listData;
          this.dataAvailable = (dataLength.length  >  0);
          if (dataLength.length > 0) {
            this.calculateBaleWithoutWeight(this.listData);
            this.calculateBaleCount(dataLength);
            // to set the paginator to first page
            if (this.paginator) {
              this.paginator.first = 0;
            }
          } else {
            this.baleWithoutWeight = 0;
            this.totalBale = 0;
          }
        });
  }

  /* calculate bale count */
  private calculateBaleCount(data) {
    this.totalBale = data.length;
    this.baleCount = {
      title: 'Bale Count',
      helpText: '',
      performance: this.totalBale,
      headingClass: 'text-positive-400'
    };
  }

  /* calculate bales without weight */
  private calculateBaleWithoutWeight(data) {
   this.baleWithoutWeight = data.reduce((prev, curr) => curr.weight === 0 ? prev + 1 : prev, 0);
   this.unWeighedBaleCount = {
     title: 'Bale W/O Weight',
     helpText: '',
     performance: this.baleWithoutWeight,
     headingClass: 'text-negative-400'
   };
  }

  /* Load doors in progress */
  private getDoorsInProgress(facility: number) {
    this.selectedDoor = null;
    forkJoin([this.inProgressService.getDoorsInProgress({facilityId: facility}),
                     timer(Constants.SPINNER_TIMEOUT)])
      .subscribe(([doorList]) => {
        this.doorsInProgress = doorList.map((door) =>
          ({label: door, value: door}));
        this.doorsExist = (this.doorsInProgress.length > 0);
        if (this.doorsInProgress && this.doorsInProgress.length > 0) {
          this.selectedDoor = this.doorsInProgress[0].value;
          this.searchInProgressBOL();
        }
      });
  }

  /* Refresh data on facility change */
  public onFacilityChange(facility: number) {
    this.getDoorsInProgress(facility);
    this.searchInProgressBOL();
  }

  /* Refresh data on door change */
  public onDoorChange(door) {
    this.selectedDoor = door;
    this.searchInProgressBOL();
  }
}
