import { MessageService } from 'primeng/api';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CloseSalvageComponent} from './close-salvage.component';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {FormControl, FormGroup, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {DateService} from '@shared/services/date/date.service';
import {ModalService} from '@shared/services/modal/modal.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {BarcodeScannerService} from '@features/salvage/services/barcode/barcode-scanner.service';
import {CloseSalvageService} from '@features/salvage/services/close-salvage/close-salvage.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';

describe('CloseSalvageComponent', () => {
  let component: CloseSalvageComponent;
  let userService: UserService;
  let modalService: ModalService;
  let facilityService: FacilityService;
  let validatorService: ValidatorsService;
  let closeBolService: CloseSalvageService;
  let printSalvageService: PrintSalvageService;
  let searchSalvageService: SearchSalvageService;
  let fixture: ComponentFixture<CloseSalvageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        ReactiveFormsModule,
      ],
      providers: [
        UserService,
        UtilService,
        DateService,
        ModalService,
        MessageService,
        FacilityService,
        ValidatorsService,
        CloseSalvageService,
        PrintSalvageService,
        CreateSalvageService,
        SearchSalvageService,
        BarcodeScannerService
      ],
      declarations: [
        CloseSalvageComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloseSalvageComponent);
    component = fixture.componentInstance;
    userService = TestBed.inject(UserService);
    modalService = TestBed.inject(ModalService);
    facilityService = TestBed.inject(FacilityService);
    validatorService = TestBed.inject(ValidatorsService);
    closeBolService = TestBed.inject(CloseSalvageService);
    printSalvageService = TestBed.inject(PrintSalvageService);
    searchSalvageService = TestBed.inject(SearchSalvageService);

    component.closeBOLForm = new FormGroup({
      'materialType': new FormControl(),
      'trailerNo': new FormControl(),
      'bolId': new FormControl()
    });

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
