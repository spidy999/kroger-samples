import {SelectItem} from 'primeng/api';
import {FormGroup} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {timer} from 'rxjs/observable/timer';
import {OverlayPanel, Paginator} from 'primeng';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {Constants} from '@shared/models/constants';
import {DateRange} from '@shared/models/reportData';
import {SearchBolData} from '@shared/models/searchBolData';
import {FacilityData} from '@app/shared/domain/facilityData';
import { SalvageBol } from '@features/salvage/domain/salvageBol';
import {closeSalvage as constants, SalvageTab} from '../models/salvage';
import {CloseSalvageService} from '../services/close-salvage/close-salvage.service';
import {AfterViewInit, Component, HostListener, Input, OnInit, ViewChild} from '@angular/core';
import {UtilService} from '@shared/services/util/util.service';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';
import {BarcodeScannerService, BarcodeScanner} from '@features/salvage/services/barcode/barcode-scanner.service';
import {CloseDialogComponent} from '@features/salvage/dialogs/close-dialog/close-dialog.component';

@Component({
  selector: 'app-close-salvage-bol',
  templateUrl: './close-salvage.component.html',
  styleUrls: ['./close-salvage.component.less'],
})
export class CloseSalvageComponent implements OnInit, AfterViewInit {

  @ViewChild('searchBolNo', {static: false}) bolSearchBox;
  @ViewChild('closeTrailerNo', {static: false}) trailerSearchBox;
  @ViewChild('closeBolList', {static: false}) paginator: Paginator;
  @ViewChild(CloseDialogComponent, {static: false}) closeDialog: CloseDialogComponent;
  @Input() facilityData: FacilityData[];
  @Input() facilityItems: SelectItem[];
  @Input() public salvageType: SalvageTab;

  public showTable = false;
  public dataAvailable = false;
  public showingAllOpen = true;
  public cols: any = [];
  public gpsResult: any = [];
  public updatedEuid: any = [];
  public trailerResult: any = [];
  public filterTrailer: any = [];
  public facilityId: number;
  public message: string;
  public loaderMessage: string;
  public dates: DateRange;
  public closeBOLForm: FormGroup;
  public singleBol: SalvageBol;
  public salvageData: SalvageBol[];
  public selectedRowData: SalvageBol;
  public searchOptions: SelectItem[];
  public selectedSalvageTab = SalvageTab;
  private barcodeScanner: BarcodeScanner;
  public materialTypes$ = this.closeSalvageService.getMaterialTypes();
  public spinner$: Observable<boolean> = this.utilService.getSpinner();

  constructor( public userService: UserService,
               private dateService: DateService,
               private utilService: UtilService,
               private validator: ValidatorsService,
               private facilityService: FacilityService,
               private salvageService: CreateSalvageService,
               private closeSalvageService: CloseSalvageService,
               public notificationService: NotificationsService,
               private searchSalvageService: SearchSalvageService) {
    const {cols, searchOptions} = constants;
    this.cols = cols;
    this.searchOptions = searchOptions;
  }

  ngOnInit() {
    this.loaderMessage = 'Loading...';
    this.utilService.hideSpinner();
    this.createForm();
  }

  ngAfterViewInit() {
    this.barcodeScanner = BarcodeScannerService.createScanner(null);
    this.barcodeScanner.addTarget({prefix: 'bol', target: this.bolSearchBox.el});
    this.barcodeScanner.addTarget({prefix: 'trl', target: this.trailerSearchBox.el});
  }

  @HostListener('document:keypress', ['$event'])
  onKeyPress(event) {
    if (this.barcodeScanner) {
      this.barcodeScanner.onKeyPress(event);
    }
  }

  private createForm() {
    this.closeBOLForm = this.closeSalvageService.searchForm(this.bolSearchBox, this.trailerSearchBox);
    this.closeBOLForm.controls['facilityId'].setValue(this.facilityItems[0].value, {onlySelf: true});
    this.closeBOLForm.controls['searchType'].setValue('bolId');
    this.dates = DateService.getLast24hours();
    this.updatedEuid = { updatedEuid: this.userService.getUserEuid() };
    this.searchAllOpen(null);
    this.closeBOLForm.get('facilityId').valueChanges.subscribe(facility => {
      this.autoSearch(facility);
      }
    );
  }

  /* Executes on scanning bol Number */
  public onBolNoScanned(event) {
    this.closeBOLForm.get('bolId').setValue(event.detail);
    this.closeBolSearch();
  }

  /* Executes on scanning Trailer Number */
  public onTrailerNoScanned(event) {
    this.closeBOLForm.get('trailerNo').setValue(event.detail);
    this.closeBolSearch();
  }

  /* Search all the open Bol's */
  public searchAllOpen(event) {
    if (event) {
      event.preventDefault();
    }
    this.showTable = true;
    this.showingAllOpen = true;
    this.utilService.showSpinner();
    this.facilityId = this.closeBOLForm.get('facilityId').value;
    switch (this.salvageType) {
      case SalvageTab.CLOSE_BOL:
        forkJoin(
          [this.closeSalvageService.closeBolSearchForOpen(this.facilityId),
          timer(Constants.SPINNER_TIMEOUT)]
        )
          .subscribe(([res]) => {
            this.utilService.hideSpinner();
            this.processCloseBolSearchResponse(res);
          });
        break;
      case SalvageTab.CLOSE_PT:
        forkJoin(
          [this.closeSalvageService.closePullTicketSearchForOpen(this.facilityId),
          timer(Constants.SPINNER_TIMEOUT)]
        )
          .subscribe(([res]) => {
            this.utilService.hideSpinner();
            this.processCloseBolSearchResponse(res);
          });
        break;
    }
  }

  public closeBolSearch() {
    this.showingAllOpen = true;
    this.loaderMessage = 'Updating...';
    const data = {
      euid: this.userService.getUserEuid(),
      facilityId: Number(this.closeBOLForm.get('facilityId').value)
    };
    let searchObj: SalvageBol;
    searchObj = {...this.closeBOLForm.getRawValue() };
    if (this.closeBOLForm.get('salvageMaterialType').value === '') {
      searchObj.salvageMaterialType = {materialTypeCd: null, materialTypeName: null};
    }
    const Params = {...searchObj, ...data, ...this.dates};
    this.getCloseBolData(Params);
  }

 /* To display list of BOL's */
  private getCloseBolData(param) {
    this.showTable = true;
    this.utilService.showSpinner();
    switch (this.salvageType) {
      case SalvageTab.CLOSE_BOL:
        forkJoin(
          [this.searchSalvageService.closeBolSearch(param),
          timer(Constants.SPINNER_TIMEOUT)]
        )
          .subscribe(([res]) => {
              this.utilService.hideSpinner();
              this.processCloseBolSearchResponse(res);
            },
            () => {
              this.utilService.hideSpinner();
            });
        break;
      case SalvageTab.CLOSE_PT:
        forkJoin(
          [this.closeSalvageService.closeBolPullTicketSearch(param),
          timer(Constants.SPINNER_TIMEOUT)]
        )
          .subscribe(([res]) => {
              this.utilService.hideSpinner();
              this.processCloseBolSearchResponse(res);
            },
            () => {
              this.utilService.hideSpinner();
            });
        break;
    }
  }

  private processCloseBolSearchResponse( response: SalvageBol[] ) {
        this.salvageData = response;
        this.conversionOfDateForCloseBolList();

        // to set the paginator to first page
        if (this.paginator) {
          this.paginator.first = 0;
        }
        this.dataAvailable = (response.length > 0);
  }

  // conversion of given date into '2018-11-19 10:47 AM' Format
  private conversionOfDateForCloseBolList() {
    this.salvageData.forEach((data) => {
      data.insertedDate = DateService.getDateForRequest(data.insertedDate);
      data.updatedDate = DateService.getDateForRequest(data.updatedDate);
    });
  }

  // To update GpsId or TrailerNo
  public onCloseDialogSaved(salvageData: SalvageBol) {
      this.getCloseBolData(salvageData);
      this.showingAllOpen = false;
  }

  public showCloseDialog(bolId) {
    this.singleBol =  this.salvageData.find(single => single.bolId === bolId);
    this.closeDialog.showDialog(this.singleBol);
  }

  private autoSearch(facility) {
    const params: SearchBolData = {
        ...this.dates,
        facilityId:   facility ? facility : this.closeBOLForm.get('facilityId').value
      };
    this.utilService.showSpinner();
    forkJoin(
      [this.searchSalvageService.getGPSandTrailerId(params),
      timer(Constants.SPINNER_TIMEOUT)]
    )
      .subscribe(([res]) => {
        this.utilService.hideSpinner();
        const { trailerResult, gpsResult } = CreateSalvageService.getAutoCompleteData(res);
        this.trailerResult = trailerResult;
        this.gpsResult = gpsResult;
      });
  }

  public autoCompleteForTrailer(event) {
    const query = event.query;
    this.filterTrailer = UtilService.filterData(query, this.trailerResult);
  }

  public selectedRow(event, row: SalvageBol, overlay: OverlayPanel) {
    this.selectedRowData = row;
    overlay.toggle(event);
  }

}
