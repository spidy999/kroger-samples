import {FormGroup} from '@angular/forms';
import {FacilityData} from '@shared/domain/facilityData';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {Component, EventEmitter, Output} from '@angular/core';
import {FacilityService} from '@shared/services/facility/facility.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';

@Component({
  selector: 'app-print-location-dialog',
  templateUrl: './print-location-dialog.component.html',
  styleUrls: ['./print-location-dialog.component.less']
})
export class PrintLocationDialogComponent  {

  @Output() saved = new EventEmitter<{facility: FacilityData, printLocation: string}>();
  public bolData: SalvageBol;
  public showDialogFlag: boolean;
  public printerLocationForm: FormGroup;
  public printerLocations$ = this.printService.getPrinterLocations();

  constructor(private printService: PrintSalvageService,
              private facilityService: FacilityService) {
    this.printerLocationForm = this.printService.createForm();
  }

  public printLocationDialog(printLocationData: SalvageBol) {
    this.bolData = printLocationData;
    this.printService.getLocationPerFacility(this.bolData.facilityId);
    this.showDialogFlag = true;
  }

  public saveChanges(flag: boolean, event) {
    event.preventDefault();
    if (flag) {
      if (this.bolData) {
        this.bolData.printLocation = this.printerLocationForm.value.printLocation;
        this.facilityService.getFacilityDataById(this.bolData.facilityId)
          .subscribe(facility => {
            this.saved.emit({facility: facility, printLocation : this.bolData.printLocation});
          });
      }
    }
    this.printerLocationForm.reset();
    this.printerLocationForm.markAsPristine();
    this.showDialogFlag = false;
  }
}
