import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EditSalvageDialogComponent } from './edit-salvage-dialog.component';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';

describe('EditSalvageDialogComponent', () => {
  let component: EditSalvageDialogComponent;
  let userService: UserService;
  let utilService: UtilService;
  let facilityService: FacilityService;
  let createSalvageService: CreateSalvageService;
  let searchSalvageService: SearchSalvageService;
  let notificationsService: NotificationsService;
  let fixture: ComponentFixture<EditSalvageDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ EditSalvageDialogComponent ],
      providers: [
        UserService,
        UtilService,
        FacilityService,
        NotificationsService,
        SearchSalvageService,
        CreateSalvageService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditSalvageDialogComponent);
    userService = TestBed.inject(UserService);
    utilService = TestBed.inject(UtilService);
    facilityService = TestBed.inject(FacilityService);
    createSalvageService = TestBed.inject(CreateSalvageService);
    searchSalvageService = TestBed.inject(SearchSalvageService);
    notificationsService = TestBed.inject(NotificationsService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
