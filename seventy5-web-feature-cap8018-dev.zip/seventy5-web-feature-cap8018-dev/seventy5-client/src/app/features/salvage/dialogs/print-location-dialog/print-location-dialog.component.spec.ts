import {PrimengModule} from '@shared/primeng/primeng.module';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PrintLocationDialogComponent } from './print-location-dialog.component';
import {FacilityService} from '@shared/services/facility/facility.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';

describe('PrintLocationDialogComponent', () => {
  let component: PrintLocationDialogComponent;
  let facilityService: FacilityService;
  let printSalvageService: PrintSalvageService;
  let fixture: ComponentFixture<PrintLocationDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ PrintLocationDialogComponent ],
      providers: [
        FacilityService,
        PrintSalvageService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintLocationDialogComponent);
    facilityService = TestBed.inject(FacilityService);
    printSalvageService = TestBed.inject(PrintSalvageService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
