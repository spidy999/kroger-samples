import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { TransferSalvageDialogComponent } from './transfer-salvage-dialog.component';
import {UserService} from '@shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

describe('TransferSalvageDialogComponent', () => {
  let component: TransferSalvageDialogComponent;
  let fixture: ComponentFixture<TransferSalvageDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ TransferSalvageDialogComponent ],
      providers: [
        UserService,
        FacilityService,
        CreateSalvageService,
        NotificationsService,
        SearchSalvageService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferSalvageDialogComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
