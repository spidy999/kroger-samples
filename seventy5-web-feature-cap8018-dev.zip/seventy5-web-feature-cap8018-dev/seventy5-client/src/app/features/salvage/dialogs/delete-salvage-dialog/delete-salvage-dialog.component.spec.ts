import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteSalvageDialogComponent } from './delete-salvage-dialog.component';
import {UserService} from '@shared/services/user/user.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

describe('DeleteSalvageDialogComponent', () => {
  let component: DeleteSalvageDialogComponent;
  let userService: UserService;
  let searchSalvageService: SearchSalvageService;
  let notificationsService: NotificationsService;
  let fixture: ComponentFixture<DeleteSalvageDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ DeleteSalvageDialogComponent ],
      providers: [
        UserService,
        NotificationsService,
        SearchSalvageService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]

    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteSalvageDialogComponent);
    userService = TestBed.inject(UserService);
    searchSalvageService = TestBed.inject(SearchSalvageService);
    notificationsService = TestBed.inject(NotificationsService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
