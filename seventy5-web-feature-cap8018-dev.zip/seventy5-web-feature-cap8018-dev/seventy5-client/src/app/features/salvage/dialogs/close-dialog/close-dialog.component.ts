import {SelectItem} from 'primeng/api';
import {FormGroup} from '@angular/forms';
import {timer} from 'rxjs/observable/timer';
import {forkJoin} from 'rxjs/observable/forkJoin';
import {Constants} from '@shared/models/constants';
import {DateRange} from '@shared/models/reportData';
import {ToastDetails} from '@shared/models/Notification';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {closeSalvage as constants} from '@features/salvage/models/salvage';
import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {CloseSalvageService} from '@features/salvage/services/close-salvage/close-salvage.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

@Component({
  selector: 'app-close-dialog',
  templateUrl: './close-dialog.component.html',
  styleUrls: ['./close-dialog.component.less']
})
export class CloseDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<SalvageBol>();
  @Input() dates: DateRange;
  public bolData: SalvageBol;
  public options: SelectItem[];
  public showDialogFlag: boolean;
  public closeBOLForm: FormGroup;
  public completeBolForm: FormGroup;
  constructor(public user: UserService,
              private validator: ValidatorsService,
              private searchSalvageService: SearchSalvageService,
              private notificationService: NotificationsService,
              private closeSalvageService: CloseSalvageService) {
    const { options } = constants;
    this.options = options;
  }

  ngOnInit() {
    this.createCloseForm();
    this.completeBolForm = this.closeSalvageService.completeForm();
  }

  private createCloseForm() {
    this.closeBOLForm = this.closeSalvageService.closeForm();
  }

  showDialog(salvageData: SalvageBol) {
    this.bolData = salvageData;
    this.showDialogFlag = true;
  }


  // To update GpsId or TrailerNo
  saveChanges(flag: boolean, event) {
    event.preventDefault();
    if (flag) {
      this.bolData.status = SalvageBolStatus.CLOSED;
      this.bolData.updatedEuid = this.user.getUserEuid();
      this.closeSalvageBol();
    }
    this.showDialogFlag = false;
    this.createCloseForm();
  }

  private closeSalvageBol() {
    let toastDetails: ToastDetails;
    let updatedBolData: SalvageBol;

    if (this.bolData) {
      const {bolId, facilityId, doorNo, salvageMaterialType,
        salvageQty, referenceNo, comments, destination, trailerNo, gpsId} = this.bolData;
      this.completeBolForm.setValue({
        bolId,
        facilityId,
        doorNo,
        salvageMaterialType: salvageMaterialType,
        salvageQty,
        referenceNo:  referenceNo ? referenceNo : null,
        comments:     comments ? comments : null,
        destination:  destination ? destination : null,
        trailerNo:    this.closeBOLForm.get('trailerNo').value ?
                      this.closeBOLForm.get('trailerNo').value : trailerNo || null,
        gpsId:        this.closeBOLForm.get('gpsId').value ?
                      this.closeBOLForm.get('gpsId').value : gpsId || null,
      });

      updatedBolData = {... this.completeBolForm.value, ... this.dates};
      if (this.closeBOLForm) {
        updatedBolData = {... updatedBolData,
          errorCategory: this.closeBOLForm.get('category').value,
          updatedEuid: this.user.getUserEuid()
        };
      }
      this.searchSalvageService.updateBolSalvage(updatedBolData).subscribe(() => {
        this.updateSalvageBolStatus(updatedBolData);
        toastDetails = {
          title: 'Success',
          message: 'Action has been successfully updated',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Action is incomplete.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
  }

  private updateSalvageBolStatus(data) {
    forkJoin([
      this.searchSalvageService.updateSalvageBolStatus(this.bolData),
      timer(Constants.SPINNER_TIMEOUT)
    ])
      .subscribe(() => {
        this.saved.emit({...this.bolData, ...data});
        this.showDialogFlag = false;
      });
  }
}
