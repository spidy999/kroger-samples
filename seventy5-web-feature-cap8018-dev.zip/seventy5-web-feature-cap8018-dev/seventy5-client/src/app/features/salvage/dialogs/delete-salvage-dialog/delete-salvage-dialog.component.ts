import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {Component, EventEmitter, Output} from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

@Component({
  selector: 'app-delete-salvage-dialog',
  templateUrl: './delete-salvage-dialog.component.html',
  styleUrls: ['./delete-salvage-dialog.component.less']
})
export class DeleteSalvageDialogComponent {

  @Output() saved = new EventEmitter<{}>();
  public bolData: SalvageBol;
  public showDialogFlag: boolean;

  constructor(private userService: UserService,
              private notificationService: NotificationsService,
              private searchSalvageService: SearchSalvageService) { }

  public showDialog(salvageData: SalvageBol) {
    this.bolData = salvageData;
    this.showDialogFlag = true;
  }

  public deleteBolData(flag: boolean, event) {
    event.preventDefault();
    if (flag) {
      this.bolData.status = SalvageBolStatus.CANCELED;
      const bolData = {... this.bolData, updatedEuid: this.userService.getUserEuid() };
      this.deleteSalvageBol(bolData);
    }
    this.showDialogFlag = false;
  }

  private deleteSalvageBol(data) {
    this.searchSalvageService.updateSalvageBolStatus(data).subscribe(() => {
      this.saved.emit({});
      const toastDetails = {
        title: 'Success',
        message: 'Action has been successfully updated.',
        toastType: 'success'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }
}
