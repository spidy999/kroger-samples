import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { PrintDialogComponent } from './print-dialog.component';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';

describe('PrintDialogComponent', () => {
  let component: PrintDialogComponent;
  let printSalvageService: PrintSalvageService;
  let notificationsService: NotificationsService;
  let fixture: ComponentFixture<PrintDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ PrintDialogComponent ],
      providers: [
       PrintSalvageService,
       NotificationsService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintDialogComponent);
    printSalvageService = TestBed.inject(PrintSalvageService);
    notificationsService = TestBed.inject(NotificationsService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
