import {SelectItem} from 'primeng/api';
import {FormGroup} from '@angular/forms';
import {select, Store} from '@ngrx/store';
import {AppState} from '@app/root-store/app.reducer';
import {FacilityData} from '@shared/domain/facilityData';
import {ReceiptData} from '@features/salvage/models/salvage';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {UtilService} from '@shared/services/util/util.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {getFacilityItems} from '@app/root-store/facility-info/facility-info.selector';
import {EditSalvageService} from '@features/salvage/services/edit-salvage/edit-salvage.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

const RNS = 'RN';
const OTHERS = 'O';
const LOOSE_PLASTIC = 'LP';
const BALED_CARDBOARD = 'BC';
const LOOSE_CARDBOARD = 'LC';
const DONATIONS_RECLAIM = 'DC';

@Component({
  selector: 'app-edit-salvage-dialog',
  templateUrl: './edit-salvage-dialog.component.html',
  styleUrls: ['./edit-salvage-dialog.component.less']
})
export class EditSalvageDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<ReceiptData>();
  public showDialogFlag: boolean;
  public bolData: SalvageBol;
  public facilityId: number;
  public receiptData: ReceiptData;
  public facilityData: FacilityData[];
  public facilityItems: SelectItem[];
  public editSalvageForm: FormGroup;
  public updatedFacility: string;
  public doors$ = this.editSalvageService.getDoors();
  public destinations$ = this.editSalvageService.getDestinations();
  public materialTypes$ = this.editSalvageService.getMaterialTypes();
  public printerLocations$ = this.editSalvageService.getPrinterLocations();
  public materialConst = {
    BALED_CARDBOARD,
    LOOSE_CARDBOARD,
    LOOSE_PLASTIC,
    RNS,
    DONATIONS_RECLAIM,
    OTHERS
  };

  constructor(public user: UserService,
              public utilService: UtilService,
              private facilityService: FacilityService,
              private readonly store: Store<AppState>,
              private editSalvageService: EditSalvageService,
              private searchSalvageService: SearchSalvageService) {
  }

  ngOnInit() {
    this.store.pipe(select(getFacilityItems)).subscribe(facilities => {
      this.facilityItems = facilities;
    });
  }

  public showEditDialog(salvageData: SalvageBol, facilityData: FacilityData[]) {
    this.bolData = salvageData;
    this.facilityData = facilityData;
    if (salvageData && salvageData.facilityId) {
      this.editSalvageForm = this.editSalvageService.editForm(salvageData);
      this.showDialogFlag = true;
    }
  }

  public checkInputKey(event) {
    return UtilService.checkKey(event);
  }

  public saveChanges(flag: boolean, event) {
    let submitSalvageDetails: any;
    event.preventDefault();
    if (flag) {
      const facility = this.facilityData.find((data) => data.facilityId === this.bolData.facilityId);
      const type = this.editSalvageForm.get('salvageMaterialType').value;
      switch (type) {
        case LOOSE_CARDBOARD:
        case LOOSE_PLASTIC:
        case RNS:
        case DONATIONS_RECLAIM:
        case OTHERS:
          this.editSalvageForm.get('salvageQty').setValue(0);
          break;
      }
      const {salvageMaterialType} = this.bolData;

      if (type === BALED_CARDBOARD) {
        submitSalvageDetails = {
          ... this.editSalvageForm.getRawValue(),
          salvageMaterialType: salvageMaterialType,
          facilityId: this.bolData.facilityId,
          updatedEuid: this.user.getUserEuid(),
          salvageQty: this.bolData.salvageQty,
          destination: this.editSalvageForm.get('destination').value !== '' ?
            this.editSalvageForm.get('destination').value : this.bolData.destination
        };
      } else {
        submitSalvageDetails = {
          ... this.editSalvageForm.getRawValue(),
          salvageMaterialType: salvageMaterialType,
          facilityId: this.bolData.facilityId,
          updatedEuid: this.user.getUserEuid(),
        };
      }
      this.receiptData = {...facility, ...submitSalvageDetails};
      this.searchSalvageService.updateBolSalvage(submitSalvageDetails).subscribe(() => {
        this.updatedFacility = this.editSalvageForm.getRawValue().facilityId;
        this.saved.emit(this.receiptData);
      });
    }
    this.editSalvageForm.reset();
    this.editSalvageForm.markAsPristine();
    this.showDialogFlag = false;
  }
}
