import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import { CloseDialogComponent } from './close-dialog.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {UserService} from '@shared/services/user/user.service';
import {ValidatorsService} from '@shared/services/validators/validators.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {CloseSalvageService} from '@features/salvage/services/close-salvage/close-salvage.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

describe('CloseDialogComponent', () => {
  let component: CloseDialogComponent;
  let userService: UserService;
  let validatorsService: ValidatorsService;
  let closeSalvageService: CloseSalvageService;
  let searchSalvageService: SearchSalvageService;
  let notificationsService: NotificationsService;
  let fixture: ComponentFixture<CloseDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ CloseDialogComponent ],
      providers: [
        UserService,
        ValidatorsService,
        SearchSalvageService,
        NotificationsService,
        CloseSalvageService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloseDialogComponent);
    userService = TestBed.inject(UserService);
    validatorsService = TestBed.inject(ValidatorsService);
    closeSalvageService = TestBed.inject(CloseSalvageService);
    searchSalvageService = TestBed.inject(SearchSalvageService);
    notificationsService = TestBed.inject(NotificationsService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
