import {Component} from '@angular/core';
import {ToastDetails} from '@shared/models/Notification';
import {ReceiptData} from '@features/salvage/models/salvage';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {PrintSalvageService} from '@features/salvage/services/print-salvage/print-salvage.service';

const RNS = 'RN';
const OTHERS = 'O';
const LOOSE_PLASTIC = 'LP';
const BALED_CARDBOARD = 'BC';
const LOOSE_CARDBOARD = 'LC';
const DONATIONS_RECLAIM = 'DC';

@Component({
  selector: 'app-print-dialog',
  templateUrl: './print-dialog.component.html',
  styleUrls: ['./print-dialog.component.less']
})
export class PrintDialogComponent {

  public showDialogFlag: boolean;
  public dateOfInvoiceFlag: boolean;
  public printData: ReceiptData = new ReceiptData();
  public materialConst = {
    BALED_CARDBOARD,
    LOOSE_CARDBOARD,
    LOOSE_PLASTIC,
    RNS,
    DONATIONS_RECLAIM,
    OTHERS
  };
  constructor(private printSalvageService: PrintSalvageService,
              private notificationService: NotificationsService) { }

  printPreviewDialog(printData: ReceiptData, dateOfInvoiceFlag: boolean) {
    this.printData = printData;
    this.dateOfInvoiceFlag = dateOfInvoiceFlag;
    this.showDialogFlag = true;
  }

  printDialog(printData: ReceiptData) {
    this.printSalvageBolReceipt(printData);
  }

  private printSalvageBolReceipt(data) {
    let toastDetails: ToastDetails;
    this.printSalvageService.printSalvageBolReceipt(data)
      .subscribe(() => {
        toastDetails = {
          title: 'Success',
          message: 'Print Successful.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      }, () => {
        toastDetails = {
          title: 'Failure',
          message: 'Printer is offline.',
          toastType: 'error'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
  }
}
