import {FormGroup} from '@angular/forms';
import {FacilityData} from '@shared/domain/facilityData';
import {TransferBolData} from '@shared/models/searchBolData';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {FacilityService} from '@shared/services/facility/facility.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';
import {CreateSalvageService} from '@features/salvage/services/create-salvage/create-salvage.service';
import {TransferSalvageService} from '@features/salvage/services/transfer-salvage/transfer-salvage.service';

@Component({
  selector: 'app-transfer-salvage-dialog',
  templateUrl: './transfer-salvage-dialog.component.html',
  styleUrls: ['./transfer-salvage-dialog.component.less']
})
export class TransferSalvageDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<{}>();
  public bolData: SalvageBol;
  public showDialogFlag: boolean;
  public facilityData: FacilityData[];
  public transferBolForm: FormGroup;
  public transferData: TransferBolData = new TransferBolData();
  public doors$ = this.transferSalvageService.getDoors();
  public totalQty$ = this.transferSalvageService.getTotalQty();
  public MaxQty$ = this.transferSalvageService.getMaxQty();

  constructor(private userService: UserService,
              private facilityService: FacilityService,
              private createSalvageService: CreateSalvageService,
              private transferSalvageService: TransferSalvageService,
              private notificationService: NotificationsService,
              private searchSalvageService: SearchSalvageService) {
  }

  ngOnInit() {
    this.transferBolForm = this.transferSalvageService.transferForm();
  }

  public showDialog(salvageData: SalvageBol, facilityData: FacilityData[]) {
    this.bolData = salvageData;
    this.facilityData = facilityData;
    if (salvageData && salvageData.facilityId) {
      this.transferSalvageService.getDataPerFacility(salvageData);
      this.showDialogFlag = true;
    }
  }

  public transferBolData(flag: boolean, event) {
    event.preventDefault();
    if (flag) {
      this.transferData = {
        bolId: this.bolData.bolId,
        euid: this.userService.getUserEuid(),
        ...this.transferBolForm.value
      };
      const param = { ... this.transferData };
      this.searchSalvageService.transferBOLData(param).subscribe(() => {
        this.saved.emit({});
        const toastDetails = {
          title: 'Success',
          message: 'Action has been successfully updated.',
          toastType: 'success'
        };
        this.notificationService.emitMessage.next(toastDetails);
      });
    }
    this.showDialogFlag = false;
    this.transferBolForm.reset();
  }

}
