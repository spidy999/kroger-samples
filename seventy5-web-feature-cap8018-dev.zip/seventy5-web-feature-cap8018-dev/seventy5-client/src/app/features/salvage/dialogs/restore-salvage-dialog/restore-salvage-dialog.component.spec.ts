import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {KrogerNgAuthModule} from 'kroger-ng-oauth2';
import {PrimengModule} from '@shared/primeng/primeng.module';
import {RouterTestingModule} from '@angular/router/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RestoreSalvageDialogComponent } from './restore-salvage-dialog.component';
import {UserService} from '@shared/services/user/user.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

describe('RestoreSalvageDialogComponent', () => {
  let component: RestoreSalvageDialogComponent;
  let fixture: ComponentFixture<RestoreSalvageDialogComponent>;
  let userService: UserService;
  let notificationService: NotificationsService;
  let searchSalvageService: SearchSalvageService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PrimengModule,
        KrogerNgAuthModule,
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ RestoreSalvageDialogComponent ],
      providers: [
        UserService,
        NotificationsService,
        SearchSalvageService
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestoreSalvageDialogComponent);
    userService = TestBed.inject(UserService);
    notificationService = TestBed.inject(NotificationsService);
    searchSalvageService = TestBed.inject(SearchSalvageService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy();
  });
});
