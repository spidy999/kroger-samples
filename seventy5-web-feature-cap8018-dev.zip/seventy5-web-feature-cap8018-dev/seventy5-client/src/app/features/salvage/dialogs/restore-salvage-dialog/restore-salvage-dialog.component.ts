import {SalvageBolStatus} from '@shared/domain/salvageBolStatus';
import {SalvageBol} from '@features/salvage/domain/salvageBol';
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {UserService} from '@shared/services/user/user.service';
import {NotificationsService} from '@shared/services/notifications/notifications.service';
import {SearchSalvageService} from '@features/salvage/services/search-salvage/search-salvage.service';

@Component({
  selector: 'app-restore-salvage-dialog',
  templateUrl: './restore-salvage-dialog.component.html',
  styleUrls: ['./restore-salvage-dialog.component.less']
})
export class RestoreSalvageDialogComponent implements OnInit {

  @Output() saved = new EventEmitter<{}>();
  public showDialogFlag: boolean;
  public bolData: SalvageBol;
  constructor(private userService: UserService,
              private notificationService: NotificationsService,
              private searchSalvageService: SearchSalvageService) { }

  ngOnInit() {}

  public showDialog(salvageData: SalvageBol) {
    this.bolData = salvageData;
    this.showDialogFlag = true;
  }

  public restoreBolData(flag: boolean, event) {
    event.preventDefault();
    if (flag) {
      this.bolData.status = SalvageBolStatus.RESTORE;
      const bolData = {... this.bolData, updatedEuid: this.userService.getUserEuid() };
      this.restoreSalvageBol(bolData);
    }
    this.showDialogFlag = false;
  }

  private restoreSalvageBol(data) {
    this.searchSalvageService.updateSalvageBolStatus(data).subscribe(() => {
      this.saved.emit({});
      const toastDetails = {
        title: 'Success',
        message: 'Action has been successfully updated.',
        toastType: 'success'
      };
      this.notificationService.emitMessage.next(toastDetails);
    });
  }
}
