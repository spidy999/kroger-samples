import {SelectItem} from 'primeng';
import {Subject} from 'rxjs/Subject';
import { MenuItem } from 'primeng/api';
import {takeUntil} from 'rxjs/operators';
import {select, Store} from '@ngrx/store';
import {Dates} from '@shared/models/dateRange';
import {DateRange} from '@shared/models/reportData';
import {AppState} from '@app/root-store/app.reducer';
import {Component, OnDestroy, OnInit} from '@angular/core';
import {SalvageTab} from '@features/salvage/models/salvage';
import {CalendarType} from '@shared/models/calendarType';
import {FacilityData} from '@shared/domain/facilityData';
import {UserService} from '@shared/services/user/user.service';
import {DateService} from '@shared/services/date/date.service';
import {UtilService} from '@shared/services/util/util.service';
import {SalvageTabs as constants} from '@features/salvage/models/salvage';
import {getFacilitiesInfo, getFacilityItems} from '@app/root-store/facility-info/facility-info.selector';

@Component({
  selector: 'app-salvage',
  templateUrl: './salvage.component.html',
  styleUrls: ['./salvage.component.less']
})
export class SalvageComponent implements OnInit, OnDestroy {

  public selectionType: SalvageTab;
  public dateRangeDisplay: DateRange;
  public availableOptions: MenuItem[];
  public selectedOptionType = SalvageTab;
  public selectedSalvageType = SalvageTab;
  public facilityData: FacilityData[] = [];
  public facilityItems: SelectItem[] = [];
  public selectedCalendarType = CalendarType;
  private destroy: Subject<boolean> = new Subject<boolean>();

  constructor(public userService: UserService,
              public utilService: UtilService,
              private dateService: DateService,
              private readonly store: Store<AppState>) {
  }

  ngOnInit() {
    this.store.pipe(select(getFacilitiesInfo), takeUntil(this.destroy)).subscribe(facilities => {
      this.facilityData = facilities;
    });
    this.store.pipe(select(getFacilityItems), takeUntil(this.destroy)).subscribe(items => {
      this.facilityItems = items;
    });
    this.extractDates();
    this.buildSubTabs();
  }

  private extractDates() {
    this.dateService.getCalendar().pipe(takeUntil(this.destroy)).subscribe((response: Dates) => {
      const {startDate, stopDate, period} = response;
      this.dateRangeDisplay = {startDate, endDate: stopDate, period: period};
    });
  }

  private buildSubTabs() {
    const { guardUserTabs, otherUserTabs } = constants;
    if (this.userService.isGuard()) {
      this.selectionType = this.selectedOptionType.CLOSE_BOL;
      this.availableOptions = guardUserTabs;
    } else {
      this.selectionType = this.selectedOptionType.SEARCH_BOL;
      this.availableOptions = otherUserTabs;
    }
  }

  public tabChange(evt) {
    if (evt) {
      const detail = evt.detail;
      switch (detail) {
        case 0:
          this.selectionType = this.selectedOptionType.SEARCH_BOL;
          break;
        case 1:
          this.selectionType = this.selectedOptionType.CREATE_BOL;
          break;
        case 2:
          this.selectionType = this.selectedOptionType.CLOSE_BOL;
          break;
        case 3:
          this.selectionType = this.selectedOptionType.CLOSE_PT;
          break;
        case 4:
          this.selectionType = this.selectedOptionType.IN_PROGRESS_BOL;
          break;
      }
    }
  }

  ngOnDestroy() {
    this.destroy.next(true);
    this.destroy.unsubscribe();
  }
}
