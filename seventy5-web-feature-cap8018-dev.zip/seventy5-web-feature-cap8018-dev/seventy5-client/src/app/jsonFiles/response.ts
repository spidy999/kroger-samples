export const RESPONSEMSG: any[] = [
  {'exitStatus' : 'SUCCESS', 'message' : ['Survey values successfully saved']}
];
