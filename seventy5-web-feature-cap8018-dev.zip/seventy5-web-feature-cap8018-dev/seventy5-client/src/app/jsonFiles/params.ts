export const PARAMS: any [] =  [
  {'division': '014', 'facility': '00430'},
  {'division': '014', 'facility': '00945'},
  {'division': '014', 'facility': '00429'},
  {'division': '014', 'facility': '00410'},
  {'division': '014', 'facility': '00383'},
  {'division': '014', 'facility': '00441'},
  {'division': '014', 'facility': '00942'},
  {'division': '014', 'facility': '00353'},
  {'division': '014', 'facility': '00465'}
  ];
