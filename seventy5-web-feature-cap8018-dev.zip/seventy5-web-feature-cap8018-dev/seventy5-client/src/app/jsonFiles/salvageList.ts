export const SALVAGELIST: any[] = [
  {bolNo: '012', facilityId: '4587', trailerNo: '5454', quantity: 48},
  {bolNo: '013', facilityId: '4552', trailerNo: '4545', quantity: 50},
  {bolNo: '014', facilityId: '2457', trailerNo: '6586', quantity: 70},
  {bolNo: '015', facilityId: '45785', trailerNo: '9867', quantity: 60},
  {bolNo: '016', facilityId: '5475', trailerNo: '1254', quantity: 72},
  {bolNo: '017', facilityId: '2474', trailerNo: '3541', quantity: 52},
  {bolNo: '018', facilityId: '2452', trailerNo: '4587', quantity: 65},
  {bolNo: '019', facilityId: '2441', trailerNo: '1254', quantity: 85}
];
