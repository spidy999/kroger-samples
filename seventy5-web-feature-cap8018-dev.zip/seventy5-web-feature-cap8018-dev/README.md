seventy5
======

Purpose
-----------------
TODO

Environment/Build
-----------------

This application contains a [server](seventy5-server/README.md) and a [client](seventy5-client/README.md)

You must install [node](https://nodejs.org/) 

In order to run the build you will need to deal with the proxy issues by running `env.sh`

This only affects the current `git bash` window and must be repeated for each new session.