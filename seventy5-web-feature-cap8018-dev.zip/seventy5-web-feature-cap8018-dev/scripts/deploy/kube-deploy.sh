#!/bin/bash

APP_NAME="$1"
ENV_NAME="$2"
ENV_LOC="$3"
ENV_DOMAIN="$4"
APP_TAG="$5"
DOCKER_REPO="$6"
ISILON_PASSWORD="$7"
SENSOR_DB_PASSWORD="$8"
SVNFIV_ENCRYPTIONKEY="$9"
KCMS_PASSWORD="${10}"
AUTH_CLIENTSECRET="${11}"

SERVICE_NAME="${APP_NAME}-${ENV_NAME}"
SERVICE_HOST="seventy5-server-dev.satshared.rch-eus2-axnonprod.azure.kroger.com"
#seventy5-server-dev.satshared.rch-eus2-axnonprod.azure.kroger.com
# INGRESS_SECRET="star-satapps-${ENV_LOC}${ENV_DOMAIN}-satapps-${ENV_NAME}"
INGRESS_SECRET="seventy5-server-certs"
#seventy5-${ENV_NAME}-${ENV_LOC}-certs
#"seventy5-server-certs"

echo "Name: ${APP_NAME}, Tag: ${APP_TAG}, Env: ${ENV_NAME}, Service: ${SERVICE_NAME}, Host: ${SERVICE_HOST}, Ingress: ${INGRESS_SECRET}"

if [[ ${ENV_NAME} == "prod" ]]
then
  VANITY_URL="seventy5.kroger.com"
else
  VANITY_URL="seventy5-serverdev.kroger.com"
  #seventy5-${ENV_NAME}.kroger.com
fi

cat scripts/deploy/kube-manifest.yml |
  sed -e 's|"{{SERVICE_NAME}}"|'${SERVICE_NAME}'|g' |
  sed -e 's|"{{SERVICE_HOST}}"|'${SERVICE_HOST}'|g' |
  sed -e 's|"{{INGRESS_SECRET}}"|'${INGRESS_SECRET}'|g' |
  sed -e 's|{{APP_NAME}}|'${APP_NAME}'|g' |
  sed -e 's|{{APP_TAG}}|'${APP_TAG}'|g' |
  sed -e 's|{{DOCKER_REPO}}|'${DOCKER_REPO}'|g' |
  sed -e 's|{{ENV_NAME}}|'${ENV_NAME}'|g' |
  sed -e 's|{{ISILON_PASSWORD}}|'${ISILON_PASSWORD}'|g' |
  sed -e 's|{{SENSOR_DB_PASSWORD}}|'${SENSOR_DB_PASSWORD}'|g' |
  sed -e 's|{{SVNFIV_ENCRYPTIONKEY}}|'${SVNFIV_ENCRYPTIONKEY}'|g' |
  sed -e 's|{{KCMS_PASSWORD}}|'${KCMS_PASSWORD}'|g' |
  sed -e 's|{{AUTH_CLIENTSECRET}}|'${AUTH_CLIENTSECRET}'|g' |
  sed -e 's|{{VANITY_URL}}|'${VANITY_URL}'|g' |
  kubectl --kubeconfig /tmp/config apply -f - --namespace seventy5-"${ENV_NAME}"